<?php

$lang['profiler_benchmarks']  = "BENCHMARKS";
$lang['profiler_queries']   = "QUERIES";
$lang['profiler_post_data']   = "POST DATA";
$lang['profiler_no_db']     = "Database driver is not currently loaded";
$lang['profiler_no_queries']  = "No queries were run";
$lang['profiler_no_post']   = "No POST data exists";

?>
