<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-26 17:20:48 --> Severity: Notice  --> Undefined property: stdClass::$code /home/Adalid/Code/clinic/app/controllers/admin/med_schedule.php 624
ERROR - 2009-08-26 17:20:48 --> Severity: Notice  --> Undefined property: stdClass::$code /home/Adalid/Code/clinic/app/controllers/admin/med_schedule.php 624
ERROR - 2009-08-26 17:20:48 --> Severity: Notice  --> Undefined property: stdClass::$code /home/Adalid/Code/clinic/app/controllers/admin/med_schedule.php 624
ERROR - 2009-08-26 17:20:48 --> Severity: Notice  --> Undefined property: stdClass::$code /home/Adalid/Code/clinic/app/controllers/admin/med_schedule.php 624
ERROR - 2009-08-26 17:20:48 --> Severity: Notice  --> Undefined property: stdClass::$code /home/Adalid/Code/clinic/app/controllers/admin/med_schedule.php 624
ERROR - 2009-08-26 17:20:48 --> Severity: Notice  --> Undefined property: stdClass::$code /home/Adalid/Code/clinic/app/controllers/admin/med_schedule.php 624
ERROR - 2009-08-26 17:20:48 --> Severity: Notice  --> Undefined property: stdClass::$code /home/Adalid/Code/clinic/app/controllers/admin/med_schedule.php 624
