<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-05-24 20:02:51 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/login_helper.php 181
ERROR - 2009-05-24 20:03:03 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/login_helper.php 181
ERROR - 2009-05-24 20:03:05 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/login_helper.php 181
ERROR - 2009-05-24 20:03:24 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/login_helper.php 181
ERROR - 2009-05-24 20:03:28 --> Severity: Notice  --> Undefined property: Principal::$db /home/Adalid/Code/clinic/app/controllers/principal.php 70
ERROR - 2009-05-24 20:03:29 --> Severity: Notice  --> Undefined property: Principal::$db /home/Adalid/Code/clinic/app/controllers/principal.php 70
