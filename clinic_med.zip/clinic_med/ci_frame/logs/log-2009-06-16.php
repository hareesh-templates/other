<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-06-16 15:55:29 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Unknown MySQL server host 'localhsot' (1) /home/Adalid/Code/clinic/app/controllers/install.php 89
ERROR - 2009-06-16 15:55:39 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Unknown MySQL server host 'localhsot' (1) /home/Adalid/Code/clinic/app/controllers/install.php 89
ERROR - 2009-06-16 15:55:43 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Unknown MySQL server host 'localhsot' (1) /home/Adalid/Code/clinic/app/controllers/install.php 89
ERROR - 2009-06-16 15:55:48 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Unknown MySQL server host 'localhsot' (1) /home/Adalid/Code/clinic/app/controllers/install.php 89
ERROR - 2009-06-16 15:56:10 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Unknown MySQL server host 'localhsot' (1) /home/Adalid/Code/clinic/app/controllers/install.php 89
ERROR - 2009-06-16 15:56:27 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Unknown MySQL server host 'localhsot' (1) /home/Adalid/Code/clinic/app/controllers/install.php 89
