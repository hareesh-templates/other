<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-05-23 16:52:31 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/theme_helper.php 181
ERROR - 2009-05-23 16:52:33 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/theme_helper.php 181
ERROR - 2009-05-23 17:34:43 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/theme_helper.php 181
ERROR - 2009-05-23 17:44:20 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/theme_helper.php 181
ERROR - 2009-05-23 17:44:22 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/theme_helper.php 181
ERROR - 2009-05-23 17:44:59 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/theme_helper.php 181
ERROR - 2009-05-23 17:45:00 --> Severity: Notice  --> Undefined property: Principal::$session /home/Adalid/Code/clinic/app/helpers/theme_helper.php 181
ERROR - 2009-05-23 17:45:20 --> Severity: Notice  --> Undefined variable: java /home/Adalid/Code/clinic/app/views/default.html 12
