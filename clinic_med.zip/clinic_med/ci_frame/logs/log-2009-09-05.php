<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-09-05 14:17:51 --> Unable to select database: borrar
