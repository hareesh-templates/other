<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-05-25 20:38:51 --> 404 Page Not Found --> 
ERROR - 2009-05-25 21:06:39 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Unknown MySQL server host 'localhosto' (1) /home/Adalid/Code/clinic/app/controllers/principal.php 181
ERROR - 2009-05-25 21:06:39 --> Severity: Warning  --> mysql_query(): supplied argument is not a valid MySQL-Link resource /home/Adalid/Code/clinic/app/controllers/principal.php 196
ERROR - 2009-05-25 21:06:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/Adalid/Code/clinic/ci_frame/libraries/Exceptions.php:164) /home/Adalid/Code/clinic/ci_frame/helpers/cookie_helper.php 90
ERROR - 2009-05-25 21:09:40 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Unknown MySQL server host 'localhosto' (1) /home/Adalid/Code/clinic/app/controllers/principal.php 181
