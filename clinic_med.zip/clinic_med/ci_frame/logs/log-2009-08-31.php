<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-31 14:29:09 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'clinic'@'localhost' (using password: YES) /home/Adalid/Code/clinic/ci_frame/database/drivers/mysql/mysql_driver.php 61
ERROR - 2009-08-31 14:29:09 --> Unable to connect to the database
ERROR - 2009-08-31 21:24:11 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'clinic'@'localhost' (using password: YES) /home/Adalid/Code/clinic/ci_frame/database/drivers/mysql/mysql_driver.php 61
ERROR - 2009-08-31 21:24:11 --> Unable to connect to the database
ERROR - 2009-08-31 21:24:14 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'clinic'@'localhost' (using password: YES) /home/Adalid/Code/clinic/ci_frame/database/drivers/mysql/mysql_driver.php 61
ERROR - 2009-08-31 21:24:14 --> Unable to connect to the database
