<?php

/**
 * @file /controllers/principal.php
 * @brief Default file to load when no one is specified
 * 
 * @class Principal
 * @brief Default class to load when no one is specified
 *
 * @details 
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class Principal extends Controller {

  var $module_url = 'principal';

  /**
   * Constructor
   *
   * Loads the parent controller
   *
   * @public
   */
  function Principal() {
    parent::Controller();
  }

// ------------------------------------------------------------------------

  /**
   * Default method to load when no one is specified
   *
   * This function generates a themed view with content (home page articles), blocks (left and right)
   * and send the result to browser.
   * Cached page will be sent instead if it exits and cache_option is enabled
   *
   * @public
   * 
   * @return  nothing
   */
  function index() {

    $this->load->helper(array('url', 'date', 'cookie'));

    if ( ! isset($this->db)) {
      redirect('install');
      return;
    }

    $this->lang->load('admin');

    if ($this->config->item('cacheenabled')) {
      $this->output->cache($this->config->item('cachetime'));
    }

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $msg;

    $where = 'enabled=1 && homepage=1 && (lang="'.$this->config->item('language').'" || lang="")';
    $this->db->where($where);
    $this->db->orderby("created, title");
    $query = $this->db->get('content');
    foreach ($query->result() as $row) {
      if ($content != '') $content .= '<br /><br />';

      $row->content = str_replace('{base_url}', $this->config->item('base_url'), $row->content);
      $row->content = str_replace('{site_url}', $this->config->site_url(), $row->content);

      $content .= '<h2>'.$row->title.'</h2>'
      .$row->content.'<br />';
    }

    $data = default_Vars_Content();
    //$data['title'] .= ' - ' . $this->lang->line('admin_title');

    make_blocks();

    $data['content'] = theme($this->block_side1, $content, $this->block_side2);

    $this->load->view($this->config->item('theme'), $data);

  }

// ------------------------------------------------------------------------

  /**
   * Shows a themed access denied message
   *
   * Generates a themed view with access denied message, blocks (left and right)
   * and send the result to browser.
   * Also shows any message stored in msg cookie
   *
   * @public
   * 
   * @return  nothing
   */
  function accessdenied() {

    if ($this->config->item('cacheenabled')) {
      $this->output->cache($this->config->item('cachetime'));
    }

    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));


    $msg_cookie = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $msg = msgErr('', $this->lang->line('main_moduleaccessdenied') . '<br />' . $this->lang->line('main_goback'));

    make_blocks();
    $data = default_Vars_Content();
    //$data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->block_side1, $msg_cookie.$msg, $this->block_side2);

    $this->load->view($this->config->item('theme'), $data);

  }

// ------------------------------------------------------------------------

  /**
   * Shows an access denied message without theme
   *
   * Generates an access denied message and send the result to browser.
   * Also show any message stored in msg cookie
   *
   * @public
   * 
   * @return  nothing
   */
  function accessdenied2() {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    $msg_cookie = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $msg = msgErr('', $this->lang->line('main_moduleaccessdenied'));
    echo $msg_cookie.$msg;
  }

}
?>
