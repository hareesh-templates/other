<?php

/**
 * @file install.php
 * @brief File to install Clinic_MED in an easy way
 * 
 * @class Install
 * @brief Class to install Clinic_MED in an easy way
 *
 * @details this class creates the DB structure, setup the config files and creates an usefull Clinic Med Portal ready to use
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class Install extends Controller {

  var $module_url = 'install';

  /**
   * Constructor
   *
   * Loads the parent controller
   *
   * @public
   */
  function Install() {
    parent::Controller();
  }

// ------------------------------------------------------------------------

  /**
   * Method to install Clinic MED
   *
   * Generates a form view to install Clinic MED and send the result to browser.
   * It will ask for database configuration (user, password and database)
   * and will create the configuration files.
   *
   * @public
   * @return  nothing
   */
  function index () {

    //erm. is Clinic_MED already installed ?
    if (isset($this->db)) {
      $this->load->helper(array('url', 'cookie'));
      //erm set cookie message
      redirect();
      return;
    }

    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie', 'date'));

    $msg = '';
    $now = now();

    $validate   = false;
    $action     = 'add';
    $vars       = array();
    $form = $this->_form ($action, $this->module_url, $vars, $validate);

    if ( ! $validate) {

      $this->_add_showform ($form);

    } else {

      $rules = array();
      $showformagain = false;

      //FIRST. try to connect to the database, else show the form again
      //----------------------------------------------------------------------
      $dbid = @mysql_connect ($this->validation->Host, $this->validation->Username, $this->validation->Password);
      if ( ! $dbid ) {
        $validate   = false;
        $rules['faildb']  = "callback__faildb";
      } else {
        $seldb = @mysql_select_db  ( $this->validation->Database, $dbid );
        if ( ! $seldb ) {
          $validate   = false;
          $rules['faildb']  = "callback__faildb";
        }
      }

      if ($validate) {
        //SECOND. try to get tables to see if already tables exists into DB
        //----------------------------------------------------------------------
        $query = sprintf('SHOW TABLES FROM %s LIKE "%s_%%"', $this->validation->Database, $this->validation->Code);
        $result = mysql_query($query, $dbid);

        if ($result === FALSE) {
          $validate   = false;
          $rules['faildb']  = "callback__faildb";
        } else {
          if (mysql_num_rows ($result)) {
            $validate   = false;
            $rules['failtables']  = "callback__failtables";
          }
        }
      }

      $path = pathinfo(FCPATH, PATHINFO_DIRNAME) . '/app/config/';

      //==> create the tables into the database selected
      //----------------------------------------------------------------------
      if ($validate) {
        $sqlfile = $path . 'clinic_MED.sql';
        $handle = fopen($sqlfile, "r");
        if ( ! $handle) {
          $msg = base64_encode(msgErr('', sprintf($this->lang->line('install_unableimportsql'), $sqlfile)));
          $validate   = false;
          $rules['config_db']  = "callback__import_db";
        } else {
          $query = "";
          while(!feof($handle)) {
            $sql_line = fgets($handle);
            if (trim($sql_line) != "" && strpos($sql_line, "--") === false) {
              $query .= str_replace('_prefix_', $this->validation->Code.'_', $sql_line);
              if (preg_match("/;[\040]*\$/", $sql_line)) {
                if ( mysql_query($query, $dbid) === FALSE) {
                  $msg = base64_encode(msgErr('', sprintf($this->lang->line('install_importsqldberr'), $sqlfile, mysql_error($dbid) .'<br />'. $query )));
                  $validate   = false;
                  $rules['config_db']  = "callback__config_import";
                  break;
                }
                $query = "";
              }
            }
          }
          $query = sprintf(
            'INSERT INTO %s_admins (code, name, password, createddate, superuser)
            VALUES ("admin", "Administrator", "%s", "%s", 1);',
            $this->validation->Code,
            'e10adc3949ba59abbe56e057f20f883e',
            $now
          );
          mysql_query($query, $dbid);
        }
        mysql_close($dbid);
      }

      //==> create config files
      //----------------------------------------------------------------------
      if ($validate) {

        $this->load->helper('file');

        $dbfile =
'<?php  if (!defined("BASEPATH")) exit("No direct script access allowed");
/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your database.
|
| For complete instructions please consult the "Database Connection"
| page of the User Guide.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|  [\'hostname\'] The hostname of your database server.
|  [\'username\'] The username used to connect to the database
|  [\'password\'] The password used to connect to the database
|  [\'database\'] The name of the database you want to connect to
|  [\'dbdriver\'] The database type. ie: mysql.  Currently supported:
         mysql, mysqli, postgre, odbc, mssql
|  [\'dbprefix\'] You can add an optional prefix, which will be added
|         to the table name when using the  Active Record class
|  [\'pconnect\'] TRUE/FALSE - Whether to use a persistent connection
|  [\'db_debug\'] TRUE/FALSE - Whether database errors should be displayed.
|  [\'active_r\'] TRUE/FALSE - Whether to load the active record class
|  [\'cache_on\'] TRUE/FALSE - Enables/disables query caching
|  [\'cachedir\'] The path to the folder where cache files should be stored
|  [\'char_set\'] The character set used in communicating with the database
|  [\'dbcollat\'] The character collation used in communicating with the database
|
| The $active_group variable lets you choose which connection group to
| make active.  By default there is only one group (the "default" group).
|
*/

$active_group = "default";

$db["default"]["hostname"] = "'.$this->validation->Host.'";
$db["default"]["username"] = "'.$this->validation->Username.'";
$db["default"]["password"] = "'.$this->validation->Password.'";
$db["default"]["database"] = "'.$this->validation->Database.'";
$db["default"]["dbdriver"] = "mysql";
$db["default"]["dbprefix"] = "'.$this->validation->Code.'_";
$db["default"]["active_r"] = TRUE;
$db["default"]["pconnect"] = TRUE;
$db["default"]["db_debug"] = TRUE;
$db["default"]["cache_on"] = FALSE;
$db["default"]["cachedir"] = "";
?>';

        $filepath = $path . 'database.php';
        if ( ! write_file($filepath, $dbfile)) {
          $msg = base64_encode(msgErr('', sprintf($this->lang->line('install_configdberr'), $filepath)));
          $validate   = false;
          $rules['config_db']  = "callback__config_db";
        }
      }

      //==> create config files
      //----------------------------------------------------------------------
      if ($validate) {

        $this->load->helper('file');

        $dbfile =
'<?php  if (!defined(\'BASEPATH\')) exit(\'No direct script access allowed\');
/*
| -------------------------------------------------------------------
| AUTO-LOADER
| -------------------------------------------------------------------
| This file specifies which systems should be loaded by default.
|
| In order to keep the framework as light-weight as possible only the
| absolute minimal resources are loaded by default. For example,
| the database is not connected to automatically since no assumption
| is made regarding whether you intend to use it.  This file lets
| you globally define which systems you would like loaded with every
| request.
|
| -------------------------------------------------------------------
| Instructions
| -------------------------------------------------------------------
|
| These are the things you can load automatically:
|
| 1. Libraries
| 2. Helper files
| 3. Plugins
| 5. Custom config files
|
*/

$autoload[\'language\'] = array();

/*
| -------------------------------------------------------------------
|  Auto-load Libraries
| -------------------------------------------------------------------
| These are the classes located in the system/libraries folder
| or in your system/application/libraries folder.
|
| Prototype:
|
|  $autoload[\'libraries\'] = array(\'database\', \'session\', \'xmlrpc\');
*/

$autoload[\'libraries\'] = array(\'database\',\'SettingsfromDB\',\'session\',\'SettingsfromCookie\');

/*
| -------------------------------------------------------------------
|  Auto-load Helper Files
| -------------------------------------------------------------------
| Prototype:
|
|  $autoload[\'helper\'] = array(\'url\', \'file\');
*/

$autoload[\'helper\'] = array(\'theme\',\'login\');

/*
| -------------------------------------------------------------------
|  Auto-load Plugins
| -------------------------------------------------------------------
| Prototype:
|
|  $autoload[\'plugin\'] = array(\'captcha\', \'js_calendar\');
*/

$autoload[\'plugin\'] = array();

/*
| -------------------------------------------------------------------
|  Auto-load Config files
| -------------------------------------------------------------------
| Prototype:
|
|  $autoload[\'config\'] = array(\'config1\', \'config2\');
|
| NOTE: This item is intended for use ONLY if you have created custom
| config files.  Otherwise, leave it blank.
|
*/

$autoload[\'config\'] = array();

/*
| -------------------------------------------------------------------
|  Auto-load Core Libraries
| -------------------------------------------------------------------
|
| DEPRECATED:  Use $autoload[\'libraries\'] above instead.
|
*/
// $autoload[\'core\'] = array();

?>';

        $filepath = $path . 'autoload.php';
        if ( ! write_file($filepath, $dbfile)) {
          $msg = base64_encode(msgErr('', sprintf($this->lang->line('install_configloaderr'), $filepath)));
          $validate   = false;
          $rules['config_db']  = "callback__config_load";
        }
      }

      set_cookie('msg', $msg, 0);

      if ( ! $validate) {
        $this->validation->set_rules($rules);
        $form = $this->_form ($action, $this->module_url, $vars, $validate);
        $this->_add_showform ($form, $msg);
        return;
      }
      else {
        $path_cfg = pathinfo(FCPATH, PATHINFO_DIRNAME) . '/app/config/';
        $file_sql = pathinfo(FCPATH, PATHINFO_DIRNAME) . '/app/config/clinic_MED.sql';
        $file_ins = pathinfo(FCPATH, PATHINFO_DIRNAME) . '/app/controllers/install.php';
        $msg = base64_encode(msgSuccess('', sprintf($this->lang->line('install_success'), $path_cfg, $file_sql, $file_ins)));
        set_cookie('msg', $msg, 0);
        redirect();
        return;
      }

    }
  }

// ------------------------------------------------------------------------

  /**
   * Installation process
   *
   * Generates the themed view to install Clinic MED and send the result to browser.
   * Also show any message stored in msg cookie
   *
   * @private
   * 
   * @param form string the installation form in html
   * @param msg_err string a message error to be displayed when install fails
   * 
   * @return  nothing
   */
  function _add_showform ($form, $msg_err = '') {
    $content = '';

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content .= base64_decode($msg_err);
    $content .= $msg;
    $content .= $form;

    $data = array();

    $data['title']  = $this->config->item('title');
    $data['title'] .= ' - ' . $this->lang->line('install_title');

    $cssscr = $this->config->item('base_url') . 'img/theme_default/style.css';

    $data['meta'] = '
    <meta content="text/html; charset=UTF8" http-equiv="content-type" >
    <meta content="Adalid-Soft" name="author" >
    <link rel="shortcut icon" href="'.$this->config->item('base_url').'img/favicon.ico" type="image/x-icon" >
    <meta name="robots" content="all" >
    <meta name="description" content="Description here" >
    <link rel="stylesheet" href="'.$cssscr.'" type="text/css">
    ';

    $data['java'] = '';
    $data['navbar'] = '';
    $data['banner'] = '';
    $data['content'] = '';

    $data['base_url'] = $this->config->item('base_url');

    $data['footer1'] = '';
    $data['footer2'] = '';
    $data['header1'] = '';
    
    $data['content'] = $content;

    $this->load->view($this->config->item('theme'), $data);
  }

// ------------------------------------------------------------------------

  /**
   * Installation Form
   *
   * Generates the form to install Clinic MED and return the form in html as string
   *
   * @private
   * 
   * @param action string options to handle the form (at this moment just "add")
   * @param url_action string the url for form action
   * @param vars array array with variables to populate the form's controls
   * @param validate string it will be set to true if rules are valid, otherwise false
   *
   * @return  string
   */
  function _form ($action, $url_action, $vars, &$validate) {

    $this->validation->set_error_delimiters('','<br />');

    $rules['Code']  = "trim|required|alpha_dash";

    if ($action == 'add') {
      $rules['Code'] .= "|callback__requirements_check";
      $rules['Database']  = "trim|required|alpha_dash";
      $rules['Host']  = "trim|required";
      $rules['Username']  = "trim|required|alpha_dash";
      $rules['Password']  = "trim|required|alpha_dash";
    }

    $this->validation->set_rules($rules);

    $fields['faildb'] = '';
    $fields['failtables'] = '';
    $fields['import_db'] = '';
    $fields['config_db'] = '';
    $fields['config_load'] = '';
    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Database'] = $this->lang->line('install_database');
    $fields['Host'] = $this->lang->line('install_host');
    $fields['Username'] = $this->lang->line('install_username');
    $fields['Password'] = $this->lang->line('install_password');
    $this->validation->set_fields($fields);

    $form = '';

    if ( ! $validate = $this->validation->run()) {

      foreach ($fields as $key => $val) {
        if ( isset($vars[$key])) $this->validation->$key = $vars[$key];
      }

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";
      $form .= $err;

      $form .= sprintf('<br /><div class="msg_1">%s</div><br />', nl2br($this->lang->line('install_notes')));

      $key   = 'formInstall';
      $data  = array('id' => $key, 'name' => $key);
      $hidden = array ('faildb'=>0, 'failtables'=>0, 'import_db'=>0, 'config_db'=>0, 'config_load'=>0);
      $form .= form_open($url_action, $data, $hidden);

      $key = 'Code';
      if ($action == 'add') {
        $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'15');
        $this->table->add_row($this->lang->line('admin_code'), form_input($data));
      }
      if ($action == 'edit') {
        $data = sprintf('<b>%s</b>', $this->validation->$key);
        $this->table->add_row($this->lang->line('admin_code'), $data.form_hidden($key, $this->validation->$key));
      }

      if ($action == 'add') {

        $key = 'Database';
        $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'15');
        $this->table->add_row($this->lang->line('install_database'), form_input($data));

        $key = 'Host';
        $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'15');
        $this->table->add_row($this->lang->line('install_host'), form_input($data));

        $key = 'Username';
        $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'15');
        $this->table->add_row($this->lang->line('install_username'), form_input($data));

        $key = 'Password';
        $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'15');
        $this->table->add_row($this->lang->line('install_password'), form_password($data));

      }

      $key = 'submit';
      if ($action == 'add') $this->table->add_row(form_submit($key, $this->lang->line('admin_install')));
      if ($action == 'edit') $this->table->add_row(form_submit($key, $this->lang->line('admin_savechanges')));

      $tmpl = array ('table_open'  => '<table border=0 cellpadding=2 cellspacing=2 >');
      $this->table->set_template($tmpl);
      $form .= $this->table->generate();

      $form .= form_close();

    }

    return $form;
  }

// ------------------------------------------------------------------------

  /**
   * Installation Form validator
   *
   * Makes several tests: the code is unique, the target directory is writeable and no
   * file nor directory exists with "code" name, asks for php5 (oop), looks if zip extension is loaded,
   * test if the zipped file is readeable, looks if the SQL file exists and is readeable
   *
   * If all test are passed return TRUE, otherwise FALSE
   *
   * @private
   * 
   * @param str string the code to test
   *
   * @return  boolean
   */
  function _requirements_check($str) {

  //erm. test if the config directory is writeable
  //--------------------------------------------------------------------------------------------
    $path = pathinfo(FCPATH, PATHINFO_DIRNAME) . '/app/config/';
    //echo $path;
    if ( ! is_writeable($path)) {
      $this->validation->set_message('_requirements_check', sprintf($this->lang->line('install_nowriteable'), $path));
      return FALSE;
    }

  //erm. test if the SQL file exists
  //--------------------------------------------------------------------------------------------
    $sqlfile = $path . 'clinic_MED.sql';
    if ( ! is_file ($sqlfile) ) {
      $this->validation->set_message('_requirements_check', sprintf($this->lang->line('install_sqlnotexist'), $sqlfile));
      return FALSE;
    }

  //erm. test if the SQL file is readable
  //--------------------------------------------------------------------------------------------
    if ( ! is_readable ($sqlfile)) {
      $this->validation->set_message('_requirements_check', sprintf($this->lang->line('install_sqlnotread'), $sqlfile));
      return FALSE;
    }

  //erm. test if the database config file is writeable
  //--------------------------------------------------------------------------------------------
    $cfgfile = $path . 'database.php';
    if ( is_file ($cfgfile) && ! is_link($sqlfile) && ! is_writable ($cfgfile)) {
      $this->validation->set_message('_requirements_check', sprintf($this->lang->line('install_configdberr'), $cfgfile));
      return FALSE;
    }

  //erm. test if the autoload config file is writeable
  //--------------------------------------------------------------------------------------------
    $cfgfile = $path . 'autoload.php';
    if ( is_file ($cfgfile) && ! is_link($sqlfile) && ! is_writable ($cfgfile)) {
      $this->validation->set_message('_requirements_check', sprintf($this->lang->line('install_configloaderr'), $cfgfile));
      return FALSE;
    }

  //erm. test if the captcha directory is writeable
  //--------------------------------------------------------------------------------------------
    $captcha = pathinfo(FCPATH, PATHINFO_DIRNAME) . '/captcha';
    if ( ! is_writable ($captcha)) {
      $this->validation->set_message('_requirements_check', sprintf($this->lang->line('install_captcha'), $captcha));
      return FALSE;
    }    

  //erm. test if the logs directory is writeable
  //--------------------------------------------------------------------------------------------
    $logs = BASEPATH . 'logs';
    if ( ! is_writable ($logs)) {
      $this->validation->set_message('_requirements_check', sprintf($this->lang->line('install_logs'), $logs));
      return FALSE;
    }    

    return TRUE;
  }

// ------------------------------------------------------------------------

  /**
   * Installation Form validator
   *
   * Just to handle when the database conection fails because vars entered by user.
   * Intented to show again the form and ask for the right values:
   * user, password, database and host
   *
   * Always return FALSE
   *
   * @private
   * 
   * @param str string dummy, enter anything or empty better!
   *
   * @return  boolean
   */
  function _faildb($str) {
    $this->validation->set_message('_faildb', $this->lang->line('install_unabletousedb'));
    return FALSE;
  }

  /**
   * Installation Form validator
   *
   * Just to handle when the database code (table prefix) already exists.
   * Intented to show again the form and ask for the right values:
   * code (table prefix)
   *
   * Always return FALSE
   *
   * @private
   * 
   * @param str string dummy, enter anything or empty better!
   *
   * @return  boolean
   */
  function _failtables($str) {
    $this->validation->set_message('_failtables', $this->lang->line('install_err_tablesexists'));
    return FALSE;
  }


  /**
   * Installation Form validator
   *
   * Just to handle when reading SQL file fail.
   * Intented to show again the form and ask for the right values:
   *
   * Always return FALSE
   *
   * @private
   * 
   * @param str string dummy, enter anything or empty better!
   *
   * @return  boolean
   */
  function _config_import ($str) {
    $this->validation->set_message('_config_import', $this->lang->line('install_config_err'));
    return FALSE;
  }

  /**
   * Installation Form validator
   *
   * Just to handle when creating config database fails.
   * Intented to show again the form and ask for the right values:
   *
   * Always return FALSE
   *
   * @private
   * 
   * @param str string dummy, enter anything or empty better!
   *
   * @return  boolean
   */
  function _config_db ($str) {
    $this->validation->set_message('_config_db', $this->lang->line('install_config_err'));
    return FALSE;
  }

  /**
   * Installation Form validator
   *
   * Just to handle when creating config autoload fails.
   * Intented to show again the form and ask for the right values:
   *
   * Always return FALSE
   *
   * @private
   * 
   * @param str string dummy, enter anything or empty better!
   *
   * @return  boolean
   */
  function _config_load ($str) {
    $this->validation->set_message('_config_load', $this->lang->line('install_config_err'));
    return FALSE;
  }

}
?>
