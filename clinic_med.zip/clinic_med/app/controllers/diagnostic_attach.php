<?php

/**
 * @file diagnostic_attach.php
 * @brief File to manage diagnostic attachments
 * 
 * @class Diagnostic_attach
 * @brief Class to manage diagnostic attachments
 *
 * @details appointment_attach are files added by physicians. Examples: movies, sounds, images, documents, etc.  Configure the extensions to handle into app/config/Upload.php
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class Diagnostic_attach extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "diagnostic_attach";

  /**
   * the title for this controller
   */ 
  var $module_name = "Diagnostic Attach";

  /**
   * the database table related to this controller
   */ 
  var $dbtablename = "med_diagnostic";

  /**
   * the number of items to show in each page
   */ 
  var $itemxpage   = 5;

  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Diagnostic_attach () {
    parent::Controller();

    if (!is_module(str_replace('.php', '', pathinfo(__FILE__, PATHINFO_BASENAME)))) {
      $this->load->helper('url');
      redirect('principal/accessdenied');
      return;
    }
  }

  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   * @param moreitems array aditional items to include in the submenu
   *
   * @return string
   */
  function _thissubmenu($title, $moreitems='') {

    $this->load->helper(array('url'));

    $items = array();
    //$items[] = anchor($this->module_url, $this->lang->line('diagnostic_appoinmnets'));

    if (is_array($moreitems)) {
      $items = array_merge($items, $moreitems);
    }

    return navbarsubmenu($title, $items, 'attachment.png');
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index () {
    $this->load->helper(array('url'));
    redirect();
  }


  /**
   * send to browser a downloable file stored in the database
   *
   * @public
   *
   * @return nothing
   */
  function download() {

    $this->lang->load('admin');
    $this->lang->load('med_common');

    $this->load->helper(array('url', 'cookie'));

//erm sino esta el parametro redirigir hacia index
//------------------------------------------------------------------------------
    $redirect = $this->module_url;

    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ( ! $code) {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }

    $this->load->helper('download');

//erm cargar la informacion desde la base de datos
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->select('attach_name, attach_size, attach_mime, attach_file');
    $this->db->where('id', $code);
    $this->db->where('is_attach', 1);
    $query = $this->db->get('med_diagnostic');

    if ($query->num_rows() > 0) {

      $row = $query->row();
      force_download($row->attach_name, $row->attach_file);

    } else {

      $msg = base64_encode(msgWarning('', $this->lang->line('diagnostic_attachnotfound')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;

    }
  }


  /**
   * returns an array with the information of the appointment
   *
   * @private
   * 
   * @param code string the code ot he appointment to get
   *
   * @return array
   */
  function _get_appointment ($code) {

    static $row = '';
    if ($row != '') {
      return $row;
    }

//erm get appointment details from DB
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->select(sprintf(
      'a.*, b.name as physician, c.name as patient, d.name as speciality
      FROM %smed_appointment as a
      LEFT JOIN %susers as b ON a.physician_code=b.code && b.is_physician=1
      LEFT JOIN %smed_patient as c ON a.patient_code=c.code
      LEFT JOIN %smed_specialities as d ON a.speciality_code=d.code
      ',
      $prefix,
      $prefix,
      $prefix,
      $prefix
    ));
    $this->db->where('a.id', $code);
    $this->db->where('a.status>=', 4);
    $query = $this->db->get();

    if ($query->num_rows() > 0) {

      $row = $query->row_array();

    } else {

      $row = -1;

    }

    return $row;

  }


  /**
   * sends to browser a file form. Also includes a success uploaded file into DB.
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with the code of the appointment
   *
   * @public
   *
   * @return nothing
   */
  function form_file () {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->load->helper(array('url', 'cookie', 'date'));
    $this->lang->load('admin');
    $this->lang->load('med_common');


    $redirect = $this->module_url;
    if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] != '') {
      $tmp = $_SERVER['HTTP_REFERER'];
      $tmp = trim(substr($tmp, strlen($this->config->site_url()), strlen($tmp)));
      if ($redirect != '') $redirect = $tmp;
    }

//erm sino esta el parametro redirigir hacia url de referencia
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }

    $content = '';
    $appointment = '';

    $row = $this->_get_appointment ($code);

    if ( ! is_array($row) ) {

      $msg = base64_encode(msgErr('', $this->lang->line('diagnostic_appoinmnetnofound')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;

    } else {

      $appointment = $this->_format_appointment (
        $row['status'],  $row['id'],  $row['time_from'],
        $row['time_to'],  $row['patient'], $row['patient_code'], $row['speciality'],  $row['notes'],
        $row['physician']
      );

    }


//erm show controls to add the diagnostic
//------------------------------------------------------------------------------
    $vars = array(
      'action'=>'add',
      'directo'=>$this->module_url.'/form_file/'.$code
    );

    $vars['code'] = $code;
    $vars['physician'] = $row['physician_code'];
    $vars['patient'] = $row['patient_code'];
    $vars['speciality'] = $row['speciality_code'];
    $vars['redirect'] = $redirect;

    if (isset($_FILES['attach_file'])) {
      $_POST['attach_file'] = $_FILES["attach_file"]["name"];
    }

    $validation = FALSE;
    $form = $this->_form_file ($vars, $validation);

    if ( $validation != FALSE) {

      $this->load->library('upload');

      $field_name = "attach_file";
      $binary_file = '';

      if ( ! $this->upload->do_upload($field_name, $binary_file)) {

        unset($_POST['attach_file']);

        $form =
        msgErr('', $this->upload->display_errors('', '<br />'))
        .$this->_form_file ($vars, $validation);

      } else {

        $file_data = $this->upload->data();

        $data = array(
        'appointment_id' => $this->validation->code,
        'physician_code' => $this->validation->physician,
        'patient_code' => $this->validation->patient,
        'speciality_code' => $this->validation->speciality,
        'datecreated' => now(),
        'is_attach' => 1,
        'attach_name' => $file_data['file_name'],
        'attach_description' => $this->validation->textarea,
        'attach_mime' => $file_data['file_type'],
        'attach_size' => $file_data['file_size'] . ' KB',
        'attach_file' => $binary_file
        );
        $this->db->insert($this->dbtablename, $data);

        if ($this->input->post('redirect') !== FALSE)
          $redirect = base64_decode($this->input->post('redirect'));

        redirect($redirect);
        return;
      }

    }

//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content =
    $msg
    .$this->_thissubmenu($this->lang->line('diagnostic_attach')).'<br />'
    .$form
    .$appointment;

    make_blocks('1');
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('diagnostic_attach');
    $data['content'] = theme($this->block_side1, $content);

    $this->load->view($this->config->item('theme'), $data);


  }

  /**
   * create and return a html form to upload a file. Also makes the validation process.
   *
   * @private
   * 
   * @param vars array An array with the form values
   * @param validation boolean This method sets it to true if validation success, else set it to false
   *
   * @return string
   */
  function _form_file ($vars, &$validation) {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('form', 'url'));
    $this->load->library(array('validation', 'table'));

    $this->table->clear();

    $this->validation->set_error_delimiters('','<br />');
    $rules['attach_file']  = "trim|required|xss_clean";
    $rules['physician']  = "trim|required|xss_clean";
    $rules['patient']  = "trim|required|xss_clean";
    $rules['speciality']  = "trim|required|xss_clean";
    $rules['code']  = "trim|required|xss_clean";
    $rules['textarea']  = "trim|xss_clean";

    $this->validation->set_rules($rules);

    $fields['attach_file'] = $this->lang->line('diagnostic_attach');
    $fields['physician'] = $this->lang->line('diagnostic_physician');
    $fields['patient'] = $this->lang->line('diagnostic_patient');
    $fields['speciality'] = $this->lang->line('diagnostic_speciality');
    $fields['code'] = $this->lang->line('diagnostic_appoinmnet');
    $fields['textarea'] = $this->lang->line('diagnostic_attach_desc');
    $this->validation->set_fields($fields);

    $form = "";
    $validation = $this->validation->run();

    if ($validation == FALSE) {

      $this->validation->physician = $vars['physician'];
      $this->validation->patient = $vars['patient'];
      $this->validation->speciality = $vars['speciality'];
      $this->validation->code = $vars['code'];
      $this->validation->redirect = $vars['redirect'];

      if ($this->validation->error_string != "") $form .= msgErr("",$this->validation->error_string);

//erm crear el formulario
//------------------------------------------------------------------------------------------
      $form_tag = 'form_file_';
      $attributes = array('id' => $form_tag, 'name' => $form_tag);

      $form .= form_open_multipart($vars['directo'], $attributes);

      $data = array(
        'name'        => 'attach_file',
        'id'          => 'attach_file',
        'style'       => 'width:95%',
      );

      $this->table->add_row(
        form_upload($data)
        .textArea('textarea', $this->validation->textarea, 'mini', '100px', '100%')
        .form_hidden('physician', $this->validation->physician)
        .form_hidden('patient', $this->validation->patient)
        .form_hidden('speciality', $this->validation->speciality)
        .form_hidden('code', $this->validation->code)
        .form_hidden('redirect', base64_encode($this->validation->redirect))
      );

      $submit = 'form_file_submit';
      $this->table->add_row(
        form_submit($submit, $this->lang->line('diagnostic_attach'))
      );

//erm si se esta creado, crear y cargar el formulario con javascript y ajax
//------------------------------------------------------------------------------------------

      $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=0 style="width:100%">');
      $this->table->set_template($tmpl);
      $form .= $this->table->generate();

      $form .= form_close();

    }

    return $form;

  }


  /**
   * return a formated appointment (style)
   *
   * @private
   *
   * @param status string the status of the appointment
   * @param id int the id of the appointment
   * @param timefrom int the begining time of the appointment
   * @param timeto int the ending time of the appointment
   * @param patient string the name of the patient
   * @param patient_code string the patiend code
   * @param speciality string the speciality for this appointment
   * @param notes string notes for this appointment.
   * @param physician string the physician name
   *
   * @return string
   */  
  function _format_appointment ($status, $id, $timefrom, $timeto, $patient, $patient_code, $speciality, $notes, $physician ) {

    $this->load->helper(array('date','url'));

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('table'));

    $now = gmt_to_local(now(), $this->config->item('timezone'));
    $today = mktime(0,0,0,date('n',$now),date('j',$now),date('Y',$now));
    $tomorrow = mktime(0,0,0,date('n',$now),date('j',$now)+1,date('Y',$now));

    $items = array();

    $class_css = 'schedule_empty';

    if ( ! $status) {
      $class_css = 'schedule_appointment_canceled';
    }

    if ($status == 4) {
      $class_css = 'schedule_free';

      $url = site_url().'/diagnostic/appointment/'.$id;
      $txt = $this->lang->line('diagnostic_handle');
      $items[] = sprintf(
        '%s<br />%s',
        sprintf('<a href="%s">%s</a>', $url, theme_imgtag ('handle.png', $txt, $txt)),
        anchor($url, $txt)
      );

    }

    $url = site_url().'/diagnostic_attach/form_file/'.$id;
    $txt = $this->lang->line('diagnostic_ins_file');
    $items[] = sprintf(
      '%s<br />%s',
      sprintf('<a href="%s">%s</a>', $url, theme_imgtag ('attachment24.png', $txt, $txt)),
      anchor($url, $txt)
    );

    $menu = '';
    if (sizeof($items)) {
      $this->table->clear();
      $menu = $this->table->make_columns($items, sizeof($items));
      $tmpl = array (
      'cell_start'=>'<td align="center" >',
      'cell_alt_start'=>'<td align="center" >'
      );
      $this->table->set_template($tmpl);
      $menu = $this->table->generate($menu);
    }


    $data = '';
    $info = '';

    $info = sprintf(
      '<b>%s - %s</b>
      <div>%s: %s</div>
      <div>%s: %s</div>
      <div>%s: %s</div>
      <i>%s</i>',
      date('h:i a', $timefrom),
      date('h:i a', $timeto),
      $this->lang->line('patient_patient'),
      anchor('history/patient/'.$patient_code, $patient),
      $this->lang->line('diagnostic_speciality'),
      $speciality,
      $this->lang->line('diagnostic_physician'),
      $physician,
      $notes
    );

    $data =
    sprintf(
      '<div id="schedule"><table border=0 class="'.$class_css.'" width="100%%" ><tr>
      <td width="75px"><h3>%s<br/>%s</h3></td>
      <td width="60%%">%s</td>
      <td valign="middle" align="center">%s</td>
      </tr></table></div>',
      date('D j', $timefrom),
      date('M Y', $timefrom),
      $info,
      $menu
    );

    return $data;
  }


  /**
   * sends to browser a list of appoinments
   *
   * @public
   *
   * @return nothing
   */  
  function appointments () {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url', 'cookie', 'date'));
    $this->load->library(array('pagination'));

//erm sino esta el parametro redirigir hacia url de referencia
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect();
      return;
    }

    $year = $this->uri->segment(4, 0);
    $month = $this->uri->segment(5, 0);

//erm creacion de los links
//------------------------------------------------------------------------------
    $uri_segment = 4;

    $config['base_url'] = site_url() . '/' . $this->module_url . '/appointments/' . $code;

    $where = array('a.status >=' => 4, 'a.patient_code' => $code);

    $this->db->select('count(*) as numrows');
    $this->db->from('med_appointment a');
    $this->db->where($where);
    $query = $this->db->get();

    $numitems = 0;
    if ($query->num_rows() > 0) {
      $row = $query->row();
      $numitems = $row->numrows;
    }

    $config['total_rows'] = $numitems;
    $config['per_page'] = $this->itemxpage;
    $config['uri_segment'] = $uri_segment;
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    $config['num_links'] = '4';
    $this->pagination->initialize($config);
    $pagination = $this->pagination->create_links();

    $begin = intval($this->uri->segment($uri_segment, 0));
    if ($begin < 0) $begin = 0;

//erm cargar la informacion desde la base de datos
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->select(sprintf(
      'a.*, b.name as physician, c.name as patient, d.name as speciality
      FROM %smed_appointment as a
      LEFT JOIN %susers as b ON a.physician_code=b.code && b.is_physician=1
      LEFT JOIN %smed_patient as c ON a.patient_code=c.code
      LEFT JOIN %smed_specialities as d ON a.speciality_code=d.code
      ',
      $prefix,
      $prefix,
      $prefix,
      $prefix
    ));
    $this->db->where($where);
    $this->db->orderby('time_from DESC');
    $this->db->limit($this->itemxpage, $begin);
    $query = $this->db->get();

    $lista = '';
    if ($query->num_rows() > 0) {

      foreach ($query->result() as $row) {
        $lista .= $this->_format_appointment (
          $row->status, $row->id, $row->time_from,
          $row->time_to, $row->patient, $row->patient_code, $row->speciality, $row->notes, $row->physician
        );
      }

    } else {
      $lista = $this->lang->line('diagnostic_notapppoinments');
    }

    $now = gmt_to_local(now(), $this->config->item('timezone'));
    $title = date('D d, M Y', $now);
    $appointments = sprintf(
      '<h3>%s: %s</h3><div>%s</div>',
      $this->lang->line('diagnostic_today'),
      $title,
      $lista
    );

//erm recuperar cualquier cookie de mensaje
//------------------------------------------------------------------------------
    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = '';
    $content .= $msg;
    $content .= $this->_thissubmenu($this->lang->line('diagnostic_attach'));
    $content .= $appointments;
    $content .= $pagination;

//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------
    make_blocks();
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('diagnostic_attach');
    $data['content'] = theme($this->block_side1, $content, $this->block_side2);
    $this->load->view($this->config->item('theme'), $data);

  }

}
?>
