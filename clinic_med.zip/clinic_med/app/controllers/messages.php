<?php

/**
 * @file messages.php
 * @brief File for user private messages
 * 
 * @class Messages
 * @brief Class for user private messages
 *
 * @details this class allows users to send and receive messages
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class Messages extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "messages";

  /**
   * the title for this controller
   */ 
  var $module_name = "messages";

  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Messages() {
    parent::Controller();

    if (!is_module(str_replace('.php', '', pathinfo(__FILE__, PATHINFO_BASENAME)))) {
      $this->load->helper('url');
      redirect('principal/accessdenied2');
      return;
    }

    if (!is_user()) {
      $this->load->helper(array('url','cookie'));
      $data = array('redirect'=>$this->module_url);
      $this->session->set_userdata($data);
      redirect('user/login');
      return 0;
    }
  }

  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    //$items[] = '<b>'.$this->lang->line('admin_actions').'</b>';
    $items[] = anchor($this->module_url, $this->lang->line('messages_inbox'));
    $items[] = anchor($this->module_url.'/sent', $this->lang->line('messages_sent'));
    $items[] = anchor($this->module_url.'/write', $this->lang->line('messages_write'));

    return navbarsubmenu($title, $items, 'messages.png');
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->lang->load('messages');
    $this->load->helper(array('url','cookie'));

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('messages_title'));
    $content .= $this->_inbox();

    make_blocks();
    $data = default_Vars_Content();
    //$data['title'] .= ' - ' . $this->lang->line('messages_title');
    $data['content'] = theme($this->block_side1, $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * sends to browser the list of messages sent
   *
   * @public
   *
   * @return nothing
   */
  function sent() {

    $this->lang->load('admin');
    $this->lang->load('messages');
    $this->load->helper(array('url','cookie'));

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('messages_title'));
    $content .= $this->_sent();

    make_blocks();
    $data = default_Vars_Content();
    //$data['title'] .= ' - ' . $this->lang->line('messages_title');
    $data['content'] = theme($this->block_side1, $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * returns a list of messages into inbox
   *
   * @private
   *
   * @return string (html)
   */
  function _inbox() {

    $directto = $this->config->site_url().'/'.$this->module_url.'/index';

    $inbox = '<br />';
    $inbox .= '<h2>'.$this->lang->line('messages_inbox').'</h2>';
    $inbox .= $this->_getlistmessages($directto, 'inbox');

    return $inbox;
  }


  /**
   * returns a list of messages into sent box
   *
   * @private
   *
   * @return string (html)
   */
  function _sent() {

    $directto = $this->config->site_url().'/'.$this->module_url.'/sent';

    $inbox = '<br />';
    $inbox .= '<h2>'.$this->lang->line('messages_sent').'</h2>';
    $inbox .= $this->_getlistmessages($directto, 'sent');

    return $inbox;
  }


  /**
   * returns a list of messages with pagination
   *
   * @private
   * 
   * @param directto string Link of the URL when a page (belongs to pagination) is clicked
   * @param folder string The folder to get. Either  "INBOX" or "SENT"
   *
   * @return string (html)
   */
  function _getlistmessages($directto, $folder) {

    $bold = 0;
    if ('INBOX' == strtoupper($folder)) {
      $where = (array('owner'=>$this->userinfo['code'], 'userto'=>$this->userinfo['code']));
      $order = 'didread, createddate DESC';
      $bold = 1;
    } elseif ('SENT' == strtoupper($folder)) {
      $where = (array('owner'=>$this->userinfo['code'], 'userfrom'=>$this->userinfo['code']));
      $order = 'createddate DESC';
    } else {
      log_message('Error', "Value not allowed for folder variable. Valid values are INBOX/SENT");
      return "";
    }


    $this->lang->load('admin');
    $this->lang->load('messages');
    $this->load->helper(array('url', 'date', 'text'));
    $this->load->library(array('pagination', 'table'));

    $inbox = '';

//erm objetos que necesito
//------------------------------------------------------------------------------
    $itemxpage = 25;

//erm creacion de los links
//------------------------------------------------------------------------------

    $table = 'messages';
    $this->db->where($where);
    $this->db->select('COUNT(id) AS numrows');
    $query = $this->db->get($table);
    if ($query->num_rows() == 0) {
      $num_records = 0;
    } else {
      $row = $query->row();
      $num_records = $row->numrows;;
    }

    $config['base_url'] = $directto;
    $config['total_rows'] = $num_records;
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = "3";
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    //$config['num_links'] = "2";
    $this->pagination->initialize($config);
    $links = $this->pagination->create_links();

    $begin = intval($this->uri->segment(3, 0));
    if ($begin < 0) $begin = 0;

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------

    $this->db->where($where);
    $this->db->orderby($order);
    $query = $this->db->get($table, $itemxpage, $begin);

    $this->table->set_heading(
    '', $this->lang->line('messages_from'),$this->lang->line('messages_to'), $this->lang->line('messages_subject'),
    $this->lang->line('messages_date'), $this->lang->line('messages_message')
    );
    $i = $begin+1;
    foreach ($query->result() as $row) {

      $message = word_limiter(strip_tags($row->message), 5);
      $date = unix_to_human(gmt_to_local($row->createddate, $this->config->item('timezone')))
      .' ' . $this->config->item('timezone');

      if (!$row->didread && $bold)  {
        $subject = '<b>'.$row->subject.'</b>';
        $row->userfrom = '<b>'.$row->userfrom.'</b>';
        $row->userto = '<b>'.$row->userto.'</b>';
        $date = '<b>'.$date.'</b>';
        $img = theme_imgtag('message_new.png', 'New', 'New');
      } else {
        $subject = $row->subject;
        $img = theme_imgtag('message_read.png', '', '');
      }
      $subject = anchor($this->module_url.'/show/'.$folder.'/'.$row->id, $subject, 'title="'.$row->subject.'"');

      $this->table->add_row($img, $row->userfrom, $row->userto, $subject, $date, $message);
      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing="0" width="100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $inbox .= $this->table->generate();
    $inbox .= '<br />'.$links;

    return $inbox;
  }



  /**
   * sends to browser a message
   *
   * @public
   *
   * this method uses as paramenter the URI segments 3 and 4.
   * segment 3 must be a valid diagnostic message code
   * segment 4 must be a valid folder (inbox/sent)
   *
   * @return nothing
   */
  function show() {

    $this->lang->load('admin');
    $this->lang->load('messages');
    $this->load->helper(array('url','cookie','form'));
    $this->load->library(array('table'));

    $folder = $this->input->xss_clean($this->uri->segment(3, 0));
    $code = $this->input->xss_clean($this->uri->segment(4, 0));

    $row = $this->_getmsg($folder, $code, 1);

    if ($row === false) {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;
    }

    $content = $this->_thissubmenu($this->lang->line('messages_title'));

    if ($row === -1) {
      $content .= '<br />'
      .msgErr('', $this->lang->line('messages_msgnotfound'));
    } else {

      $this->table->add_row('<b>'.$this->lang->line('messages_from').':</b> ', $row->userfrom);
      $this->table->add_row('<b>'.$this->lang->line('messages_to').':</b> ', $row->userto);
      $date = unix_to_human(gmt_to_local($row->createddate, $this->config->item('timezone')));
      $this->table->add_row('<b>'.$this->lang->line('messages_date').':</b> ', $date);
      $this->table->add_row('<b>'.$this->lang->line('messages_subject').':</b> ', $row->subject);

      $content .=
      '<br />'
      .$this->table->generate()
      .'<hr />'
      .$row->message
      .'<br />'
      .'<br />';

//erm boton reply
//------------------------------------------------------------------------------

      $del = $this->lang->line('messages_delthismsg');

      $key = 'formReply';
      $attributes = array('id' => $key, 'name' => $key);
      $hidden = array('To'=>$row->userfrom, 'Subject' =>$row->subject);
      $form = '';
      $form .= form_open($this->module_url.'/write', $attributes, $hidden);
      $form .= form_submit('submit', $this->lang->line('messages_reply'));
      $form .= ' ' . anchor($this->module_url.'/del/'.$folder.'/'.$code, '['.$del.']', 'title="'.$del.'"');
      $form .= form_close();

      $content .= '<br />'.$form;

    }


//erm enviar los resultados a la salida
//------------------------------------------------------------------------------
    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    make_blocks();
    $data = default_Vars_Content();
    //$data['title'] .= ' - ' . $this->lang->line('messages_title');
    $data['content'] = theme($this->block_side1, $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * deletes a message
   *
   * @public
   *
   * this method uses as paramenter the URI segments 3 and 4.
   * segment 3 must be a valid diagnostic message code
   * segment 4 must be a valid folder (inbox/sent)
   *
   * @return nothing
   */
  function del() {

//erm objetos que necesito
//------------------------------------------------------------------------------

    $this->lang->load('admin');
    $this->lang->load('messages');
    $this->load->helper(array('url','form', 'cookie'));
    $this->load->library(array('table', 'validation'));

    $folder = $this->input->xss_clean($this->uri->segment(3, 0));
    $code = $this->input->xss_clean($this->uri->segment(4, 0));

    $row = $this->_getmsg($folder, $code, 0);

    if ($row === false) {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;
    }

    if ($row === -1) {
      $msg = base64_encode(msgErr('', $this->lang->line('messages_msgnotfound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;

    } else {


      $this->validation->set_error_delimiters('','<br />');
      $rules['Submit']  = "required";
      $this->validation->set_rules($rules);

      if ($this->validation->run() == FALSE) {

        if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
        else $err = "";

        $form = $this->_thissubmenu($this->lang->line('messages_del')).'<br />'
        . $err
        . Ask_yesno_form (sprintf($this->lang->line('messages_askdel'), $code), $this->module_url.'/del/'.$folder.'/'.$code, $this->module_url);


        $this->table->add_row('<b>'.$this->lang->line('messages_from').':</b> ', $row->userfrom);
        $this->table->add_row('<b>'.$this->lang->line('messages_to').':</b> ', $row->userto);
        $date = unix_to_human(gmt_to_local($row->createddate, $this->config->item('timezone')));
        $this->table->add_row('<b>'.$this->lang->line('messages_date').':</b> ', $date);
        $this->table->add_row('<b>'.$this->lang->line('messages_subject').':</b> ', $row->subject);

        $content =
        '<br />'
        .$this->table->generate()
        .'<hr />'
        .$row->message
        .'<br />'
        .'<br />';


        $data = default_Vars_Content();
        make_blocks();
        //$data['title'] .= ' - ' . $this->lang->line('messages_title');
        $data['content'] = theme($this->block_side1, $form.$content);
        $this->load->view($this->config->item('theme'), $data);

      } else {
        $this->db->delete('messages', array('id' => $code));
        $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
        set_cookie('msg', $msg, 0);
        redirect($this->module_url.'');
        return;
      }

    }

  }


  /**
   * get a message from DB and returns it
   *
   * @private
   *
   * @param folder string The folder to look for [INBOX/SENT]
   * @param code string The code of the message
   * @param markasread boolean True to mark the message as read, false to do nothing
   *
   * @return array
   */
  function _getmsg($folder, $code, $markasread = 0) {

    $this->load->helper(array('date'));

    $msg = -1;

    $folderallowed = ' INBOX SENT ';

    $pos = strpos ($folderallowed, ' '.strtoupper($folder).' ');
    if ($pos === false  || intval($code) == 0) {
      return false;
    }

    if ('INBOX' == strtoupper($folder)) {
      $where = (array('id'=>$code, 'owner'=>$this->userinfo['code'], 'userto'=>$this->userinfo['code']));
    } elseif ('SENT' == strtoupper($folder)) {
      $where = (array('id'=>$code, 'owner'=>$this->userinfo['code'], 'userfrom'=>$this->userinfo['code']));
    } else {
      $where = (array('id'=>-1, 'owner'=>$this->userinfo['code'], 'userfrom'=>$this->userinfo['code']));
    }

    $query = $this->db->where($where);
    $query = $this->db->get('messages', 1);

    if ($query->num_rows() > 0) {
      $msg = $query->row();

      if ($markasread) {
        $now = now();
        $data = array ('didread'=>1, 'readdate'=>$now);
        $this->db->where($where);
        $this->db->update('messages', $data);
      }

    }

    return $msg;
  }


  /**
   * sends to browser a form to write a new message
   *
   * this method shows the form, do the form validation and if it is successful, then save new message into DB
   *
   * @public
   *
   * @return nothing
   */
  function write() {
//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('messages');
    $this->lang->load('user');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie','date'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['To']  = "trim|strip_tags|required|htmlentities|xss_clean|callback__code_exists";
    $rules['Subject']  = "trim|strip_tags|required|xss_clean";
    $rules['Message']  = "trim|required|xss_clean";
    $this->validation->set_rules($rules);

    $fields['To'] = $this->lang->line('messages_writeto');
    $fields['Subject'] = $this->lang->line('messages_subject');
    $fields['Message'] = $this->lang->line('messages_message');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

//erm crear el formulario
//------------------------------------------------------------------------------
      $err = "";
      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);

      $form = $err;

      $required = $this->lang->line('admin_required');

      $key = 'To';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
      $this->table->add_row('<b>'.$this->lang->line('messages_writeto').':</b>', form_input($data).$required);

      $key = 'Subject';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '60');
      $this->table->add_row('<b>'.$this->lang->line('messages_subject').':</b>', form_input($data).$required);

      $this->table->add_row('<br /><b>'.$this->lang->line('messages_message').':</b>', '<br />'.$required);

      $key = 'formWrite';
      $attributes = array('id' => $key, 'name' => $key);

      $key = 'Message';
      $textarea = textArea($key, $this->validation->$key, 'little', '400px').'<br />';

      $form .= form_open($this->module_url.'/write', $attributes);
      $form .= $this->table->generate();
      $form .= $textarea;
      $form .= form_submit('submit', $this->lang->line('messages_send'));
      $form .= form_close();

//erm enviar la info al navegador
//------------------------------------------------------------------------------
    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('messages_title'))
    .'<br />'
    .$form;

    make_blocks();
    $data = default_Vars_Content();
    //$data['title'] .= ' - ' . $this->lang->line('messages_title');
    $data['content'] = theme($this->block_side1, $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

    } else {

      $now = now();
      $this->db->trans_start();

//erm sent the message
//---------------------------------------------------------------------------
      $data = array(
      'owner' => $this->validation->To,
      'userfrom' => $this->userinfo['code'],
      'userto' => $this->validation->To,
      'subject' => $this->validation->Subject,
      'message' => $this->validation->Message,
      'createddate' => $now,
      'priority' => 1,
      'didread' => 0,
      'readdate' => 0
      );
      $this->db->insert('messages', $data);

//erm makes a copy into "sent folder"
//---------------------------------------------------------------------------
      if ($this->validation->To <> $this->userinfo['code']) {
      //erm don't save at sent folder if message was sent to him/her self
        $data['owner'] = $this->userinfo['code'];
        $data['didread'] = 1;
        $data['readdate'] = $now;
        $this->db->insert('messages', $data);
      }

      $this->db->trans_complete();

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;
    }
  }

  /**
   * Look for the message code into db, if it exists, return TRUE, else return FALSE
   *
   * @param str string The code to look for.
   *
   * @private
   *
   * @return boolean
   */
  function _code_exists($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('users');
    if ($query->num_rows() == 0) {
      $this->validation->set_message('_code_exists', $this->lang->line('users_usernoexist'));
      return FALSE;
    } else {
      return TRUE;
    }
  }

  /**
   * sends to browser a html box with the number of new messages in inbox
   *
   * @public
   *
   * @return nothing
   */
  function seeinbox () {

    if (!is_user()) {
      return "";
    }

    $this->load->helper(array('url'));
    $this->lang->load('messages');

    $restul = '';

    $table = 'messages';
    $where = (array('owner'=>$this->userinfo['code'], 'userto'=>$this->userinfo['code'], 'didread'=>'0'));
    $this->db->where($where);
    $this->db->select('COUNT(id) AS numrows');
    $query = $this->db->get($table);
    if ($query->num_rows() == 0) {
      $num_records = 0;
    } else {
      $row = $query->row();
      $num_records = $row->numrows;;
    }

    $img = theme_imgtag('message_new.png', 'New', 'New', 'hspace="5" ');

    $newmsg = $num_records.' '.$this->lang->line('messages_newmsg');
    if ($num_records) {
      $newmsg = anchor('messages', '<b>'.$newmsg.'</b>', 'title="'.$newmsg.'"') . ' ' . $img ;
    }
    $restul .= $newmsg.'<br />';
    $restul .= anchor('messages/write',$this->lang->line('messages_write'));

    echo $restul;

  }

}
?>
