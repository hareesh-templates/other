<?php

/**
 * @file diagnostic.php
 * @brief File to manage diagnostic
 * 
 * @class Diagnostic
 * @brief Class to manage diagnostic
 *
 * @details diagnostic are entered by physicians. examples of diagnostic are: written text and valid ICD (international code of disease) 
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class Diagnostic extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "diagnostic";

  /**
   * the title for this controller
   */ 
  var $module_name = "Diagnostic";

  /**
   * the database table related to this controller
   */ 
  var $dbtablename = "med_diagnostic";


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Diagnostic () {
    parent::Controller();

    if (!is_module(str_replace('.php', '', pathinfo(__FILE__, PATHINFO_BASENAME)))) {
      $this->load->helper('url');
      redirect('principal/accessdenied');
      return;
    }

    if ( ! $this->userinfo['is_physician']) {
      $this->lang->load('med_common');
      $this->load->helper(array('url', 'cookie'));

      $msg = base64_encode(msgErr('', $this->lang->line('physician_youarentdr')));
      $redirect = $this->module_url;
      set_cookie('msg', $msg, 0);
      redirect('principal/accessdenied');
    }

  }

  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * @param title string the title to show in the submenu navbar
   * @param moreitems array aditional items to include in the submenu
   *
   * @return string
   */
  function _thissubmenu($title, $moreitems='') {

    $this->load->helper(array('url'));

    $items[] = anchor($this->module_url, $this->lang->line('diagnostic_appoinmnets'));
    $items[] = anchor('patient_search', $this->lang->line('patientsearch_patient'));

    if (is_array($moreitems)) {
      $items = array_merge($items, $moreitems);
    }

    return navbarsubmenu('', $items, 'diagnostic.png');
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {
    $this->appointments();
  }


  /**
   * send to browser the patient profile
   *
   * history is loaded using ajax
   *
   * this method uses as paramenter the URI segment 3.
   * that segment must has a valid diagnostic code
   *
   * @public
   *
   * @return nothing
   */
  function patient () {

    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->helper(array('url', 'cookie'));

    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      $redirect = $this->module_url;
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }

    $lista  = '';
    $lista .= sprintf('<div id="schedule"> <div class="schedule_free"> <h3> %s </h3> </div></div>', $this->lang->line('diagnostic_no_appointment'));

//erm enviar los resultados a la salida
//------------------------------------------------------------------------------

    $items = array();
    $items[] = sprintf('<div id="button_diagnostic"><a href="" >%s</a></div>',
      $this->lang->line('diagnostic_ins_diagnostic'));
    $items[] = sprintf('<div id="button_cid"><a href="">%s</a></div>',
      $this->lang->line('diagnostic_ins_cid'));
    $items[] =  anchor_popup('history/print_friendly/' . $code, $this->lang->line('medhistory_print_friendly'));

    $diagnostic_url = site_url().'/'.$this->module_url.'/form_diagnostic/'.$code.'/1';
    $cid_url = site_url().'/'.$this->module_url.'/form_cid/'.$code.'/1';
    $history_url    = site_url().'/history/patient_/'.$code;

    $forms =sprintf(
      '<div id="forms" ></div>
      %s
      <div id="history" >Enable Javascript</div>
      %s',
      $lista,
      '<script type="text/javascript" >
        window.addEvent("domready", function() {

          $("history").load("'.$history_url.'");

          $("button_diagnostic").addEvent("click", function(e) {
            e.stop(); // prevent default
            $("forms").load("'.$diagnostic_url.'");
          });
          $("button_cid").addEvent("click", function(e) {
            e.stop(); // prevent default
            $("forms").load("'.$cid_url.'");
          });
        });
      </script>'
    );

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content =
    $msg
    .$this->_thissubmenu($this->lang->line('diagnostic_title'), $items)
    .$forms;

//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------
    make_blocks('1');
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('diagnostic_title');
    $data['content'] = theme($this->block_side1, $content);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * returns an array with the information of the appointment
   *
   * @private
   * @param code string the code ot he appointment to get
   *
   * @return array
   */
  function _get_appointment ($code) {

    static $row = '';
    if ($row != '') {
      return $row;
    }

//erm get appointment details from DB
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->select(sprintf(
      'a.*, b.name as physician, b.code as physician_code, c.name as patient, d.name as speciality
      FROM %smed_appointment as a
      LEFT JOIN %susers as b ON a.physician_code=b.code && b.is_physician=1
      LEFT JOIN %smed_patient as c ON a.patient_code=c.code
      LEFT JOIN %smed_specialities as d ON a.speciality_code=d.code
      ',
      $prefix,
      $prefix,
      $prefix,
      $prefix
    ));
    $this->db->where('a.id', $code);
    $this->db->where('a.status', 4);
    $this->db->where('a.physician_code', $this->userinfo['code']);
    $query = $this->db->get();

    if ($query->num_rows() > 0) {

      $row = $query->row_array();

    } else {

      $row = -1;

    }

    return $row;

  }

  /**
   * send to browser a html form to upload files
   *
   * this method uses as paramenter the URI segment 3.
   * that segment must has a valid appoinment code
   *
   * @public
   *
   * @return nothing
   */
  function form_file () {

    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      echo msgErr('', $this->lang->line('admin_ignoringtask'));
      return;
    }

    $content = '';

    $this->load->helper(array('url', 'cookie', 'date'));

    $row = $this->_get_appointment ($code);

//erm show controls to add the diagnostic
//------------------------------------------------------------------------------
    $vars = array(
      'action'=>'add',
      'directo'=>$this->module_url.'/form_file/'.$code
    );

    $vars['code'] = $code;
    $vars['physician'] = $row['physician_code'];
    $vars['patient'] = $row['patient_code'];
    $vars['speciality'] = $row['speciality_code'];
    $vars['cid_search'] = $this->input->post('cid_search');

    $validation = FALSE;
    $form = $this->_form_file ($vars, $validation);

    if ($validation == FALSE) {

//erm enviar los resultados a la salida
//------------------------------------------------------------------------------

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $content =  $msg  . $form;

    } else {

      $data = array(
      'appointment_id' => $this->validation->code,
      'physician_code' => $this->validation->physician,
      'patient_code' => $this->validation->patient,
      'speciality_code' => $this->validation->speciality,
      'datecreated' => now(),
      'diagnosis_code' => $this->validation->cid_control,
      );
      $this->db->insert($this->dbtablename, $data);

      //$content = msgSuccess('', $this->lang->line('admin_taskok'));

    }

//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------
    echo $content;

  }

  /**
   * returs a string with html form, also makes the validation process
   * for the file to upload
   *
   * @private
   * @param vars array An array with the form values
   * @param validation boolean This method sets it to true if validation success, else set it to false
   *
   * @return string
   */
  function _form_file ($vars, &$validation) {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('form', 'url'));
    $this->load->library(array('validation', 'table'));

    $this->table->clear();

    $this->validation->set_error_delimiters('','<br />');
    $rules['file']  = "trim|required|xss_clean";
    $rules['physician']  = "trim|required|xss_clean";
    $rules['patient']  = "trim|required|xss_clean";
    $rules['speciality']  = "trim|required|xss_clean";
    $rules['code']  = "trim|required|xss_clean";

    $this->validation->set_rules($rules);

    $fields['file'] = $this->lang->line('diagnostic_diagnostic');
    $fields['physician'] = $this->lang->line('diagnostic_physician');
    $fields['patient'] = $this->lang->line('diagnostic_patient');
    $fields['speciality'] = $this->lang->line('diagnostic_speciality');
    $fields['code'] = $this->lang->line('diagnostic_appoinmnet');
    $this->validation->set_fields($fields);

    $form = "";
    $validation = $this->validation->run();

    if ($validation == FALSE) {

      $this->validation->physician = $vars['physician'];
      $this->validation->patient = $vars['patient'];
      $this->validation->speciality = $vars['speciality'];
      $this->validation->code = $vars['code'];

      if ($this->validation->error_string != "") $form .= msgErr("",$this->validation->error_string);

//erm crear el formulario
//------------------------------------------------------------------------------------------
      $form_tag = 'form_file_';
      $attributes = array('id' => $form_tag, 'name' => $form_tag);

      $form .= form_open_multipart($vars['directo'], $attributes);

      $key = $textarea = 'file';
      $this->table->add_row(
        form_upload($key)
        .form_hidden('physician', $this->validation->physician)
        .form_hidden('patient', $this->validation->patient)
        .form_hidden('speciality', $this->validation->speciality)
        .form_hidden('code', $this->validation->code)
      );

      $submit = 'form_file_submit';
      $this->table->add_row(
        form_submit($submit, $this->lang->line('diagnostic_attach'))
        .sprintf(' <a id="form_close" href="">%s</a>', $this->lang->line('diagnostic_cancel'))
      );

//erm si se esta creado, crear y cargar el formulario con javascript y ajax
//------------------------------------------------------------------------------------------

      $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=0 style="width:100%">');
      $this->table->set_template($tmpl);
      $form .= $this->table->generate();

      $history_url =
      site_url().'/history/patient_/'.$this->validation->patient.'/'.$this->validation->speciality;

      $js =
      '
      <script type="text/javascript">
        window.addEvent("domready", function() {

          $("form_close").addEvent("click", function(e) {
            e.stop(); // prevent default
            $("forms").set("html", "");
          });

          $("'.$form_tag.'").addEvent("submit", function(e) {

            e.stop(); // prevent default

            var myHTMLRequest = new Request.HTML({
              url: "' .  site_url().'/' .  $vars['directo'].'",
              update: $("forms"),
              onComplete: function() {
                if ($("history") != null) {
                  $("history").load("'.$history_url.'");
                }
              }
            }).post($("'.$form_tag.'"));

          });

        });
      </script>'
      ;


      $form .= form_close();
      $form .= $js;

    }

    return $form;

  }

  /**
   * return the locale CID table name
   *
   * this method search in the database the proper name of the CID table
   * based in the language selected by the user
   * 
   * The name returned does not include the DB prefix
   * If table language does not exists then english one will be returned instead
   *
   * @private
   *
   * @return string
   */
  function _get_cid_tablename () {

    static $name = '';
    if ($name != '') {
      return $name;
    }

    $name = 'med_cid10_'.$this->config->item('language');
    if ( ! $this->db->table_exists('med_cid10_'.$this->config->item('language'))) {
      $name = 'med_cid10_english';
    }

    return $name;
  }


  /**
   * send to browser a list of CIDS (code and name)
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with text to search for CIDs in the DB
   *
   * @public
   *
   * @return nothing
   */
  function cids () {

    $search = $this->input->xss_clean($this->uri->segment(3, 0));
    if ( ! $search) {
      echo "";
      return;
    }

    if (strlen($search) < 3) {
      echo "";
      return;
    }

    $this->lang->load('admin');

//erm load cids from table
//------------------------------------------------------------------------------

    //$search =  htmlspecialchars_decode($search) . ' ';

    $search_select = sprintf(", concat('1') as relev" );
    $search_where  = sprintf("(description LIKE '%%%s%%')", $search );

    $this->db->select('diagnosis_code as code, description as name ' . $search_select);
    $this->db->from($this->_get_cid_tablename());
    $this->db->where($search_where);
    $this->db->orwhere('diagnosis_code LIKE "%'.$search.'%"');
    $this->db->orderby('relev DESC, code, name');

    $query = $this->db->get();

    $options = '';
    $options = 'ok';

    foreach ($query->result() as $row) {
      if ($options != '')  $options .= '&&';
      $options .= $row->code;
      $options .= '|';
      // !!if ($selected) $options .= 'selected';
      $options .= '|';
      // !!$options .= sprintf('(%.1f) (%s) %s', $row->relev, $row->code, $row->name);
      $options .= sprintf('(%s) %s', $row->code, $row->name);
    }

    // !!echo $this->db->last_query();
    echo $options;
  }


  /**
   * send to browser a html form to select a CID
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with the code of the patient
   *
   * @public
   *
   * @return nothing
   */
  function form_cid () {

    $this->lang->load('med_common');
    $this->lang->load('admin');

    $this->load->helper(array('url', 'cookie', 'date'));

    $vars = array('action'=>'add');

    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      echo msgErr('', $this->lang->line('admin_ignoringtask'));
      return;
    }

    $type = $this->input->xss_clean($this->uri->segment(4, 0));

    if ($type !== "0") {
      //erm. It is not an appointment. Search for patient instead

      $vars['directo'] = $this->module_url.'/form_cid/'.$code.'/1';
      $vars['code'] = 0; //erm. this is the appointment ID
      $vars['physician'] = $this->userinfo['code'];
      $vars['patient'] = $code;
      $vars['speciality'] = $this->input->post('speciality');
      $vars['cid_search'] = $this->input->post('cid_search');
      $vars['speciality_ctrl'] = TRUE;

    } else {

      $row = $this->_get_appointment ($code);
      if ( ! is_array($row) ) {
        echo msgErr('', $this->lang->line('diagnostic_appoinmnetnofound'));
        return;
      }

  //erm show controls to add the diagnostic
  //------------------------------------------------------------------------------
      $vars['directo'] = $this->module_url.'/form_cid/'.$code;
      $vars['code'] = $code;
      $vars['physician'] = $row['physician_code'];
      $vars['patient'] = $row['patient_code'];
      $vars['speciality'] = $row['speciality_code'];
      $vars['cid_search'] = $this->input->post('cid_search');
      $vars['speciality_ctrl'] = FALSE;

    }

    $content = '';

    $validation = FALSE;
    $form = $this->_form_cid ($vars, $validation);

    if ($validation == FALSE) {

//erm enviar los resultados a la salida
//------------------------------------------------------------------------------

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $content =  $msg  . $form;

    } else {

      $data = array(
      'appointment_id' => $this->validation->code,
      'physician_code' => $this->validation->physician,
      'patient_code' => $this->validation->patient,
      'speciality_code' => $this->validation->speciality,
      'datecreated' => now(),
      'diagnosis_code' => $this->validation->cid_control,
      'is_cid' => 1,
      );
      $this->db->insert($this->dbtablename, $data);

      //$content = msgSuccess('', $this->lang->line('admin_taskok'));

    }

//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------
    echo $content;

  }


  /**
   * create and return a html form to select a CID. Also makes the validation process.
   *
   * @private
   * @param vars array An array with the form values
   * @param validation boolean This method sets it to true if validation success, else set it to false
   *
   * @return string
   */
  function _form_cid ($vars, &$validation) {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('form', 'url'));
    $this->load->library(array('validation', 'table'));

    $this->table->clear();

    $this->validation->set_error_delimiters('','<br />');
    $rules['cid_control']  = "trim|required|xss_clean";
    $rules['physician']  = "trim|required|xss_clean";
    $rules['patient']  = "trim|required|xss_clean";
    $rules['speciality']  = "trim|required|xss_clean";
    $rules['code']  = "trim|required|xss_clean";

    $this->validation->set_rules($rules);

    $fields['cid_control'] = $this->lang->line('diagnostic_cid');
    $fields['physician'] = $this->lang->line('diagnostic_physician');
    $fields['patient'] = $this->lang->line('diagnostic_patient');
    $fields['speciality'] = $this->lang->line('diagnostic_speciality');
    $fields['code'] = $this->lang->line('diagnostic_appoinmnet');
    $this->validation->set_fields($fields);

    $form = "";
    $validation = $this->validation->run();

    if ($validation == FALSE) {

      $this->validation->physician = $vars['physician'];
      $this->validation->patient = $vars['patient'];
      $this->validation->speciality = $vars['speciality'];
      $this->validation->code = $vars['code'];
      $this->validation->cid_search = $vars['cid_search'];

      if ($this->validation->error_string != "") $form .= msgErr("",$this->validation->error_string);

//erm crear el formulario
//------------------------------------------------------------------------------------------
      $form_tag = 'form_cid_';
      $attributes = array('id' => $form_tag, 'name' => $form_tag);

      $form .= form_open($vars['directo'], $attributes);

      $form .= form_hidden('physician', $this->validation->physician);
      $form .= form_hidden('patient', $this->validation->patient);
      $form .= form_hidden('code', $this->validation->code);

      if ($vars['speciality_ctrl'] == TRUE) {
        $options = $this->_get_specialities ($this->userinfo['code']);
        $form .= form_dropdown('speciality', $options, $this->validation->speciality);
      } else {
        $form .= form_hidden('speciality', $this->validation->speciality);
      }

      $cid_search = 'cid_search';
      $cid_control = 'cid_control';
      $this->table->add_row(
        $this->lang->line('diagnostic_cidtype').'<br />'
        .form_input($cid_search, $this->validation->cid_search, ' class="diagnostic_cid_search" id="'.$cid_search.'" ')
        .'<br />'
        .form_dropdown($cid_control, array(), '', ' size="12" class="diagnostic_cid_control" id="'.$cid_control.'" ')
      );

      $submit = 'form_diagnostic_submit';
      $this->table->add_row(
        form_submit($submit, $this->lang->line('diagnostic_ins_diagnostic'))
        .sprintf(' <a id="form_close" href="">%s</a>', $this->lang->line('diagnostic_cancel'))
      );

//erm si se esta creado, crear y cargar el formulario con javascript y ajax
//------------------------------------------------------------------------------------------

      $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=0 style="width:100%">');
      $this->table->set_template($tmpl);
      $form .= $this->table->generate();

      $history_url =
      site_url().'/history/patient_/'.$this->validation->patient.'/'.$this->validation->speciality;

      $cids_url = site_url().'/'.$this->module_url.'/cids/';


      $js =
      '
      <script type="text/javascript">
        window.addEvent("domready", function() {


          $("form_close").addEvent("click", function(e) {
            e.stop(); // prevent default
            $("forms").set("html", "");
          });

          $("'.$form_tag.'").addEvent("submit", function(e) {

            e.stop(); // prevent default

            var myHTMLRequest = new Request.HTML({
              url: "' .  site_url().'/' .  $vars['directo'].'",
              update: $("forms"),
              onComplete: function() {
                if ($("history") != null) {
                  $("history").load("'.$history_url.'");
                }
              }
            }).post($("'.$form_tag.'"));

          });

          $("'.$cid_search.'").addEvent("keyup" , function(e) {
            var url = "'.$cids_url.'" + $("'.$cid_search.'").get("value");
            ajax_cids.get(url);
          });

          var ajax_cids = new Request.HTML({
            method: "get",
            autoCancel: true,
            onComplete: function() {

              $("'.$cid_control.'").options.length = 0;
              if (this.response.text != "") {
                var j = 0;
                var options = this.response.text.split("&&");
                if (options[0] == "ok") {
                  for(i = 1; i < options.length; i++) {
                    var option = options[i].split("|");
                    $("'.$cid_control.'").options[j] = new Option(option[2], option[0]);
                    if (option[1] != "") $("'.$cid_control.'").selectedIndex=j;
                    j = j + 1;
                  }
                }
              }

            }
          });

          if ($("'.$cid_search.'").get("value") != "") {
            var url = "'.$cids_url.'" + $("'.$cid_search.'").get("value");
            ajax_cids.get(url);
          }

        });
      </script>'
      ;


      $form .= form_close();
      $form .= $js;

    }

    return $form;

  }

  /**
   * send to browser a html form to select a diagnostic text
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with the code of the patient
   *
   * @public
   *
   * @return nothing
   */
  function form_diagnostic () {

    $this->lang->load('med_common');
    $this->lang->load('admin');

    $this->load->helper(array('url', 'cookie', 'date'));

    $vars = array('action'=>'add');

    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      echo msgErr('', $this->lang->line('admin_ignoringtask'));
      return;
    }

    $type = $this->input->xss_clean($this->uri->segment(4, 0));

    if ($type !== "0") {
      //erm. It is not an appointment. Search for patient instead

      $vars['directo'] = $this->module_url.'/form_diagnostic/'.$code.'/1';
      $vars['code'] = 0; //erm. this is the appointment ID
      $vars['physician'] = $this->userinfo['code'];
      $vars['patient'] = $code;
      $vars['speciality'] = $this->input->post('speciality');
      $vars['speciality_ctrl'] = TRUE;

    } else {

      $row = $this->_get_appointment ($code);
      if ( ! is_array($row) ) {
        echo msgErr('', $this->lang->line('diagnostic_appoinmnetnofound'));
        return;
      }

  //erm show controls to add the diagnostic
  //------------------------------------------------------------------------------
      $vars['directo'] = $this->module_url.'/form_diagnostic/'.$code;
      $vars['code'] = $code;
      $vars['physician'] = $row['physician_code'];
      $vars['patient'] = $row['patient_code'];
      $vars['speciality'] = $row['speciality_code'];
      $vars['speciality_ctrl'] = FALSE;

    }

    $content = '';

    $this->load->helper(array('url', 'cookie', 'date'));


    $validation = FALSE;
    $form = $this->_form_diagnostic ($vars, $validation);

    if ($validation == FALSE) {

//erm enviar los resultados a la salida
//------------------------------------------------------------------------------

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $content =  $msg  . $form;

    } else {

      $data = array(
      'appointment_id' => $this->validation->code,
      'physician_code' => $this->validation->physician,
      'patient_code' => $this->validation->patient,
      'speciality_code' => $this->validation->speciality,
      'datecreated' => now(),
      'diagnostic' => $this->validation->diagnostic,
      );
      $this->db->insert($this->dbtablename, $data);

      //$content = msgSuccess('', $this->lang->line('admin_taskok'));

    }

//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------
    echo $content;

  }


  /**
   * return a list of specialities for physician
   *
   * @private
   * @param physician_code string the physician selected
   *
   * @return string
   */
  function _get_specialities ($physician_code) {

    $this->lang->load('admin');

//erm load specialities list
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->distinct();
    $this->db->select('code, name');
    $this->db->from(array('med_specialities','med_schedule'));

    $this->db->where($prefix.'med_specialities.code=' . $prefix.'med_schedule.speciality_code');
    $this->db->where('physician_code', $physician_code);

    $this->db->orderby('name');
    $query = $this->db->get();

    $result = array('' => '--- '.$this->lang->line('specialities_please_select').' ---');

    foreach ($query->result() as $row) {
      $result[$row->code] = $row->name;
    }

    return $result;
  }


  /**
   * create and return a html form to include a text diagnostic. Also makes the validation process.
   *
   * @private
   * @param vars array An array with the form values
   * @param validation boolean This method sets it to true if validation success, else set it to false
   *
   * @return string
   */
  function _form_diagnostic ($vars, &$validation) {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('form', 'url'));
    $this->load->library(array('validation', 'table'));

    $this->table->clear();

    $this->validation->set_error_delimiters('','<br />');
    $rules['diagnostic']  = "trim|required|xss_clean";
    $rules['physician']  = "trim|required|xss_clean";
    $rules['patient']  = "trim|required|xss_clean";
    $rules['speciality']  = "trim|required|xss_clean";
    $rules['code']  = "trim|required|xss_clean";

    $this->validation->set_rules($rules);

    $fields['diagnostic'] = $this->lang->line('diagnostic_diagnostic');
    $fields['physician'] = $this->lang->line('diagnostic_physician');
    $fields['patient'] = $this->lang->line('diagnostic_patient');
    $fields['speciality'] = $this->lang->line('diagnostic_speciality');
    $fields['code'] = $this->lang->line('diagnostic_appoinmnet');
    $this->validation->set_fields($fields);

    $form = "";
    $validation = $this->validation->run();

    if ($validation == FALSE) {

      $this->validation->physician = $vars['physician'];
      $this->validation->patient = $vars['patient'];
      $this->validation->speciality = $vars['speciality'];
      $this->validation->code = $vars['code'];

      if ($this->validation->error_string != "") $form .= msgErr("",$this->validation->error_string);

//erm crear el formulario
//------------------------------------------------------------------------------------------
      $form_tag = 'form_diagnostic_';
      $attributes = array('id' => $form_tag, 'name' => $form_tag);

      $form .= form_open($vars['directo'], $attributes);

      $form .= form_hidden('physician', $this->validation->physician);
      $form .= form_hidden('patient', $this->validation->patient);
      $form .= form_hidden('code', $this->validation->code);

      if ($vars['speciality_ctrl'] == TRUE) {
        $options = $this->_get_specialities ($this->userinfo['code']);
        $form .= form_dropdown('speciality', $options, $this->validation->speciality);
      } else {
        $form .= form_hidden('speciality', $this->validation->speciality);
      }

      $key = $textarea = 'diagnostic';
      $this->table->add_row(textArea($key, $this->validation->$key, 'little', '250px', '95%'));

      $submit = 'form_diagnostic_submit';
      $this->table->add_row(
        form_submit($submit, $this->lang->line('diagnostic_ins_diagnostic'))
        .sprintf(' <a id="form_close" href="">%s</a>', $this->lang->line('diagnostic_cancel'))
      );

//erm si se esta creado, crear y cargar el formulario con javascript y ajax
//------------------------------------------------------------------------------------------

      $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=0 style="width:100%">');
      $this->table->set_template($tmpl);
      $form .= $this->table->generate();

      $history_url =
      site_url().'/history/patient_/'.$this->validation->patient.'/'.$this->validation->speciality;

      $js =
      '
      <script type="text/javascript">
        window.addEvent("domready", function() {

          $("form_close").addEvent("click", function(e) {
            e.stop(); // prevent default
            $("forms").set("html", "");
          });

          $("'.$form_tag.'").addEvent("submit", function(e) {

            e.stop(); // prevent default

            try {
              var oEditor = FCKeditorAPI.GetInstance("'.$textarea.'");
              $("'.$textarea.'").set("value", oEditor.GetHTML());
            } catch(err) {
              //erm nothing to do. The control is a raw textarea instead html FCKeditor
            }

            var myHTMLRequest = new Request.HTML({
              url: "' .  site_url().'/' .  $vars['directo'].'",
              update: $("forms"),
              onComplete: function() {
                if ($("history") != null) {
                  $("history").load("'.$history_url.'");
                }
              }
            }).post($("'.$form_tag.'"));

          });

        });
      </script>'
      ;


      $form .= form_close();
      $form .= $js;

    }

    return $form;

  }


  /**
   * send to browser a html with a formated appointment
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with the code of the appointment
   *
   * @public
   *
   * @return nothing
   */
  function appointment () {

    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->helper(array('url', 'cookie'));

    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      $redirect = $this->module_url;
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }

    $lista = '';

    $row = $this->_get_appointment ($code);

    if ( ! is_array($row) ) {

      $msg = base64_encode(msgErr('', $this->lang->line('diagnostic_appoinmnetnofound')));
      $redirect = $this->module_url;
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;

    } else {

      $lista .= $this->_format_appointment (
        $row['status'],  $row['id'],  $row['time_from'],
        $row['time_to'],  $row['patient'], $row['patient_code'], $row['speciality'], $row['notes']
      );

    }

//erm enviar los resultados a la salida
//------------------------------------------------------------------------------

    $items = array();
    $items[] = sprintf('<div id="button_diagnostic"><a href="" >%s</a></div>',
      $this->lang->line('diagnostic_ins_diagnostic'));
    $items[] = sprintf('<div id="button_cid"><a href="">%s</a></div>',
      $this->lang->line('diagnostic_ins_cid'));
    $items[] = sprintf('<div id="button_file">%s</div>',
      anchor('diagnostic_attach/form_file/'.$code, $this->lang->line('diagnostic_ins_file'))
      );
    $items[] =  anchor_popup('history/print_friendly/' . $row['patient_code'], $this->lang->line('medhistory_print_friendly'));

    $diagnostic_url = site_url().'/'.$this->module_url.'/form_diagnostic/'.$code;
    $cid_url = site_url().'/'.$this->module_url.'/form_cid/'.$code;
    $file_url = site_url().'/diagnostic_attach/iform_file/'.$code;
    $history_url    = site_url().'/history/patient_/'.$row['patient_code'].'/'.$row['speciality_code'];

    $forms =sprintf(
      '<div id="forms" ></div>
      %s
      <div id="history" >Enable Javascript</div>
      %s',
      $lista,
      '<script type="text/javascript" >
        window.addEvent("domready", function() {

          $("history").load("'.$history_url.'");

          $("button_diagnostic").addEvent("click", function(e) {
            e.stop(); // prevent default
            $("forms").load("'.$diagnostic_url.'");
          });
          $("button_cid").addEvent("click", function(e) {
            e.stop(); // prevent default
            $("forms").load("'.$cid_url.'");
          });
        });
      </script>'
    );

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content =
    $msg
    .$this->_thissubmenu($this->lang->line('diagnostic_title'), $items)
    .$forms;

//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------
    make_blocks('1');
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('diagnostic_title');
    $data['content'] = theme($this->block_side1, $content);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * returns a html calendar with the appointments for the selected physician
   *
   * @private
   *
   * @return string
   */
  function _schedule_calendar ($year=0, $month=0) {

    $physician = $this->userinfo['code'];

    $this->load->helper(array('date', 'url'));
    $time = gmt_to_local(now(), $this->config->item('timezone'));

    if (intval($year) == 0) $year = date('Y', $time);
    if (intval($month) == 0) $month = date('n', $time);

    $date1 = mktime  (0, 0, 0, $month, 1, $year);
    $date2 = mktime  (23, 59, 59, $month, date('t', $date1), $year);

    $prefs = array (
      'local_time' => $time,
      'show_next_prev' => TRUE,
      'next_prev_url' => site_url() . '/' . $this->module_url . '/appointments/0/'
    );


    $prefs['template'] = '
    {table_open}<table class="calendar" cellpadding="3" cellspacing="0">{/table_open}
    {table_close}</table>{/table_close}

    {cal_cell_content}<div class="calendar_content"><a href="{content}">{day}</a></div>{/cal_cell_content}
    {cal_cell_content_today}<div class="calendar_content"><a href="{content}"><span class="calendar_today">{day}</span></a></div>{/cal_cell_content_today}

    {cal_cell_no_content}<span class="calendar_no_content" >{day}</span>{/cal_cell_no_content}
    {cal_cell_no_content_today}<span class="calendar_no_content" ><span class="calendar_today">{day}</span></span>{/cal_cell_no_content_today}
    ';


    $this->load->library('calendar', $prefs);

    $data = array();
//erm load schedules days for physician selected
//------------------------------------------------------------------------------
    $this->db->select('time_from');
    $this->db->from(array('med_appointment'));
    $this->db->where('time_from>=', $date1);
    $this->db->where('time_to<=', $date2);

    if ($physician != '') $this->db->where('physician_code', $physician);

    $this->db->orderby('time_from');
    $query = $this->db->get();

    $days = array();
    foreach ($query->result() as $row) {
      $date_time_zone = $row->time_from;
      $day = intval(date('d', $date_time_zone));
      if (!isset($days[$day])) {
        $days[$day] = 1;
      }
    }

    for ($i=1;$i<=31;$i++) {
      if (isset($days[$i])) {
        $data[$i] =
        sprintf('%s/%s/appointments/', site_url(), $this->module_url);
      }
    }

    return
    sprintf(
      '%s %s',
      $this->calendar->generate($year, $month, $data),
      anchor($this->module_url.'/appointments', $this->lang->line('schedule_gotoday'))
    );

  }


  /**
   * sends to browser a list of appoinments
   *
   * @public
   *
   * @return nothing
   */  
  function appointments () {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url', 'cookie', 'date'));
    $this->load->library(array('pagination'));

    $year = $this->uri->segment(4, 0);
    $month = $this->uri->segment(5, 0);

//erm creacion de los links
//------------------------------------------------------------------------------
    $itemxpage = 5;
    $uri_segment = 3;

    $config['base_url'] = site_url() . '/' . $this->module_url . '/appointments/' ;

    $where = array('a.status >' => 0, 'a.status <=' => 4, 'a.physician_code' => $this->userinfo['code']);

    $this->db->select('count(*) as numrows');
    $this->db->from('med_appointment a');
    $this->db->where($where);
    $query = $this->db->get();

    $numitems = 0;
    if ($query->num_rows() > 0) {
      $row = $query->row();
      $numitems = $row->numrows;
    }

    $config['total_rows'] = $numitems;
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = $uri_segment;
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    $config['num_links'] = '4';
    $this->pagination->initialize($config);
    $pagination = $this->pagination->create_links();

    $begin = intval($this->uri->segment($uri_segment, 0));
    if ($begin < 0) $begin = 0;

//erm cargar la informacion desde la base de datos
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->select(sprintf(
      'a.*, b.name as physician, c.name as patient, d.name as speciality
      FROM %smed_appointment as a
      LEFT JOIN %susers as b ON a.physician_code=b.code && b.is_physician=1
      LEFT JOIN %smed_patient as c ON a.patient_code=c.code
      LEFT JOIN %smed_specialities as d ON a.speciality_code=d.code
      ',
      $prefix,
      $prefix,
      $prefix,
      $prefix
    ));
    $this->db->where($where);
    $this->db->orderby('time_from');
    $this->db->limit($itemxpage, $begin);
    $query = $this->db->get();

    $lista = '';
    if ($query->num_rows() > 0) {

      foreach ($query->result() as $row) {
        $lista .= $this->_format_appointment (
          $row->status, $row->id, $row->time_from,
          $row->time_to, $row->patient, $row->patient_code, $row->speciality, $row->notes
        );
      }

    } else {
      $lista = $this->lang->line('diagnostic_notapppoinments');
    }

    $now = gmt_to_local(now(), $this->config->item('timezone'));
    $title = date('D d, M Y', $now);
    $appointments = sprintf(
      '<h3>%s: %s</h3><div>%s</div>',
      $this->lang->line('diagnostic_today'),
      $title,
      $lista
    );

//erm recuperar cualquier cookie de mensaje
//------------------------------------------------------------------------------
    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = '';
    $content .= $msg;
    $content .= $this->_thissubmenu($this->lang->line('diagnostic_title'));
    $content .= $appointments;
    $content .= $pagination;

    $calentar = block($title, $this->_schedule_calendar($year, $month));

//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------
    make_blocks();
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('diagnostic_title');
    $data['content'] = theme($this->block_side1, $content, $calentar.$this->block_side2);
    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * return a formated appointment (style)
   *
   * @private
   *
   * @param status string the status of the appointment
   * @param id int the id of the appointment
   * @param timefrom int the begining time of the appointment
   * @param timeto int the ending time of the appointment
   * @param patient string the name of the patient
   * @param patient_code string the patiend code
   * @param speciality string the speciality for this appointment
   * @param notes string notes for this appointment.
   *
   * @return string
   */  
  function _format_appointment ($status, $id, $timefrom, $timeto, $patient, $patient_code, $speciality, $notes ) {

    $this->load->helper(array('date','url'));

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('table'));

    $now = gmt_to_local(now(), $this->config->item('timezone'));
    $today = mktime(0,0,0,date('n',$now),date('j',$now),date('Y',$now));
    $tomorrow = mktime(0,0,0,date('n',$now),date('j',$now)+1,date('Y',$now));

    $items = array();
    $action_url = site_url().'/'.$this->module_url;

    $class_css = 'schedule_patient_today';

    if ($timefrom < $today) {
      $class_css = 'schedule_busy';
    }

    if ($timefrom >= $tomorrow) {
      $class_css = 'schedule_empty';
    }

    if ( ! $status) {
      $class_css = 'schedule_appointment_canceled';
    }

    if ($status > 0 && $status < 4 && $timefrom < $tomorrow) {
      $action_url .= '/begin/'.$id;
      $txt = $this->lang->line('appointment_begin');
      $items[] = sprintf(
        '%s<br />%s',
        sprintf('<a href="%s">%s</a>', $action_url, theme_imgtag ('doctor.png', $txt, $txt)),
        anchor($action_url, $txt)
      );
    }

    if ($status == 4) {
      $class_css = 'schedule_free';
      $url = $action_url . '/end/'.$id;
      $txt = $this->lang->line('appointment_end');
      $items[] = sprintf(
        '%s<br />%s',
        sprintf('<a href="%s">%s</a>', $url, theme_imgtag ('invoice.png', $txt, $txt)),
        anchor($url, $txt)
      );

      $url = $action_url . '/appointment/'.$id;
      $txt = $this->lang->line('diagnostic_handle');
      $items[] = sprintf(
        '%s<br />%s',
        sprintf('<a href="%s">%s</a>', $url, theme_imgtag ('handle.png', $txt, $txt)),
        anchor($url, $txt)
      );

    }

    $menu = '';
    if (sizeof($items)) {
      $this->table->clear();
      $menu = $this->table->make_columns($items, sizeof($items));
      $tmpl = array (
      'cell_start'=>'<td align="center" >',
      'cell_alt_start'=>'<td align="center" >'
      );
      $this->table->set_template($tmpl);
      $menu = $this->table->generate($menu);
    }


    $data = '';
    $info = '';

    $info = sprintf(
      '<b>%s - %s</b>
      <div>%s: %s</div>
      <div>%s: %s</div>
      <i>%s</i>',
      date('h:i a', $timefrom),
      date('h:i a', $timeto),
      $this->lang->line('patient_patient'),
      anchor('history/patient/'.$patient_code, $patient),
      $this->lang->line('diagnostic_speciality'),
      $speciality,
      $notes
    );

    $data =
    sprintf(
      '<div id="schedule"><table border=0 class="'.$class_css.'" width="100%%" ><tr>
      <td width="75px"><h3>%s<br/>%s</h3></td>
      <td >%s</td>
      <td width="100px" valign="middle" align="center">%s</td>
      </tr></table></div>',
      date('D j', $timefrom),
      date('M Y', $timefrom),
      $info,
      $menu
    );

    return $data;
  }


  /**
   * changes the status of the appointment to 'begin'
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with the code of the appointment
   *
   * @public
   *
   * @return nothing
   */
  function begin () {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->load->helper(array('url'));

    $redirect = $this->module_url;

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }

    $data = array(
      'status' => 4,
    );
    $this->db->where('id', $code);
    $this->db->where('status >', 0);
    $this->db->where('status <', 4);
    $this->db->update('med_appointment', $data);

    $redirect .= '/appointment/'.$code;
    redirect($redirect);

    return;
  }


  /**
   * changes the status of the appointment to 'end'
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with the code of the appointment
   *
   * @public
   *
   * @return nothing
   */
  function end() {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->load->helper(array('url'));

    $redirect = $this->module_url;
    if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] != '') {
      $tmp = $_SERVER['HTTP_REFERER'];
      $tmp = trim(substr($tmp, strlen($this->config->site_url()), strlen($tmp)));
      if ($redirect != '') $redirect = $tmp;
    }

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }


    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('appointment_del')).'<br />'
      . $err
      . Ask_yesno_form (
        sprintf($this->lang->line('appointment_askend'), $code),
        $this->module_url.'/end/'.$code,
        $redirect,
        form_hidden('redirect', base64_encode($redirect))
      );

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('appointment_title');
      $data['content'] = theme($this->block_side1, $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
        'status' => 5,
      );
      $this->db->where('id', $code);
      $this->db->where('status', 4);
      $this->db->update('med_appointment', $data);

      $redirect = $this->module_url.'/appointments/';

      redirect($redirect);

      return;
    }
  }


  /**
   * changes the status of the appointment to 'delete'
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with the code of the appointment
   *
   * @public
   *
   * @return nothing
   */
  function delete() {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->load->helper(array('url'));

    $redirect = $this->module_url;
    if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] != '') {
      $tmp = $_SERVER['HTTP_REFERER'];
      $tmp = trim(substr($tmp, strlen($this->config->site_url()), strlen($tmp)));
      if ($redirect != '') $redirect = $tmp;
    }

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }


    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('diagnostic_delete')).'<br />'
      . $err
      . Ask_yesno_form (
        sprintf($this->lang->line('diagnostic_askdel'), $code),
        $this->module_url.'/delete/'.$code,
        $redirect,
        form_hidden('redirect', base64_encode($redirect))
      );

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('appointment_title');
      $data['content'] = theme($this->block_side1, $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
        'status' => 0,
        'datemodified' => now()
      );
      $prefix = $this->db->dbprefix;
      $this->db->where('id', $code);
      $this->db->where('status', 1);
      $this->db->where('physician_code', $this->userinfo['code']);
      $this->db->update('med_diagnostic', $data);

      if ($this->input->post('redirect') !== FALSE)
        $redirect = base64_decode($this->input->post('redirect'));

      redirect($redirect);

      return;
    }
  }


  /**
   * changes the status of the appointment to 'remove'
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with the code of the appointment
   *
   * @public
   *
   * @return nothing
   */
  function remove() {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->load->helper(array('url'));

    $redirect = $this->module_url;
    if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] != '') {
      $tmp = $_SERVER['HTTP_REFERER'];
      $tmp = trim(substr($tmp, strlen($this->config->site_url()), strlen($tmp)));
      if ($redirect != '') $redirect = $tmp;
    }

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }


    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('diagnostic_delete')).'<br />'
      . $err
      . Ask_yesno_form (
        sprintf($this->lang->line('diagnostic_askremove'), $code),
        $this->module_url.'/remove/'.$code,
        $redirect,
        form_hidden('redirect', base64_encode($redirect))
      );

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('appointment_title');
      $data['content'] = theme($this->block_side1, $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {

      // !!$this->db->query ('LOCK TABLES ' . $this->db->dbprefix . 'med_diagnostic WRITE');

      $this->db->where('id', $code);
      $this->db->where('status', 1);
      $this->db->where('is_cid', 1);
      $this->db->from('med_diagnostic');
      $query = $this->db->get();

      if ($query->num_rows() > 0) {
        $row = $query->row();

        $data = array(
          'status' => 2,
          'datemodified' => now()
        );
        $prefix = $this->db->dbprefix;
        $this->db->where('id', $code);
        $this->db->update('med_diagnostic', $data);

        $sql = sprintf(
          "INSERT INTO %smed_diagnostic
          (physician_code,
            datecreated,
            status,
            appointment_id,
            speciality_code,
            patient_code,
            diagnostic,
            is_cid,
            diagnosis_code,
            is_attach,
            attach_name,
            attach_mime,
            attach_size,
            attach_file,
            attach_description)

          VALUES (
            '%s',
            '%s',
            -1,
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s'
          )",
          $prefix,
          $this->userinfo['code'],
          now(),
          $row->appointment_id,
          $row->speciality_code,
          $row->patient_code,
          $row->diagnostic,
          $row->is_cid,
          $row->diagnosis_code,
          $row->is_attach,
          $row->attach_name,
          $row->attach_mime,
          $row->attach_size,
          $row->attach_file,
          $row->attach_description
        );

        $this->db->query ($sql);

      }

      // !!$this->db->query ('UNLOCK TABLES');

      if ($this->input->post('redirect') !== FALSE)
        $redirect = base64_decode($this->input->post('redirect'));

      redirect($redirect);

      return;
    }
  }

}
?>
