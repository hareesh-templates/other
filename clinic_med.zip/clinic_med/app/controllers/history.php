<?php

/**
 * @file history.php
 * @brief File to show/print the patients history
 * 
 * @class History
 * @brief Class to show/print the patients history
 *
 * @details this class manages the medical history of patients
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class History extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "history";

  /**
   * the title for this controller
   */ 
  var $module_name = "Medical History";

  /**
   * the name of the DB table that this class uses
   */ 
  var $dbtablename = "med_diagnostic";

  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function History () {
    parent::Controller();

    if (!is_module(str_replace('.php', '', pathinfo(__FILE__, PATHINFO_BASENAME)))) {
      $this->load->helper('url');
      redirect('principal/accessdenied');
      return;
    }

  }

  /**
   * Actions Submenu for this controller
   *
   * returns a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   * @param moreitems array aditional items to include in the submenu
   *
   * @return string
   */
  function _thissubmenu($title, $moreitems='') {

    $this->load->helper(array('url'));

    $items = array();
    //$items[] = anchor($this->module_url . '/print_friendly', $this->lang->line('medhistory_print_friendly'));

    if (is_array($moreitems)) {
      $items = array_merge($items, $moreitems);
    }

    return navbarsubmenu($title, $items, 'med_history.png');
  }

  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {
    $this->load->helper(array('url'));
    redirect();
  }


  /**
   * send to browser the patient history in a printer friendly format
   *
   * @public
   *
   * @return nothing
   */
  function print_friendly () {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url', 'cookie'));
    $this->load->library(array('pagination'));

    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ( ! $code) {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

//erm recuperar cualquier cookie de mensaje
//------------------------------------------------------------------------------


    echo '
    <head>
      <meta content="text/html; charset=utf-8" http-equiv="content-type" >

      <meta content="Adalid-Soft" name="author" >
      <link rel="shortcut icon" href="http://10.0.0.5/erm-dev/clinic/img/favicon.ico" type="image/x-icon" >

      <link rel="stylesheet" href="http://10.0.0.5/erm-dev/clinic/img/theme_default/style.css" type="text/css">
      <title>Clinic Manager - Patient History</title>
    </head>
    <body style="background-color: #FFFFFF; color: #000000;" >
    ';

    //echo  '<div class="print_friendly" ><div id="main" class="main">';
    echo  '<div align="center"> <div class="print_friendly" >';
    echo  $this->_get_patient ($code, '_print_friendly_');
    echo  '</div></div>';

    echo '
    <script type="text/javascript">
    <!--
    print();
    -->
    </script>
    ';

    echo '</body>';

  }


  /**
   * sends to browser a themed view of the patient profile
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with the code of the patient
   * 
   * this method uses as paramenter the URI segment 4.
   * that segment is a string with the code of the speciality
   *
   * @public
   *
   * @return nothing
   */
  function patient () {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url', 'cookie'));
    $this->load->library(array('pagination'));

    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ( ! $code) {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

    $code2 = $this->input->xss_clean($this->uri->segment(4, ''));

//erm recuperar cualquier cookie de mensaje
//------------------------------------------------------------------------------
    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $items = array();
    $items[] =  anchor('diagnostic/patient/' . $code, $this->lang->line('diagnostic_no_appointment'));
    $items[] =  anchor_popup('history/print_friendly/' . $code, $this->lang->line('medhistory_print_friendly'));

    $content = '';
    $content .= $msg;
    $content .= $this->_thissubmenu($this->lang->line('medhistory_title'), $items);
    $content .= $this->_get_patient ($code, $code2);

//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------
    make_blocks();
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('medhistory_title');
    $data['content'] = theme($this->block_side1, $content, $this->block_side2);
    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * sends to browser a simple echo of the patient profile
   *
   * this is intented to be used with an ajax request
   *
   * this method uses as paramenter the URI segment 3.
   * that segment is a string with the code of the patient
   * 
   * this method uses as paramenter the URI segment 4.
   * that segment is a string with the code of the speciality
   *
   * @public
   *
   * @return nothing
   */
  function patient_ () {

    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ( ! $code) {
      echo msgErr('', $this->lang->line('admin_ignoringtask'));
      return;
    }

    $code2 = $this->input->xss_clean($this->uri->segment(4, ''));

    echo $this->_get_patient ($code, $code2, true);

  }


//erm RETURN the name of the CID table in base to user language.
//    IT DOT NOT include DB prefix
//    If table language not found then return english as default
//------------------------------------------------------------------------------

  /**
   * returns the locale CID table name
   *
   * this method search in the database the proper name of the CID table
   * based in the language selected by the user
   * 
   * The name returned does not include the DB prefix
   * If table language does not exists then english one will be returned instead
   *
   * @private
   *
   * @return string
   */
  function _get_cid_tablename () {

    static $name = '';
    if ($name != '') {
      return $name;
    }

    $name = 'med_cid10_'.$this->config->item('language');
    if ( ! $this->db->table_exists('med_cid10_'.$this->config->item('language'))) {
      $name = 'med_cid10_english';
    }

    return $name;
  }


  /**
   * returns the patient medical history grouped by speciality
   *
   * if speciality is not provided, then all groups are "closed"
   * when speciality is provided, that group is "open"
   *
   * @private
   * @param code string the code of the patient
   * @param code2 string the code of the speciality
   * @param showdel boolean shows or not show the delete button
   *
   * @return string
   */
  function _get_patient ($code, $code2='', $showdel=false) {

    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->helper(array('url', 'cookie', 'date'));
    $this->load->library(array('table'));

//erm cargar la informacion del paciente desde la DB
//------------------------------------------------------------------------------

    $this->db->where('code', $code);
    $query = $this->db->get('med_patient');
    $patient = $query->row_array();

    $patient['createddate'] = gmt_to_local($patient['createddate'], $this->config->item('timezone'));
    $patient['createddate'] = date('Y M d / h:i a', $patient['createddate']);

    $this->table->add_row(sprintf('<b>%s:</b>', $this->lang->line('patient_patient')), sprintf('<h1> %s </h1>', $patient['name']));
    $this->table->add_row(sprintf('<b>%s:</b>', $this->lang->line('patient_code')), $patient['code']);
    $this->table->add_row(sprintf('<b>%s:</b>', $this->lang->line('admin_email')), $patient['email']);
    $this->table->add_row(sprintf('<b>%s:</b>', $this->lang->line('patient_datecreated')), $patient['createddate']);
    $this->table->add_row(sprintf('<b>%s:</b>', $this->lang->line('admin_notes')), $patient['notes']);

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=0 style="width:100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">'
    );
    $this->table->set_template($tmpl);

//erm cargar el historial desde la base de datos
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->select(sprintf(
      'a.id, a.physician_code, a.datecreated, a.speciality_code, a.diagnostic, a.diagnosis_code, a.status, a.is_cid,
      a.is_attach, a.attach_name, a.attach_size, a.attach_mime, a.attach_description,
      (SELECT name FROM %smed_patient WHERE code=a.patient_code) as patient,
      (SELECT name FROM %susers WHERE code=a.physician_code) as physician,
      (SELECT name FROM %smed_specialities WHERE code=a.speciality_code) as speciality,
      (SELECT concat(diagnosis_code, " ", description) FROM %s'.$this->_get_cid_tablename().' WHERE diagnosis_code=a.diagnosis_code) as cid,
      (SELECT status FROM %smed_appointment WHERE id=a.appointment_id) as app_status
      FROM %smed_diagnostic as a
      ',
      $prefix,
      $prefix,
      $prefix,
      $prefix,
      $prefix,
      $prefix
    ));
    $this->db->where('a.patient_code', $code);
    $this->db->where('a.status != ', 0);
    $this->db->orderby('speciality');
    $this->db->orderby('datecreated DESC');
    $query = $this->db->get();

    $js    = '';
    $lista = '';
    $sprintf = '
    <div class="medhistory_speciality" id="speciality_%d" >%s</div>
    <div class="medhistory_speciality_block" id="block_%d" style="display: %s;" >%s</div>
    ';

    $icds = array();

    $i = 0;
    if ($query->num_rows() > 0) {

      $block = '';
      $speciality = '';
      $display = 'block';

      foreach ($query->result() as $row) {

        if ($speciality != $row->speciality) {

          if ($speciality != '') {
            $lista .= sprintf(
              $sprintf,
              $i,
              $speciality,
              $i,
              $display,
              sprintf('<div>%s</div>', $block)
            );
            $block = '';
            $i++;
          }
          $speciality = $row->speciality;
          if ($code2 != $row->speciality_code && $code2 != '_print_friendly_') {
            $display = 'none';
          } else {
            $display = 'block';
          }

        }

        $row->datecreated = gmt_to_local($row->datecreated, $this->config->item('timezone'));

        $actions = '';

        //if ($showdel && $this->userinfo['is_physician'] && $row->status == 1  && $row->app_status == 4) {
        if ($showdel && $this->userinfo['is_physician'] && $row->status == 1 && $row->is_cid) {
          $action_url = site_url().'/diagnostic/remove/'.$row->id;
          $txt = $this->lang->line('diagnostic_remove');
          $actions .= sprintf(
            '<div align="center" style="display: table-cell; padding: 4px;" > %s <br /> %s</div>',
            sprintf('<a href="%s">%s</a>', $action_url, theme_imgtag ('remove16.png', $txt, $txt)),
            anchor($action_url, $txt)
          );
        }

        //if ($showdel && $this->userinfo['is_physician'] && $row->physician_code == $this->userinfo['code'] && $row->status == 1  && $row->app_status == 4) {
        if ($showdel && $this->userinfo['is_physician'] && $row->physician_code == $this->userinfo['code'] && $row->status == 1) {

          $action_url = site_url().'/diagnostic/delete/'.$row->id;
          $txt = $this->lang->line('diagnostic_delete');
          $actions .= sprintf(
            '<div align="center" style="display: table-cell; padding: 4px;" > %s <br /> %s </div>',
            sprintf('<a href="%s">%s</a>', $action_url, theme_imgtag ('delete16.png', $txt, $txt)),
            anchor($action_url, $txt)
          );
        }

        if ($row->cid != '') {
          $row->cid = sprintf('%s %s', $this->lang->line('diagnostic_cid'), $row->cid);

          if ($row->status == 1) {

            $tmp = '';

            if ($showdel && $this->userinfo['is_physician'] && $row->status == 1) {
              $action_url = site_url().'/diagnostic/remove/'.$row->id;
              $txt = $this->lang->line('diagnostic_remove');
              $tmp = sprintf(
                '<a href="%s" title="%s"> <img src="%s" alt="%s" border=0 hspace=2 /> </a>',
                $action_url, $txt, $this->config->item('theme_url').'remove16.png', $txt);
              }

            $icds[] = $tmp . $row->cid;
          }
        }

        $attach = '';
        if ($row->is_attach) {
          $txt = $this->lang->line('diagnostic_download');

          $attach =
          sprintf (
            '<div><b>%s</b> (%s %s)</div>
             <div>%s</div>
            ',
            anchor('diagnostic_attach/download/'.$row->id, $row->attach_name),
            $row->attach_size,
            $row->attach_mime,
            $row->attach_description
          );
        }

        $class_delete = '';
        if ($row->status == -1) {
          $class_delete = 'style="text-decoration: line-through;;"';
        }

        if ($row->cid != '') $row->cid = sprintf('<div '.$class_delete.' class="medhistory_cid"> %s </div>', $row->cid);
        if ($row->diagnostic != '') $row->diagnostic = sprintf('<div '.$class_delete.' class="medhistory_text"> %s </div>', $row->diagnostic);
        if ($attach != '') $attach = sprintf('<div '.$class_delete.' class="medhistory_file"> %s </div>', $attach);

        $block .= sprintf(
          '<div class="medhistory_diagnostic">
            <table width="100%%"><tr>
              <td width="175px">
                <div>%s</div>
                <div>%s</div>
              </td>
              <td>
                %s
                %s
                %s
              </td>
              <td align="right" valign="middle" >%s</td>
            </tr></table>
          </div>',
          sprintf('%s %s', $this->lang->line('appointment_dr'), $row->physician != '' ? $row->physician : $row->physician_code),
          date('Y M d / h:i a', $row->datecreated),
          $row->cid,
          $row->diagnostic,
          $attach,
          $actions
        );
      }

      $lista .= sprintf(
        $sprintf,
        $i,
        $speciality,
        $i,
        $display,
        sprintf('<div>%s</div>', $block)
      );
      $block = '';
      $i++;

      $tmp = '';
      for ($j=0; $j<$i; $j++) {
        //$tmp .= sprintf('$("speciality_%d").addEvent("click", function(e) {$("block_%d").fade("toggle");});', $j, $j);
        $tmp .= sprintf(
          '$("speciality_%d").addEvent("click", function(e) {
            if ($("block_%d").getStyle("display") == "none") {
              $("block_%d").setStyle("display", "");
            } else {
              $("block_%d").setStyle("display", "none");
            }
          });
          ', $j, $j, $j, $j
        );
      }
      $js = '
      <script type="text/javascript" >
        window.addEvent("domready", function() {
          '.$tmp.'
        });
      </script>
      ';

    } else {
      $lista = $this->lang->line('medhistory_empty');
    }

    if (sizeof($icds) > 0) {
      $this->table->add_row(
        sprintf('<b> %s </b>', $this->lang->line('medhistory_summary')),
        sprintf('<div class="medhistory_cid"> %s </div>', implode('<br />', $icds))
      );
    }
    $patient_info =  sprintf('<div class="medhistory_patientinfo">%s</div>', $this->table->generate());

//erm enviar los resultados a la salida
//------------------------------------------------------------------------------

    $content = '';
    $content .= sprintf('<h2>%s</h2>', $this->lang->line('medhistory_title'));
    $content .= $patient_info;
    $content .= $lista;

    if ($code2 != '_print_friendly_') {
      $content .= $js;
    }

    return $content;

  }


}
?>
