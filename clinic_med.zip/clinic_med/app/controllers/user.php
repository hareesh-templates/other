<?php

/**
 * @file user.php
 * @brief File to manage users
 * 
 * @class User
 * @brief Class to manage users
 *
 * @details this class allows: register, login, logout, reset password, update profile
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class User extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "user";

  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function User() {
    parent::Controller();

    if (!is_module(str_replace('.php', '', pathinfo(__FILE__, PATHINFO_BASENAME)))) {
      $this->load->helper('url');
      redirect('principal/accessdenied');
      return;
    }

    $this->settingsfromdb->loadconfig('users');
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    $items[] = anchor($this->module_url, $this->lang->line('users_youraccount'));
    $items[] = anchor($this->module_url.'/profile', $this->lang->line('users_profile'));
    $items[] = anchor($this->module_url.'/logout', $this->lang->line('users_logout'));

    return navbarsubmenu($title, $items, 'users.png');
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {
//erm probar si esta logueado, sino, enviarlo a login
    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->helper(array('url','cookie','date'));
    $this->load->library(array('table'));

    if (is_user() == 0) {

      $data = array('redirect'=>'');
      $this->session->set_userdata($data);

      redirect($this->module_url.'/login');
      return;
    }

    $content =
    $this->_thissubmenu($this->lang->line('users_youraccount'))
    .'<br />'
    .$this->_lastloginfo()
    .$this->_mymoduleslinks();

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    make_blocks();
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('users_title');
    $data['content'] = theme($this->block_side1, $msg.$content, $this->block_side2);

    $this->load->view($this->config->item('theme'), $data);
   }


  /**
   * return html with link list of  granted modules for the logged user
   *
   * @private
   *
   * @return string (html)
   */
  function _mymoduleslinks() {

    $links = '';
    $modules_granted = get_granted_modules();
    if (is_array($modules_granted)) {
      foreach ($modules_granted as $code => $name) {
        if (strpos($name, '.:hidden:.') === false) {
          $links .= anchor($code, $name).'<br />';
        }
      }
    }

    $text = '';
    $text .= '<br />';
    $text .= msgNormal($this->lang->line('users_modulesgranted'), $links);
    return $text;

  }


  /**
   * returns html with last login information (ip and date)
   *
   * @private
   *
   * @return string (html)
   */
  function _lastloginfo() {

    $img = theme_imgtag ('lastlog.png', "",  "", " align='middle' style='float: left;' hspace='10' vspace='10'");

    $text = '';
    $text .= '<div class="table_1">';
    $text .= $img;

    $last1 = unix_to_human(gmt_to_local($this->userinfo['lastlogdate'], $this->config->item('timezone'))) . '  '
    .$this->lang->line('main_lastip') . '  '
    .$this->userinfo['lastip'];

    $last2 = unix_to_human(gmt_to_local($this->userinfo['lastlogdate2'], $this->config->item('timezone'))) . '  '
    .$this->lang->line('main_lastip') . '  '
    .$this->userinfo['lastip2'];

    $this->table->add_row('<b>'.$this->lang->line('main_lastloginfo').'</b>');
    $this->table->add_row('1. '. $last1);
    $this->table->add_row('2. '. $last2);
    $this->table->add_row($this->lang->line('main_yourip') .': '. $this->input->ip_address());

    $tmpl = array ('table_open'  => '<table border=0 width="100%">');
    $this->table->set_template($tmpl);

    $text .=
    '<br />'
    .$this->table->generate()
    .'</div>';

    return $text;

  }

  /**
   * send to browser the user login form, do the validation process, and if it is successfull, then login the user
   *
   * @public
   *
   * @return nothing
   */
  function login() {

    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->helper(array('url','form','cookie','date'));
    $this->load->library(array('validation','table'));
    $this->load->plugin('captcha');

    if (is_user() == 1) {
      $msg = base64_encode(msgWarning('', $this->lang->line('login_alreadylog')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['User_Name']  = "trim|required|xss_clean";
    $rules['Password']  = "trim|required|xss_clean";
    $rules['Security_Code']  = "trim|required|strtoupper|md5|matches[Code]";
    $this->validation->set_rules($rules);

    $fields['User_Name'] = $this->lang->line('login_user');
    $fields['Password'] = $this->lang->line('login_pass');
    $fields['Security_Code'] = $this->lang->line('login_entercaptcha');
    $fields['Code'] = $this->lang->line('login_captcha');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $vals = array(
      'word'     => '',
      'img_path'   => '././captcha/',
      'img_url'   => $this->config->item('base_url').'captcha/',
      'font_path'   => './system/texb.ttf',
      'expiration' => 120
      );
      $img = create_captcha($vals);


      $data = array('name' => 'User_Name', 'id' => 'User_Name', 'value' => $this->validation->User_Name, 'size' => '16');
      $this->table->add_row($this->lang->line('login_user'), form_input($data).$this->lang->line('admin_required'));

      $data = array('name' => 'Password', 'id' => 'Password', 'value' => $this->validation->Password, 'size' => '16');
      $this->table->add_row($this->lang->line('login_pass'), form_password($data).$this->lang->line('admin_required'));

      $this->table->add_row("",$this->lang->line('users_captchanote'));

      $data = array('name' => 'Security_Code', 'id' => 'Security_Code', 'value' => '', 'size' => '16');
      $this->table->add_row($this->lang->line('login_entercaptcha'), form_input($data).$this->lang->line('admin_required'));

      $this->table->add_row($this->lang->line('login_captcha'), $img['image']);

      $this->table->add_row('', form_submit('submit', $this->lang->line('login_login')));

      $attributes = array('id' => 'formLogin', 'name' => 'formLogin');
      $hidden = array('Code' => md5($img['word']));

      $form = form_open($this->module_url.'/login', $attributes, $hidden)
      .$err
      .$this->table->generate()
      .form_close()
      ."<br />".$this->lang->line('users_cookienote')."<br />";

      if ($this->config->item('users_accept') == 1) {
        $form .= "<br />".anchor($this->module_url.'/register', $this->lang->line('users_register'));
      }

      $form .= "<br />".anchor($this->module_url.'/forgot', $this->lang->line('users_forgot'));

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $subtitle = "<h2>".$this->lang->line('users_youcansignhere')."</h2>";

      $data = default_Vars_Content();
      make_blocks();
      $data['title'] .= ' - ' . $this->lang->line('users_title');
      $data['content'] = theme($this->block_side1, $msg.$subtitle.$form, $this->block_side2);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $where = array('status<>'=>0,'code'=>$this->validation->User_Name,'password'=>md5($this->validation->Password),'password<>'=>'');
      $query = $this->db->getwhere('users', $where);
      if ($query->num_rows() > 0) {

        $row = $query->row();

        if ($row->status != 1) {
          //erm. credenciales del login ok, pero user no esta activo
          $msg = base64_encode(msgErr('', $this->lang->line('users_nologinallowed')));
          set_cookie('msg', $msg, 0);
          redirect($this->module_url.'/login');
          return;
        }

        $data = array(
        'user'=>$row->code,
        'userpass'=>$row->password,
        'usertheme'=>$row->theme,
        'userlang'=>$row->lang,
        'usertimezone'=>$row->timezone
        );
        $this->session->set_userdata($data);

        $where = ' WHERE code="'.$this->validation->User_Name.'" && password="'.md5($this->validation->Password).'"';
        $slq = 'UPDATE '.$this->db->dbprefix.'users SET lastlogdate2=lastlogdate, lastlogdate='.now()
        .', lastip2=lastip, lastip="'.$this->input->ip_address().'" '
        .', session_id="'.$this->session->userdata('session_id').'"'
        . $where;
        $this->db->query($slq);

        $redirect = $this->module_url;
        if ($this->session->userdata('redirect')) {
          $redirect = $this->session->userdata('redirect');
        }

        $data = array('redirect'=>'');
        $this->session->set_userdata($data);

        redirect($redirect);
        return;
        //erm. la informacion provista para conexion es correcta

      } else {
        //erm. login fallado, preguntar de nuevo.
        $msg = base64_encode(msgErr('', $this->lang->line('login_failed')));
        set_cookie('msg', $msg, 0);
        redirect($this->module_url.'/login');
        return;
      }
    }
  }


  /**
   * logout an user
   *
   * @public
   *
   * @return nothing
   */
  function logout() {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    $msg = base64_encode(msgSuccess('', $this->lang->line('login_logoutsuccess')));
    set_cookie('msg', $msg, 0);

    $this->db->where('code', $this->session->userdata('user'));
    $this->db->where('password', $this->session->userdata('userpass'));
    $data = array('session_id' => '');
    $this->db->update('users', $data);

    $data = array(
    'user'=>'',
    'userpass'=>'',
    'usertheme'=>'',
    'userlang'=>'',
    'usertimezone'=>''
    );

    $this->session->set_userdata($data);

    redirect($this->module_url.'/login');

  }


  /**
   * send to browser a register form, do the validation proccess and if it is successfull then add the new user with inactive status
   *
   * @public
   *
   * @return nothing
   */
  function register() {

    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->helper(array('url','form', 'cookie','date'));
    $this->load->library(array('validation', 'table'));
    $this->load->plugin('captcha');

    if (is_user() == 1) {

      $data = array('redirect'=>'');
      $this->session->set_userdata($data);

      $msg = base64_encode(msgWarning('', $this->lang->line('login_alreadylog')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

    if ($this->config->item('users_accept') == 0) {
      $msg = base64_encode(msgErr('', $this->lang->line('users_nonewaccounts')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/login');
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['User_Name']  = "trim|strip_tags|required|xss_clean|callback__unique_code_check";
    $rules['Password']  = "trim|required|xss_clean";
    $rules['Password2']  = "trim|required|matches[Password]|xss_clean";
    $rules['Email']  = "trim|required|valid_email|xss_clean";
    $rules['Security_Code']  = "trim|required|strtoupper|md5|matches[Code]";
    $this->validation->set_rules($rules);

    $fields['User_Name'] = $this->lang->line('users_username');
    $fields['Password'] = $this->lang->line('admin_password');
    $fields['Password2'] = $this->lang->line('admin_passwordagain');
    $fields['Email'] = $this->lang->line('admin_email');
    $fields['Security_Code'] = $this->lang->line('login_entercaptcha');
    $fields['Code'] = $this->lang->line('login_captcha');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $vals = array(
      'word'     => '',
      'img_path'   => '././captcha/',
      'img_url'   => $this->config->item('base_url').'captcha/',
      'font_path'   => './system/texb.ttf',
      'expiration' => 120
      );
      $img = create_captcha($vals);


      $data = array('name' => 'User_Name', 'id' => 'User_Name', 'value' => $this->validation->User_Name, 'size' => '16');
      $this->table->add_row($this->lang->line('users_username'), form_input($data).$this->lang->line('admin_required'));

      $data = array('name' => 'Password', 'id' => 'Password', 'value' => $this->validation->Password, 'size' => '16');
      $this->table->add_row($this->lang->line('admin_password'), form_password($data).$this->lang->line('admin_required'));

      $data = array('name' => 'Password2', 'id' => 'Password2', 'value' => $this->validation->Password2, 'size' => '16');
      $this->table->add_row($this->lang->line('admin_passwordagain'), form_password($data).$this->lang->line('admin_required'));

      $data = array('name' => 'Email', 'id' => 'Email', 'value' => $this->validation->Email, 'size' => '26');
      $this->table->add_row($this->lang->line('admin_email'), form_input($data).$this->lang->line('admin_required'));

      $this->table->add_row("",$this->lang->line('users_captchanote'));

      $data = array('name' => 'Security_Code', 'id' => 'Security_Code', 'value' => '', 'size' => '16');
      $this->table->add_row($this->lang->line('login_entercaptcha'), form_input($data).$this->lang->line('admin_required'));

      $this->table->add_row($this->lang->line('login_captcha'), $img['image']);

      $this->table->add_row("",msgWarning('',$this->lang->line('users_iacceptnote')));

      $this->table->add_row('', form_submit('submit', $this->lang->line('users_createaccount')));

      $attributes = array('id' => 'formRegister', 'name' => 'formRegister');
      $hidden = array('Code' => md5($img['word']));

      $form =
      msgNormal('',$this->lang->line('users_ifyouhaveaccount').' '.anchor($this->module_url.'/login', $this->lang->line('users_youcansignhere')))
      .form_open($this->module_url.'/register', $attributes, $hidden)
      .$err
      .$this->table->generate()
      .form_close();

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $subtitle = "<h2>".$this->lang->line('users_register')."</h2>";

      $data = default_Vars_Content();
      make_blocks('1');
      $data['title'] .= ' - ' . $this->lang->line('users_title');
      $data['content'] = theme($this->block_side1, $msg.$subtitle.$form, "");

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $now = now();

      $data = array(
      'code' => $this->validation->User_Name,
      'name' => '',
      'password' => md5($this->validation->Password),
      'email' => $this->validation->Email,
      'createddate' => $now,
      'groups' => '',
      'lastlogdate' => 0,
      'lang' => $this->config->item('language'),
      'theme' => $this->config->item('theme'),
      'timezone' => $this->config->item('timezone'),
      'notes' => "",
      'status' => 0
      );
      $this->db->insert('users', $data);

//erm send a confirmation email
//--------------------------------------------------------------------
      $md5code = md5($now . $this->validation->User_Name . $this->config->item('encryption_key'));

      $verifylink = "{unwrap}"
      .anchor($this->module_url.'/activate/'.$md5code)
      ."<br /><br />"
      .$this->lang->line('users_username').": ".$this->validation->User_Name
      ."<br />"
      .$this->lang->line('admin_password').": ".$this->validation->Password
      ."{/unwrap}";

      $this->load->library('email');

      $config['priority'] = 1;
      $this->email->initialize($config);

      $this->email->from($this->config->item('users_fromemail'));
      $this->email->to($this->validation->Email);
      $this->email->subject($this->config->item('users_verifysubject'));
      $this->email->message(sprintf($this->config->item('users_verifymessage'), $verifylink));
      $this->email->send();

      redirect($this->module_url.'/emailverify');
      return;

    }
  }

  /**
   * look for the user code in DB, if it already exists return FALSE, else TRUE
   * 
   * @param str string The code to look for
   *
   * @public
   *
   * @return boolean
   */
  function _unique_code_check($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('users');
    if ($query->num_rows() > 0) {
      $this->validation->set_message('_unique_code_check', $this->lang->line('users_usernametaken'));
      return FALSE;
    } else {
      return TRUE;
    }
  }

  /**
   * look for the user code in DB, if it exists return TRUE, else FALSE
   *
   * @param str string The code to look for
   * 
   * @private
   *
   * @return boolean
   */
  function _code_exists($str) {
    $this->db->where(array('code'=>$str, 'status'=>1));
    $this->db->select("code");
    $query = $this->db->get('users');
    if ($query->num_rows() == 0) {
      $this->validation->set_message('_code_exists', $this->lang->line('users_usernoexist'));
      return FALSE;
    } else {
      return TRUE;
    }
  }

  /**
   * send to browser an email verification warning to activate the new registered user
   *
   * @public
   *
   * @return nothing
   */
  function emailverify() {

    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->helper(array('url','cookie'));

//erm poner en cache la pagina si es que esta activa la opcion
//------------------------------------------------------------------------------
    if ($this->config->item('cacheenabled')) {
      $this->output->cache($this->config->item('cachetime'));
    }

    $content = "<h2>".$this->lang->line('users_emailverify')."</h2>"
    .$this->lang->line('users_emailverifynote')
    ."<br /><br />"
    .$this->lang->line('users_alreadyverified') . " "
    .anchor($this->module_url.'/login', $this->lang->line('users_youcansignhere'));


    make_blocks();

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('users_title');
    $data['content'] = theme($this->block_side1, $content, $this->block_side2);

    $this->load->view($this->config->item('theme'), $data);
  }


  /**
   * if link is valid and non expired, then activates the new user registered and send the result to browser (succesfull or failed)
   *
   * this method looks for a valid link into URI segment 3
   * 
   * @public
   *
   * @return nothing
   */
  function activate() {

    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->helper(array('url','cookie','date'));

    $now = now();

//erm delete all pending activations older than 24 hrs
    $this->db->where('status=0 && '.$now.'>(createddate+24*60*60)');
    $this->db->delete('users');

    $md5code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($md5code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

//erm activate account when md5code is fount into database
    $data = array(
    'status' => 1
    );
    $where = array ('MD5(CONCAT(createddate, code, '.$this->db->escape($this->config->item('encryption_key')).'))='=>$md5code, 'status'=>0);
    $this->db->where($where);
    $this->db->update('users', $data);

    $subtitle = "";
    $content = "";

    if ($this->db->affected_rows() == 0) {
      $subtitle = "<h2>".$this->lang->line('users_emailexpired')."</h2>";
      $content = $this->lang->line('users_emailexpiredthanks')
      ."<br />"."<br />".anchor($this->module_url.'/register', $this->lang->line('users_register'))."<br />";

    } else {
      $subtitle = "<h2>".$this->lang->line('users_emailverified')."</h2>";
      $content = $this->lang->line('users_emailverifiedthanks')
      ."<br />"."<br />".$this->lang->line('users_alreadyverified').' '.anchor($this->module_url.'/login', $this->lang->line('users_youcansignhere'))."<br />";
    }

    make_blocks();

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('users_title');
    $data['content'] = theme($this->block_side1, $subtitle.$content, $this->block_side2);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * sends to browser a form for "forgotten password", and send an email to user with instructions to reset password
   *
   * @public
   *
   * @return nothing
   */
  function forgot() {
    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->helper(array('form','url','cookie'));
    $this->load->library(array('validation', 'table'));
    $this->load->plugin('captcha');


    $this->validation->set_error_delimiters('','<br />');
    $rules['User_Name']  = "trim|required|xss_clean|callback__code_exists";
    $rules['Security_Code']  = "trim|required|strtoupper|md5|matches[Code]";
    $this->validation->set_rules($rules);

    $fields['User_Name'] = $this->lang->line('users_username');
    $fields['Security_Code'] = $this->lang->line('login_entercaptcha');
    $fields['Code'] = $this->lang->line('login_captcha');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $vals = array(
      'word'     => '',
      'img_path'   => '././captcha/',
      'img_url'   => $this->config->item('base_url').'captcha/',
      'font_path'   => './system/texb.ttf',
      'expiration' => 120
      );
      $img = create_captcha($vals);

      $data = array('name' => 'User_Name', 'id' => 'User_Name', 'value' => $this->validation->User_Name, 'size' => '16');
      $this->table->add_row($this->lang->line('users_username'), form_input($data).$this->lang->line('admin_required'));

      $this->table->add_row("",$this->lang->line('users_captchanote'));

      $data = array('name' => 'Security_Code', 'id' => 'Security_Code', 'value' => '', 'size' => '16');
      $this->table->add_row($this->lang->line('login_entercaptcha'), form_input($data).$this->lang->line('admin_required'));

      $this->table->add_row($this->lang->line('login_captcha'), $img['image']);

      $this->table->add_row('', form_submit('submit', $this->lang->line('users_emailsendpass')));

      $attributes = array('id' => 'formForgot', 'name' => 'formForgot');
      $hidden = array('Code' => md5($img['word']));

      $form =
      $this->lang->line('users_emailforgotmsg')."<br /><br />"
      .form_open($this->module_url.'/forgot', $attributes, $hidden)
      .$err
      .$this->table->generate()
      .form_close()
      ."<br /><br />".$this->lang->line('users_alreadyknowpass').' '.anchor($this->module_url.'/login', $this->lang->line('users_youcansignhere'));

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $subtitle = "<h2>".$this->lang->line('users_emailforgot')."</h2>";

      $data = default_Vars_Content();
      make_blocks();
      $data['title'] .= ' - ' . $this->lang->line('users_title');
      $data['content'] = theme($this->block_side1, $msg.$subtitle.$form, $this->block_side2);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $query = $this->db->getwhere('users', array('code'=>$this->validation->User_Name));
      if ($query->num_rows() > 0) {

        $row = $query->row();

        $md5code = md5($row->password . $row->code . $this->config->item('encryption_key'));
        $link = "{unwrap}".anchor($this->module_url.'/resetpass/'.$md5code)."{/unwrap}";

        $this->load->library('email');

        $config['priority'] = 1;
        $this->email->initialize($config);

        $this->email->from($this->config->item('users_fromemail'));
        $this->email->to($row->email);
        $this->email->subject($this->config->item('users_resetsubject'));
        $this->email->message(sprintf($this->config->item('users_resetinstructions'), $link));
        $this->email->send();

      }

      redirect($this->module_url.'/reset');
      return;
    }
  }

  /**
   * sends to browser a message to let know to the user that must see his email to reset password
   *
   * @public
   *
   * @return nothing
   */
  function reset() {

    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->helper(array('url','cookie'));

//erm poner en cache la pagina si es que esta activa la opcion
//------------------------------------------------------------------------------
    if ($this->config->item('cacheenabled')) {
      $this->output->cache($this->config->item('cachetime'));
    }

    $content = "<h2>".$this->lang->line('users_emailforgot')."</h2>"
    .$this->lang->line('users_emailforgotstep2')
    ."<br /><br />"
    .$this->lang->line('users_alreadyknowpass') . " "
    .anchor($this->module_url.'/login', $this->lang->line('users_youcansignhere'));


    make_blocks();

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('users_title');
    $data['content'] = theme($this->block_side1, $content, $this->block_side2);

    $this->load->view($this->config->item('theme'), $data);
  }


  /**
   * reset the password if the link is valid, then send it to the user by email
   *
   * this method looks for a valid link into URI segment 3
   *
   * @public
   *
   * @return nothing
   */
  function resetpass() {

    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->helper(array('url','cookie'));


    $md5code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($md5code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

//erm reset password when md5code is fount into database

    $where = array('MD5(CONCAT(password, code, '.$this->db->escape($this->config->item('encryption_key')).'))='=>$md5code, 'status'=>1);
    $this->db->where($where);
    $query = $this->db->select('code, email');
    $query = $this->db->get('users');

    $subtitle = "";
    $content = "";

    //if ($this->db->affected_rows() == 0) {
    if ($query->num_rows() == 0) {

      $subtitle = "<h2>".$this->lang->line('users_resetexpired')."</h2>";
      $content = $this->lang->line('users_resetexpiredthanks')
      ."<br />"."<br />".anchor($this->module_url.'/forgot', $this->lang->line('users_forgot'))."<br />";

    } else {

      $row = $query->row();

      $newpass = '';
      //$pool = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $pool = '0123456789abcdefghijklmnopqrstuvwxyz';

      for ($i = 0; $i < 8; $i++) {
        $newpass .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
      }

      $data = array(
      'password' => md5($newpass)
      );
      $this->db->where($where);
      $this->db->update('users', $data);

      $this->load->library('email');

      $config['priority'] = 1;
      $this->email->initialize($config);

      $this->email->from($this->config->item('users_fromemail'));
      $this->email->to($row->email);
      $this->email->subject($this->config->item('users_newpass'));
      $this->email->message(sprintf($this->config->item('users_newpassmsg'), $newpass)."<br /><br />".anchor('user/login'));
      $this->email->send();

      $subtitle = "<h2>".$this->lang->line('users_newpass')."</h2>";
      $content = $this->lang->line('users_newpassmsg')
      ."<br />"."<br />".$this->lang->line('users_alreadyknowpass').' '.anchor($this->module_url.'/login', $this->lang->line('users_youcansignhere'))."<br />";

    }

    make_blocks();

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('users_title');
    $data['content'] = theme($this->block_side1, $subtitle.$content, $this->block_side2);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * sends to browser a form to change the user profile, do the validation proccess, then update the user information
   *
   * @public
   *
   * @return nothing
   */
  function profile() {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm note that is_user () f_unction will get all user information into array variable userinfo
    if (is_user() == 0) {

      $data = array('redirect'=>'');
      $this->session->set_userdata($data);

      $msg = base64_encode(msgErr('', $this->lang->line('users_nologged')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/login');
      return;
    }

//erm buscar si el codigo existe en la base de datos
//------------------------------------------------------------------------------

    $code = $this->userinfo['code'];

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Email'] = $this->lang->line('admin_email');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Password'] = $this->lang->line('admin_password');
    $fields['Language'] = $this->lang->line('admin_lang');
    $fields['timezone'] = $this->lang->line('settings_timezone');
    $fields['Theme'] = $this->lang->line('admin_theme');
    //$fields['Notes'] = $this->lang->line('admin_notes');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {

      $this->validation->Code = $code;
      $this->validation->Name = $this->userinfo['name'];
      $this->validation->Email = $this->userinfo['email'];
      $this->validation->Password = '';
      $this->validation->Language = $this->userinfo['lang'];
      $this->validation->timezone = $this->userinfo['timezone'];
      $this->validation->Theme = $this->userinfo['theme'];
      //$this->validation->Notes = $row->notes;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|xss_clean";
    $rules['Email']  = "trim|required|valid_email|xss_clean";
    $rules['Name']  = "trim|htmlentities|xss_clean";
    $rules['Password']  = "trim|xss_clean";
    $rules['Language']  = "trim|required|xss_clean";
    $rules['timezone']  = "trim|required|xss_clean";
    $rules['Theme']  = "trim|required|xss_clean";
    //$rules['Notes']  = "trim|htmlentities|xss_clean";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

//erm create the form to update user profile
//-----------------------------------------------------------------

      $form = $err;

      $key = 'formProfile';
      $attributes = array('id' => $key, 'name' => $key);
      $form .= form_open($this->module_url.'/profile', $attributes);


//erm login settings
//--------------------------------------------------------------------
      $this->table->add_row('<b>'.$this->lang->line('users_logininfo').'</b>','');

      $data = "<b>".$code."</b>";
      $this->table->add_row($this->lang->line('users_username'), $data.form_hidden('Code', $this->validation->Code));

      $passnote = $this->lang->line('admin_enternewpasstochange');

      $key = 'Password';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
      $this->table->add_row($this->lang->line('admin_password'), form_input($data).$passnote);

//erm contact settings
//--------------------------------------------------------------------
      $this->table->add_row('<b>'.$this->lang->line('users_contactinfo').'</b>','');

      $key = 'Name';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '26');
      $this->table->add_row($this->lang->line('admin_name'), form_input($data));

      $key = 'Email';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '26');
      $this->table->add_row($this->lang->line('admin_email'), form_input($data).$this->lang->line('admin_required'));

//erm website settings
//--------------------------------------------------------------------
      $this->table->add_row('<b>'.$this->lang->line('users_websettings').'</b>','');
      $key = 'Language';
      $this->table->add_row($this->lang->line('admin_lang'), form_dropdown($key, get_lang_list(), $this->validation->$key));

      $key = 'timezone';
      $this->table->add_row($this->lang->line('settings_timezone'), timezone_menu($this->validation->$key, "", $key));

      $key = 'Theme';
      $this->table->add_row($this->lang->line('admin_theme'), form_dropdown($key, get_theme_list(), $this->validation->$key));

      /*
      $key = 'Notes';
      $this->table->add_row($this->lang->line('admin_notes'), textArea($key, $this->validation->$key, 'mini', '150'));
      */

      $this->table->add_row('', '<br />'.form_submit('submit', $this->lang->line('admin_savechanges')));

      $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=0 style="width:100%">',
      'row_start'           => '<tr class="table_1_td1">',
      'row_alt_start'       => '<tr class="table_1_td2">'
      );
      $this->table->set_template($tmpl);

      $form .= $this->table->generate();
      $form .= form_close();

      $form .= "<br />";
      $form .= msgWarning('', $this->lang->line('users_cachenote'));

//erm sent the info in browser
//-----------------------------------------------------------------

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $subtitle = $this->_thissubmenu($this->lang->line('users_youraccount')).'<br />';

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('users_title');
      $data['content'] = theme($this->block_side1, $msg.$subtitle.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      'email' => $this->validation->Email,
      'lang' => $this->validation->Language,
      'theme' => $this->validation->Theme,
      'timezone' => $this->validation->timezone,
      );
      if ($this->validation->Password != "") $data['password'] = md5($this->validation->Password);

      $this->db->where('code', $code);
      $this->db->update('users', $data);

      $data = array(
      'usertheme'=>$this->validation->Theme,
      'userlang'=>$this->validation->Language,
      'usertimezone'=>$this->validation->timezone
      );
      if ($this->validation->Password != "") $data['userpass'] = md5($this->validation->Password);
      $this->session->set_userdata($data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/profile');
      return;
    }

  }

}
?>
