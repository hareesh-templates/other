<?php

/**
 * @file /controllers/content.php
 * @brief File to show content
 * 
 * @class Content
 * @brief Class to show content
 *
 * @details content are articles to be shown either in home page or in content module
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class Content extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "content";


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Content() {
    parent::Controller();

    if (!is_module(str_replace('.php', '', pathinfo(__FILE__, PATHINFO_BASENAME)))) {
      $this->load->helper('url');
      redirect('principal/accessdenied');
      return;
    }
  }

  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    //$items[] = '<b>'.$this->lang->line('med_actions').'</b>';
    //$items[] = anchor($this->module_url.'/add', $this->lang->line('med_add'));

    return navbarsubmenu($title, '', 'content.png');
  }


  /**
   * controller default method
   *
   * this default method send to browser the list of articles splitted by pages
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->lang->load('content');
    $this->load->helper(array('url', 'date', 'text', 'cookie'));
    $this->load->library(array('pagination', 'table'));

//erm poner en cache la pagina si es que esta activa la opcion
//------------------------------------------------------------------------------
    if ($this->config->item('cacheenabled')) {
      $this->output->cache($this->config->item('cachetime'));
    }

    $search_for = $this->input->xss_clean($this->uri->segment(3, ''));
    if ($search_for == '') $search_for = 'all';

//erm creacion de los links
//------------------------------------------------------------------------------
    $itemxpage = 5;
    $uri_segment = 4;

    $config['base_url'] = $this->config->site_url().'/'.$this->module_url.'/index/'.$search_for;

    if ($search_for != 'all') {

      $search_select = ', MATCH (code,title,content,keywords) AGAINST (\''.$search_for.'\' IN BOOLEAN MODE) as relev';
      $search_where  = ' && (MATCH (code,title,content,keywords) AGAINST (\''.$search_for.'\' IN BOOLEAN MODE))';

    } else {
      $search_for = '';
      $search_select = ', concat("") as relev';
      $search_where = '';
    }

    $where = 'enabled=1 && (lang="'.$this->config->item('language').'" || lang="")';

    $this->db->where($where . $search_where);
    $this->db->select('count(*) as numrows');
    $query = $this->db->get('content');

    $numitems = 0;
    if ($query->num_rows() > 0) {
      $row = $query->row();
      $numitems = $row->numrows;
    }

    $config['total_rows'] = $numitems;
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = $uri_segment;
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    $config['num_links'] = '4';
    $this->pagination->initialize($config);
    $pagination = $this->pagination->create_links();

    $begin = intval($this->uri->segment($uri_segment, 0));
    if ($begin < 0) $begin = 0;


//erm recuperar cualquier cookie de mensaje
//------------------------------------------------------------------------------
    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

//erm crear los bloques
//------------------------------------------------------------------------------
    make_blocks();

    $content = '';
    $content .= $this->_thissubmenu($this->lang->line('content_title'));
    $content .= $msg;
    //$content .= $pagination;

//erm cargar la informacion desde la base de datos
//------------------------------------------------------------------------------
    $this->db->select("*" . $search_select);
    $this->db->where($where . $search_where);
    $this->db->orderby("relev DESC, modified DESC, title");
    $query = $this->db->get('content', $itemxpage, $begin);

    if ($query->num_rows() > 0) {
      $img = theme_imgtag ('content.png', $this->lang->line('content_title'),  $this->lang->line('content_title'), ' ');
      foreach ($query->result() as $row) {
        $dates = '<p class="small">'
        .$this->lang->line('content_modified').': '.unix_to_human(gmt_to_local($row->modified, $this->config->item('timezone')))
        .' ' . $this->config->item('timezone')
        .'<br />'
        .$this->lang->line('content_created').': '.unix_to_human(gmt_to_local($row->created, $this->config->item('timezone')))
        .' ' . $this->config->item('timezone')
        .'</p>';

        if ($row->title == '') $row->title = $row->code;
        $title = anchor ('content/show/'.$row->code, $row->title);

        $row->content = str_replace('{base_url}', $this->config->item('base_url'), $row->content);
        $row->content = str_replace('{site_url}', $this->config->site_url(), $row->content);

        if ($row->relev != '') $title .= '<br />' . $this->lang->line('content_relevancy') . ': ' . $row->relev;
        $this->table->add_row($img, $title.'<br />'.word_limiter(strip_tags($row->content), 30).'<br />'.$dates);
      }

      $tmpl = array (
      'table_open'  => '<table class="" cellpadding=4>',
      'row_start'           => '<tr class="table_1_td1">',
      'row_alt_start'       => '<tr class="table_1_td2">',

      );
      $this->table->set_template($tmpl);
      $lista = $this->table->generate();

    } else {
      $lista = $this->lang->line('content_noresults');
    }

    $this->validation->Name = $search_for;
    $content .= $this->_searchForm('basic', $this->module_url.'/search/') . '<br />';

    $content .= $lista;
    $content .= $pagination;

//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('content_title');
    $data['content'] = theme($this->block_side1, $content, $this->block_side2);
    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * 
   * this method send to browser a selected article (content)
   *
   * @public
   *
   * @return nothing
   */
  function show() {

    $this->lang->load('admin');
    $this->lang->load('content');

    $this->load->helper(array('url', 'cookie', 'date'));

//erm poner en cache la pagina si es que esta activa la opcion
//------------------------------------------------------------------------------
    if ($this->config->item('cacheenabled')) {
      $this->output->cache($this->config->item('cachetime'));
    }

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

    $where = 'enabled=1 && code="'.$code.'"';
    $this->db->where($where);
    $query = $this->db->get('content', 1);
    if ($query->num_rows() == 0) {
      $msg = base64_encode(msgErr('', sprintf($this->lang->line('content_noavailable'), $code)));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

    $row = $query->row();

    make_blocks();
    $content = '';

    $dates = '<p class="small">'
    .$this->lang->line('content_modified').': '.unix_to_human(gmt_to_local($row->modified, $this->config->item('timezone')))
    .' ' . $this->config->item('timezone')
    .'<br />'
    .$this->lang->line('content_created').': '.unix_to_human(gmt_to_local($row->created, $this->config->item('timezone')))
    .' ' . $this->config->item('timezone')
    .'</p>';

    $row->content = str_replace('{base_url}', $this->config->item('base_url'), $row->content);
    $row->content = str_replace('{site_url}', $this->config->site_url(), $row->content);

    $content .=
    $this->_thissubmenu($row->title)
    .$row->content.'<br />'
    .$dates;

    $this->config->set_item('keywords', $this->config->item('keywords').' '.$row->keywords);
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('content_title');
    $data['content'] = theme($this->block_side1, $content);

    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * 
   * this method creates a search form
   *
   * @private
   * 
   * @param action string (add or edit options) add create empty form, edit populates the form
   * @param directo string the hmtl form action (url)
   * 
   * @return string
   */
  function _searchForm ($action, $directo) {
    //@action - allowed values: add / edit

    $this->load->helper(array('form'));
    $this->load->library(array('table'));

    $this->table->clear();
    $form =  '';
    $key = 'formSearch';
    $attributes = array('id' => $key, 'name' => $key);
    $form = form_open($directo, $attributes);

    $key = 'Name';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '30');
    $this->table->add_row(
      $this->lang->line('search_keywords')
      .'<br />'
      .form_input($data)
      .' '
      .form_submit('submit', $this->lang->line('search_submit'))
      .'<br />'.anchor_popup(base_url().'doc/search_tips.html', $this->lang->line('search_tips'), '')
    );

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=2 cellspacing=2 style="width:100%;">');
    $this->table->set_template($tmpl);

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }

  /**
   * 
   * send to browser a search themed page and validates the user input
   *
   * @public
   * 
   * @return string
   */
  function search () {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('content');
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));


    $this->validation->set_error_delimiters('','<br />');
    $rules['Name']  = "trim|xss_clean";
    $this->validation->set_rules($rules);


    $fields['Name'] = $this->lang->line('search_keywords');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('content_search'));
      $form .= $err . $this->_searchForm('basic', $this->module_url.'/search/');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('search_title');
      $data['content'] = theme($this->block_side1, $msg.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/index/'.$this->validation->Name);
      return;
    }
  }

}
?>
