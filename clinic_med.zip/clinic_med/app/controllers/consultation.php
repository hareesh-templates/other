<?php

/**
 * @file consultation.php
 * @brief File to manage consultations
 * 
 * @class Consultation
 * @brief Class to manage consultations
 *
 * @details consultations are managed by physicians. they are the list of patients that he/she will handle
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class Consultation extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url  = "consultation";

  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Consultation() {
    parent::Controller();

    if (!is_user()) {
      $this->load->helper(array('url','cookie'));
      $data = array('redirect'=>$this->module_url);
      $this->session->set_userdata($data);
      redirect('user/login');
      return 0;
    }

    if (!is_module(str_replace('.php', '', pathinfo(__FILE__, PATHINFO_BASENAME)))) {
      $this->load->helper('url');
      redirect('principal/accessdenied');
      return;
    }

  }

  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    $items[] = anchor($this->module_url.'/add_bydoc', $this->lang->line('consultation_add_bymed'));
    $items[] = anchor($this->module_url.'/add_byspe', $this->lang->line('consultation_add_byspe'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('consultation_myconsultations'));

    return navbarsubmenu($title, $items, 'users.png');
  }


  /**
   * give format to an appointment
   *
   * @private
   * 
   * @param status string the status of the appointment
   * @param id string the appointment identifier
   * @param timefrom string for this appointment
   * @param timeto string for this appointment
   * @param patient string the patient name
   * @param doctor string the physician name
   * @param notes string the notes for this appointment
   *
   * @return html string
   */
  function _format_appointment ($status, $id, $timefrom, $timeto, $patient, $doctor, $notes ) {

    $this->load->helper(array('date','url'));

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('table'));

    $items = array();

    $txt = '';
    $img = '';
    $class_action = "schedule_action_img";

    if ( $status == -1) { //requested but not aproved yet

      $txt = $this->lang->line('appointment_pending');
      $img = theme_imgtag ('pending.png', $txt, $txt, "class='$class_action'" );

    } elseif ( ! $status ) { //canceled

      $txt = $this->lang->line('appointment_canceled');
      $img = theme_imgtag ('cancel.png', $txt, $txt, "class='$class_action'" );

    } else { //aproved

      $txt = $this->lang->line('appointment_confirmed');
      $img = theme_imgtag ('confirmed.png', $txt, $txt, "class='$class_action'" );
    }

    $menu = sprintf('<div>%s<br />%s</div>', $txt, $img);


    $class_css = '';
    switch ($status) {
      case -1:
        $class_css = 'schedule_appointment';
        break;
      case 0:
      $class_css = 'schedule_empty';
        break;
      default:
        $class_css = 'schedule_free';
        break;
    }

    $data = '';
    $info = '';
    $info = sprintf(
      '<b>%s @ %s - %s</b><br />%s: %s<br />%s %s<br /><i>%s</i>',
      date('d M Y', $timefrom),
      date('h:i a', $timefrom),
      date('h:i a', $timeto),
      $this->lang->line('patient_patient'),
      $patient,
      $this->lang->line('appointment_dr'),
      $doctor,
      $notes
    );

    $data =
    sprintf(
      '<table class="'.$class_css.'" width="100%%" ><tr>
      <td >%s</td>
      <td align="right">%s</td>
      </tr></table>',
      $info,
      $menu
    );

    return $data;
  }


  /**
   * create a list of consutations
   *
   * @private
   *
   * @return html string
   */
  function _show_consultations () {

    $content = '';

    $data = $this->_get_patients_assigned();

    $where = '';
    $data = $this->_get_patients_assigned();
    foreach ($data as $key => $val) {
      if ($where != '') $where .= ' || ';
      $where .= sprintf('patient_code = "%s"' , $key);
    }

    if ($where != '') {

      $prefix = $this->db->dbprefix;
      $this->db->select(sprintf(
        'a.*, b.name as physician, c.name as patient
        FROM %smed_appointment as a
        LEFT JOIN %susers as b ON a.physician_code=b.code && b.is_physician=1
        LEFT JOIN %smed_patient as c ON a.patient_code=c.code
        ',
        $prefix,
        $prefix,
        $prefix
      ));
      $this->db->where('a.time_from > ', intval(now()-(60*60*24*15))); //get last 15 days
      $this->db->where('a.status < ', 4);
      $this->db->where(sprintf('(%s)', $where));

      $this->db->orderby('time_from, physician, patient');
      $query = $this->db->get();



      if ( ! $query->num_rows() ) {

        $content = $this->lang->line('consultation_nopending');

      } else {

        foreach ($query->result() as $row) {
          $content .= $this->_format_appointment (
            $row->status, $row->id, $row->time_from,
            $row->time_to, $row->patient, $row->physician, $row->notes
          );

        }
      }

    } else {
      $content = $this->lang->line('consultation_nopending');
    }

    return $content;

  }

  /**
   * send to browser a themed list of consultations
   *
   * @public
   *
   * @return nothing
   */
  function show () {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url', 'cookie', 'date'));

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content  = '';
    $content .= $msg;
    $content .= $this->_thissubmenu($this->lang->line('consultation_title'));
    $instructions = msgNormal('', nl2br($this->lang->line('consultation_instructions')));
    $content .= '<br />'.$instructions;

    $patients = '';
    $consultations = '';
    if ($this->userinfo['my_patients'] == '') {
      $nopatients = msgErr('', nl2br($this->lang->line('consultation_patients_noassigned')));
    } else {

      $data = $this->_get_patients_assigned();
      $tmp = '';
      foreach ($data as $key => $val) {
        $tmp .= sprintf('<div>%s</div>', $val);
      }
      $patients = msgNormal($this->lang->line('consultation_patients'), $tmp);
      $consultations = $this->_show_consultations();
    }

    $content .= $patients;
    $content .= $consultations;

    make_blocks();
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('consultation_title');
    $data['content'] = theme($this->block_side1, $content, $this->block_side2);

    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * controller default method
   *
   * this default method loads 'show' method
   *
   * @public
   *
   * @return nothing
   */
  function index() {
    $this->show();
  }

  /**
   * loads _add method with true
   *
   * @public
   *
   * @return nothing
   */
  function add_bydoc () {
    if ($this->userinfo['my_patients'] == '') {
      $this->load->helper('url');
      redirect($this->module_url);
      return;
    }
    $this->_add(true);
  }

  /**
   * loads _add method with false
   *
   * @public
   *
   * @return nothing
   */
  function add_byspe () {
    if ($this->userinfo['my_patients'] == '') {
      $this->load->helper('url');
      redirect($this->module_url);
      return;
    }
    $this->_add(false);
  }

  /**
   * frontend themed view to create a form control to ask for an online consultation (appointment)
   * 
   * send to browser a themed view with ajax capabilities and add appoinments into DB
   *
   * @private
   * 
   * @param bydoctor boolean Set to true to show physician control first and includes consul_bydoc.js
   * Set to false to show speciality control first  and includes consul_byspe.js
   *
   * @return nothing
   */
  function _add($bydoctor = true) {

    $this->lang->load('admin');
    $this->lang->load('med_common');

    $this->load->helper(array('cookie', 'date'));

    //erm main vars to initialice make_form
    if ($bydoctor) {
      $vars = array('action'=>'add','directo'=>$this->module_url.'/add_bydoc');
    } else {
      $vars = array('action'=>'add','directo'=>$this->module_url.'/add_byspe');
    }

    $vars['physicians'] = array('-'=>'--- '.$this->lang->line('main_pleaseselect').' ---');
    $vars['specialities'] = array('-'=>'--- '.$this->lang->line('main_pleaseselect').' ---');

    $validation = FALSE;
    $form = $this->_form_main ($vars, $validation, $bydoctor);

    if ($validation == FALSE) {

      $content = $this->_thissubmenu($this->lang->line('consultation_add')).'<br />'.$form;

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      make_blocks();
      $data = default_Vars_Content();
      $data['meta'] .= '
      <meta http-equiv="expires" content="-1" >
      <meta http-equiv="pragma" content="no-cache" >
      ';
      $data['title'] .= ' - ' . $this->lang->line('consultation_title');
      $data['content'] = theme($this->block_side1, $msg.$content);

      if ($bydoctor) {

        $data['java'] .= sprintf(
          '<script type="text/javascript" src="%sinclude/consul_bydoc.js"></script>',
          base_url()
        );

      } else {

        $data['java'] .= sprintf(
          '<script type="text/javascript" src="%sinclude/consul_byspe.js"></script>',
          base_url()
        );

      }

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $tmp = split('-', $this->validation->Form_Hour);

      $tmp[0] = $this->validation->Form_Day . ' ' . trim($tmp[0]);
      $tmp[1] = $this->validation->Form_Day . ' ' . trim($tmp[1]);

      $date1 = strtotime($tmp[0]);
      $date2 = strtotime($tmp[1]);

      if ($this->_check_date_isfree ($date1, $date2, $this->validation->Physician)) {

        $data = array(
        'physician_code' => $this->validation->Physician,
        'speciality_code' => $this->validation->Speciality,
        'patient_code' => $this->validation->patient_selected,
        'time_from' => $date1,
        'time_to' => $date2,
        'datecreated' => now(),
        'status' => -1,
        'notes' => $this->validation->Notes,
        );
        $this->db->insert('med_appointment', $data);

        $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));

      } else {

        $msg = base64_encode(msgErr('', $this->lang->line('appointment_timenoavailable')));

      }
      set_cookie('msg', $msg, 0);
      $this->load->helper(array('url'));

      redirect($this->module_url);
      return;

    }
  }

  /**
   * return an array with patients assigned to the logged user
   * 
   * send to browser a themed view with ajax capabilities and add appoinments into DB
   *
   * @private
   * 
   * @return array
   */
  function _get_patients_assigned () {

    static $data = '';
    if ($data != '') return $data;

    $where = '';
    $tmp = explode('-', $this->userinfo['my_patients']);
    foreach ($tmp as $val) {
      if ($where != '') $where .= ' || ';
      $where .= sprintf('code = "%s"' , $val);
    }

    $data = array();
    if ($where != '') {
      $this->db->where('status', 1);
      $this->db->where(sprintf('(%s)', $where));
      $this->db->select('name, code');
      $query = $this->db->get('med_patient');

      foreach ($query->result() as $row) {
        $data[$row->code] = $row->name;
      }
    }

    return $data;
  }


  /**
   * return a html with form to add consultation
   *
   * @private
   * 
   * @return string
   */
  function _form_main ($vars, &$validation, $bydoctor) {
    //@action - allowed values: add / edit

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('form', 'url'));
    $this->load->library(array('validation', 'table'));

    $speciality_tag = 'Speciality';
    $physician_tag = 'Physician';
    $calendar_tag = 'Form_Day';
    $time_tag = 'Form_Hour';
    $patient_tag = 'patient_selected';


    $this->validation->set_error_delimiters('','<br />');
    $rules[$speciality_tag]  = "trim|required|xss_clean|callback__check_speciality";
    $rules[$physician_tag]  = "trim|required|xss_clean|callback__check_physician";
    $rules[$calendar_tag]  = "trim|required|xss_clean|callback__check_valid_day";
    $rules[$time_tag]  = "trim|required|xss_clean|callback__check_valid_time";
    $rules[$patient_tag]  = "trim|required|xss_clean|callback__check_patient";
    $rules['Notes']  = "trim|xss_clean";

    $this->validation->set_rules($rules);

    $fields[$speciality_tag] = $this->lang->line('specialities_name');
    $fields[$physician_tag] = $this->lang->line('physician_physician');
    $fields[$calendar_tag] = $this->lang->line('schedule_day');
    $fields[$time_tag] = $this->lang->line('schedule_time');
    $fields[$patient_tag] = $this->lang->line('patient_patient');
    $fields['Notes'] = $this->lang->line('admin_notes');
    $this->validation->set_fields($fields);

    $form = "";
    $validation = $this->validation->run();

    if ($validation == FALSE) {

      if ($vars['action'] == 'edit') {
        $this->validation->Code = $vars['Code'];
        $this->validation->Physician = $vars['Physician'];
        $this->validation->Speciality = $vars['Speciality'];
      }

      if ($this->validation->error_string != "") $form .= msgErr("",$this->validation->error_string);

      if ($vars['action'] == 'edit') {
        $data = "<b>".$this->validation->Code."</b>";
        $this->table->add_row($this->lang->line('admin_code'), $data.form_hidden('Code', $this->validation->Code));
      }

//erm crear el formulario
//------------------------------------------------------------------------------------------
      $form_tag = 'form_Appoinment';
      $attributes = array('id' => $form_tag, 'name' => $form_tag);

      $form .= form_open($vars['directo'], $attributes);

//erm si se esta creado, crear y cargar el formulario con javascript y ajax
//------------------------------------------------------------------------------------------

      if ($bydoctor) {
        $control1 = '
            <td>'.$this->lang->line('physician_physician').'</td>
            <td id="ajax_physician" width="30px">&nbsp;</td>
            <td>
              <select id="'.$physician_tag.'" name="'.$physician_tag.'" >
              <option value="">Enable Javascript</option>
              </select>
            </td>
        ';
        $control2 = '
            <td width="30px">'.$this->lang->line('specialities_name').'</td>
            <td id="ajax_speciality" width="30px">&nbsp;</td>
            <td>
              <select  id="'.$speciality_tag.'" name="'.$speciality_tag.'" >
              <option value="">-- '.$this->lang->line('main_none').' --</option>
              </select>
            </td>
        ';
      } else {

        $control1 = '
            <td width="30px">'.$this->lang->line('specialities_name').'</td>
            <td id="ajax_speciality" width="30px">&nbsp;</td>
            <td>
              <select  id="'.$speciality_tag.'" name="'.$speciality_tag.'" >
              <option value="">Enable Javascript</option>
              </select>
            </td>
        ';
        $control2 = '
            <td>'.$this->lang->line('physician_physician').'</td>
            <td id="ajax_physician" width="30px">&nbsp;</td>
            <td>
              <select id="'.$physician_tag.'" name="'.$physician_tag.'" >
              <option value="">-- '.$this->lang->line('main_none').' --</option>
              </select>
            </td>
        ';

      }

      $data = $this->_get_patients_assigned();
      $patients_control = form_dropdown($patient_tag, $data, '', sprintf('id="%s"', $patient_tag));

      $controls = '
      <table border="0" cellpadding="4" >
        <tr>

        '.$control1.'

          <td valign="top" rowspan="4">
            <div id="calendar"  style="padding: 10px 10px 10px 10px ;">
            </div>
          </td>

          <td valign="top" rowspan="4">
            <div id="time">
            </div>
          </td>

        </tr>
        <tr>

        '.$control2.'

        </tr>
        <tr>
          <td>'.$this->lang->line('schedule_day').'</td>
          <td id="ajax_calendar" width="30px">&nbsp;</td>
          <td>
            <input id="'.$calendar_tag.'" name="'.$calendar_tag.'" readonly value="--" />
          </td>
        </tr>
        <tr>
          <td >'.$this->lang->line('schedule_time').'</td>
          <td id="ajax_time" width="30px">&nbsp;</td>
          <td>
            <input id="'.$time_tag.'" name="'.$time_tag.'" readonly value="--" />
          </td>
        </tr>

        <tr>
          <td colspan="5" style="height: 100%;">
          <hr>
          </td>
        </tr>

        <tr>

          <td  width="30px">'.$this->lang->line('patient_patient').'</td>
          <td id="ajax_patient" width="30px">&nbsp;</td>
          <td colspan="3">
            '.$patients_control.'
          </td>
        </tr>

        <tr>
          <td colspan="5" style="height: 100%;">
          <hr>
          </td>
        </tr>

        <tr>
          <td  width="30px">'.$this->lang->line('admin_notes').'</td>
          <td id="ajax_patient" width="30px">&nbsp;</td>
          <td colspan="3">

        ';

        $key = 'Notes';
        $controls .= textArea($key, $this->validation->$key, 'mini', '75px', '100%');

        $controls .= '
        </tr>

        <tr>
          <td colspan="5">
          <div>
          <input id="sumbmit_appoinment" type="submit" value="'.$this->lang->line('appointment_add').'">
          </div>
          </td>
        </tr>

      </table>
      ';

      $form .= $controls;
      $form .= form_close();

    }

    return $form;
  }

  /**
   * return a string with a list of physicians
   *
   * to be used with ajax
   *
   * @public
   * 
   * @return string
   */
  function form_physician () {

    $speciality_code = $this->input->xss_clean($this->uri->segment(3, ''));

    $this->lang->load('admin');

//erm load physicians list
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->distinct();
    $this->db->select('code, name');
    $this->db->from(array('users','med_schedule'));

    $this->db->where('status', 1);
    $this->db->where('is_physician', 1);
    $this->db->where($prefix.'users.code=' . $prefix.'med_schedule.physician_code');
    if ($speciality_code != '') $this->db->where($prefix.'med_schedule.speciality_code=' . $speciality_code);

    $this->db->orderby('name');
    $query = $this->db->get();

    $options = '';
    $options .= '||--- '.$this->lang->line('main_pleaseselect').' ---';

    foreach ($query->result() as $row) {
      $options .= '&&'.$row->code.'|';
      //if ($selected == $row->code) $options .=  'selected';
      $options .='|'.sprintf('%s [%s]', htmlspecialchars($row->name), $row->code);

    }

    echo $options;
  }

  /**
   * return a html calender for physicians loading the _form_calendar method 
   *
   * to be used with ajax
   *
   * @public
   * 
   * @return string
   */
  function form_calendar_spe () {

    $speciality = $this->input->xss_clean($this->uri->segment(3, ''));
    $year = $this->input->xss_clean($this->uri->segment(4, 0));
    $month = $this->input->xss_clean($this->uri->segment(5, 0));
    $physician = $this->input->xss_clean($this->uri->segment(6, ''));

    //echo $this->_form_calendar ('speciality');
    echo $this->_form_calendar ($speciality, $year, $month, $physician, 'doctor');
  }

  /**
   * return a html calender for specialities loading the _form_calendar method 
   *
   * to be used with ajax
   *
   * @public
   * 
   * @return string
   */
  function form_calendar_doc () {

    $physician = $this->input->xss_clean($this->uri->segment(3, ''));
    $year = $this->input->xss_clean($this->uri->segment(4, 0));
    $month = $this->input->xss_clean($this->uri->segment(5, 0));
    $speciality = $this->input->xss_clean($this->uri->segment(6, ''));

    echo $this->_form_calendar ($speciality, $year, $month, $physician, 'speciality');
  }

  /**
   * return a html calender with days available for consultation
   *
   * to be used with ajax
   *
   * @private
   * 
   * @return string
   */
  function _form_calendar ($speciality, $year, $month, $physician, $tips) {

    $this->lang->load('admin');
    $this->lang->load('med_common');

    $this->load->helper(array('date'));
    $time = gmt_to_local(now(), $this->config->item('timezone'));

    if (intval($year) == 0) $year = date('Y', $time);
    if (intval($month) == 0) $month = date('n', $time);

    $prefs = array (
      'local_time' => $time,
      'show_next_prev' => TRUE,
      'next_prev_url' => '#/'
    );

    $prefs['template'] = '
    {table_open}<table class="calendar" cellpadding="3" cellspacing="0">{/table_open}
    {table_close}</table>{/table_close}

    {heading_previous_cell}<th style="cursor: pointer;"><a id="cal_previous" title="{previous_url}">&lt;&lt;</a></th>{/heading_previous_cell}
    {heading_next_cell}<th style="cursor: pointer;"><a id="cal_next" title="{next_url}">&gt;&gt;</a></th>{/heading_next_cell}

    {cal_cell_content}<div class="calendar_content" {content}>{day}</div>{/cal_cell_content}
    {cal_cell_content_today}<div class="calendar_content" {content}><span class="calendar_today">{day}</span></div>{/cal_cell_content_today}

    {cal_cell_no_content}<span class="calendar_no_content" >{day}</span>{/cal_cell_no_content}
    {cal_cell_no_content_today}<span class="calendar_no_content" ><span class="calendar_today">{day}</span></span>{/cal_cell_no_content_today}

    ';

    $this->load->library('calendar', $prefs);

//erm load appointments to see if physicians are busy
//------------------------------------------------------------------------------
    $appointments = array();

    $date1 = mktime  (0, 0, 0, $month, 1, $year);
    $date2 = mktime  (0, 0, -1, $month+1, 1, $year);

    $this->db->from(array('med_appointment'));
    $this->db->where('status !=', 0);
    $this->db->where('time_from>=', $date1);
    $this->db->where('time_to<=', $date2);

    if ($speciality != '') $this->db->where('speciality_code', $speciality);
    if ($physician != '') $this->db->where('physician_code', $physician);

    $this->db->orderby('time_from, patient_code');
    $query = $this->db->get();

    foreach ($query->result() as $row) {
      $day = date('j', $row->time_from);
      $tmp = mktime  (0, 0, 0, $month, $day, $year);
      $ini = $row->time_from - $tmp;
      $end = $row->time_to - $tmp;
      $appointments [$day][$row->physician_code][] = sprintf('%d-%d', $ini, $end);
    }

//erm load schedule expected to physicians be available
//------------------------------------------------------------------------------
    $schedule = array();
    $doctors  = array();

    $prefix = $this->db->dbprefix;
    $this->db->select(sprintf(
      'a.day, a.intervallum, a.time_from, a.time_to, a.speciality_code, b.name, b.code, c.name as speciality
      FROM %smed_schedule as a
      JOIN %susers as b ON a.physician_code=b.code
      JOIN %smed_specialities as c ON a.speciality_code=c.code
      ',
      $prefix,
      $prefix,
      $prefix
    ));

    if ($speciality != '') $this->db->where('speciality_code', $speciality);
    if ($physician != '') $this->db->where('physician_code', $physician);
    $this->db->where('b.status', 1);
    $this->db->where('b.is_physician', 1);

    $query = $this->db->get();

    foreach ($query->result() as $row) {

      for ($j=1;$j<=31;$j++) {
        $temp_date = mktime(23, 59, 59, intval($month), $j, intval($year));
        $day_of_week = intval(date('w', $temp_date));

        if ($day_of_week == $row->day && $temp_date > $time) {

          $tooltip = '';
          if ($tips == 'doctor') {
            if ($row->name == '') $row->name = sprintf('[%s]', $row->code);
            $tooltip = sprintf('%s %s', $this->lang->line('appointment_dr'), $row->name);
            if (trim($tooltip) == '') $tooltip = sprintf('[%s]', $row->code);
          }
          if ($tips == 'speciality') {
            $tooltip = $row->speciality;
            if (trim($tooltip) == '') $tooltip = sprintf('[%s]', $row->speciality_code);
          }

          $tmp_dr = true;
          if ($tooltip == '' || (isset($doctors[$j]) && strpos($doctors[$j], $tooltip) !== false) ) $tmp_dr = false;
          if ( $tmp_dr == true) {

            $tmp_str = sprintf('<div>%s</div>', $tooltip);
            if (isset($doctors[$j])) $doctors[$j] .= $tmp_str;
            else $doctors[$j] = $tmp_str;

          }


          if ( ! $row->intervallum) $row->intervallum = 3600;
          for ($i=$row->time_from; $i<$row->time_to; $i+=$row->intervallum) { //erm intervalos de xx minutos
            $ini = $i;
            $end = $i+$row->intervallum-1;
            if ($ini >= $row->time_from && $end <= $row->time_to) {
              $schedule[$j][$row->code][] = sprintf('%d-%d', $ini, $end);
            }
          }

        }
      }
    }

    $schedule_keep = array();

//erm see beetween appointments and schedule to see free time
//------------------------------------------------------------------------------
    foreach ($appointments as $akey => $aval) {

      if (isset($schedule[$akey])) {

        foreach ($schedule[$akey] as $skey => $sval) {

          if (isset($appointments[$akey][$skey])) {

            $tmpsche = $sval;
            $tmpappo = $appointments[$akey][$skey];

            for ($a=0; $a<sizeof($tmpappo); $a++) {
              for ($b=0; $b<sizeof($tmpsche); $b++) {
              //!!for ($b=sizeof($tmpsche)-1; $b>=0; $b--) {

                $sp1 = explode('-', $tmpappo[$a]);
                $sp2 = explode('-', $tmpsche[$b]);

                if (
                  ($sp1[0] >= $sp2[0] && $sp1[0] <= $sp2[1]) ||
                  ($sp1[1] >= $sp2[0] && $sp1[1] <= $sp2[1])
                ) {
                  unset ($schedule[$akey][$skey][$b]);
                }

              }
            }

          }
        }
      }
    }

    foreach($schedule as $key => $val) {

      $count = 0;
      foreach($val as $meds) $count += count($meds);
      if ( ! $count) $schedule[$key] = '';

    }


//erm create calendar links with freetime days and busy days
//------------------------------------------------------------------------------

    $data = array();

    for ($i=1;$i<=31;$i++) {
      $doc = '';
      if (isset($doctors[$i])) $doc = $doctors[$i];
      if (isset($schedule[$i])) {
        if (is_array($schedule[$i])) $class = '';
        else $class = 'style="color: red;" ';
        $data[$i]= sprintf('id="%d/%d/%d" title="%s" %s ', $year, $month, $i, $doc, $class);
      }
    }

    return
    '<input id="cal_actual_month" type="hidden" value="/'.$year.'/'.$month.'/" />'
    .$this->calendar->generate($year, $month, $data)
    ;

  }

  /**
   * return a string with a list of specialities
   *
   * to be used with ajax
   *
   * @public
   * 
   * @return string
   */
  function form_speciality () {

    $physician_code = $this->input->xss_clean($this->uri->segment(3, ''));

    $this->lang->load('admin');

//erm load specialities list
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->distinct();
    $this->db->select('code, name');
    $this->db->from(array('med_specialities','med_schedule'));

    $this->db->where($prefix.'med_specialities.code=' . $prefix.'med_schedule.speciality_code');
    if ($physician_code != '') $this->db->where('physician_code', $physician_code);

    $this->db->orderby('name');
    $query = $this->db->get();

    $options = '';
    $options .= '||--- '.$this->lang->line('main_pleaseselect').' ---';

    foreach ($query->result() as $row) {
      $options .= '&&'.$row->code . '|';
      //!!if ($selected == $row->code) $options .=  'selected';
      $options .= '|'.htmlspecialchars($row->name);
    }

    echo $options;
  }


  /**
   * return html with form to select appointment hour
   *
   * to be used with ajax
   *
   * @public
   * 
   * @return string
   */
  function form_hours () {

    $speciality = $this->input->xss_clean($this->uri->segment(3, ''));
    $year = $this->input->xss_clean($this->uri->segment(4, 0));
    $month = $this->input->xss_clean($this->uri->segment(5, 0));
    $day = $this->input->xss_clean($this->uri->segment(6, 0));
    $physician = $this->input->xss_clean($this->uri->segment(7, ''));

    $date = mktime  (0, 0, 0, $month, $day, $year);

    $doquery = 1;

    if ($speciality == '') $doquery = 0;
    if ($year == 0) $doquery = 0;
    if ($month == 0) $doquery = 0;
    if ($day == 0) $doquery = 0;
    if ($physician == '') $doquery = 0;
    if ($date === FALSE || $date == -1) $doquery = 0;

    $this->lang->load('admin');
    $this->lang->load('med_common');


    $schedule = array();
    $busy = array();

    if ($doquery == 1) {

      $this->db->from(array('med_schedule'));
      $this->db->where('speciality_code', $speciality);
      $this->db->where('physician_code', $physician);
      $this->db->where('day', date('w', $date));
      $this->db->orderby('time_from');
      $query = $this->db->get();

      $key = 0;
      foreach ($query->result() as $row) {

        if ( ! $row->intervallum) $row->intervallum = 3600;

        for ($i=$row->time_from; $i<$row->time_to; $i+=$row->intervallum) { //erm intervalos de xx minutos
          $ini = $i;
          $end = $i+$row->intervallum-1;
          if ($ini >= $row->time_from && $end <= $row->time_to) {
            $schedule[$key]['ini'] = $ini;
            $schedule[$key]['end'] = $end;
            $key++;
          }
        }
      }

      $date1 = mktime  (0, 0, 0, $month, $day, $year);
      $date2 = mktime  (23, 59, 59, $month, $day, $year);

      $this->db->from(array('med_appointment'));
      $this->db->where('status !=', 0);
      $this->db->where('physician_code', $physician);
      $this->db->where('time_from>=', $date1);
      $this->db->where('time_to<=', $date2);
      $this->db->orderby('time_from, patient_code');
      $query = $this->db->get();

      foreach ($query->result() as $row) {

        foreach ($schedule as $key => $val) {
          $ini = $date1 + $val['ini'];
          $end = $date1 + $val['end'];
          if (
            ($row->time_from >= $ini && $row->time_from <= $end) ||
            ($row->time_to >= $ini && $row->time_to <= $end)
          ) {
            $busy[$key] = 1;
          }
        }

      }
    }

    $allday = '';
    foreach ($schedule as $key => $val) {

      if (isset($busy[$key])) {
        $class = 'schedule_busy';
        $title = $this->lang->line('schedule_busy');
      } else {
        $class = 'schedule_free';
        $title = $this->lang->line('schedule_available');
      }

      $date_temp = mktime (0, 0, 0, 4, 26, 1926);
      $allday .= sprintf(
        '<div class="%s" title="%s">%s - %s</div>',
        $class,
        $title,
        date('h:ia',$date_temp+$val['ini']),
        date('h:ia',$date_temp+$val['end'])
      );
    }

    echo sprintf('<div id="schedule">%s</div>', $allday);
  }

  /**
   * test if the time selected is free
   *
   * to be used with ajax
   *
   * @private
   * 
   * @return nothing
   */
  function _check_date_isfree ($date1, $date2, $physician) {

    $where = sprintf(
    '((time_from>=%d && time_from<=%d) || (time_from>=%d && time_from<=%d))',
    $date1,
    $date2,
    $date1,
    $date2
    );

    $this->db->from(array('med_appointment'));
    $this->db->where('status != ', 0);
    $this->db->where('physician_code', $physician);
    $this->db->where($where);
    $this->db->limit(1);
    $query = $this->db->get();

    if ($query->num_rows() > 0) {
      return 0;
    }

    return 1;
  }

  /**
   * test if the patient selected is valid
   *
   * to be used with ajax
   *
   * @private
   * 
   * @return nothing
   */
  function _check_patient($str) {

    $patients = $this->_get_patients_assigned();
    if ( ! array_key_exists($str, $patients)) {
      $this->validation->set_message('_check_patient', $this->lang->line('consultation_patientnofound'));
      return FALSE;
    }
    return TRUE;
  }


  /**
   * test if the physician selected is valid
   *
   * to be used with ajax
   *
   * @private
   * 
   * @return nothing
   */
  function _check_physician($str) {
    $this->db->where(array('code'=>$str));
    $this->db->where(array('status'=>1, 'is_physician'=>1));
    $this->db->select("code");
    $query = $this->db->get('users');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_physician', $this->lang->line('physician_codenofound'));
      return FALSE;
    }
  }


  /**
   * test if the day selected is valid
   *
   * to be used with ajax
   *
   * @private
   * 
   * @return nothing
   */
  function _check_valid_day($str) {
    $date = 1;
    $validdate = "[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}";
    if (eregi($validdate, $str) === FALSE) {
      $date = 0;
    }

    if ($date) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_valid_day', $this->lang->line('schedule_invalid_day'));
      return FALSE;
    }
  }


  /**
   * test if the time selected is valid
   *
   * to be used with ajax
   *
   * @private
   * 
   * @return nothing
   */
  function _check_valid_time($str) {

    $date1 = true;
    $date2 = true;

    $tmp = split('-', $str);

    if (is_array($tmp)) {
      $validtime = "[0-9][0-9]:[0-9][0-9](a|p)m";

      if (eregi($validtime, $tmp[0]) === FALSE) {
        $date1 = 0;
      } else {
        $tmp[0] = "1926-04-06 " . trim($tmp[0]);
        if (strtotime($tmp[0]) === FALSE) $date1 = 0;
      }

      if (eregi($validtime, $tmp[1]) === FALSE) {
        $date2 = 0;
      } else {
        $tmp[1] = "1926-04-06 " . trim($tmp[1]);
        if (strtotime($tmp[1]) === FALSE) $date2 = 0;
      }
    } else {
      $date1 = false;
      $date2 = false;
    }

    if ($date1 && $date2) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_valid_time', $this->lang->line('schedule_invalid_time'));
      return FALSE;
    }
  }


  /**
   * test if the speciality selected is valid
   *
   * to be used with ajax
   *
   * @private
   * 
   * @return nothing
   */
  function _check_speciality($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('med_specialities');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_speciality', $this->lang->line('specialities_codenofound'));
      return FALSE;
    }
  }

}
?>
