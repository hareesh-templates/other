<?php

/**
 * @file patient_search.php
 * @brief File to search for patients
 * 
 * @class Patient_Search
 * @brief Class to search for patients
 *
 * @details this class allows to search patients by: patient's name, physician or speciality
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class Patient_Search extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url  = "patient_search";

  /**
   * the title for this controller
   */ 
  var $module_name = "Patient Search";

  /**
   * the database table related to this controller
   */ 
  var $dbtablename = "med_patient";

  /**
   * the number of items to show in each page
   */ 
  var $itemxpage   = 8;


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Patient_Search () {
    parent::Controller();

    if (!is_module(str_replace('.php', '', pathinfo(__FILE__, PATHINFO_BASENAME)))) {
      $this->load->helper('url');
      redirect('principal/accessdenied');
      return;
    }
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   * @param moreitems array aditional items to include in the submenu
   *
   * @return string
   */
  function _thissubmenu($title, $moreitems='') {

    $this->load->helper(array('url'));

    $items = array();
    $items[] = anchor($this->module_url, $this->lang->line('patientsearch_new'));

    if (is_array($moreitems)) {
      $items = array_merge($items, $moreitems);
    }

    return navbarsubmenu($title, $items, 'med_patient.png');
  }


  /**
   * controller default method.  Sends to browser the result with pagination of one search.
   *
   * default method to load when this class is invoqued with not controller in the URI
   * 
   * this method uses as paramenter the URI segment 3.
   * that segment must has a valid patient code
   *
   *
   * @public
   *
   * @return nothing
   */
  function index () {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url', 'date', 'text', 'cookie'));
    $this->load->library(array('pagination', 'table'));


    $param = $this->input->xss_clean($this->uri->segment(3, ''));
    if ($param != '') $param = trim($param);


    $vars   = array();
    $lista  = '';
    $pagination = '';

    if (str_replace('|','',$param) != '') {

      $vars = explode('|', $param);

      $where0 = '';
      $where1 = '';
      $where2 = '';

      if (isset($vars[0]) && $vars[0] != '') {
        $where0  = sprintf("(code LIKE '%%%s%%' || name LIKE '%%%s%%' || notes LIKE '%%%s%%')", $vars[0], $vars[0], $vars[0] );
      }

      if (isset($vars[1]) && $vars[1] != '') {

        $where1 = sprintf(
        'code = ANY
        (SELECT DISTINCT c.patient_code FROM %susers b, %smed_diagnostic c
        WHERE b.is_physician=1 AND b.code=c.physician_code AND b.name LIKE "%%%s%%")
        ',
        $this->db->dbprefix,
        $this->db->dbprefix,
        $vars[1]
        );

      }

      if (isset($vars[2]) && $vars[2] != '') {

        $where2 = sprintf(
        'code = ANY
        (SELECT DISTINCT c.patient_code FROM %smed_specialities b, %smed_diagnostic c
        WHERE b.code=c.speciality_code AND b.name LIKE "%%%s%%")
        ',
        $this->db->dbprefix,
        $this->db->dbprefix,
        $vars[2]
        );

      }

      if ($where0 != '') $this->db->where($where0);
      if ($where1 != '') $this->db->where($where1);
      if ($where2 != '') $this->db->where($where2);
      $this->db->select('count(*) as numrows');
      $query = $this->db->get($this->dbtablename);

      $numitems = 0;
      if ($query->num_rows() > 0) {
        $row = $query->row();
        $numitems = $row->numrows;
      }

//erm creacion de los links
//------------------------------------------------------------------------------
      $uri_segment = 4;

      $config['base_url'] =
        $this->config->site_url().'/'.$this->module_url.'/index/'.$param;

      $config['total_rows'] = $numitems;
      $config['per_page'] = $this->itemxpage;
      $config['uri_segment'] = $uri_segment;
      $config['full_tag_open'] = "<div class='pagination'>";
      $config['full_tag_close'] = "</div>";
      $config['num_links'] = '4';
      $this->pagination->initialize($config);
      $pagination = $this->pagination->create_links();

      $begin = intval($this->uri->segment($uri_segment, 0));
      if ($begin < 0) $begin = 0;

//erm cargar la informacion desde la base de datos
//------------------------------------------------------------------------------

      if ($where0 != '') $this->db->where($where0);
      if ($where1 != '') $this->db->where($where1);
      if ($where2 != '') $this->db->where($where2);

      $this->db->select('code, name, createddate');
      $this->db->orderby("name");
      $query = $this->db->get($this->dbtablename, $this->itemxpage, $begin);

      if ($query->num_rows() > 0) {

        foreach ($query->result() as $row) {
          $lista .=
          $this->_patient_format (
            $row->code, $row->name, $row->createddate
          );
        }

      } else {
        $lista = $this->lang->line('patientsearch_noresults');
      }
    }

//erm recuperar cualquier cookie de mensaje
//------------------------------------------------------------------------------

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = '';

    $content .= $this->_thissubmenu($this->lang->line('patientsearch_title'));
    $content .= $msg;
    $content .= $this->_searchForm('basic', $this->module_url.'/search/', $vars) . '<br />';
    $content .= $lista;
    $content .= $pagination;


//erm recuperar/enviar la salida al navegador / del control
//------------------------------------------------------------------------------
    make_blocks();
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('content_title');
    $data['content'] = theme($this->block_side1, $content, $this->block_side2);
    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * sends to browser the search form. Also does the validation proccess.
   *
   * @public
   *
   * @return nothing
   */
  function search () {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Name']  = "trim|xss_clean";
    $rules['Phys']  = "trim|xss_clean";
    $rules['Spec']  = "trim|xss_clean";
    $this->validation->set_rules($rules);

    $fields['Name'] = $this->lang->line('patientsearch_patient');
    $fields['Phys'] = $this->lang->line('patientsearch_physician');
    $fields['Spec'] = $this->lang->line('patientsearch_speciality');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      $vars = array();
      $vars[0] = $this->validation->Name;
      $vars[1] = $this->validation->Phys;
      $vars[2] = $this->validation->Spec;

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('patientsearch_title'));
      $form .= $err . $this->_searchForm('basic', $this->module_url.'/search/', $vars);

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('patientsearch_title');
      $data['content'] = theme($this->block_side1, $msg.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $vars = array();
      $vars[0] = $this->validation->Name;
      $vars[1] = $this->validation->Phys;
      $vars[2] = $this->validation->Spec;
      $param = implode('|', $vars);

      redirect($this->module_url.'/index/'.$param);
      return;
    }
  }

  /**
   * creates and returns an html search form.
   *
   * @private
   *
   * @return string
   */
  function _searchForm ($action, $directo, $vars) {
    //@action - allowed values: add / edit

    $this->load->helper(array('form'));
    $this->load->library(array('table'));

    if ( ! isset($vars[0])) $vars[0] = '';
    if ( ! isset($vars[1])) $vars[1] = '';
    if ( ! isset($vars[2])) $vars[2] = '';

    $options = array(
      1 => $this->lang->line('patientsearch_normal'),
      2 => $this->lang->line('patientsearch_speciality'),
      3 => $this->lang->line('patientsearch_physician')
    );

    $this->table->clear();
    $form =  '';
    $key = 'formSearch';
    $attributes = array('id' => $key, 'name' => $key);
    $form = form_open($directo, $attributes);

    $key = 'Name';
    $data = array('name' => $key, 'id' => $key, 'value' => $vars[0], 'size' => '25');
    $input1 = form_input($data);

    $key = 'Phys';
    $data = array('name' => $key, 'id' => $key, 'value' => $vars[1], 'size' => '12');
    $input2 = form_input($data);

    $key = 'Spec';
    $data = array('name' => $key, 'id' => $key, 'value' => $vars[2], 'size' => '12');
    $input3 = form_input($data);

    $this->table->add_row(
      sprintf('%s<br />%s<br />',
        $this->lang->line('patientsearch_patient'),
        $input1
      ),
      sprintf('%s<br />%s', $this->lang->line('patientsearch_physician'), $input2),
      sprintf('%s<br />%s', $this->lang->line('patientsearch_speciality'), $input3)
    );

    //$this->table->add_row(anchor_popup(base_url().'doc/search_tips.html', $this->lang->line('search_tips'), ''));
    $this->table->add_row(
      form_submit('submit', $this->lang->line('search_submit'))
    );

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=2 cellspacing=2  >');
    $this->table->set_template($tmpl);

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }


  /**
   * returns an html formatted patient record.
   *
   * @private
   *
   * @param code string the patient's code
   * @param name string the patient's name
   * @param createddate int the date that this patient was created
   *
   * @return string
   */
  function _patient_format ($code, $name, $createddate) {

    $this->load->library(array('table'));
    $this->load->helper(array('date'));

    $this->table->clear();

    $history  = '';
    $history .= sprintf(
      '<a href="%s">%s</a>',
      site_url() . '/history/patient/' . $code,
      theme_imgtag('med_history24.png')
    );
    $history .= '<br />';
    $history .= anchor('history/patient/' . $code, $this->lang->line('medhistory_history'));

    $attach  = '';
    $attach .= sprintf(
      '<a href="%s">%s</a>',
      site_url() . '/diagnostic_attach/appointments/' . $code,
      theme_imgtag('attachment24.png')
    );
    $attach .= '<br />';
    $attach .= anchor('diagnostic_attach/appointments/' . $code, $this->lang->line('diagnostic_ins_file'));

    $diagnostic  = '';
    $diagnostic .= sprintf(
      '<a href="%s">%s</a>',
      site_url() . '/diagnostic/patient/' . $code,
      theme_imgtag('diagnostic24.png')
    );
    $diagnostic .= '<br />';
    $diagnostic .= anchor('diagnostic/patient/' . $code, $this->lang->line('diagnostic_diagnostic'));


    $createddate = gmt_to_local($createddate, $this->config->item('timezone'));
    $createddate = date('Y M d / h:i a', $createddate);

    $content = '';

    $content = sprintf(
      '<table style="width:100%%">
        <tr>
          <td width="75%%"> %s </td>
          <td align="center" rowspan="5"> %s </td>
          <td align="center" rowspan="5"> %s </td>
          <td align="center" rowspan="5"> %s </td>
        </tr>
        <tr><td> %s </td></tr>
        <tr><td> %s </td></tr>
      </table>',
      anchor('/history/patient/' . $code),
      $diagnostic,
      $history,
      $attach,
      sprintf('<b>%s:</b> %s (%s)', $this->lang->line('patient_patient'), $name, $code),
      sprintf('<b>%s:</b> %s', $this->lang->line('patient_datecreated'), $createddate)
    );

    return sprintf('<div class="patientsearch_result"> %s </div>', $content);

  }

}
?>
