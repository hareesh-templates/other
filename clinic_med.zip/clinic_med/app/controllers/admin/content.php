<?php

/**
 * @file /controllers/admin/content.php 
 * @brief File to manage content. (list, add, edit and delete)
 * 
 * @class Content
 * @brief Class to manage content. (list, add, edit and delete)
 *
 * @details content is a piece of HTML to be shown by the content controller
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Content extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/content";

  /**
   * the title for this controller
   */ 
  var $module_name = "content";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Content() {
    parent::Controller();

    $this->access[1] = "add";
    $this->access[2] = "show";
    $this->access[3] = "del";
    $this->access[4] = "edit";
  }


  /**
   * return the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "add show del edit";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    $items[] = anchor($this->module_url.'/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    $items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));

    return navbarsubmenu($title, $items, 'content.png');
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";
    make_blocks(array(1));
    $leftmenu = $this->block_side1;
    return $leftmenu;
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('admin_content')).'<br />';
    $content .= $this->lang->line('admin_defactions');

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * sends to browser an add content form, do the validation proccess and if it is successfull, then add the new content
   *
   * @public
   *
   * @return nothing
   */
  function add () {
    if ($this->_accesgranted($this->access[1]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie','date'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|strip_tags|required|xss_clean|callback__unique_code_check";
    $rules['Title']  = "trim|strip_tags|htmlentities|xss_clean";
    $rules['Enabled']  = "trim|required|xss_clean";
    $rules['HomePage']  = "trim|required|xss_clean";
    $rules['Language']  = "trim|xss_clean";
    $rules['Text']  = "trim|required|xss_clean";
    $rules['Keywords']  = "trim|strip_tags|xss_clean";
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Title'] = $this->lang->line('main_title');
    $fields['Enabled'] = $this->lang->line('main_enabled');
    $fields['HomePage'] = $this->lang->line('content_homepage');
    $fields['Language'] = $this->lang->line('admin_lang');
    $fields['Text'] = $this->lang->line('content_content');
    $fields['Keywords'] = $this->lang->line('content_keywords');
    $this->validation->set_fields($fields);
    if ($this->input->post('Order') === FALSE) {
      $this->validation->Enabled = 1;
      $this->validation->HomePage = 0;
    }

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_content')).'<br />';
      $form .= $err . $this->_make_form('add', $this->module_url.'/add');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
      'code' => $this->validation->Code,
      'title' => $this->validation->Title,
      'enabled' => $this->validation->Enabled,
      'homepage' => $this->validation->HomePage,
      'lang' => $this->validation->Language,
      'content' => $this->validation->Text,
      'keywords' => $this->validation->Keywords,
      'created' => now(),
      'modified' => now(),
      );
      $this->db->insert('content', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/add');
      return;
    }
  }


  /**
   * creates and return a html form to add or edit a content.
   *
   * @private
   *
   * @param action enum The type of form to create. Valid options are "add" or "edit"
   * @param directo string. The form's action URL.
   *
   * @return string
   */
  function _make_form ($action, $directo) {
    //action - allowed values: add / edit

    $form =  '';

    $key = 'formContent';
    $attributes = array('id' => $key, 'name' => $key);

    $form = form_open($directo, $attributes);

    if ($action == 'add') {
      $data = array('name' => 'Code', 'id' => 'Code', 'value' => $this->validation->Code, 'size' => '16');
      $this->table->add_row($this->lang->line('admin_code'), form_input($data).$this->lang->line('admin_required'));
    }
    if ($action == 'edit') {
      $data = "<b>".$this->validation->Code."</b>";
      $this->table->add_row($this->lang->line('admin_code'), $data.form_hidden('Code', $this->validation->Code));
    }

    $key = 'Title';
    $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'style' => 'width:95%');
    $this->table->add_row($this->lang->line('main_title'), form_input($data));

    $key = 'Enabled';
    $radio = form_radio($key, '1', intval($this->validation->$key)) . $this->lang->line('main_yes')
    .form_radio($key, '0', !intval($this->validation->$key)) . $this->lang->line('main_no');
    $this->table->add_row($this->lang->line('main_enabled'), $radio);

    $key = 'HomePage';
    $radio = form_radio($key, '1', intval($this->validation->$key)) . $this->lang->line('main_yes')
    .form_radio($key, '0', !intval($this->validation->$key)) . $this->lang->line('main_no');
    $this->table->add_row($this->lang->line('content_homepage'), $radio);

    $this->table->add_row($this->lang->line('admin_lang'), form_dropdown('Language', get_lang_list(), $this->validation->Language));

    $key = 'Keywords';
    $data = array('name'=>$key,'id'=>$key,'value'=>$this->validation->$key, 'style'=>'width:95%; height:50px;');
    $this->table->add_row($this->lang->line('content_keywords'), form_textarea($data));


    $tmpl = array ('table_open'  => '<table border=0 cellpadding=2 cellspacing=2 style="width:100%">');
    $this->table->set_template($tmpl);
    $form .= $this->table->generate();
    $this->table->clear();

    $key = 'Text';
    $this->table->add_row($this->lang->line('content_content').'<br />'.textArea($key, $this->validation->$key, 'all', '400px', '100%').'<br />');

    if ($action == 'add') $this->table->add_row(form_submit('submit', $this->lang->line('content_add')));
    if ($action == 'edit') $this->table->add_row(form_submit('submit', $this->lang->line('admin_savechanges')));

    $form .= $this->table->generate();

    $form .= form_close();

    return $form;
  }


  /**
   * looks for the content code into DB. If it exists, return FALSE, else return TRUE
   *
   * @private
   *
   * @param str string. The content code
   *
   * @return boolean
   */
  function _unique_code_check($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('content');
    if ($query->num_rows() > 0) {
      $this->validation->set_message('_unique_code_check', $this->lang->line('content_codeduplicated'));
      return FALSE;
    } else {
      return TRUE;
    }
  }

  /**
   * looks for the content code into DB. If it exists, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. The content code
   *
   * @return boolean
   */
  function _code_exits($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('content');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_code_exits', $this->lang->line('content_codenofound'));
      return FALSE;
    }
  }

  /**
   * creates and return a html form asking the content code for edit or delete actions.
   *
   * @private
   *
   * @param action enum. The action URL of the form. Valid options are "edit" and "del"
   *
   * @return string
   */
  function _askcode_form ($action) {
    //action - allowed values: del / edit
    $form = "";

    $key = 'formContent';
    $attributes = array('id' => $key, 'name' => $key);

    if ($action == 'del') $form .= form_open($this->module_url.'/delask', $attributes);
    if ($action == 'edit') $form .= form_open($this->module_url.'/editask', $attributes);

    $key = 'Code';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_code'), form_input($data));

    if ($action == 'del') $this->table->add_row('', form_submit('submit', $this->lang->line('content_del')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('content_edit')));

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }


  /**
   * sends to browser the list of content.
   *
   * @public
   *
   * @return nothing
   */
  function show() {

    if ($this->_accesgranted($this->access[2]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $itemxpage = 25;

    $this->lang->load('admin');
    $this->load->helper(array('url','form','text'));
    $this->load->library(array('pagination', 'table'));

//erm creacion de los links
//------------------------------------------------------------------------------
    $config['base_url'] = $this->config->site_url().'/'.$this->module_url."/show";
    $config['total_rows'] = $this->db->count_all('content');
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = "4";
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    //$config['num_links'] = "2";
    $this->pagination->initialize($config);
    $links = $this->pagination->create_links();

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------
    $begin = intval($this->uri->segment(4, 0));
    if ($begin < 0) $begin = 0;
    $lista = "";
    $this->db->orderby("created DESC, title");
    $query = $this->db->get('content', $itemxpage, $begin);

    $this->table->set_heading(
    '#', $this->lang->line('admin_code'), $this->lang->line('main_title'), $this->lang->line('content_homepage'),
    $this->lang->line('main_enabled'), $this->lang->line('admin_lang'), $this->lang->line('main_functions')
    );
    $i = $begin+1;
    foreach ($query->result() as $row) {
      $del = anchor($this->module_url.'/del/'.$row->code, $this->lang->line('admin_del'));
      $edit = anchor($this->module_url.'/edit/'.$row->code, $this->lang->line('admin_edit'));
      if ($row->lang == "") $row->lang = $this->lang->line('admin_all');

      $inhome = $row->homepage == 1 ? $this->lang->line('main_yes') : $this->lang->line('main_no');
      $enabled = $row->enabled == 1 ? $this->lang->line('main_yes') : $this->lang->line('main_no');

      $this->table->add_row($i, $row->code, $row->title, $inhome, $enabled, $row->lang, $edit.'-'.$del);
      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing=0 width="100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $lista = $this->table->generate();


//erm enviar los resultados a la salida
//------------------------------------------------------------------------------
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');

    $center = $this->_thissubmenu($this->lang->line('content_listof')).'<br />';
    $center .= $lista ."<br />". $links;
    $data['content'] = theme($this->_leftmenu(), $center);
    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * sends to browser a form asking the content to be deleted
   *
   * @public
   *
   * @return nothing
   */
  function delask() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|xss_clean";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('content_del')) . '<br />';
      $form .= $err . $this->_askcode_form ('del');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/del/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to confirm the content deletion, if user click yes, the content is deleted
   *
   * @public
   *
   * @return nothing
   */
  function del() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask/');
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('content_del')).'<br />'
      . $err
      . Ask_yesno_form (sprintf($this->lang->line('content_askdel'), $code), $this->module_url.'/del/'.$code, $this->module_url.'/delask');

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      $this->db->delete('content', array('code' => $code));
      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask');
      return;
    }
  }


  /**
   * sends to browser a form asking the content to be edited
   *
   * @public
   *
   * @return nothing
   */
  function editask () {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|xss_clean|callback__code_exits";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('content_edit')).'<br />';
      $form .= $err . $this->_askcode_form ('edit');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/edit/'.$this->validation->Code);
      return;
    }
  }

  /**
   * sends to browser a form to update the contect, do the validation proccess
   * and if it is successfull, update the new content information
   *
   * @public
   *
   * @return nothing
   */
  function edit() {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

//erm buscar si el codigo existe en la base de datos
//------------------------------------------------------------------------------
    $this->db->where('code', $code);
    $query = $this->db->get('content');

    if ($query->num_rows() == 0) {

      $msg = base64_encode(msgWarning('',$this->lang->line('content_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Title'] = $this->lang->line('main_title');
    $fields['Enabled'] = $this->lang->line('main_enabled');
    $fields['HomePage'] = $this->lang->line('content_homepage');
    $fields['Language'] = $this->lang->line('admin_lang');
    $fields['Text'] = $this->lang->line('content_content');
    $fields['Keywords'] = $this->lang->line('content_keywords');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {
      $row = $query->row();
      $this->validation->Code = $code;
      $this->validation->Title = $row->title;
      $this->validation->Language = $row->lang;
      $this->validation->Text = $row->content;
      $this->validation->Enabled = $row->enabled;
      $this->validation->HomePage = $row->homepage;
      $this->validation->Keywords = $row->keywords;
    }

    $this->validation->set_error_delimiters('','<br />');

    $rules['Code']  = "trim|strip_tags|required|xss_clean";
    $rules['Title']  = "trim|strip_tags|htmlentities|xss_clean";
    $rules['Enabled']  = "trim|required|xss_clean";
    $rules['HomePage']  = "trim|required|xss_clean";
    $rules['Language']  = "trim|xss_clean";
    $rules['Text']  = "trim|required|xss_clean";
    $rules['Keywords']  = "trim|strip_tags|xss_clean";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_content')).'<br />';
      $form .= $err . $this->_make_form('edit', $this->module_url.'/edit/'.$code);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
      'code' => $this->validation->Code,
      'title' => $this->validation->Title,
      'enabled' => $this->validation->Enabled,
      'homepage' => $this->validation->HomePage,
      'lang' => $this->validation->Language,
      'content' => $this->validation->Text,
      'keywords' => $this->validation->Keywords,
      'modified' => now()
      );
      $this->db->where('code', $code);
      $this->db->update('content', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

  }
}
?>
