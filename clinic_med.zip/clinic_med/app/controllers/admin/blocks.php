<?php

/**
 * @file admin/blocks.php
 * @brief File to manage blocks. (list, add, edit and delete)
 * 
 * @class Blocks
 * @brief Class to manage blocks. (list, add, edit and delete)
 *
 * @details One block is a piece of HTML to be shown in some specific side of the theme.
 * Each block can be HTML content entered by admin, or a file doing something and returning the HTML
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Blocks extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/blocks";

  /**
   * the title for this controller
   */ 
  var $module_name = "blocks";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Blocks() {
    parent::Controller();

    $this->access[1] = "add";
    $this->access[2] = "show";
    $this->access[3] = "del";
    $this->access[4] = "edit";
  }


  /**
   * returns the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "add show del edit";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * returns a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    $items[] = anchor($this->module_url.'/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    $items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));

    return navbarsubmenu($title, $items, 'blocks.png');
  }

  /**
   *
   * returns a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";
    make_blocks(array(1));
    $leftmenu = $this->block_side1;
    return $leftmenu;
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('admin_blocks')).'<br />';
    $content .= $this->lang->line('admin_defactions');

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * sends to browser an add block form, do the validation proccess and if it is successfull, then add the new block
   *
   * @public
   *
   * @return nothing
   */
  function add () {
    if ($this->_accesgranted($this->access[1]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));


    $customgroups = get_usersgroups_list();


    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|strip_tags|required|xss_clean|callback__unique_code_check";
    $rules['Name']  = "trim|strip_tags|htmlentities|xss_clean";
    $rules['Order']  = "trim|required|numeric|xss_clean";
    $rules['Side']  = "trim|required|numeric|xss_clean";
    $rules['Language']  = "trim|xss_clean";
    $rules['Contenido']  = "trim|xss_clean";
    $rules['Enabled']  = "trim|required|xss_clean";
    $rules['Type']  = "trim|required|xss_clean";
    $rules['File']  = "trim|htmlentities|xss_clean";

    $rules['Group-admin'] = "trim|alpha_dash|xss_clean";
    $rules['Group-user'] = "trim|alpha_dash|xss_clean";
    $rules['Group-guest'] = "trim|alpha_dash|xss_clean";
    $rules['Group-all'] = "trim|alpha_dash|xss_clean";
    foreach ($customgroups as $key => $value) {
      $rules['Group-'.$key] = "trim|alpha_dash|xss_clean";
    }
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Side'] = $this->lang->line('blocks_side');
    $fields['Order'] = $this->lang->line('admin_order');
    $fields['Language'] = $this->lang->line('admin_lang');
    $fields['Contenido'] = $this->lang->line('admin_content');
    $fields['Enabled'] = $this->lang->line('main_enabled');
    $fields['Type'] = $this->lang->line('blocks_type');
    $fields['File'] = $this->lang->line('blocks_file');

    $this->validation->set_fields($fields);

    if ($this->input->post('Order') === FALSE) {
      $this->validation->Order = '20';
      $this->validation->Enabled = 1;
      $this->validation->Type = 1;
    }

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_blocks')).'<br />';
      $form .= $err . $this->_make_form('add', $this->module_url.'/add', $customgroups);

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $groups = '';

      $var = 'Group-admin';
      if (isset($this->validation->$var)) $groups .= '+admin[]';
      $var = 'Group-user';
      if (isset($this->validation->$var)) $groups .= '+user[]';
      $var = 'Group-guest';
      if (isset($this->validation->$var)) $groups .= '+guest[]';
      $var = 'Group-all';
      if (isset($this->validation->$var)) $groups .= '+all[]';

      foreach ($customgroups as $key => $value) {
        $varname = 'Group-'.$key;
        if (isset($this->validation->$varname)) $groups .= '+'.$key.'[]';
      }

      if ($this->validation->Type == 1) $this->validation->File = '';
      if ($this->validation->Type == 2) $this->validation->Contenido = '';

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      'lang' => $this->validation->Language,
      'sort' => $this->validation->Order,
      'side' => $this->validation->Side,
      'content' => $this->validation->Contenido,
      'enabled' => $this->validation->Enabled,
      'type' => $this->validation->Type,
      'file' => $this->validation->File,
      'groupaccess' => $groups,
      );
      $this->db->insert('blocks', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/add');
      return;
    }
  }


  /**
   * creates and return a html form to add or edit a block.
   *
   * @private
   *
   * @param action enum. The type of form to create. Valid options are "add" or "edit"
   * @param directo string. The form's action URL.
   * @param customgroups array. Custom groups taken from "Groups" option into Administration Panel.  System groups are: Group-admin, Group-user, Group-guest, Group-guest, Group-all
   *
   * @return string
   */
  function _make_form ($action, $directo, $customgroups) {
    //action - allowed values: add / edit

//erm formularios para introducir los permisos de los grupos
//------------------------------------------------------------------------------------------------------
    $groupsform = '';
    $groupsform = $this->table->set_heading($this->lang->line('blocks_whocansee'),$this->lang->line('admin_notes'));

    $this->table->add_row('<b>'.$this->lang->line('usersgroups_system').'</b>','');
    $varname = 'Group-admin';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_admin'), $this->lang->line('usersgroups_adminnote'));

    $varname = 'Group-user';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_user'), $this->lang->line('usersgroups_usernote'));

    $varname = 'Group-guest';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_guest'), $this->lang->line('usersgroups_guestnote'));

    $varname = 'Group-all';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_all'), $this->lang->line('usersgroups_allnote'));

    $this->table->add_row('<b>'.$this->lang->line('usersgroups_custom').'</b>','');

    foreach ($customgroups as $key => $value) {
      $var = 'Group-'.$key;
      $this->table->add_row(form_checkbox($var, '1', (isset($this->validation->$var) ? 1: 0)).$key, html_entity_decode ($value));
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing="0" width="95%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',
    );
    $this->table->set_template($tmpl);
    $groupsform .= $this->table->generate();
    $this->table->clear();

//erm FIN formularios para introducir los permisos de los grupos
//------------------------------------------------------------------------------------------------------


    $form =  '';

    $attributes = array('id' => 'formBlock', 'name' => 'formBlock');

    $form = form_open($directo, $attributes);

    if ($action == 'add') {
      $data = array('name' => 'Code', 'id' => 'Code', 'value' => $this->validation->Code, 'size' => '16');
      $this->table->add_row($this->lang->line('admin_code'), form_input($data).$this->lang->line('admin_required'));
    }
    if ($action == 'edit') {
      $data = "<b>".$this->validation->Code."</b>";
      $this->table->add_row($this->lang->line('admin_code'), $data.form_hidden('Code', $this->validation->Code));
    }

    $key = 'Name';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
    $this->table->add_row($this->lang->line('main_title'), form_input($data));

    $key = 'Enabled';
    $radio = form_radio($key, '1', intval($this->validation->$key)) . $this->lang->line('main_yes')
    .form_radio($key, '0', !intval($this->validation->$key)) . $this->lang->line('main_no');
    $this->table->add_row($this->lang->line('main_enabled'), $radio);

    $data = array();
    $data[''] = '--- '.$this->lang->line('main_pleaseselect').' ---';
    for ($i = 1; $i <= 6; $i++) {
      $data[$i] = $this->lang->line('blocks_side'.$i);
    }
    $key = 'Side';
    $this->table->add_row($this->lang->line('blocks_side'), form_dropdown($key, $data, $this->validation->$key).$this->lang->line('admin_required'));

    $data = array('name' => 'Order', 'id' => 'Order', 'value' => $this->validation->Order, 'size' => '5');
    $this->table->add_row($this->lang->line('admin_order'), form_input($data).$this->lang->line('admin_required'));

    $this->table->add_row($this->lang->line('admin_lang'), form_dropdown('Language', get_lang_list(), $this->validation->Language));

    $this->table->add_row($this->lang->line('blocks_groups'), $groupsform);

    $key = 'Type';
    $selfile = intval($this->validation->$key) == 2 ? 1 : 0;
    $selcont = intval($this->validation->$key) == 1 ? 1 : 0;
    $radio = form_radio($key, '2', $selfile) . $this->lang->line('blocks_file')
    . form_radio($key, '1', $selcont) . $this->lang->line('blocks_content');
    $this->table->add_row($this->lang->line('blocks_type'), $radio);

    $note = msgWarning('', $this->lang->line('blocks_filenote'));
    $key = 'File';
    $this->table->add_row($this->lang->line('blocks_file'), form_dropdown($key, get_blocks_list(), $this->validation->$key).$note);

    $note = msgWarning('', $this->lang->line('blocks_contentnote'));
    $key = 'Contenido';
    $this->table->add_row($this->lang->line('blocks_content'), textArea($key, $this->validation->$key, 'standard', '200px').$note);

    if ($action == 'add') $this->table->add_row('', form_submit('submit', $this->lang->line('blocks_add')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('admin_savechanges')));

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=2 cellspacing=2 style="width:100%">');
    $this->table->set_template($tmpl);

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }

  /**
   * looks for the block code into DB. If it exists, return FALSE, else return TRUE
   *
   * @private
   *
   * @param str string. The block code
   *
   * @return boolean
   */
  function _unique_code_check($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('blocks');
    if ($query->num_rows() > 0) {
      $this->validation->set_message('_unique_code_check', $this->lang->line('blocks_codeduplicated'));
      return FALSE;
    } else {
      return TRUE;
    }
  }

  /**
   * looks for the block code into DB. If it exists, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. The block code
   *
   * @return boolean
   */
  function _code_exits($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('blocks');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_code_exits', $this->lang->line('blocks_codenofound'));
      return FALSE;
    }
  }

  /**
   * creates and return a html form asking the block code for edit or delete actions.
   *
   * @private
   *
   * @param action enum. The action URL of the form. Valid options are "edit" and "del"
   *
   * @return string
   */
  function _askcode_form ($action) {
    //action - allowed values: del / edit
    $form = "";

    $attributes = array('id' => 'formBlock', 'name' => 'formBlock');

    if ($action == 'del') $form .= form_open($this->module_url.'/delask', $attributes);
    if ($action == 'edit') $form .= form_open($this->module_url.'/editask', $attributes);

    $data = array('name' => 'Code', 'id' => 'Code', 'value' => $this->validation->Code, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_code'), form_input($data));

    if ($action == 'del') $this->table->add_row('', form_submit('submit', $this->lang->line('blocks_del')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('blocks_edit')));

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }

  /**
   * sends to browser the list of blocks.
   *
   * @public
   *
   * @return nothing
   */
  function show() {

    if ($this->_accesgranted($this->access[2]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $itemxpage = 25;

    $this->lang->load('admin');
    $this->load->helper(array('url','form'));
    $this->load->library(array('pagination', 'table'));

//erm creacion de los links
//------------------------------------------------------------------------------
    $config['base_url'] = $this->config->site_url().'/'.$this->module_url."/show";
    $config['total_rows'] = $this->db->count_all('blocks');
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = "4";
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    //$config['num_links'] = "2";
    $this->pagination->initialize($config);
    $links = $this->pagination->create_links();

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------
    $begin = intval($this->uri->segment(4, 0));
    if ($begin < 0) $begin = 0;
    $lista = "";
    $this->db->orderby("side, sort, name");
    $query = $this->db->get('blocks', $itemxpage, $begin);

    $this->table->set_heading(
    '#', $this->lang->line('admin_code'), $this->lang->line('admin_name'), $this->lang->line('admin_order'), $this->lang->line('main_enabled'),
    $this->lang->line('blocks_side'), $this->lang->line('admin_lang'), $this->lang->line('blocks_type'), $this->lang->line('blocks_groups'),
    $this->lang->line('main_functions')
    );
    $i = $begin+1;
    foreach ($query->result() as $row) {
      $del = anchor($this->module_url.'/del/'.$row->code, $this->lang->line('admin_del'));
      $edit = anchor($this->module_url.'/edit/'.$row->code, $this->lang->line('admin_edit'));
      if ($row->lang == "") $row->lang = $this->lang->line('admin_all');
      $row->side = $this->lang->line('blocks_side'.$row->side);
      $type = $row->type == 2 ? $this->lang->line('blocks_file') : $this->lang->line('blocks_content');
      $enabled = $row->enabled == 1 ? $this->lang->line('main_yes') : $this->lang->line('main_no');

      $groups = str_replace('[]','',$row->groupaccess);
      $groups = str_replace('+',' ',$groups);
      if ($groups == '') $groups = '<b>'.$this->lang->line('usersgroups_none').'</b>';

      $this->table->add_row($i, $row->code, $row->name, $row->sort, $enabled, $row->side, $row->lang, $type, $groups, $edit.'-'.$del);
      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing="0" width="100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $lista = $this->table->generate();


//erm enviar los resultados a la salida
//------------------------------------------------------------------------------
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');

    $center = $this->_thissubmenu($this->lang->line('blocks_listof')).'<br />';
    $center .= $lista ."<br />". $links;
    $data['content'] = theme($this->_leftmenu(), $center);
    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * sends to browser a form asking the block to be deleted
   *
   * @public
   *
   * @return nothing
   */
  function delask() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|xss_clean";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('blocks_del')) . '<br />';
      $form .= $err . $this->_askcode_form ('del');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/del/'.$this->validation->Code);
      return;
    }
  }

  /**
   * sends to browser a form to confirm the block deletion, if user click yes, the block is deleted
   *
   * @public
   *
   * @return nothing
   */
  function del() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask/');
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('blocks_del')).'<br />'
      . $err
      . Ask_yesno_form (sprintf($this->lang->line('blocks_askdel'), $code), $this->module_url.'/del/'.$code, $this->module_url.'/delask');

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      $this->db->delete('blocks', array('code' => $code));
      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask');
      return;
    }
  }

  /**
   * sends to browser a form asking the block to be edited
   *
   * @public
   *
   * @return nothing
   */
  function editask () {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|xss_clean|callback__code_exits";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('blocks_edit')).'<br />';
      $form .= $err . $this->_askcode_form ('edit');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/edit/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to update the block, do the validation proccess
   * and if it is successfull, update the new block information
   *
   * @public
   *
   * @return nothing
   */
  function edit() {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

//erm buscar si el codigo existe en la base de datos
//------------------------------------------------------------------------------
    $this->db->where('code', $code);
    $query = $this->db->get('blocks');

    if ($query->num_rows() == 0) {

      $msg = base64_encode(msgWarning('',$this->lang->line('blocks_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

    $customgroups = get_usersgroups_list();

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Side'] = $this->lang->line('blocks_side');
    $fields['Order'] = $this->lang->line('admin_order');
    $fields['Language'] = $this->lang->line('admin_lang');
    $fields['Contenido'] = $this->lang->line('admin_content');
    $fields['Enabled'] = $this->lang->line('main_enabled');
    $fields['Type'] = $this->lang->line('blocks_type');
    $fields['File'] = $this->lang->line('blocks_file');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {
      $row = $query->row();
      $this->validation->Code = $code;
      $this->validation->Name = $row->name;
      $this->validation->Order = $row->sort;
      $this->validation->Side = $row->side;
      $this->validation->Language = $row->lang;
      $this->validation->Contenido = $row->content;
      $this->validation->Enabled = $row->enabled;
      $this->validation->Type = $row->type;
      $this->validation->File = $row->file;

      $tmparray = array('admin','user','guest','all');
      foreach ($tmparray as $key) {
        if (strpos($row->groupaccess, '+'.$key.'[]') !== FALSE) {
          $varname = 'Group-'.$key;
          $this->validation->$varname = 1;
        }
      }

      foreach ($customgroups as $key => $value) {
        if (strpos($row->groupaccess, '+'.$key.'[]') !== FALSE) {
          $varname = 'Group-'.$key;
          $this->validation->$varname = 1;
        }
      }

    }

    $this->validation->set_error_delimiters('','<br />');

    $rules['Code']  = "trim|strip_tags|required|xss_clean";
    $rules['Name']  = "trim|strip_tags|htmlentities|xss_clean";
    $rules['Order']  = "trim|required|numeric|xss_clean";
    $rules['Side']  = "trim|required|numeric|xss_clean";
    $rules['Language']  = "trim|xss_clean";
    $rules['Contenido']  = "trim|xss_clean";
    $rules['Enabled']  = "trim|required|xss_clean";
    $rules['Type']  = "trim|required|xss_clean";
    $rules['File']  = "trim|htmlentities|xss_clean";

    $rules['Group-admin'] = "trim|alpha_dash|xss_clean";
    $rules['Group-user'] = "trim|alpha_dash|xss_clean";
    $rules['Group-guest'] = "trim|alpha_dash|xss_clean";
    $rules['Group-all'] = "trim|alpha_dash|xss_clean";
    foreach ($customgroups as $key => $value) {
      $rules['Group-'.$key] = "trim|alpha_dash|xss_clean";
    }
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_blocks')).'<br />';
      $form .= $err . $this->_make_form('edit', $this->module_url.'/edit/'.$code, $customgroups);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $groups = '';

      $var = 'Group-admin';
      if (isset($this->validation->$var)) $groups .= '+admin[]';
      $var = 'Group-user';
      if (isset($this->validation->$var)) $groups .= '+user[]';
      $var = 'Group-guest';
      if (isset($this->validation->$var)) $groups .= '+guest[]';
      $var = 'Group-all';
      if (isset($this->validation->$var)) $groups .= '+all[]';

      foreach ($customgroups as $key => $value) {
        $varname = 'Group-'.$key;
        if (isset($this->validation->$varname)) $groups .= '+'.$key.'[]';
      }

      if ($this->validation->Type == 1) $this->validation->File = '';
      if ($this->validation->Type == 2) $this->validation->Contenido = '';

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      'lang' => $this->validation->Language,
      'sort' => $this->validation->Order,
      'side' => $this->validation->Side,
      'content' => $this->validation->Contenido,
      'enabled' => $this->validation->Enabled,
      'type' => $this->validation->Type,
      'file' => $this->validation->File,
      'groupaccess' => $groups,
      );
      $this->db->where('code', $code);
      $this->db->update('blocks', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

  }
}
?>
