<?php

/**
 * @file admin/menu.php
 * @brief File to manage menus (list, add, edit and delete)
 * 
 * @class Menu
 * @brief Class to manage menus (list, add, edit and delete)
 *
 * @details
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Menu extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/menu";

  /**
   * the title for this controller
   */ 
  var $module_name = "Menu";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If admin has not permissions, redirect to access denied
   *
   * @public
   */
  function Menu() {
    parent::Controller();

    $this->access[1] = "add";
    $this->access[2] = "show";
    $this->access[3] = "del";
    $this->access[4] = "edit";
  }


  /**
   * return the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "add del edit";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    /*
    $items[] = '<b>'.$this->lang->line('admin_actions').'</b>';
    $items[] = anchor($this->module_url.'/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    $items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));
    */

    return navbarsubmenu($title, '', 'menu.png');
    //!!return navbarsubmenu($title, $items, 'menu.png');
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";
    make_blocks(array(1));
    $leftmenu = $this->block_side1;
    return $leftmenu;
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index () {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie','date'));

    $customgroups = get_usersgroups_list();

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if ($this->_accesgranted($this->access[1]) == 0) return;

    $this->validation->set_error_delimiters('','<br />');
    $rules['Type']  = "trim|required|xss_clean";
    $rules['Title']  = "trim|strip_tags|htmlentities|xss_clean";
    $rules['Url']  = "trim|strip_tags|xss_clean";
    $rules['Order']  = "trim|required|numeric|xss_clean";

    $rules['Group-admin'] = "trim|alpha_dash|xss_clean";
    $rules['Group-user'] = "trim|alpha_dash|xss_clean";
    $rules['Group-guest'] = "trim|alpha_dash|xss_clean";
    $rules['Group-all'] = "trim|alpha_dash|xss_clean";
    foreach ($customgroups as $key => $value) {
      $rules['Group-'.$key] = "trim|alpha_dash|xss_clean";
    }
    $this->validation->set_rules($rules);

    $fields['Type'] = $this->lang->line('menu_selcontroller');
    $fields['Title'] = $this->lang->line('menu_title');
    $fields['Url'] = $this->lang->line('menu_url');
    $fields['Order'] = $this->lang->line('menu_weight');
    $this->validation->set_fields($fields);
    if ($this->input->post('Order') === FALSE) {
      $this->validation->Order = '50';
    }

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_menu'));

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $form .= $msg.$err
      .$this->show().'<br /><br />'
      .$this->_make_form('add', $this->module_url, $customgroups);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $groups = '';

      $var = 'Group-admin';
      if (isset($this->validation->$var)) $groups .= '+admin[]';
      $var = 'Group-user';
      if (isset($this->validation->$var)) $groups .= '+user[]';
      $var = 'Group-guest';
      if (isset($this->validation->$var)) $groups .= '+guest[]';
      $var = 'Group-all';
      if (isset($this->validation->$var)) $groups .= '+all[]';

      foreach ($customgroups as $key => $value) {
        $varname = 'Group-'.$key;
        if (isset($this->validation->$varname)) $groups .= '+'.$key.'[]';
      }

      switch ($this->validation->Type) {
        case '-title-':
          $this->validation->Url = "";
          break;
        case '-line-':
          $this->validation->Url = "";
          $this->validation->Title = "";
          break;
        case '-inlink-':
        case '-oulink-':
          break;
        default:
          $this->validation->Url = $this->validation->Type;
          break;
      }

      $data = array(
      'name' => $this->validation->Title,
      'type' => $this->validation->Type,
      'link' => $this->validation->Url,
      'weight' => $this->validation->Order,
      'groupaccess' => $groups,
      );
      $this->db->insert('menu', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }
  }


  /**
   * creates and return a html form to add or edit a menu.
   *
   * @private
   *
   * @param action enum. The type of form to create. Valid options are "add" or "edit"
   * @param directo string. The form's action URL.
   * @param customgroups array. Custom groups taken from "Groups" option into Administration Panel.  System groups are: Group-admin, Group-user, Group-guest, Group-guest, Group-all
   *
   * @return string
   */
  function _make_form ($action, $directo, $customgroups) {
    //@action - allowed values: add / edit

//erm formularios para introducir los permisos de los grupos
//------------------------------------------------------------------------------------------------------
    $groupsform = '';
    $groupsform = $this->table->set_heading($this->lang->line('blocks_whocansee'),$this->lang->line('admin_notes'));

    $this->table->add_row('<b>'.$this->lang->line('usersgroups_system').'</b>','');
    $varname = 'Group-admin';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_admin'), $this->lang->line('usersgroups_adminnote'));

    $varname = 'Group-user';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_user'), $this->lang->line('usersgroups_usernote'));

    $varname = 'Group-guest';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_guest'), $this->lang->line('usersgroups_guestnote'));

    $varname = 'Group-all';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_all'), $this->lang->line('usersgroups_allnote'));

    $this->table->add_row('<b>'.$this->lang->line('usersgroups_custom').'</b>','');

    foreach ($customgroups as $key => $value) {
      $var = 'Group-'.$key;
      $this->table->add_row(form_checkbox($var, '1', (isset($this->validation->$var) ? 1: 0)).$key, html_entity_decode ($value));
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing="0" width="95%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',
    );
    $this->table->set_template($tmpl);
    $groupsform .= $this->table->generate();
    $this->table->clear();

//erm FIN formularios para introducir los permisos de los grupos
//------------------------------------------------------------------------------------------------------


    $form =  '';

    $key = 'formMenu';
    $attributes = array('id' => $key, 'name' => $key);

    $form = form_open($directo, $attributes);

    if ($action == 'edit') {
      $data = "<b>".$this->validation->Code."</b>";
      $this->table->add_row($this->lang->line('admin_code'), $data.form_hidden('Code', $this->validation->Code));
    }

    $key = 'Title';
    $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'15');
    $this->table->add_row($this->lang->line('menu_title'), form_input($data));

    $key = 'Type';
    $array = get_controllers_list();
    $array['  '] = '';
    $array['   '] = '--- '.$this->lang->line('menu_options').' ---';
    $array['-title-'] = 'Add Title';
    $array['-inlink-'] = 'Add Inside Link';
    $array['-oulink-'] = 'Add Outside Link';
    $array['-line-'] = 'Add Line';
    $value =  form_dropdown($key, $array, $this->validation->$key);
    $this->table->add_row($this->lang->line('menu_selcontroller'),$value.$this->lang->line('admin_required'));

    $key = 'Order';
    $data = array('name'=>$key, 'id'=>$key, 'value' => $this->validation->$key, 'size' => '5');
    $this->table->add_row($this->lang->line('menu_weight'), form_input($data).$this->lang->line('admin_required'));

    $key = 'Url';
    $note = msgWarning('', sprintf($this->lang->line('menu_urlnote'), $this->config->site_url()));
    $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'style'=>'width:98%');
    $this->table->add_row($this->lang->line('menu_url'), form_input($data).$note);

    $this->table->add_row($this->lang->line('blocks_groups'), $groupsform);

    if ($action == 'add') $this->table->add_row('', form_submit('submit', $this->lang->line('menu_add')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('admin_savechanges')));

    $tmpl = array ( 'table_open'  => '<table border="0" cellpadding="2" cellspacing="1">' );
    $this->table->set_template($tmpl);
    $form .= $this->table->generate();

    $form .= form_close();

    return $form;
  }


  /**
   * looks for the menu code into DB. If it exists, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. The menu code
   *
   * @return boolean
   */
  function _code_exits($str) {
    $this->db->where(array('id'=>$str));
    $this->db->select("id");
    $query = $this->db->get('menu');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_code_exits', $this->lang->line('menu_codenofound'));
      return FALSE;
    }
  }


  /**
   * sends to browser the list of menus.
   *
   * @public
   *
   * @return nothing
   */
  function show() {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->helper(array('url'));
    $this->load->library(array('table'));

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------

    $lista = "";
    $this->db->order_by("weight");
    $this->db->order_by("type");
    $this->db->order_by("name");
    $query = $this->db->get('menu');

    $this->table->set_heading(
    '#', $this->lang->line('menu_id'), $this->lang->line('menu_weight'), $this->lang->line('menu_title'),
    $this->lang->line('menu_url'), $this->lang->line('menu_groups'),
    /*$this->lang->line('menu_selcontroller'),*/ $this->lang->line('main_functions')
    );
    $i = 1;
    foreach ($query->result() as $row) {

      $menu_class = '';
      switch ($row->type) {
        case '-title-':
          $menu_class = 'title';
          break;
        case '-line-':
          $menu_class = 'line';
          break;
        case '-oulink-':
          $menu_class = 'oulink';
          break;
        case '-inlink-':
        default:
          $menu_class = 'inlink';
          break;
      }

      $groups = str_replace('[]','',$row->groupaccess);
      $groups = str_replace('+',' ',$groups);
      if ($groups == '') $groups = '<b>'.$this->lang->line('usersgroups_none').'</b>';


      $del = anchor($this->module_url.'/del/'.$row->id, $this->lang->line('admin_del'));
      $edit = anchor($this->module_url.'/edit/'.$row->id, $this->lang->line('admin_edit'));
      $this->table->add_row($i, $row->id, $row->weight,
      sprintf('<div class="menu"><div class="'.$menu_class.'">%s</div></div>', $row->name),
      $row->link, $groups, /*$row->type,*/ $edit.'-'.$del);
      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing="0" style="width:100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',
    );
    $this->table->set_template($tmpl);
    $lista = $this->table->generate();
    $this->table->clear();

//erm enviar los resultados a la salida
//------------------------------------------------------------------------------

    return $lista;

  }


  /**
   * sends to browser a form to confirm the menu deletion, if admin click yes, the menu is deleted
   *
   * @public
   *
   * @return nothing
   */
  function del() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('menu_del'))
      . $err
      . Ask_yesno_form (sprintf($this->lang->line('menu_askdel'), $code), $this->module_url.'/del/'.$code, $this->module_url);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      $this->db->delete('menu', array('id' => $code));
      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }
  }


  /**
   * sends to browser a form to update the menu, do the validation proccess
   * and if it is successfull, update the new menu information
   *
   * @public
   *
   * @return nothing
   */
  function edit() {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

//erm buscar si el codigo existe en la base de datos
//------------------------------------------------------------------------------
    $this->db->where('id', $code);
    $query = $this->db->get('menu');

    if ($query->num_rows() == 0) {

      $msg = base64_encode(msgWarning('',$this->lang->line('menu_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

    $customgroups = get_usersgroups_list();

    $fields['Type'] = $this->lang->line('menu_selcontroller');
    $fields['Title'] = $this->lang->line('menu_title');
    $fields['Url'] = $this->lang->line('menu_url');
    $fields['Order'] = $this->lang->line('menu_weight');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {
      $row = $query->row();

      switch ($row->type) {
        case '-oulink-':
        case '-inlink-':
          break;
        case '-title-':
        case '-line-':
        default:
          $row->link = "";
          break;
      }

      $this->validation->Code = $code;
      $this->validation->Title = $row->name;
      $this->validation->Type = $row->type;
      $this->validation->Url = $row->link;
      $this->validation->Order = $row->weight;

      $tmparray = array('admin','user','guest','all');
      foreach ($tmparray as $key) {
        if (strpos($row->groupaccess, '+'.$key.'[]') !== FALSE) {
          $varname = 'Group-'.$key;
          $this->validation->$varname = 1;
        }
      }

      foreach ($customgroups as $key => $value) {
        if (strpos($row->groupaccess, '+'.$key.'[]') !== FALSE) {
          $varname = 'Group-'.$key;
          $this->validation->$varname = 1;
        }
      }

    }

    $this->validation->set_error_delimiters('','<br />');

    $rules['Code']  = "trim|required|xss_clean";
    $rules['Type']  = "trim|required|xss_clean";
    $rules['Title']  = "trim|htmlentities|xss_clean";
    $rules['Url']  = "trim|xss_clean";
    $rules['Order']  = "trim|required|numeric|xss_clean";

    $rules['Group-admin'] = "trim|alpha_dash|xss_clean";
    $rules['Group-user'] = "trim|alpha_dash|xss_clean";
    $rules['Group-guest'] = "trim|alpha_dash|xss_clean";
    $rules['Group-all'] = "trim|alpha_dash|xss_clean";
    foreach ($customgroups as $key => $value) {
      $rules['Group-'.$key] = "trim|alpha_dash|xss_clean";
    }
    $this->validation->set_rules($rules);


    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_menu'));
      $form .= $err . $this->_make_form('edit', $this->module_url.'/edit/'.$code, $customgroups);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $groups = '';

      $var = 'Group-admin';
      if (isset($this->validation->$var)) $groups .= '+admin[]';
      $var = 'Group-user';
      if (isset($this->validation->$var)) $groups .= '+user[]';
      $var = 'Group-guest';
      if (isset($this->validation->$var)) $groups .= '+guest[]';
      $var = 'Group-all';
      if (isset($this->validation->$var)) $groups .= '+all[]';

      foreach ($customgroups as $key => $value) {
        $varname = 'Group-'.$key;
        if (isset($this->validation->$varname)) $groups .= '+'.$key.'[]';
      }

      switch ($this->validation->Type) {
        case '-title-':
          $this->validation->Url = "";
          break;
        case '-line-':
          $this->validation->Url = "";
          $this->validation->Title = "";
          break;
        case '-inlink-':
        case '-oulink-':
          break;
        default:
          $this->validation->Url = $this->validation->Type;
          break;
      }

      $data = array(
      'name' => $this->validation->Title,
      'type' => $this->validation->Type,
      'link' => $this->validation->Url,
      'weight' => $this->validation->Order,
      'groupaccess' => $groups,
      );

      $this->db->where('id', $code);
      $this->db->update('menu', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

  }
}
?>
