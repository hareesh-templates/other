<?php

/**
 * @file admin/users.php
 * @brief File to manage users (list, add, edit and delete)
 * 
 * @class Users
 * @brief Class to manage users (list, add, edit and delete)
 *
 * @details Some modules requires a valid logued user
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */


class Users extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/users";

  /**
   * the title for this controller
   */ 
  var $module_name = "users";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If admin has not permissions, redirect to access denied
   *
   * @public
   */
  function Users() {
    parent::Controller();

    $this->access[1] = "add";
    $this->access[2] = "show";
    $this->access[3] = "del";
    $this->access[4] = "edit";
    $this->access[5] = "config";
    $this->access[6] = "assign";

  }


  /**
   * return the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "add show del edit assign config";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string. the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    //$items[] = '<b>'.$this->lang->line('admin_actions').'</b>';
    $items[] = anchor($this->module_url.'/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    $items[] = anchor($this->module_url.'/assignask', $this->lang->line('users_assign'));
    $items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));
    $items[] = anchor($this->module_url.'/settings', $this->lang->line('users_config'));

    return navbarsubmenu($title, $items, 'users.png');
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";
    make_blocks(array(1));
    $leftmenu = $this->block_side1;
    return $leftmenu;
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('admin_users')).'<br />';
    $content .= $this->lang->line('admin_defactions');

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * sends to browser an add user form, do the validation proccess and if it is successfull, then add the new user
   *
   * @public
   *
   * @return nothing
   */
  function add() {
    if ($this->_accesgranted($this->access[1]) == 0) return;

    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->helper(array('url','form', 'cookie','date'));
    $this->load->library(array('validation', 'table'));

    $customgroups = get_usersgroups_list();

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|strip_tags|required|alpha_dash|callback__unique_code_check";
    $rules['Name']  = "trim|required|xss_clean";
    $rules['Password']  = "trim|required";
    $rules['Email']  = "trim|strip_tags|required|valid_email|xss_clean";
    $rules['Status']  = "trim|required";
    $rules['Notes']  = "trim|xss_clean";
    $rules['is_physician']  = "trim|xss_clean";

    foreach ($customgroups as $key => $value) {
      $rules['Group-'.$key] = "trim|alpha_dash|xss_clean";
    }

    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('users_username');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Password'] = $this->lang->line('admin_password');
    $fields['Email'] = $this->lang->line('admin_email');
    $fields['Status'] = $this->lang->line('users_status');
    $fields['Notes'] = $this->lang->line('admin_notes');
    $fields['is_physician'] = $this->lang->line('users_isphysician');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_users')).'<br />';
      $form .= $err . $this->_make_form('add', $this->module_url.'/add', $customgroups);

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();

      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $groups = '';
      foreach ($customgroups as $key => $value) {
        $varname = 'Group-'.$key;
        if (isset($this->validation->$varname)) $groups .= '+'.$key.'[]';
      }

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      'password' => md5($this->validation->Password),
      'email' => $this->validation->Email,
      'createddate' => now(),
      'groups' => $groups,
      'lastlogdate' => 0,
      'lang' => $this->config->item('language'),
      'theme' => $this->config->item('theme'),
      'timezone' => $this->config->item('timezone'),
      'status' => $this->validation->Status,
      'notes' => $this->validation->Notes,
      'is_physician'   => $this->validation->is_physician,
      );
      $this->db->insert('users', $data);

      $redirect = $this->module_url.'/show';
      if ($this->validation->is_physician) $redirect = 'admin/med_physician/edit/'.$this->validation->Code;

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;

    }
  }


  /**
   * creates and return a html form to add or edit an user.
   *
   * @private
   *
   * @param action enum. The type of form to create. Valid options are "add" or "edit"
   * @param directo string. The form's action URL.
   * @param customgroups array. Custom groups taken from "Groups" option into Administration Panel.  System groups are: Group-admin, Group-user, Group-guest, Group-guest, Group-all
   *
   * @return string
   */
  function _make_form ($action, $directo, $customgroups) {
    //@action - allowed values: add / edit

//erm formularios para introducir los permisos de los grupos
//------------------------------------------------------------------------------------------------------
    $groupsform = '';
    $groupsform = $this->table->set_heading($this->lang->line('users_groups4user'),$this->lang->line('admin_notes'));

    $this->table->add_row('<b>'.$this->lang->line('usersgroups_custom').'</b>','');

    foreach ($customgroups as $key => $value) {
      $var = 'Group-'.$key;
      $this->table->add_row(form_checkbox($var, '1', (isset($this->validation->$var) ? 1: 0)).$key, html_entity_decode ($value));
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing="0" width="95%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',
    );
    $this->table->set_template($tmpl);
    $groupsform .= $this->table->generate();
    $this->table->clear();

//erm FIN formularios para introducir los permisos de los grupos
//------------------------------------------------------------------------------------------------------


    $form = "";

    $key = 'formUsers';
    $attributes = array('id' => $key, 'name' => $key);
    $form = form_open($directo, $attributes);

    if ($action == 'add') {
      $key = 'Code';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
      $this->table->add_row($this->lang->line('users_username'), form_input($data).$this->lang->line('admin_required'));
    }
    if ($action == 'edit') {

      $detail_url = '';
      if ($this->validation->is_physician) {
        $this->lang->load('med_common');
        $detail_url = sprintf(
          ' (%s)',
          anchor('admin/med_physician/edit/'.$this->validation->Code, $this->lang->line('physician_details'))
        );
      }

      $key = 'Code';
      $data = "<b>".$this->validation->$key."</b> " . $detail_url;
      $this->table->add_row($this->lang->line('users_username'), $data.form_hidden($key, $this->validation->Code));
    }

    if ($action == 'add') $passnote = $this->lang->line('admin_required');
    if ($action == 'edit') $passnote = $this->lang->line('admin_enternewpasstochange');

    $key = 'Name';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_name'), form_input($data).$this->lang->line('admin_required'));

    $key = 'Password';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_password'), form_input($data).$passnote);

    $key = 'Email';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_email'), form_input($data).$this->lang->line('admin_required'));

    $key = 'Status';
    $active = intval($this->validation->$key) == 1 ? 1 : 0;
    $disabled = intval($this->validation->$key) == 2 ? 1 : 0;
    $radio = form_radio($key, '1', $active) . $this->lang->line('users_statusactive')
    . form_radio($key, '2', $disabled) . $this->lang->line('users_statusdisabled');
    $this->table->add_row($this->lang->line('users_status'), $radio.$this->lang->line('admin_required'));


    $key = 'Notes';
    $this->table->add_row($this->lang->line('admin_notes'), textArea($key, $this->validation->$key, 'mini'));

    $this->table->add_row($this->lang->line('blocks_groups'), $groupsform);


    $key = 'is_physician';
    $radio = form_radio($key, '1', intval($this->validation->$key)) . $this->lang->line('main_yes')
    .form_radio($key, '0', !intval($this->validation->$key)) . $this->lang->line('main_no');
    $this->table->add_row($this->lang->line('users_isphysician'), $radio);


    if ($action == 'add') $this->table->add_row('', ''.form_submit('submit', $this->lang->line('users_add')));
    if ($action == 'edit') $this->table->add_row('', ''.form_submit('submit', $this->lang->line('admin_savechanges')));

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=4 style="width:100%">');
    $this->table->set_template($tmpl);

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;

  }


  /**
   * looks for the user code into DB. If it exists, return FALSE, else return TRUE
   *
   * @private
   *
   * @param str string. The user code
   *
   * @return boolean
   */
  function _unique_code_check($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('users');
    if ($query->num_rows() > 0) {
      $this->validation->set_message('_unique_code_check', $this->lang->line('users_usernametaken'));
      return FALSE;
    } else {
      return TRUE;
    }
  }


  /**
   * looks for the user code into DB. If it exists, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string The user code
   *
   * @return boolean
   */
  function _code_exists($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('users');
    if ($query->num_rows() == 0) {
      $this->validation->set_message('_code_exists', $this->lang->line('users_usernoexist'));
      return FALSE;
    } else {
      return TRUE;
    }
  }


  /**
   * sends to browser the list of users.
   *
   * @public
   *
   * @return nothing
   */
  function show() {

    if ($this->_accesgranted($this->access[2]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $itemxpage = 25;

    $this->lang->load('admin');
    $this->lang->load('user');
    $this->lang->load('med_common');
    $this->load->helper(array('url','form','text', 'date'));
    $this->load->library(array('pagination', 'table'));

//erm creacion de los links
//------------------------------------------------------------------------------
    $config['base_url'] = $this->config->site_url().'/'.$this->module_url."/show";
    $config['total_rows'] = $this->db->count_all('users');
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = "4";
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    //$config['num_links'] = "2";
    $this->pagination->initialize($config);
    $links = $this->pagination->create_links();

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------
    $begin = intval($this->uri->segment(4, 0));
    if ($begin < 0) $begin = 0;
    $lista = "";

    $this->db->join('sessions', 'sessions.session_id = users.session_id', 'left');
    $this->db->orderby("name");
    $query = $this->db->get('users', $itemxpage, $begin);

    $this->table->set_heading(
    '', '#', $this->lang->line('admin_code'), $this->lang->line('admin_name'),
    $this->lang->line('users_status'),
    $this->lang->line('admin_lang'), $this->lang->line('users_groups'),
    $this->lang->line('main_functions')
    );
    $i = $begin+1;
    foreach ($query->result() as $row) {

      $assign = anchor($this->module_url.'/assign/'.$row->code, $this->lang->line('users_assign'));
      $edit = anchor($this->module_url.'/edit/'.$row->code, $this->lang->line('admin_edit'));
      $del = anchor($this->module_url.'/del/'.$row->code, $this->lang->line('admin_del'));


      if ($row->lang == "") $row->lang = $this->lang->line('admin_all');

      switch ($row->status) {
        case 0:
          $status =  $this->lang->line('users_statuspending');
          break;
        case 1:
          $status =  $this->lang->line('users_statusactive');
          break;
        case 2:
        default:
          $status =  $this->lang->line('users_statusdisabled');
          break;
      }

      $groups = str_replace('[]','',$row->groups);
      $groups = str_replace('+',' ',$groups);
      if ($groups == '') $groups = '<b>'.$this->lang->line('usersgroups_none').'</b>';

      $online = '';
      if ($row->session_id != '') {
        $onlinetitle = unix_to_human(gmt_to_local($row->last_activity, $this->config->item('timezone')))
        .' [' . $row->ip_address . ']';
        $online = theme_imgtag('online.png', $onlinetitle, "ONLINE");
      }

      $is_physician = '';
      if ($row->is_physician) {
        $is_physician = theme_imgtag('doctor.png', '', "DR");
      }

      $this->table->add_row(
        $is_physician.$online, $i, $row->code, $row->name, $status, $row->lang, $groups,
        sprintf('%s - %s - %s', $assign, $edit, $del)
      );
      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing=0 width="100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $lista = $this->table->generate();


//erm enviar los resultados a la salida
//------------------------------------------------------------------------------
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');

    $center = $this->_thissubmenu($this->lang->line('users_listof')).'<br />';
    $center .= $lista ."<br />". $links;
    $data['content'] = theme($this->_leftmenu(), $center);
    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * creates and return a html form asking the user code for edit or delete actions.
   *
   * @private
   *
   * @param action string The action URL of the form. Valid options are "edit" and "del"
   *
   * @return string
   */
  function _askcode_form ($action) {
    //@action - allowed values: del / edit / assign
    $form = "";

    $key = 'formContent';
    $attributes = array('id' => $key, 'name' => $key);

    if ($action == 'del') $form .= form_open($this->module_url.'/delask', $attributes);
    if ($action == 'edit') $form .= form_open($this->module_url.'/editask', $attributes);
    if ($action == 'assign') $form .= form_open($this->module_url.'/assignask', $attributes);

    $key = 'Code';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
    $this->table->add_row($this->lang->line('users_username'), form_input($data));

    if ($action == 'del') $this->table->add_row('', form_submit('submit', $this->lang->line('users_del')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('users_edit')));
    if ($action == 'assign') $this->table->add_row('', form_submit('submit', $this->lang->line('users_assignpatients')));

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }


  /**
   * sends to browser a form asking the user to be edited
   *
   * @public
   *
   * @return nothing
   */
  function editask () {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|alpha_dash|callback__code_exists";
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('users_edit')).'<br />';
      $form .= $err . $this->_askcode_form ('edit');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/edit/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to update the user, do the validation proccess
   * and if it is successfull, update the new user information
   *
   * @public
   *
   * @return nothing
   */
  function edit() {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

//erm buscar si el codigo existe en la base de datos
//------------------------------------------------------------------------------
    $this->db->where('code', $code);
    $query = $this->db->get('users');

    if ($query->num_rows() == 0) {
      $msg = base64_encode(msgWarning('',$this->lang->line('users_usernoexist')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

    $customgroups = get_usersgroups_list();

    $rules['Code']  = "trim|strip_tags|required|alpha_dash|callback__code_exists";
    $rules['Name']  = "trim|required|xss_clean";
    $rules['Password']  = "trim|xss_clean";
    $rules['Email']  = "trim|strip_tags|required|valid_email|xss_clean";
    $rules['Status']  = "trim|required";
    $rules['Notes']  = "trim|xss_clean";
    $rules['is_physician']  = "trim|xss_clean";
    foreach ($customgroups as $key => $value) {
      $rules['Group-'.$key] = "trim|alpha_dash|xss_clean";
    }
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('users_username');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Password'] = $this->lang->line('admin_password');
    $fields['Email'] = $this->lang->line('admin_email');
    $fields['Status'] = $this->lang->line('users_status');
    $fields['Notes'] = $this->lang->line('admin_notes');
    $fields['is_physician'] = $this->lang->line('users_isphysician');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {
      $row = $query->row();
      $this->validation->Code = $code;
      $this->validation->Name = $row->name;
      $this->validation->Password = '';
      $this->validation->Email = $row->email;
      $this->validation->Status = $row->status;
      $this->validation->Notes = $row->notes;
      $this->validation->is_physician = $row->is_physician;

      foreach ($customgroups as $key => $value) {
        if (strpos($row->groups, '+'.$key.'[]') !== FALSE) {
          $varname = 'Group-'.$key;
          $this->validation->$varname = 1;
        }
      }

    }

    $this->validation->set_error_delimiters('','<br />');


    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('users_edit')).'<br />';
      $form .= $err . $this->_make_form('edit', $this->module_url.'/edit/'.$code, $customgroups);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $groups = '';
      foreach ($customgroups as $key => $value) {
        $varname = 'Group-'.$key;
        if (isset($this->validation->$varname)) $groups .= '+'.$key.'[]';
      }

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      'email' => $this->validation->Email,
      'status' => $this->validation->Status,
      'notes' => $this->validation->Notes,
      'groups' => $groups,
      'is_physician'   => $this->validation->is_physician
      );
      if ($this->validation->Password != '') $data['password'] = md5($this->validation->Password);

      $this->db->where('code', $code);
      $this->db->update('users', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

  }


  /**
   * sends to browser a form asking the user to be deleted
   *
   * @public
   *
   * @return nothing
   */
  function delask() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|alpha_dash";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('users_del')) . '<br />';
      $form .= $err . $this->_askcode_form ('del');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/del/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to confirm the user deletion, if admin click yes, the user is deleted
   *
   * @public
   *
   * @return nothing
   */
  function del() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask/');
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('users_del')).'<br />'
      . $err
      . Ask_yesno_form (sprintf($this->lang->line('users_askdel'), $code), $this->module_url.'/del/'.$code, $this->module_url.'/delask');

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      $this->db->delete('users', array('code' => $code));
      $this->db->delete('med_physician', array('physician_code' => $code));
      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask');
      return;
    }
  }


  /**
   * sends to browser a form to configure the user settings (email notifications, enable/disable new user registration, etc.)
   * do the validaton process and save the new configuration
   *
   * @public
   *
   * @return nothing
   */
  function settings() {

    if ($this->_accesgranted($this->access[5]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie','date'));

//erm buscar todas las variables de configuracion de categoria users
//------------------------------------------------------------------------------
    $cat = 'users';
    $this->db->where('cat', $cat);
    $query = $this->db->get('settings');

    $settings_var = array();
    foreach ($query->result() as $row) {
      $settings_var[$row->var] = $row->value;
    }

    if (!isset($settings_var['users_accept'])) $settings_var['users_accept'] = 1;
    if (!isset($settings_var['users_fromemail'])) $settings_var['users_fromemail'] = 'noreply@domain.com';
    if (!isset($settings_var['users_verifysubject'])) $settings_var['users_verifysubject'] = 'New account Verification';
    if (!isset($settings_var['users_verifymessage'])) $settings_var['users_verifymessage'] = 'To activate your new account click %s';
    if (!isset($settings_var['users_resetsubject'])) $settings_var['users_resetsubject'] = 'Reset password instructions';
    if (!isset($settings_var['users_resetinstructions'])) $settings_var['users_resetinstructions'] = 'To reset your password click %s';
    if (!isset($settings_var['users_newpass'])) $settings_var['users_newpass'] = 'New Password';
    if (!isset($settings_var['users_newpassmsg'])) $settings_var['users_newpassmsg'] = 'Your new password is %s';


    $fields['allownewuser'] = $this->lang->line('users_allownewuser');
    $fields['fromemail'] = $this->lang->line('users_fromemail');
    $fields['verifysubject'] = $this->lang->line('users_emailsubject');
    $fields['verifymessage'] = $this->lang->line('users_emailmsg');
    $fields['resetsubject'] = $this->lang->line('users_emailsubject');
    $fields['resetinstructions'] = $this->lang->line('users_emailmsg');
    $fields['newpass'] = $this->lang->line('users_emailsubject');
    $fields['newpassmsg'] = $this->lang->line('users_emailmsg');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    $this->validation->allownewuser = $settings_var['users_accept'];
    $this->validation->fromemail = $settings_var['users_fromemail'];
    $this->validation->verifysubject = $settings_var['users_verifysubject'];
    $this->validation->verifymessage = $settings_var['users_verifymessage'];
    $this->validation->resetsubject = $settings_var['users_resetsubject'];
    $this->validation->resetinstructions = $settings_var['users_resetinstructions'];
    $this->validation->newpass = $settings_var['users_newpass'];
    $this->validation->newpassmsg = $settings_var['users_newpassmsg'];

    $this->validation->set_error_delimiters('','<br />');

    $rules['allownewuser']  = "trim|required|xss_clean";
    $rules['fromemail']  = "trim|strip_tags|required|valid_email|xss_clean";
    $rules['verifysubject']  = "trim|strip_tags|required|xss_clean";
    $rules['verifymessage']  = "trim|required|callback__s_mandatory1|xss_clean";
    $rules['resetsubject']  = "trim|strip_tags|required|xss_clean";
    $rules['resetinstructions']  = "trim|required|callback__s_mandatory2|xss_clean";
    $rules['newpass']  = "trim|strip_tags|required|xss_clean";
    $rules['newpassmsg']  = "trim|required|callback__s_mandatory3|xss_clean";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

//erm search for message cookie
//-----------------------------------------------------------------------------
      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

//erm create the form
//-----------------------------------------------------------------------------

      $tool_bar = 'little';

      $note = $this->lang->line('users_includevarmsg');
      $form = $err;

      $attributes = array('id' => 'formSettings', 'name' => 'formSettings');
      $form .= form_open($this->module_url.'/settings', $attributes);

      $form .= '** '.$this->lang->line('admin_allfieldsrequired').'<br /><br />';

//erm global site settings
//--------------------------------------------------------------------
      $this->table->add_row('<b>'.$this->lang->line('users_settingsmain').'</b>','');

      $key = "allownewuser";
      $radio = form_radio($key, '1', intval($this->validation->$key)) . $this->lang->line('main_yes')
      .form_radio($key, '0', !intval($this->validation->$key)) . $this->lang->line('main_no');
      $this->table->add_row($this->lang->line('users_allownewuser'), $radio);

      $key = "fromemail";
      $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'30');
      $this->table->add_row($this->lang->line('users_fromemail'), form_input($data));

//erm new accounts registration
//--------------------------------------------------------------------
      $this->table->add_row('<b>'.$this->lang->line('users_settingsnew').'</b>','');

      $key = "verifysubject";
      $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'60');
      $this->table->add_row($this->lang->line('users_emailsubject'), form_input($data));

      $key = "verifymessage";
      $this->table->add_row($this->lang->line('users_emailmsg'), $note.textArea($key, $this->validation->$key, $tool_bar, '300', '580px'));


//erm forgoten password
//--------------------------------------------------------------------
      $this->table->add_row('<b>'.$this->lang->line('users_settingsforgotten').'</b>','');

      $key = "resetsubject";
      $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'60');
      $this->table->add_row($this->lang->line('users_emailsubject'), form_input($data));

      $key = "resetinstructions";
      $this->table->add_row($this->lang->line('users_emailmsg'), $note.textArea($key, $this->validation->$key, $tool_bar, '300', '580px'));


//erm new password
//--------------------------------------------------------------------
      $this->table->add_row('<b>'.$this->lang->line('users_settingsnewpass').'</b>','');

      $key = "newpass";
      $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'60');
      $this->table->add_row($this->lang->line('users_emailsubject'), form_input($data));

      $key = "newpassmsg";
      $this->table->add_row($this->lang->line('users_emailmsg'), $note.textArea($key, $this->validation->$key, $tool_bar, '300', '580px'));


      $this->table->add_row('', '<br />'.form_submit('submit', $this->lang->line('admin_savechanges')));

      $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=0 style="width:100%">',
      'row_start'           => '<tr class="table_1_td1">',
      'row_alt_start'       => '<tr class="table_1_td2">'
      );
      $this->table->set_template($tmpl);

      $form .= $this->table->generate();
      $form .= form_close();


//erm send info to browser
//-----------------------------------------------------------------------------
      $subtitle = $this->_thissubmenu($this->lang->line('admin_users')).'<br />';
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$subtitle.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $this->db->trans_start();
      $this->db->delete('settings', array('cat'=>$cat));

      $cat = $this->db->escape($cat);
      $sql = "INSERT INTO " . $this->db->dbprefix . "settings (var, value, cat) VALUES "
      . " ('users_accept',".$this->db->escape($this->validation->allownewuser).",$cat), "
      . " ('users_fromemail',".$this->db->escape($this->validation->fromemail).",$cat), "
      . " ('users_verifysubject',".$this->db->escape($this->validation->verifysubject).",$cat), "
      . " ('users_verifymessage',".$this->db->escape($this->validation->verifymessage).",$cat), "
      . " ('users_resetsubject',".$this->db->escape($this->validation->resetsubject).",$cat), "
      . " ('users_resetinstructions',".$this->db->escape($this->validation->resetinstructions).",$cat), "
      . " ('users_newpass',".$this->db->escape($this->validation->newpass).",$cat), "
      . " ('users_newpassmsg',".$this->db->escape($this->validation->newpassmsg).",$cat); ";

      $this->db->query($sql);
      $this->db->trans_complete();

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/settings');
      return;
    }
  }



  /**
   * search for "%s" pattern into the param. If it does match, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. Email notification for new user registration.
   *
   * @return boolean
   */
  function _s_mandatory1($str) {
    if (!ereg('\%s', $str)) {
      $this->validation->set_message('_s_mandatory1', $this->lang->line('users_smandatorynew'));
      return FALSE;
    } else {
      return TRUE;
    }
  }


  /**
   * search for "%s" pattern into the param. If it does match, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. Email notification for forgotten password.
   *
   * @return boolean
   */
  function _s_mandatory2($str) {
    if (!ereg('\%s', $str)) {
      $this->validation->set_message('_s_mandatory2', $this->lang->line('users_smandatoryforgotten'));
      return FALSE;
    } else {
      return TRUE;
    }
  }


  /**
   * search for "%s" pattern into the param. If it does match, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. Email notification for password sent.
   *
   * @return boolean
   */
  function _s_mandatory3($str) {
    if (!ereg('\%s', $str)) {
      $this->validation->set_message('_s_mandatory3', $this->lang->line('users_smandatorysent'));
      return FALSE;
    } else {
      return TRUE;
    }
  }



  /**
   * sends to browser a form asking the user to be assigned with "patients"
   *
   * @public
   *
   * @return nothing
   */
  function assignask () {

    if ($this->_accesgranted($this->access[6]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('user');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|alpha_dash|callback__code_exists";
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('users_assignpatients')).'<br />';
      $form .= $err . $this->_askcode_form ('assign');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/assign/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to update the user's assigned patient, do the validation proccess
   * and if it is successfull, update the new user's assigned patient
   *
   * @public
   *
   * @return nothing
   */
  function assign() {

    if ($this->_accesgranted($this->access[6]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm sino esta el parametro redirigir hacia assign function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/assignask');
      return;
    }

//erm buscar si el codigo existe en la tabla de pacientes
//------------------------------------------------------------------------------
    $this->db->where('code', $code);
    $query = $this->db->get('users');
    if ($query->num_rows() == 0) {
      $msg = base64_encode(msgWarning('',$this->lang->line('physician_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/assignask');
      return;
    }

    $vars       = array();

    if ($this->input->post('Code') === FALSE) {
      $row = $query->row();
      $vars['my_patients'] = $row->my_patients;
    }

    $vars['Code'] = $code;


    $validate   = false;
    $action     = 'edit';
    $url_action = $this->module_url . '/assign/' . $code;
    $form = $this->_form_assign ($action, $url_action, $vars, $validate);

    if ( ! $validate) {

      $content = '';
      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $content .= $msg;
      $content .= $this->_thissubmenu($this->lang->line('admin_title'));
      $content .= sprintf('<br /><div class="msg_1">%s</div><br />', nl2br($this->lang->line('users_assigninstructions')));
      $content .= $form;

      $data = default_Vars_Content();
      $data['title']  .= ' - ' . $this->lang->line('admin_users');
      $data['content'] = theme($this->_leftmenu(), $content);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
        'my_patients' =>  $this->validation->my_patients,
      );

      $this->db->where('code', $code);
      $this->db->update('users', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/assignask');
      return;
    }

  }



  /**
   * creates and return a html form to add or edit the user's patient assigned.
   *
   * @private
   *
   * @param action enum. The type of form to create. Valid options are "add" or "edit"
   * @param url_action string. The form's action URL.
   * @param vars array. An array with default values for the form or the values stored into DB for existing assigned patients.
   * @param validate boolean. It is set to TRUE by this method if validations was successful, else it is set to FALSE
   *
   * @return string
   */
  function _form_assign ($action, $url_action, $vars, &$validate) {

    $this->validation->set_error_delimiters('','<br />');

    $rules = array();
    $rules['Code']  = "trim|required|alpha_dash";
    $rules['my_patients']  = "trim|alpha_dash";

    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['my_patients'] = $this->lang->line('users_assignpatients');

    $this->validation->set_fields($fields);

    $form = '';

    if ( ! $validate = $this->validation->run()) {

      foreach ($fields as $key => $val) {
        if ( isset($vars[$key])) $this->validation->$key = $vars[$key];
      }

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";
      $form .= $err;

      $required = $this->lang->line('admin_required');

      //------------------------------------------------------------------------------

      $key   = 'formPhysician';
      $data  = array('id' => $key, 'name' => $key);
      $hidden = array ('Code'=>$this->validation->Code, 'failbirth'=>0);
      $form .= form_open($url_action, $data, $hidden);

      //------------------------------------------------------------------------------

      $key = 'Code';
      $fcode = sprintf('<b>%s: %s</b>', $this->lang->line('admin_code'), $this->validation->$key );

      $key = 'my_patients';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'rows'=>3);
      $fmypatients = sprintf('%s <br /> %s', $this->lang->line('users_assignpatients'), form_textarea($data));

      //------------------------------------------------------------------------------

      $key = 'Submit';
      if ($action == 'add') {
        $fsubmit = form_submit($key, $this->lang->line('users_assignpatients'));
      }
      if ($action == 'edit') {
        $fsubmit = form_submit($key, $this->lang->line('admin_savechanges'));
      }

      //------------------------------------------------------------------------------

      $this->table->add_row($fmypatients);

      $tmpl = array (
      'table_open'  => '<table class="" cellspacing="0" width="95%">',
      );
      $this->table->set_template($tmpl);

      $form .= $this->table->generate();

      $form .= '<br />'.$fsubmit;
      $form .= form_close();

    }

    return $form;

  }


}
?>
