<?php

/**
 * @file admin/med_patient.php
 * @brief File to manage patients. (list, add, edit and delete)
 * 
 * @class Med_Patient
 * @brief Class to manage patients. (list, add, edit and delete)
 *
 * @details
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Med_Patient extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/med_patient";

  /**
   * the title for this controller
   */ 
  var $module_name = "med_patient";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();

  /**
   * the DB table to store patients
   */ 
  var $dbtablename = "med_patient";


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Med_Patient() {
    parent::Controller();

    $this->access[1] = "add";
    $this->access[2] = "show";
    $this->access[3] = "del";
    $this->access[4] = "edit";
    $this->access[5] = "detail";
  }


  /**
   * return the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "add show del edit detail";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    $items[] = anchor($this->module_url.'/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    $items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));
    $items[] = anchor($this->module_url.'/detailask', $this->lang->line('patient_detail'));

    return navbarsubmenu($title, $items, 'med_patient.png');
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";
    make_blocks(array(1));
    $leftmenu = $this->block_side1;
    return $leftmenu;
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('admin_patients')).'<br />';
    $content .= $this->lang->line('admin_defactions');

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * send to browser an add patient form, do the validation proccess and if it is successfull, then add the new patient
   *
   * @public
   *
   * @return nothing
   */
  function add() {
    if ($this->_accesgranted($this->access[1]) == 0) return;

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','form', 'cookie','date'));
    $this->load->library(array('validation', 'table'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|strip_tags|required|alpha_numeric|callback__unique_code_check";
    $rules['Name']  = "trim|strip_tags|required|xss_clean";
    $rules['Email']  = "trim|strip_tags|required|valid_email|xss_clean";
    $rules['Notes']  = "trim|htmlentities|xss_clean";
    $rules['Status']  = "trim|required";

    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Email'] = $this->lang->line('admin_email');
    $fields['Notes'] = $this->lang->line('admin_notes');
    $fields['Status'] = $this->lang->line('main_status');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_patients')).'<br />';
      $form .= $err . $this->_form_addedit('add', $this->module_url.'/add');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();

      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      'email' => $this->validation->Email,
      'createddate' => now(),
      'status' => $this->validation->Status,
      'notes' => $this->validation->Notes,
      );
      $this->db->insert($this->dbtablename, $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/add');
      return;

    }
  }


  /**
   * creates and return a html form to add or edit a patient.
   *
   * @private
   *
   * @param action enum. The type of form to create. Valid options are "add" or "edit"
   * @param directo string. The form's action URL.
   *
   * @return string
   */
  function _form_addedit ($action, $directo) {
    //action - allowed values: add / edit

    $form = "";

    $key = 'formPatients';
    $attributes = array('id' => $key, 'name' => $key);
    $form = form_open($directo, $attributes);

    if ($action == 'add') {
      $key = 'Code';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
      $this->table->add_row($this->lang->line('admin_code'), form_input($data).$this->lang->line('admin_required'));
    }
    if ($action == 'edit') {
      $key = 'Code';
      $data = "<b>".$this->validation->$key."</b>";
      $this->table->add_row(
        $this->lang->line('admin_code'),
        sprintf('%s %s (%s)',
          form_hidden($key, $this->validation->Code),
          $data,
          anchor($this->module_url.'/detail/'.$this->validation->Code, $this->lang->line('patient_detail'))
        )
      );
    }

    if ($action == 'add') $passnote = $this->lang->line('admin_required');
    if ($action == 'edit') $passnote = $this->lang->line('admin_enternewpasstochange');

    $key = 'Name';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '26');
    $this->table->add_row($this->lang->line('admin_name'), form_input($data).$this->lang->line('admin_required'));

    $key = 'Email';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '26');
    $this->table->add_row($this->lang->line('admin_email'), form_input($data).$this->lang->line('admin_required'));

    $key = 'Status';
    if ($this->input->post($key) !== FALSE || $action == 'edit') {
      $active = intval($this->validation->$key) == 1 ? 1 : 0;
      $disabled = intval($this->validation->$key) == 0 ? 1 : 0;
    } else {
      $active = 0;
      $disabled = 0;
    }

    $radio = form_radio($key, '1', $active) . $this->lang->line('main_enabled')
    . form_radio($key, '0', $disabled) . $this->lang->line('main_disabled');
    $this->table->add_row($this->lang->line('main_status'), $radio.$this->lang->line('admin_required'));


    $key = 'Notes';
    $this->table->add_row($this->lang->line('admin_notes'), textArea($key, $this->validation->$key, 'mini', '150px'));

    if ($action == 'add') $this->table->add_row('', '<br />'.form_submit('submit', $this->lang->line('patient_add')));
    if ($action == 'edit') $this->table->add_row('', '<br />'.form_submit('submit', $this->lang->line('admin_savechanges')));

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=4 style="width:100%">');
    $this->table->set_template($tmpl);

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;

  }


  /**
   * looks for the patient code into DB. If it exists, return FALSE, else return TRUE
   *
   * @private
   *
   * @param str string. The patient code
   *
   * @return boolean
   */
  function _unique_code_check($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get($this->dbtablename);
    if ($query->num_rows() > 0) {
      $this->validation->set_message('_unique_code_check', $this->lang->line('patient_codeduplicated'));
      return FALSE;
    } else {
      return TRUE;
    }
  }


  /**
   * looks for the patient code into DB. If it exists, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. The patient code
   *
   * @return boolean
   */
  function _code_exists($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get($this->dbtablename);
    if ($query->num_rows() == 0) {
      $this->validation->set_message('_code_exists', $this->lang->line('patient_codenofound'));
      return FALSE;
    } else {
      return TRUE;
    }
  }


  /**
   * sends to browser the list of patients.
   *
   * @public
   *
   * @return nothing
   */
  function show() {

    if ($this->_accesgranted($this->access[2]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $itemxpage = 25;

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','form','text'));
    $this->load->library(array('pagination', 'table'));

//erm creacion de los links
//------------------------------------------------------------------------------
    $config['base_url'] = $this->config->site_url().'/'.$this->module_url."/show";
    $config['total_rows'] = $this->db->count_all($this->dbtablename);
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = "4";
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    //$config['num_links'] = "2";
    $this->pagination->initialize($config);
    $links = $this->pagination->create_links();

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------
    $begin = intval($this->uri->segment(4, 0));
    if ($begin < 0) $begin = 0;
    $lista = "";
    $this->db->orderby("name");
    $query = $this->db->get($this->dbtablename, $itemxpage, $begin);

    $this->table->set_heading(
    '#', $this->lang->line('admin_code'), $this->lang->line('admin_name'), $this->lang->line('main_status'),
    $this->lang->line('main_functions')
    );
    $i = $begin+1;
    foreach ($query->result() as $row) {

      $history = anchor('/history/patient/'.$row->code, $this->lang->line('admin_history'));
      $edit = anchor($this->module_url.'/edit/'.$row->code, $this->lang->line('admin_edit'));
      $details = anchor($this->module_url.'/detail/'.$row->code, $this->lang->line('patient_detail'));
      $del = anchor($this->module_url.'/del/'.$row->code, $this->lang->line('admin_del'));

      switch ($row->status) {
        case 0:
          $status =  $this->lang->line('main_disabled');
          break;
        case 1:
        default:
          $status =  $this->lang->line('main_enabled');
          break;
      }

      $this->table->add_row(
        $i, $row->code, $row->name, $status,
        sprintf('%s - %s - %s - %s', $history, $details, $edit, $del)
        );
      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing=0 width="100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $lista = $this->table->generate();


//erm enviar los resultados a la salida
//------------------------------------------------------------------------------
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');

    $center = $this->_thissubmenu($this->lang->line('patient_listof')).'<br />';
    $center .= $lista ."<br />". $links;
    $data['content'] = theme($this->_leftmenu(), $center);
    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * creates and return a html form asking the patient code for edit or delete actions.
   *
   * @private
   *
   * @param action enum. The action URL of the form. Valid options are "edit" and "del"
   *
   * @return string
   */
  function _askcode_form ($action) {
    //action - allowed values: del / edit
    $form = "";

    $key = 'formPatient';
    $attributes = array('id' => $key, 'name' => $key);

    if ($action == 'del') $form .= form_open($this->module_url.'/delask', $attributes);
    if ($action == 'edit') $form .= form_open($this->module_url.'/editask', $attributes);
    if ($action == 'detail') $form .= form_open($this->module_url.'/detailask', $attributes);

    $key = 'Code';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_code'), form_input($data));

    if ($action == 'del') $this->table->add_row('', form_submit('submit', $this->lang->line('patient_del')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('patient_edit')));
    if ($action == 'detail') $this->table->add_row('', form_submit('submit', $this->lang->line('patient_details')));

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }


  /**
   * sends to browser a form asking the patient to be edited
   *
   * @public
   *
   * @return nothing
   */
  function editask () {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|alpha_numeric|callback__code_exists";
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('patient_edit')).'<br />';
      $form .= $err . $this->_askcode_form ('edit');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/edit/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to update the patient, do the validation proccess
   * and if it is successfull, update the new patient information
   *
   * @public
   *
   * @return nothing
   */
  function edit() {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

//erm buscar si el codigo existe en la base de datos
//------------------------------------------------------------------------------
    $this->db->where('code', $code);
    $query = $this->db->get($this->dbtablename);

    if ($query->num_rows() == 0) {
      $msg = base64_encode(msgWarning('',$this->lang->line('patient_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

    $customgroups = get_usersgroups_list();

    $rules['Code']  = "trim|strip_tags|required|alpha_numeric|callback__code_exists";
    $rules['Name']  = "trim|strip_tags|required|xss_clean";
    $rules['Email']  = "trim|strip_tags|required|valid_email|xss_clean";
    $rules['Notes']  = "trim|htmlentities|xss_clean";
    $rules['Status']  = "trim|required";
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Email'] = $this->lang->line('admin_email');
    $fields['Status'] = $this->lang->line('main_status');
    $fields['Notes'] = $this->lang->line('admin_notes');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {
      $row = $query->row();
      $this->validation->Code = $code;
      $this->validation->Name = $row->name;
      $this->validation->Email = $row->email;
      $this->validation->Status = $row->status;
      $this->validation->Notes = $row->notes;

    }

    $this->validation->set_error_delimiters('','<br />');

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('patient_edit')).'<br />';
      $form .= $err . $this->_form_addedit('edit', $this->module_url.'/edit/'.$code);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      'email' => $this->validation->Email,
      'status' => $this->validation->Status,
      'notes' => $this->validation->Notes
      );

      $this->db->where('code', $code);
      $this->db->update($this->dbtablename, $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

  }

  /**
   * sends to browser a form asking the patient to be deleted
   *
   * @public
   *
   * @return nothing
   */
  function delask() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|alpha_numeric";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('patient_del')) . '<br />';
      $form .= $err . $this->_askcode_form ('del');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/del/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to confirm the patient deletion, if user click yes, the patient is deleted
   *
   * @public
   *
   * @return nothing
   */
  function del() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask/');
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('users_del')).'<br />'
      . $err
      . Ask_yesno_form (sprintf($this->lang->line('users_askdel'), $code), $this->module_url.'/del/'.$code, $this->module_url.'/delask');

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      $this->db->delete($this->dbtablename, array('code' => $code));
      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask');
      return;
    }
  }

  /**
   * creates and return a html form to add or edit the patient information (address, phones, job, etc)
   * also this method runs the validation process and store the result into $validate param
   *
   * @private
   *
   * @param action enum. The type of form to create. Valid options are "add" or "edit"
   * @param url_action string. The form's action URL.
   * @param vars array. An array with default values for the form or values stored into DB for existing patients.
   * @param validate boolean. Set to TRUE for this method if validations was successful, else it is set to FALSE
   *
   * @return string
   */
  function _form_detail ($action, $url_action, $vars, &$validate) {

    $this->validation->set_error_delimiters('','<br />');

    $rules = array();
    $rules['Code']  = "trim|required|alpha_numeric";
    $rules['identifier']  = "trim|alpha_dash|max_length[50]";
    $rules['RegHosp']  = "trim|alpha_dash|max_length[50]";

    $rules['Birth_y'] = "trim|numeric|exact_length[4]";
    $rules['Birth_m'] = "trim|numeric|exact_length[2]";
    $rules['Birth_d'] = "trim|numeric|exact_length[2]";
    $rules['Gender'] = "trim|numeric";

    $rules['insurance_type'] = "trim|strip_tags|max_length[50]";
    $rules['insurance_number'] = "trim|alpha_dash|max_length[50]";
    $rules['bloob_group'] = "trim|strip_tags|max_length[50]";
    $rules['profession'] = "trim|strip_tags|max_length[50]";

    $rules['Address1_street'] = "trim|strip_tags|max_length[50]";
    $rules['Address1_city'] = "trim|strip_tags|max_length[50]";
    $rules['Address1_state'] = "trim|strip_tags|max_length[50]";
    $rules['Address1_other'] = "trim|strip_tags|max_length[250]";
    $rules['Address1_zipcode'] = "trim|strip_tags|max_length[50]";
    $rules['Address1_country'] = "trim|strip_tags|max_length[50]";
    $rules['Address2_street'] = "trim|strip_tags|max_length[50]";
    $rules['Address2_city'] = "trim|strip_tags|max_length[50]";
    $rules['Address2_state'] = "trim|strip_tags|max_length[50]";
    $rules['Address2_other'] = "trim|strip_tags|max_length[250]";
    $rules['Address2_zipcode'] = "trim|strip_tags|max_length[50]";
    $rules['Address2_country'] = "trim|strip_tags|max_length[50]";

    $rules['Phone1_home'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone1_work'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone1_mobil'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone1_other'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone2_home'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone2_work'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone2_mobil'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone2_other'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone_contact'] = "trim|strip_tags|max_length[250]";

    $rules['responsable'] = "trim|strip_tags|max_length[250]";
    $rules['spouse'] = "trim|strip_tags|max_length[250]";
    $rules['mother'] = "trim|strip_tags|max_length[250]";
    $rules['father'] = "trim|strip_tags|max_length[250]";

    $rules['birth_mother_y'] = "trim|numeric|exact_length[4]";
    $rules['birth_mother_m'] = "trim|numeric|exact_length[2]";
    $rules['birth_mother_d'] = "trim|numeric|exact_length[2]";

    $rules['birth_father_y'] = "trim|numeric|exact_length[4]";
    $rules['birth_father_m'] = "trim|numeric|exact_length[2]";
    $rules['birth_father_d'] = "trim|numeric|exact_length[2]";

    $this->validation->set_rules($rules);
    //------------------------------------------------------------------------------

    $fields['failbirth'] = '';
    $fields['failfabirth'] = '';
    $fields['failmobirth'] = '';

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['identifier'] = $this->lang->line('patient_id1');
    $fields['RegHosp'] = $this->lang->line('patient_reghosp');
    $fields['Birth_y'] = $this->lang->line('patient_birth_y');
    $fields['Birth_m'] = $this->lang->line('patient_birth_m');
    $fields['Birth_d'] = $this->lang->line('patient_birth_d');
    $fields['Gender'] = $this->lang->line('patient_gender');

    $fields['insurance_type'] = $this->lang->line('patient_insurance_type');
    $fields['insurance_number'] = $this->lang->line('patient_insurance_number');
    $fields['bloob_group'] = $this->lang->line('patient_bloob_group');
    $fields['profession'] = $this->lang->line('patient_profession');

    $fields['Address1_street'] = $this->lang->line('patient_street');
    $fields['Address1_city'] = $this->lang->line('patient_city');
    $fields['Address1_state'] = $this->lang->line('patient_state');
    $fields['Address1_other'] = $this->lang->line('patient_othersignals');
    $fields['Address1_zipcode'] = $this->lang->line('patient_zipcode');
    $fields['Address1_country'] = $this->lang->line('patient_country');
    $fields['Address2_street'] = $this->lang->line('patient_street');
    $fields['Address2_city'] = $this->lang->line('patient_city');
    $fields['Address2_state'] = $this->lang->line('patient_state');
    $fields['Address2_other'] = $this->lang->line('patient_othersignals');
    $fields['Address2_zipcode'] = $this->lang->line('patient_zipcode');
    $fields['Address2_country'] = $this->lang->line('patient_country');

    $fields['Phone1_home'] = $this->lang->line('patient_homephone');
    $fields['Phone1_work'] = $this->lang->line('patient_businessphone');
    $fields['Phone1_mobil'] = $this->lang->line('patient_mobilphone');
    $fields['Phone1_other'] = $this->lang->line('patient_otherphone');
    $fields['Phone2_home'] = $this->lang->line('patient_homephone');
    $fields['Phone2_work'] = $this->lang->line('patient_businessphone');
    $fields['Phone2_mobil'] = $this->lang->line('patient_mobilphone');
    $fields['Phone2_other'] = $this->lang->line('patient_otherphone');
    $fields['Phone_contact'] = $this->lang->line('patient_contactto');

    $fields['responsable'] = $this->lang->line('patient_responsable');
    $fields['spouse'] = $this->lang->line('patient_spouse');
    $fields['mother'] = $this->lang->line('patient_mother');
    $fields['father'] = $this->lang->line('patient_father');

    $fields['birth_mother_y'] = $this->lang->line('patient_mobirth_y');
    $fields['birth_mother_m'] = $this->lang->line('patient_mobirth_m');
    $fields['birth_mother_d'] = $this->lang->line('patient_mobirth_d');

    $fields['birth_father_y'] = $this->lang->line('patient_fabirth_y');
    $fields['birth_father_m'] = $this->lang->line('patient_fabirth_m');
    $fields['birth_father_d'] = $this->lang->line('patient_fabirth_d');

    $this->validation->set_fields($fields);
    //------------------------------------------------------------------------------

    $form = '';

    if ( ! $validate = $this->validation->run()) {

      foreach ($fields as $key => $val) {
        if ( isset($vars[$key])) $this->validation->$key = $vars[$key];
      }

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";
      $form .= $err;

      $required = $this->lang->line('admin_required');

      //------------------------------------------------------------------------------

      $key   = 'formPatient';
      $data  = array('id' => $key, 'name' => $key);
      $hidden = array ('Code'=>$this->validation->Code, 'failbirth'=>0, 'failmobirth'=>0, 'failfabirth'=>0);
      $form .= form_open($url_action, $data, $hidden);

      //------------------------------------------------------------------------------

      $key = 'Code';
      $fcode = sprintf(
        '<b>%s: %s</b> <br /> (%s)',
        $this->lang->line('admin_code'),
        $this->validation->$key,
        anchor($this->module_url.'/edit/'.$this->validation->$key, $this->lang->line('admin_edit'))
      );

      $key = 'identifier';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fid = sprintf('%s <br /> %s', $this->lang->line('patient_id1'), form_input($data));

      $key = 'RegHosp';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fRegHosp = sprintf('%s <br /> %s', $this->lang->line('patient_reghosp'), form_input($data));

      $key = 'Birth_y';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '3');
      $fbirth_y = form_input($data);

      $key = 'Birth_m';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '2');
      $fbirth_m = form_input($data);

      $key = 'Birth_d';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '2');
      $fbirth_d = form_input($data);
      $fbirth = sprintf('%s (yyyy/mm/dd) <br /> %s %s %s', $this->lang->line('patient_birth'), $fbirth_y, $fbirth_m, $fbirth_d);

      $key  = 'Gender';
      $data = array(0=>$this->lang->line('main_pleaseselect'),1=>$this->lang->line('patient_gender_m'),2=>$this->lang->line('patient_gender_f'));
      $fgender = sprintf('%s <br /> %s', $this->lang->line('patient_gender'), form_dropdown($key, $data, $this->validation->$key));


      $key = 'insurance_type';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $finsurance_t = sprintf('%s <br /> %s', $this->lang->line('patient_insurance_type'), form_input($data));

      $key = 'insurance_number';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $finsurance_n = sprintf('%s <br /> %s', $this->lang->line('patient_insurance_number'), form_input($data));

      $key = 'bloob_group';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fblood = sprintf('%s <br /> %s', $this->lang->line('patient_bloob_group'), form_input($data));

      $key = 'profession';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fprof = sprintf('%s <br /> %s', $this->lang->line('patient_profession'), form_input($data));

      //------------------------------------------------------------------------------

      $key = 'Address1_street';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa1street = sprintf('%s <br /> %s', $this->lang->line('patient_street'), form_input($data));

      $key = 'Address1_city';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa1city = sprintf('%s <br /> %s', $this->lang->line('patient_city'), form_input($data));

      $key = 'Address1_state';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa1state = sprintf('%s <br /> %s', $this->lang->line('patient_state'), form_input($data));

      $key = 'Address1_zipcode';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa1zipcode = sprintf('%s <br /> %s', $this->lang->line('patient_zipcode'), form_input($data));

      $key = 'Address1_country';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa1country = sprintf('%s <br /> %s', $this->lang->line('patient_country'), form_input($data));

      $key = 'Address1_other';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'style'=>'width: 99%;' );
      $fa1other = sprintf('%s <br /> %s', $this->lang->line('patient_othersignals'), form_input($data));

      $key = 'Address2_street';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa2street = sprintf('%s <br /> %s', $this->lang->line('patient_street'), form_input($data));

      $key = 'Address2_city';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa2city = sprintf('%s <br /> %s', $this->lang->line('patient_city'), form_input($data));

      $key = 'Address2_state';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa2state = sprintf('%s <br /> %s', $this->lang->line('patient_state'), form_input($data));

      $key = 'Address2_zipcode';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa2zipcode = sprintf('%s <br /> %s', $this->lang->line('patient_zipcode'), form_input($data));

      $key = 'Address2_country';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa2country = sprintf('%s <br /> %s', $this->lang->line('patient_country'), form_input($data));

      $key = 'Address2_other';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'style'=>'width: 99%;' );
      $fa2other = sprintf('%s <br /> %s', $this->lang->line('patient_othersignals'), form_input($data));

      //------------------------------------------------------------------------------

      $key = 'Phone1_home';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp1home = sprintf('%s 1<br /> %s', $this->lang->line('patient_homephone'), form_input($data));

      $key = 'Phone1_work';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp1work = sprintf('%s 1<br /> %s', $this->lang->line('patient_businessphone'), form_input($data));

      $key = 'Phone1_mobil';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp1mobil = sprintf('%s 1<br /> %s', $this->lang->line('patient_mobilphone'), form_input($data));

      $key = 'Phone1_other';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp1other = sprintf('%s 1<br /> %s', $this->lang->line('patient_otherphone'), form_input($data));

      $key = 'Phone2_home';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp2home = sprintf('%s 2<br /> %s', $this->lang->line('patient_homephone'), form_input($data));

      $key = 'Phone2_work';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp2work = sprintf('%s 2<br /> %s', $this->lang->line('patient_businessphone'), form_input($data));

      $key = 'Phone2_mobil';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp2mobil = sprintf('%s 2<br /> %s', $this->lang->line('patient_mobilphone'), form_input($data));

      $key = 'Phone2_other';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp2other = sprintf('%s 2<br /> %s', $this->lang->line('patient_otherphone'), form_input($data));

      $key = 'Phone_contact';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '40');
      $fpcontact = sprintf('%s <br /> %s', $this->lang->line('patient_contactto'), form_input($data));

      //------------------------------------------------------------------------------

      $key = 'responsable';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '25');
      $fresponsable = sprintf('%s <br /> %s', $this->lang->line('patient_responsable'), form_input($data));

      $key = 'spouse';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '25');
      $fspouse = sprintf('%s <br /> %s', $this->lang->line('patient_spouse'), form_input($data));

      $key = 'mother';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '25');
      $fmother = sprintf('%s <br /> %s', $this->lang->line('patient_mother'), form_input($data));

      $key = 'father';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '25');
      $ffather = sprintf('%s <br /> %s', $this->lang->line('patient_father'), form_input($data));

      $key = 'birth_mother_y';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '3');
      $fbirth_y = form_input($data);

      $key = 'birth_mother_m';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '2');
      $fbirth_m = form_input($data);

      $key = 'birth_mother_d';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '2');
      $fbirth_d = form_input($data);

      $fmobirth = sprintf('%s (yyyy/mm/dd) <br /> %s %s %s', $this->lang->line('patient_mobirth'), $fbirth_y, $fbirth_m, $fbirth_d);

      $key = 'birth_father_y';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '3');
      $fbirth_y = form_input($data);

      $key = 'birth_father_m';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '2');
      $fbirth_m = form_input($data);

      $key = 'birth_father_d';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '2');
      $fbirth_d = form_input($data);

      $ffabirth = sprintf('%s (yyyy/mm/dd) <br /> %s %s %s', $this->lang->line('patient_fabirth'), $fbirth_y, $fbirth_m, $fbirth_d);

      //------------------------------------------------------------------------------

      $key = 'Submit';
      if ($action == 'add') {
        $fsubmit = form_submit($key, $this->lang->line('patient_add'));
      }
      if ($action == 'edit') {
        $fsubmit = form_submit($key, $this->lang->line('admin_savechanges'));
      }

      //------------------------------------------------------------------------------

      $tmpl =
      '<table width="100%%" border=0>
          <tr>
            <td colspan="6"> <h4>%s</h4> </td>
          </tr>
          <tr>
            <td > %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center" nowrap >  %s </td>
            <td align="center"> %s </td>
          </tr>
          <tr>
            <td > </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
          </tr>

          <tr>
            <td colspan="6"> <h4>%s</h4> </td>
          </tr>

          <tr>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
          </tr>
          <tr>
            <td colspan="6"> %s </td>
          </tr>

          <tr>
            <td colspan="6"> <h4>%s</h4> </td>
          </tr>
          <tr>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
          </tr>
          <tr>
            <td colspan="6"> %s </td>
          </tr>

          <tr>
            <td colspan="6"> <h4>%s</h4> </td>
          </tr>
          <tr>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
          </tr>
          <tr>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
          </tr>
          <tr>
            <td colspan="6"> %s </td>
          </tr>

          <tr>
            <td colspan="6"> <h4>%s</h4> </td>
          </tr>
          <tr>
            <td colspan="2" > %s </td>
            <td colspan="3" > %s </td>
          </tr>
          <tr>
            <td colspan="2" > %s </td>
            <td colspan="3" > %s </td>
          </tr>
          <tr>
            <td colspan="2" > %s </td>
            <td colspan="3" > %s </td>
          </tr>
      </table>
      ';

      $form .= sprintf(
        $tmpl,
        $this->lang->line('patient_general'),
        $fcode,
        $fid,
        $fRegHosp,
        $fbirth,
        $fgender,
        $finsurance_t,
        $finsurance_n,
        $fblood,
        $fprof,

        $this->lang->line('patient_homeaddress'),
        $fa1street,
        $fa1city,
        $fa1state,
        $fa1zipcode,
        $fa1country,
        $fa1other,

        $this->lang->line('patient_bussinessaddress'),
        $fa2street,
        $fa2city,
        $fa2state,
        $fa2zipcode,
        $fa2country,
        $fa2other,

        $this->lang->line('patient_contact'),
        $fp1home,
        $fp1work,
        $fp1mobil,
        $fp1other,
        $fp2home,
        $fp2work,
        $fp2mobil,
        $fp2other,
        $fpcontact,

        $this->lang->line('patient_family'),
        $fresponsable,
        $fspouse,
        $fmother,
        $fmobirth,
        $ffather,
        $ffabirth
      );

      $form .= '<br />'.$fsubmit;
      $form .= form_close();

    }

    return $form;

  }

  /**
   * always returns FALSE. This method is called when the birth date is invalid
   *
   * @private
   *
   * @param str string. dummy param. Enter a empty value
   *
   * @return boolean
   */
  function _failbirth($str) {
    $this->validation->set_message('_failbirth', $this->lang->line('patient_failbirth'));
    return FALSE;
  }


  /**
   * always returns FALSE. This method is called when the mother birth date is invalid
   *
   * @private
   *
   * @param str string. dummy param. Enter a empty value
   *
   * @return boolean
   */
  function _failmotherbirth($str) {
    $this->validation->set_message('_failmotherbirth', $this->lang->line('patient_failmotherbirth'));
    return FALSE;
  }

  /**
   * always returns FALSE. This method is called when the father birth date is invalid
   *
   * @private
   *
   * @param str string. dummy param. Enter a empty value
   *
   * @return boolean
   */
  function _failfatherbirth($str) {
    $this->validation->set_message('_failfatherbirth', $this->lang->line('patient_failfatherbirth'));
    return FALSE;
  }


  /**
   * sends to browser a form asking the patient code of the patient' details to be edited 
   *
   * @public
   *
   * @return nothing
   */
  function detailask () {

    if ($this->_accesgranted($this->access[5]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|alpha_numeric|callback__code_exists";
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('patient_details')).'<br />';
      $form .= $err . $this->_askcode_form ('detail');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/detail/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to update the patient's details, do the validation proccess
   * and if it is successfull, update the new patient's details
   *
   * @public
   *
   * @return nothing
   */
  function detail() {

    if ($this->_accesgranted($this->access[5]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/detailask');
      return;
    }

//erm buscar si el codigo existe en la tabla de usuarios
//------------------------------------------------------------------------------
    $this->db->where('code', $code);
    $query = $this->db->get($this->dbtablename);
    if ($query->num_rows() == 0) {
      $msg = base64_encode(msgWarning('',$this->lang->line('patient_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/detailask');
      return;
    }

    $vars       = array();

//erm buscar si el codigo existe en la tabla physcians, sino agregarlo
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {
      $row = $query->row();

      $vars['identifier'] = $row->identifier;
      $vars['RegHosp'] = $row->reghosp;

      $vars['Birth_y'] = $row->birthdate ? date('Y', $row->birthdate) : '';
      $vars['Birth_m'] = $row->birthdate ? date('m', $row->birthdate) : '';
      $vars['Birth_d'] = $row->birthdate ? date('d', $row->birthdate) : '';

      $vars['Gender'] = $row->gender;

      $vars['insurance_type'] = $row->insurance_type;
      $vars['insurance_number'] = $row->insurance_number;
      $vars['bloob_group'] = $row->bloob_group;
      $vars['profession'] = $row->profession;

      $vars['Address1_street'] = $row->address1_street;
      $vars['Address1_city'] = $row->address1_city;
      $vars['Address1_state'] = $row->address1_state;
      $vars['Address1_other'] = $row->address1_other;
      $vars['Address1_zipcode'] = $row->address1_zipcode;
      $vars['Address1_country'] = $row->address1_country;

      $vars['Address2_street'] = $row->address2_street;
      $vars['Address2_city'] = $row->address2_city;
      $vars['Address2_state'] = $row->address2_state;
      $vars['Address2_other'] = $row->address2_other;
      $vars['Address2_zipcode'] = $row->address2_zipcode;
      $vars['Address2_country'] = $row->address2_country;

      $vars['Phone1_home'] = $row->phone1_home;
      $vars['Phone1_work'] = $row->phone1_work;
      $vars['Phone1_mobil'] = $row->phone1_mobil;
      $vars['Phone1_other'] = $row->phone1_other;

      $vars['Phone2_home'] = $row->phone2_home;
      $vars['Phone2_work'] = $row->phone2_work;
      $vars['Phone2_mobil'] = $row->phone2_mobil;
      $vars['Phone2_other'] = $row->phone2_other;

      $vars['Phone_contact'] = $row->phone_contact;

      $vars['responsable'] = $row->responsable;
      $vars['spouse'] = $row->spouse;
      $vars['mother'] = $row->mother;
      $vars['father'] = $row->father;

      $vars['birth_mother_y'] = $row->birth_mother ? date('Y', $row->birth_mother) : '';
      $vars['birth_mother_m'] = $row->birth_mother ? date('m', $row->birth_mother) : '';
      $vars['birth_mother_d'] = $row->birth_mother ? date('d', $row->birth_mother) : '';

      $vars['birth_father_y'] = $row->birth_father ? date('Y', $row->birth_father) : '';
      $vars['birth_father_m'] = $row->birth_father ? date('m', $row->birth_father) : '';
      $vars['birth_father_d'] = $row->birth_father ? date('d', $row->birth_father) : '';

    }

    $vars['Code'] = $code;


    $validate   = false;
    $action     = 'edit';
    $url_action = $this->module_url . '/detail/' . $code;
    $form = $this->_form_detail ($action, $url_action, $vars, $validate);

    if ( ! $validate) {

      $this->_show_formdetail ($form);

    } else {

      $rules = array();
      $form_again = 0;

      $datebirth = 0;
      $dd = intval($this->validation->Birth_d);
      $mm = intval($this->validation->Birth_m);
      $yy = intval($this->validation->Birth_y);
      if ($dd || $mm || $yy) {
        if ( ! checkdate  ($mm, $dd, $yy)) {
          $rules['failbirth']  = "callback__failbirth";
          $form_again = 1;
        } else {
          $datebirth = mktime(0,0,0, $mm, $dd, $yy);
        }
      }

      $motherbirth = 0;
      $dd = intval($this->validation->birth_mother_d);
      $mm = intval($this->validation->birth_mother_m);
      $yy = intval($this->validation->birth_mother_y);
      if ($dd || $mm || $yy) {
        if ( ! checkdate  ($mm, $dd, $yy)) {
          $rules['failmobirth']  = "callback__failmotherbirth";
          $form_again = 1;
        } else {
          $motherbirth = mktime(0,0,0, $mm, $dd, $yy);
        }
      }

      $fatherbirth = 0;
      $dd = intval($this->validation->birth_father_d);
      $mm = intval($this->validation->birth_father_m);
      $yy = intval($this->validation->birth_father_y);
      if ($dd || $mm || $yy) {
        if ( ! checkdate  ($mm, $dd, $yy)) {
          $rules['failfabirth']  = "callback__failfatherbirth";
          $form_again = 1;
        } else {
          $fatherbirth = mktime(0,0,0, $mm, $dd, $yy);
        }
      }

      if ($form_again) {
        $this->validation->set_rules($rules);
        $form = $this->_form_detail ($action, $url_action, $vars, $validate);
        $this->_show_formdetail ($form);
        return;
      }


      $data = array(
        'identifier' =>  $this->validation->identifier,
        'reghosp' =>  $this->validation->RegHosp,
        'birthdate' =>  $datebirth,
        'gender' =>  $this->validation->Gender,

        'insurance_type' => $this->validation->insurance_type,
        'insurance_number' => $this->validation->insurance_number,
        'bloob_group' => $this->validation->bloob_group,
        'profession' => $this->validation->profession,

        'address1_street' =>  $this->validation->Address1_street,
        'address1_city' =>  $this->validation->Address1_city,
        'address1_state' =>  $this->validation->Address1_state,
        'address1_other' =>  $this->validation->Address1_other,
        'address1_zipcode' =>  $this->validation->Address1_zipcode,
        'address1_country' =>  $this->validation->Address1_country,

        'address2_street' =>  $this->validation->Address2_street,
        'address2_city' =>  $this->validation->Address2_city,
        'address2_state' =>  $this->validation->Address2_state,
        'address2_other' =>  $this->validation->Address2_other,
        'address2_zipcode' =>  $this->validation->Address2_zipcode,
        'address2_country' =>  $this->validation->Address2_country,

        'phone1_home' =>  $this->validation->Phone1_home,
        'phone1_work' =>  $this->validation->Phone1_work,
        'phone1_mobil' =>  $this->validation->Phone1_mobil,
        'phone1_other' =>  $this->validation->Phone1_other,

        'phone2_home' =>  $this->validation->Phone2_home,
        'phone2_work' =>  $this->validation->Phone2_work,
        'phone2_mobil' =>  $this->validation->Phone2_mobil,
        'phone2_other' =>  $this->validation->Phone2_other,

        'phone_contact' =>  $this->validation->Phone_contact,

        'responsable' => $this->validation->responsable,
        'spouse' => $this->validation->spouse,
        'mother' => $this->validation->mother,
        'father' => $this->validation->father,

        'birth_mother' => $motherbirth,
        'birth_father' => $fatherbirth,

      );

      $this->db->where('code', $code);
      $this->db->update($this->dbtablename, $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/detailask');
      return;
    }

  }

  /**
   * send to browser a html form to edit the patient's details (phone, address, job, etc)
   *
   * @private
   *
   * @param form string. The patient's detail html form
   *
   * @return nothing
   */
  function _show_formdetail ($form) {
    $content = '';
    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content .= $msg;
    $content .= $this->_thissubmenu($this->lang->line('admin_title'));
    $content .= $form;

    $data = default_Vars_Content();
    $data['title']  .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $content);

    $this->load->view($this->config->item('theme'), $data);
  }


}
?>
