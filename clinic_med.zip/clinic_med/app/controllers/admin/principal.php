<?php

/**
 * @file /controllers/admin/principal.php
 * @brief Default file to load when no one is specified
 * 
 * @class Principal
 * @brief Default class to load when no one is specified
 *
 * @details Also this class does the login / logout process for admins.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Principal extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/principal";


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If admin has not permissions, redirect to access denied
   *
   * @public
   */
  function Principal() {
    parent::Controller();
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {

    make_blocks();

    $leftmenu = "";
    $leftmenu = $this->block_side1;

    return $leftmenu;
  }


  /**
   *
   * Sends to browser an administration panel with options to setup the Clinic_MED
   *
   * @private
   * 
   * @return nothing
   */
  function _mainmenu () {

    $this->load->library(array('table'));
    $content = "<h2>".$this->lang->line('menu_admin')."</h2>";

    $data = get_admin_list();
    $items = array();
    $img = theme_imgtag ('logout.png', $this->lang->line('login_logout'));
    $items[] = anchor($this->module_url.'/logout', $img)
    .'<br />'. anchor($this->module_url.'/logout', $this->lang->line('login_logout'));

    foreach ($data as $item) {
      if ($this->admininfo['superuser'] == 1 || strpos($this->admininfo['accessgranted'], '+'.$item.'[') !== false) {
        $img = theme_imgtag($item.'.png', $this->lang->line('menu_'.strtolower($item)), $item, ' ');
        $items[] = anchor('admin/'.$item, $img)
        .'<br />'. anchor('admin/'.$item, $this->lang->line('menu_'.strtolower($item)));
      }
    }

    $menu = $this->table->make_columns($items, 6);
    $tmpl = array (
    'table_open'=>'<table border="0" cellspacing="2" cellpadding="15" style="width:100%">',
    'cell_start'=>'<td align="center" >',
    'cell_alt_start'=>'<td align="center" >'
    );
    $this->table->set_template($tmpl);

    $content .= $this->table->generate($menu);

    return $content;
  }


  /**
   *
   * Sends to browser an access denied warning/message
   *
   * @public
   * 
   * @return nothing
   */
  function accessdenied() {

    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    $img = theme_imgtag ('stop.png', "", "", "vspace='10' hspace='5' style='float: left'");
    $msg = msgErr('', $img.$this->lang->line('main_accessdenied') . '<br /><br />' . $this->lang->line('main_goback'));

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $msg, $this->block_side2);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {
//erm probar si esta logueado, sino, enviarlo a login
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie','date'));
    $this->load->library(array('table'));

    if (is_admin() == 0) {
      redirect($this->module_url.'/login');
      return;
    }

    $content = $this->_mainmenu();
    $this->table->clear();

    $content .= '<br />' . $this->_lastloginfo();

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $msg.$content, $this->block_side2);

    $this->load->view($this->config->item('theme'), $data);
  }


  /**
   * returns html with last login information (ip and date)
   *
   * @private
   *
   * @return string (html)
   */
  function _lastloginfo() {

    $img = theme_imgtag ('lastlog.png', "",  "", " style='float: left;' hspace='10' vspace='10'");

    $text = '';
    $text .= '<div class="table_1">';
    $text .= $img;

    $last1 = unix_to_human(gmt_to_local($this->admininfo['lastlogdate'], $this->config->item('timezone'))) . '  '
    .$this->lang->line('main_lastip') . '  '
    .$this->admininfo['lastip'];

    $last2 = unix_to_human(gmt_to_local($this->admininfo['lastlogdate2'], $this->config->item('timezone'))) . '  '
    .$this->lang->line('main_lastip') . '  '
    .$this->admininfo['lastip2'];

    $this->table->add_row('<b>'.$this->lang->line('main_lastloginfo').'</b>');
    $this->table->add_row('1. '. $last1);
    $this->table->add_row('2. '. $last2);
    $this->table->add_row($this->lang->line('main_yourip') .': '. $this->input->ip_address());

    $tmpl = array ('table_open'  => '<table border=0 width="100%">');
    $this->table->set_template($tmpl);

    $text .=
    '<br />'
    .$this->table->generate()
    .'</div>';

    return $text;

  }


  /**
   * send to browser the admin login form, do the validation process, and if it is successfull, then login the admin
   *
   * @public
   *
   * @return nothing
   */
  function login() {

    $this->lang->load('admin');
    $this->load->helper(array('url','form', 'cookie','date'));
    $this->load->library(array('validation', 'table'));
    $this->load->plugin('captcha');

    if (is_admin() == 1) {
      $msg = base64_encode(msgWarning('', $this->lang->line('login_alreadylog')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['User_Name']  = "trim|required|xss_clean";
    $rules['Password']  = "trim|required|xss_clean";
    $rules['Security_Code']  = "trim|required|strtoupper|md5|matches[Code]";
    $this->validation->set_rules($rules);

    $fields['User_Name'] = $this->lang->line('login_user');
    $fields['Password'] = $this->lang->line('login_pass');
    $fields['Security_Code'] = $this->lang->line('login_entercaptcha');
    $fields['Code'] = $this->lang->line('login_captcha');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $vals = array(
      'word'     => '',
      'img_path'   => '././captcha/',
      'img_url'   => $this->config->item('base_url').'captcha/',
      'font_path'   => './system/texb.ttf',
      'expiration' => 120
      );
      $img = create_captcha($vals);


      $data = array('name' => 'User_Name', 'id' => 'User_Name', 'value' => $this->validation->User_Name, 'size' => '16');
      $this->table->add_row($this->lang->line('login_user'), form_input($data).$this->lang->line('admin_required'));

      $data = array('name' => 'Password', 'id' => 'Password', 'value' => $this->validation->Password, 'size' => '16');
      $this->table->add_row($this->lang->line('login_pass'), form_password($data).$this->lang->line('admin_required'));

      $this->table->add_row("",$this->lang->line('login_captchanote'));

      $data = array('name' => 'Security_Code', 'id' => 'Security_Code', 'value' => '', 'size' => '16');
      $this->table->add_row($this->lang->line('login_entercaptcha'), form_input($data).$this->lang->line('admin_required'));

      $this->table->add_row($this->lang->line('login_captcha'), $img['image']);

      $this->table->add_row('', form_submit('submit', $this->lang->line('login_login')));

      $attributes = array('id' => 'formLogin', 'name' => 'formLogin');
      $hidden = array('Code' => md5($img['word']));

      $form = form_open($this->module_url.'/login', $attributes, $hidden)
      .$err
      .$this->table->generate()
      .form_close();

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $subtitle = "<h2>".$this->lang->line('login_title')."</h2>";

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$subtitle.$form, $this->block_side2);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $where = array('code'=>$this->validation->User_Name,'password'=>md5($this->validation->Password),'password<>'=>'');
      $query = $this->db->getwhere('admins', $where);
      if ($query->num_rows() > 0) {

        $data = array('admin'=>$this->validation->User_Name, 'password'=>md5($this->validation->Password));
        $this->session->set_userdata($data);

        $where = ' WHERE code="'.$this->validation->User_Name.'" && password="'.md5($this->validation->Password).'"';
        $slq = 'UPDATE '
        .$this->db->dbprefix.'admins SET lastlogdate2=lastlogdate, lastlogdate='.now()
        .', lastip2=lastip, lastip="'.$this->input->ip_address().'" '
        .', session_id="'.$this->session->userdata('session_id').'"'
        . $where;
        $this->db->query($slq);

        redirect($this->module_url);
        return;
        //erm. la informacion provista par conexion es correcta

      } else {
        //erm. login fallado, preguntar de nuevo.
        $msg = base64_encode(msgErr('', $this->lang->line('login_failed')));
        set_cookie('msg', $msg, 0);
        redirect($this->module_url.'/login');
        return;
      }
    }
  }

  /**
   * logout an admin
   *
   * @public
   *
   * @return nothing
   */
  function logout() {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    $msg = base64_encode(msgSuccess('', $this->lang->line('login_logoutsuccess')));
    set_cookie('msg', $msg, 0);

    $this->db->where('code', $this->session->userdata('admin'));
    $this->db->where('password', $this->session->userdata('password'));
    $data = array('session_id' => '');
    $this->db->update('admins', $data);

    $data = array('admin'=>'', 'password'=>'');//erm  0 significa que esta deslogueado
    $this->session->set_userdata($data);

    redirect($this->module_url.'/login');

  }


}
?>
