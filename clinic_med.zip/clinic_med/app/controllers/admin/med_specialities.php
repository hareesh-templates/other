<?php

/**
 * @file admin/med_specialities.php
 * @brief File to manage physician's specialities (list, add, edit and delete)
 * 
 * @class Med_Specialities
 * @brief Class to manage physician's specialities (list, add, edit and delete)
 *
 * @details Physicians are grouped by speciality when adding appointments
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Med_Specialities extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/med_specialities";

  /**
   * the title for this controller
   */ 
  var $module_name = "med_specialities";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If admin has not permissions, redirect to access denied
   *
   * @public
   */
  function Med_Specialities() {

    parent::Controller();

    $this->access[1] = "add";
    $this->access[2] = "show";
    $this->access[3] = "del";
    $this->access[4] = "edit";
  }

  /**
   * return the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "add show del edit";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    //$items[] = '<b>'.$this->lang->line('admin_actions').'</b>';
    $items[] = anchor($this->module_url.'/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    $items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));

    return navbarsubmenu($title, $items, 'med_specialities.png');
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('specialities_title')).'<br />';
    $content .= $this->lang->line('admin_defactions');

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";
    make_blocks(array(1));
    $leftmenu = $this->block_side1;
    return $leftmenu;
  }


  /**
   * sends to browser an add speciality form, do the validation proccess and if it is successfull, then add the new speciality
   *
   * @public
   *
   * @return nothing
   */
  function add () {

    if ($this->_accesgranted($this->access[1]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));


    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|strip_tags|required|xss_clean|callback__unique_code_check";
    $rules['Name']  = "trim|strip_tags|htmlentities|xss_clean";
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Name'] = $this->lang->line('admin_name');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('specialities_add')).'<br />';
      $form .= $err . $this->_make_form('add', $this->module_url.'/add');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('specialities_title');
      $data['content'] = theme($this->block_side1, $msg.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      );
      $this->db->insert('med_specialities', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/add');
      return;
    }
  }


  /**
   * creates and return a html form to add or edit an speciality.
   *
   * @private
   *
   * @param action enum. The type of form to create. Valid options are "add" or "edit"
   * @param directo string. The form's action URL.
   *
   * @return string
   */
  function _make_form ($action, $directo) {
    //action - allowed values: add / edit

//erm FIN formularios para introducir los permisos de los grupos
//------------------------------------------------------------------------------------------------------

    $form =  '';

    $key = 'formSpeciality';
    $attributes = array('id' => $key, 'name' => $key);

    $form = form_open($directo, $attributes);

    if ($action == 'add') {
      $data = array('name' => 'Code', 'id' => 'Code', 'value' => $this->validation->Code, 'size' => '16');
      $this->table->add_row($this->lang->line('admin_code'), form_input($data).$this->lang->line('admin_required'));
    }
    if ($action == 'edit') {
      $data = "<b>".$this->validation->Code."</b>";
      $this->table->add_row($this->lang->line('admin_code'), $data.form_hidden('Code', $this->validation->Code));
    }

    $key = 'Name';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '50');
    $this->table->add_row($this->lang->line('main_title'), form_input($data));

    if ($action == 'add') $this->table->add_row('', form_submit('submit', $this->lang->line('specialities_add')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('admin_savechanges')));

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=2 cellspacing=2 style="width:100%">');
    $this->table->set_template($tmpl);

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }

  /**
   * looks for the speciality code into DB. If it exists, return FALSE, else return TRUE
   *
   * @private
   *
   * @param str string. The speciality code
   *
   * @return boolean
   */
  function _unique_code_check($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('med_specialities');
    if ($query->num_rows() > 0) {
      $this->validation->set_message('_unique_code_check', $this->lang->line('specialities_codeduplicated'));
      return FALSE;
    } else {
      return TRUE;
    }
  }


  /**
   * looks for the speciality code into DB. If it exists, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. The speciality code
   *
   * @return boolean
   */
  function _code_exits($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('med_specialities');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_code_exits', $this->lang->line('specialities_codenofound'));
      return FALSE;
    }
  }


  /**
   * creates and return a html form asking the speciality code for edit or delete actions.
   *
   * @private
   *
   * @param action enum. The action URL of the form. Valid options are "edit" and "del"
   *
   * @return string
   */
  function _askcode_form ($action) {
    //action - allowed values: del / edit
    $form = "";

    $key = 'formAskCode';
    $attributes = array('id' => $key, 'name' => $key);

    if ($action == 'del') $form .= form_open($this->module_url.'/delask', $attributes);
    if ($action == 'edit') $form .= form_open($this->module_url.'/editask', $attributes);

    $data = array('name' => 'Code', 'id' => 'Code', 'value' => $this->validation->Code, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_code'), form_input($data));

    if ($action == 'del') $this->table->add_row('', form_submit('submit', $this->lang->line('specialities_del')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('specialities_edit')));

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }


  /**
   * sends to browser the list of specialities.
   *
   * @public
   *
   * @return nothing
   */
  function show() {

    if ($this->_accesgranted($this->access[2]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $itemxpage = 25;

    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->helper(array('url','form'));
    $this->load->library(array('pagination', 'table'));

//erm creacion de los links
//------------------------------------------------------------------------------

    $uri_segment = 4;
    $table_name = 'med_specialities';


    $config['base_url'] = $this->config->site_url().'/'.$this->module_url."/show";
    $config['total_rows'] = $this->db->count_all($table_name);
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = $uri_segment;
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    //$config['num_links'] = "2";
    $this->pagination->initialize($config);
    $links = $this->pagination->create_links();

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------
    $begin = intval($this->uri->segment($uri_segment, 0));
    if ($begin < 0) $begin = 0;
    $lista = "";

    $this->db->orderby("name, code");
    $query = $this->db->get($table_name, $itemxpage, $begin);

    $this->table->set_heading(
    '#', $this->lang->line('specialities_code'), $this->lang->line('specialities_name'),
    $this->lang->line('med_functions')
    );
    $i = $begin+1;
    foreach ($query->result() as $row) {

      $del = anchor($this->module_url.'/del/'.$row->code, $this->lang->line('med_delete'));
      $edit = anchor($this->module_url.'/edit/'.$row->code, $this->lang->line('med_edit'));

      $this->table->add_row($i, $row->code, $row->name, $edit.'-'.$del);
      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing=0 width="100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $lista = $this->table->generate();


//erm enviar los resultados a la salida
//------------------------------------------------------------------------------
    make_blocks();
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('specialities_title');

    $center = $this->_thissubmenu($this->lang->line('specialities_listof')).'<br />';
    $center .= $lista ."<br />". $links;
    $data['content'] = theme($this->block_side1, $center);
    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * sends to browser a form asking the speciality to be deleted
   *
   * @public
   *
   * @return nothing
   */
  function delask() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|xss_clean";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('specialities_del')) . '<br />';
      $form .= $err . $this->_askcode_form ('del');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('specialities_title');
      $data['content'] = theme($this->block_side1, $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/del/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to confirm the speciality deletion, if admin click yes, the speciality is deleted
   *
   * @public
   *
   * @return nothing
   */
  function del() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask/');
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('specialities_del')).'<br />'
      . $err
      . Ask_yesno_form (sprintf($this->lang->line('specialities_askdel'), $code), $this->module_url.'/del/'.$code, $this->module_url.'/delask');

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('specialities_title');
      $data['content'] = theme($this->block_side1, $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      $this->db->delete('med_specialities', array('code' => $code));
      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask');
      return;
    }
  }


  /**
   * sends to browser a form asking the speciality to be edited
   *
   * @public
   *
   * @return nothing
   */
  function editask () {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|xss_clean|callback__code_exits";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('specialities_edit')).'<br />';
      $form .= $err . $this->_askcode_form ('edit');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('specialities_title');
      $data['content'] = theme($this->block_side1, $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/edit/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to update the speciality, do the validation proccess
   * and if it is successfull, update the new speciality information
   *
   * @public
   *
   * @return nothing
   */
  function edit() {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

//erm buscar si el codigo existe en la base de datos
//------------------------------------------------------------------------------
    $this->db->where('code', $code);
    $query = $this->db->get('med_specialities');

    if ($query->num_rows() == 0) {

      $msg = base64_encode(msgWarning('',$this->lang->line('specialities_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

    $customgroups = get_usersgroups_list();

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Name'] = $this->lang->line('admin_name');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {
      $row = $query->row();
      $this->validation->Code = $code;
      $this->validation->Name = $row->name;
    }

    $this->validation->set_error_delimiters('','<br />');

    $rules['Code']  = "trim|strip_tags|required|xss_clean";
    $rules['Name']  = "trim|strip_tags|htmlentities|xss_clean";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('specialities_edit')).'<br />';
      $form .= $err . $this->_make_form('edit', $this->module_url.'/edit/'.$code);

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('specialities_title');
      $data['content'] = theme($this->block_side1, $form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      );
      $this->db->where('code', $code);
      $this->db->update('med_specialities', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

  }
}
?>
