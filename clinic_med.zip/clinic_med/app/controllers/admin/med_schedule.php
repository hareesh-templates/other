<?php

/**
 * @file admin/med_schedule.php
 * @brief File to manage physician's schedules. (list, add, edit and delete)
 * 
 * @class Med_Schedule
 * @brief Class to manage physician's schedules. (list, add, edit and delete)
 *
 * @details Schedules will be shown when adding new appointments
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Med_Schedule extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/med_schedule";

  /**
   * the title for this controller
   */ 
  var $module_name = "med_shudule";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();

  /**
   * the name of the DB table to store the physicians
   */ 
  var $dbtablename = "med_schedule";


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Med_Schedule() {
    parent::Controller();

    $this->access[1] = "add";
    $this->access[2] = "show";
    $this->access[3] = "del";
    $this->access[4] = "edit";
    $this->access[5] = "settings";

    $this->settingsfromdb->loadconfig('med_schedule');

  }

  /**
   * return the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "add show del edit";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }

  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    //$items[] = '<b>'.$this->lang->line('admin_actions').'</b>';
    $items[] = anchor($this->module_url.'/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    $items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));
    //$items[] = anchor($this->module_url.'/settings', $this->lang->line('admin_settings'));

    return navbarsubmenu($title, $items, 'med_schedule.png');
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";
    make_blocks(array(1));
    $leftmenu = $this->block_side1;
    return $leftmenu;
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('admin_schedule')).'<br />';
    $content .= $this->lang->line('admin_defactions');

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * sends to browser an add schedule form, do the validation proccess and if it is successfull, then add the new schedule
   *
   * @public
   *
   * @return nothing
   */
  function add() {

    if ($this->_accesgranted($this->access[1]) == 0) return;

    $this->lang->load('admin');
    $this->lang->load('med_common');

    //erm main vars to initialice make_form
    $vars = array('action'=>'add','directo'=>$this->module_url.'/add');
    $vars['physicians'] = array(''=>'--- '.$this->lang->line('main_pleaseselect').' ---');
    $vars['specialities'] = array(''=>'--- '.$this->lang->line('main_pleaseselect').' ---');
    $vars['hours'] = $this->_hours();
    $vars['minutes'] = $this->_minutes();
    $vars['rawhours'] = $this->_rawhours();
    $vars['rawminutes'] = $this->_rawminutes();

    //erm load physicians list
    $this->db->select(array('code','name'));
    $this->db->orderby('name');
    $this->db->where('is_physician', 1);
    $query = $this->db->get('users');
    foreach ($query->result() as $row) {
      $vars['physicians'][$row->code] = sprintf('%s [%s]', $row->name, $row->code);
    }

    //erm load specialities list
    $this->db->select(array('code','name'));
    $this->db->orderby('name');
    $query = $this->db->get('med_specialities');
    foreach ($query->result() as $row) {
      $vars['specialities'][$row->code] = $row->name;
    }

    $validation = FALSE;
    $form = $this->_make_form ($vars, $validation);

    if ($validation == FALSE) {

      $content = $this->_thissubmenu($this->lang->line('admin_schedule')).'<br />'.$form;

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$content);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $from = $this->validation->Hour + $this->validation->Minute;
      $to = $from + $this->validation->Howlonga + $this->validation->Howlongb;
      $interval = $this->validation->Intervala + $this->validation->Intervalb;

      $data = array(
      'physician_code' => $this->validation->Physician,
      'speciality_code' => $this->validation->Speciality,
      'day' => $this->validation->Day,
      'time_from' => $from,
      'time_to' => $to,
      'intervallum' => $interval
      );
      $this->db->insert($this->dbtablename, $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);

      redirect($this->module_url.'/add');
      return;

    }
  }

  /**
   * returns an array with intervals of 300 seconds (each five minutes: 0, 300, 600 ...  3000, 3300)
   * 
   * the key of the array item is the number of seconds,
   * the value of the array item is in the format "i" (see date) plus " minutes" word
   *
   * @private
   *
   * @return array
   */
  function _rawminutes () {
    $date_temp = mktime (0, 0, 0, 4, 26, 1926);
    $control = array();
    for ($i=0; $i < (60*60); $i+=300) {
      $control[$i] = date('i',$date_temp+$i).' '.$this->lang->line('schedule_minutes');
    }
    return $control;
  }


  /**
   * returns an array with intervals of 3600 seconds (each one hour: 0, 3600, 7200 ... 79200, 82800)
   *
   * the key of the array item is the number of seconds,
   * the value of the array item is in the format "H" (see date) plus " hours" word
   *
   * @private
   *
   * @return array
   */
  function _rawhours () {
    $date_temp = mktime (0, 0, 0, 4, 26, 1926);
    $control = array();
    for ($i=0; $i < (60*60*24); $i+=3600) {
      $control[$i] = date('H',$date_temp+$i).' '.$this->lang->line('schedule_hours');
    }
    return $control;
  }

  /**
   * returns an array with intervals of 300 seconds (each five minutes: 0, 300, 600 ...  3000, 3300)
   * the key of the array item is the number of seconds, the value of the array item is in the format "i" (see date)
   * 
   * @private
   *
   * @return array
   */
  function _minutes () {
    $date_temp = mktime (0, 0, 0, 4, 26, 1926);
    $control = array();
    for ($i=0; $i < (60*60); $i+=300) {
      $control[$i] = date('i',$date_temp+$i);
    }
    return $control;
  }


  /**
   * returns an array with intervals of 3600 seconds (each one hour: 0, 3600, 7200 ... 79200, 82800)
   * the key of the array item is the number of seconds, the value of the array item is in the format "h:i a" (see date)
   *
   * @private
   *
   * @return array
   */
  function _hours () {
    $date_temp = mktime (0, 0, 0, 4, 26, 1926);
    $control = array();
    for ($i=0; $i < (60*60*24); $i+=3600) {
      $control[$i] = date('h:i a',$date_temp+$i);
    }
    return $control;
  }


  /**
   * creates and return a html form to add or edit schedules
   * also this method runs the validation process and store the result into $validation param
   *
   * the param $vars must has an item with key named "action". The valid values for this item are "edit" or "del"
   *
   * @private
   *
   * @param vars array. An array with default values for the form or the values stored into DB for existing schedules.
   * @param validation boolean. Set to TRUE for this method if validations was successful, else it is set to FALSE
   *
   * @return string (html)
   */
  function _make_form ($vars, &$validation) {
    //action - allowed values: add / edit

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('form'));
    $this->load->library(array('validation', 'table'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Speciality']  = "trim|strip_tags|required|xss_clean|callback__check_speciality";
    $rules['Physician']  = "trim|strip_tags|required|xss_clean|callback__check_physician";
    $rules['Day']  = "trim|numeric|required";
    $rules['Hour']  = "trim|numeric|required";
    $rules['Minute']  = "trim|numeric|required";
    $rules['Howlonga']  = "trim|numeric|required";
    $rules['Howlongb']  = "trim|numeric|required";
    $rules['Intervala']  = "trim|numeric|required";
    $rules['Intervalb']  = "trim|numeric|required";
    $this->validation->set_rules($rules);

    $fields['Speciality'] = $this->lang->line('specialities_name');
    $fields['Physician'] = $this->lang->line('physician_physician');
    $fields['Day'] = $this->lang->line('day_name');
    $fields['Hour'] = $this->lang->line('schedule_hour');
    $fields['Minute'] = $this->lang->line('schedule_minute');
    $fields['Howlonga'] = $this->lang->line('schedule_howlong');
    $fields['Howlongb'] = $this->lang->line('schedule_howlong');
    $fields['Intervala'] = $this->lang->line('schedule_interval');
    $fields['Intervalb'] = $this->lang->line('schedule_interval');
    $this->validation->set_fields($fields);

    $form = "";
    $validation = $this->validation->run();

    if ($validation == FALSE) {

      if ($vars['action'] == 'edit') {
        $this->validation->Code = $vars['Code'];
        $this->validation->Physician = $vars['Physician'];
        $this->validation->Speciality = $vars['Speciality'];
        $this->validation->Day = $vars['Day'];
        $this->validation->Hour = $vars['Hour'];
        $this->validation->Minute = $vars['Minute'];
        $this->validation->Howlonga = $vars['Howlonga'];
        $this->validation->Howlongb = $vars['Howlongb'];
        $this->validation->Intervala = $vars['Intervala'];
        $this->validation->Intervalb = $vars['Intervalb'];
      }

      $vars['days'] = array(
      ''=>'-- '.$this->lang->line('main_pleaseselect').' --',
      0=>$this->lang->line('day_sun'),
      1=>$this->lang->line('day_mon'),
      2=>$this->lang->line('day_tue'),
      3=>$this->lang->line('day_wed'),
      4=>$this->lang->line('day_thu'),
      5=>$this->lang->line('day_fri'),
      6=>$this->lang->line('day_sat'),
      );

      $tmparray = $vars['hours'];
      $tmparray[''] = '-- '.$this->lang->line('schedule_hour').' --';
      ksort($tmparray);
      $drop1a = form_dropdown('Hour', $tmparray, $this->validation->Hour);

      $tmparray = $vars['minutes'];
      $tmparray[''] = '-- '.$this->lang->line('schedule_minute').' --';
      asort($tmparray);
      $drop1b = form_dropdown('Minute', $tmparray, $this->validation->Minute);

      $tmparray = $vars['rawhours'];
      $tmparray[''] = '-- '.$this->lang->line('main_pleaseselect').' --';
      ksort($tmparray);
      $drop2a = form_dropdown('Howlonga', $tmparray, $this->validation->Howlonga);

      $tmparray = $vars['rawminutes'];
      $tmparray[''] = '-- '.$this->lang->line('main_pleaseselect').' --';
      asort($tmparray);
      $drop2b = form_dropdown('Howlongb', $tmparray, $this->validation->Howlongb);

      $tmparray = $vars['rawhours'];
      $tmparray[''] = '-- '.$this->lang->line('main_pleaseselect').' --';
      ksort($tmparray);
      $drop3a = form_dropdown('Intervala', $tmparray, $this->validation->Intervala);

      $tmparray = $vars['rawminutes'];
      $tmparray[''] = '-- '.$this->lang->line('main_pleaseselect').' --';
      asort($tmparray);
      $drop3b = form_dropdown('Intervalb', $tmparray, $this->validation->Intervalb);


      if ($this->validation->error_string != "") $form .= msgErr("",$this->validation->error_string);

      if ($vars['action'] == 'edit') {
        $data = "<b>".$this->validation->Code."</b>";
        $this->table->add_row($this->lang->line('admin_code'), $data.form_hidden('Code', $this->validation->Code));
      }

      $key = 'formSchedule';
      $attributes = array('id' => $key, 'name' => $key);
      $form .= form_open($vars['directo'], $attributes);

      $key = 'Speciality';
      $drop = form_dropdown($key, $vars['specialities'], $this->validation->Speciality);
      $this->table->add_row($this->lang->line('specialities_name'), $drop . $this->lang->line('admin_required'));

      $key = 'Physician';
      $drop = form_dropdown($key, $vars['physicians'], $this->validation->Physician);
      $this->table->add_row($this->lang->line('physician_physician'), $drop . $this->lang->line('admin_required'));

      $key = 'Day';
      $days = form_dropdown($key, $vars['days'], $this->validation->Day);
      $this->table->add_row($this->lang->line('day_name'), $days . $this->lang->line('admin_required'));

      $this->table->add_row($this->lang->line('schedule_from'), $drop1a .' '. $drop1b . $this->lang->line('admin_required'));

      $this->table->add_row($this->lang->line('schedule_howlong'), $drop2a .' '. $drop2b . $this->lang->line('admin_required'));

      $this->table->add_row($this->lang->line('schedule_interval'), $drop3a .' '. $drop3b . $this->lang->line('admin_required'));

      if ($vars['action'] == 'add') $this->table->add_row('', '<br />'.form_submit('submit', $this->lang->line('schedule_add')));
      if ($vars['action'] == 'edit') $this->table->add_row('', '<br />'.form_submit('submit', $this->lang->line('admin_savechanges')));

      $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=4 style="width:100%">');
      $this->table->set_template($tmpl);

      $form .= $this->table->generate();
      $form .= form_close();

    }

    return $form;

  }
  

  /**
   * looks for the physician code into DB. If it exists, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. The physician code
   *
   * @return boolean
   */
  function _check_physician($str) {
    $this->db->where(array('code'=>$str, 'is_physician'=>1));
    $this->db->select("code");
    $query = $this->db->get('users');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_physician', $this->lang->line('physician_codenofound'));
      return FALSE;
    }
  }


  /**
   * looks for the speciality code into DB. If it exists, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. The speciality code
   *
   * @return boolean
   */
  function _check_speciality($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('med_specialities');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_speciality', $this->lang->line('specialities_codenofound'));
      return FALSE;
    }
  }


  /**
   * sends to browser the list of schedules.
   *
   * @public
   *
   * @return nothing
   */
  function show() {

    if ($this->_accesgranted($this->access[2]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $itemxpage = 25;

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','form','text', 'date'));
    $this->load->library(array('pagination', 'table'));

//erm creacion de los links
//------------------------------------------------------------------------------
    $config['base_url'] = $this->config->site_url().'/'.$this->module_url."/show";
    $config['total_rows'] = $this->db->count_all($this->dbtablename);
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = "4";
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    //$config['num_links'] = "2";
    $this->pagination->initialize($config);
    $links = $this->pagination->create_links();

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------
    $begin = intval($this->uri->segment(4, 0));
    if ($begin < 0) $begin = 0;
    $lista = "";

    $prefix = $this->db->dbprefix;
    $this->db->distinct();
    $this->db->select($prefix.$this->dbtablename.'.*, '.$prefix.'users.name as physician, '.$prefix.'users.code as physician_code, '.$prefix.'med_specialities.name as speciality');
    $this->db->from($this->dbtablename);
    $this->db->join('users', 'users.code = '.$this->dbtablename.'.physician_code', 'left');
    $this->db->join('med_specialities', 'med_specialities.code = '.$this->dbtablename.'.speciality_code', 'left');
    $this->db->orderby('physician, day, time_from, time_to, speciality');
    $this->db->limit($itemxpage, $begin);
    $query = $this->db->get();

    $this->table->set_heading(
    '#', $this->lang->line('physician_physician'), $this->lang->line('specialities_name'), $this->lang->line('admin_code'),
    $this->lang->line('day_name'), $this->lang->line('schedule_from'), $this->lang->line('schedule_to'),
    $this->lang->line('schedule_interval'),
    $this->lang->line('main_functions')
    );

    $date_temp = mktime (0, 0, 0, 4, 26, 1926);
    $i = $begin+1;
    foreach ($query->result() as $row) {
      $del = anchor($this->module_url.'/del/'.$row->id, $this->lang->line('admin_del'));
      $edit = anchor($this->module_url.'/edit/'.$row->id, $this->lang->line('admin_edit'));

      $day = '';
      switch ($row->day) {
      case 0: $day = $this->lang->line('day_sun');
      break;
      case 1: $day = $this->lang->line('day_mon');
      break;
      case 2: $day = $this->lang->line('day_tue');
      break;
      case 3: $day = $this->lang->line('day_wed');
      break;
      case 4: $day = $this->lang->line('day_thu');
      break;
      case 5: $day = $this->lang->line('day_fri');
      break;
      case 6: $day = $this->lang->line('day_sat');
      break;
      default:
      break;
      }

      $now = now();
      $tmp = $now + $row->intervallum;
      $interval = timespan($now, $tmp);

      $this->table->add_row(
        $i, sprintf('%s [%s]', $row->physician, $row->physician_code), $row->speciality, $row->id, $day,
        date('h:i a',$date_temp+$row->time_from),
        date('h:i a',$date_temp+$row->time_to),
        $interval,
        $edit.'-'.$del
       );
      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing=0 width="100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $lista = $this->table->generate();


//erm enviar los resultados a la salida
//------------------------------------------------------------------------------
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');

    $center = $this->_thissubmenu($this->lang->line('schedule_listof')).'<br />';
    $center .= $lista ."<br />". $links;
    $data['content'] = theme($this->_leftmenu(), $center);
    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * creates and return a html form asking the schedule code for edit or delete actions.
   *
   * @private
   *
   * @param action enum. The action URL of the form. Valid options are "edit" and "del"
   *
   * @return string
   */
  function _askcode_form ($action) {
    //action - allowed values: del / edit
    $form = "";

    $key = 'formSchedule';
    $attributes = array('id' => $key, 'name' => $key);

    if ($action == 'del') $form .= form_open($this->module_url.'/delask', $attributes);
    if ($action == 'edit') $form .= form_open($this->module_url.'/editask', $attributes);

    $key = 'Code';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_code'), form_input($data));

    if ($action == 'del') $this->table->add_row('', form_submit('submit', $this->lang->line('schedule_del')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('schedule_edit')));

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }


  /**
   * sends to browser a form asking the schedule to be edited
   *
   * @public
   *
   * @return nothing
   */
  function editask () {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|numeric|required|xss_clean";
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('schedule_edit')).'<br />';
      $form .= $err . $this->_askcode_form ('edit');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/edit/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to update the schedule, do the validation proccess
   * and if it is successfull, update the new schedule information
   *
   * @public
   *
   * @return nothing
   */
  function edit() {
    if ($this->_accesgranted($this->access[4]) == 0) return;

    $this->lang->load('admin');
    $this->lang->load('med_common');

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

//erm buscar si el codigo existe en la base de datos
//------------------------------------------------------------------------------
    $this->db->where('id', $code);
    $query = $this->db->get($this->dbtablename);

    if ($query->num_rows() == 0) {
      $msg = base64_encode(msgErr('',$this->lang->line('schedule_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

//erm main vars to initialice make_form
//------------------------------------------------------------------------------
    $vars = array('action'=>'edit','directo'=>$this->module_url.'/edit/'.$code);
    $vars['physicians'] = array(''=>'--- '.$this->lang->line('main_pleaseselect').' ---');
    $vars['specialities'] = array(''=>'--- '.$this->lang->line('main_pleaseselect').' ---');
    $vars['hours'] = $this->_hours();
    $vars['minutes'] = $this->_minutes();
    $vars['rawhours'] = $this->_rawhours();
    $vars['rawminutes'] = $this->_rawminutes();

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {

      $row = $query->row();

      $minute = intval($row->time_from % 3600);
      $hour = $row->time_from - $minute;

      $howlong = $row->time_to - $row->time_from;
      $howlong2 = intval($howlong % 3600);
      $howlong1 = $howlong - $howlong2;

      $interval = $row->intervallum;
      $interval2 = intval($interval % 3600);
      $interval1 = $interval - $interval2;

      $vars['Code'] = $code;
      $vars['Physician'] = $row->physician_code;
      $vars['Speciality'] = $row->speciality_code;
      $vars['Day'] = $row->day;
      $vars['Hour'] = $hour;
      $vars['Minute'] = $minute;
      $vars['Howlonga'] = $howlong1;
      $vars['Howlongb'] = $howlong2;
      $vars['Intervala'] = $interval1;
      $vars['Intervalb'] = $interval2;

    } else {

      $vars['Code'] = $code;
      $vars['Physician'] = $this->input->post('Physician');
      $vars['Speciality'] = $this->input->post('Speciality');
      $vars['Day'] = $this->input->post('Day');
      $vars['Hour'] = $this->input->post('Hour');
      $vars['Minute'] = $this->input->post('Minute');
      $vars['Hownlong1'] = $this->input->post('Howlonga');
      $vars['Hownlong2'] = $this->input->post('Howlongb');
      $vars['Hownlong1'] = $this->input->post('Intervala');
      $vars['Hownlong2'] = $this->input->post('Intervalb');

    }

//erm load physicians list
//------------------------------------------------------------------------------
    $this->db->select(array('code','name'));
    $this->db->where('is_physician', 1);
    $this->db->orderby('name');
    $query = $this->db->get('users');
    foreach ($query->result() as $row) {
      $vars['physicians'][$row->code] = sprintf('%s [%s]', $row->name, $row->code);
    }

//erm load specialities list
//------------------------------------------------------------------------------
    $this->db->select(array('code','name'));
    $this->db->orderby('name');
    $query = $this->db->get('med_specialities');
    foreach ($query->result() as $row) {
      $vars['specialities'][$row->code] = $row->name;
    }

    $validation = FALSE;
    $form = $this->_make_form ($vars, $validation);

    if ($validation == FALSE) {

      $content = $this->_thissubmenu($this->lang->line('admin_schedule')).'<br />'.$form;

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$content);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $from = $this->validation->Hour + $this->validation->Minute;
      $to = $from + $this->validation->Howlonga + $this->validation->Howlongb;
      $interval = $this->validation->Intervala + $this->validation->Intervalb;

      $data = array(
      'physician_code' => $this->validation->Physician,
      'speciality_code' => $this->validation->Speciality,
      'day' => $this->validation->Day,
      'time_from' => $from,
      'time_to' => $to,
      'intervallum' => $interval,
      );

      $this->db->where('id', $code);
      $this->db->update($this->dbtablename, $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/add');
      return;

    }

  }

  /**
   * sends to browser a form asking the schedule to be deleted
   *
   * @public
   *
   * @return nothing
   */
  function delask() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|xss_clean";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('schedule_del')) . '<br />';
      $form .= $err . $this->_askcode_form ('del');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/del/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to confirm the schedule deletion, if user click yes, the schedule is deleted
   *
   * @public
   *
   * @return nothing
   */
  function del() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask/');
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('schedule_del')).'<br />'
      . $err
      . Ask_yesno_form (sprintf($this->lang->line('schedule_askdel'), $code), $this->module_url.'/del/'.$code, $this->module_url.'/delask');

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      $this->db->delete($this->dbtablename, array('id' => $code));
      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask');
      return;
    }
  }

/*
  function settings() {

    if ($this->_accesgranted($this->access[5]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie','date'));

//erm buscar todas las variables de configuracion de categoria users
//------------------------------------------------------------------------------
    $cat = 'med_schedule';
    $this->db->where('cat', $cat);
    $query = $this->db->get('settings');

    $settings_var = array();
    foreach ($query->result() as $row) {
      $settings_var[$row->var] = $row->value;
    }

    if (!isset($settings_var['schedule_interval'])) $settings_var['schedule_interval'] = 30;

    $fields['schedule_interval'] = $this->lang->line('schedule_interval');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    $this->validation->schedule_interval = $settings_var['schedule_interval']/60;

    $this->validation->set_error_delimiters('','<br />');

    $rules['schedule_interval']  = "trim|numeric|required|xss_clean";

    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

//erm search for message cookie
//-----------------------------------------------------------------------------
      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

//erm create the form
//-----------------------------------------------------------------------------
      $form = $err;

      $attributes = array('id' => 'formSettings', 'name' => 'formSettings');
      $form .= form_open($this->module_url.'/settings', $attributes);

//erm global site settings
//--------------------------------------------------------------------
      $this->table->add_row('<b>'.$this->lang->line('users_settingsmain').'</b>','');

      $key = "schedule_interval";
      $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'30');
      $this->table->add_row($this->lang->line('schedule_interval'), form_input($data));


      $this->table->add_row('', '<br />'.form_submit('submit', $this->lang->line('admin_savechanges')));

      $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=0 style="width:100%">',
      'row_start'           => '<tr class="table_1_td1">',
      'row_alt_start'       => '<tr class="table_1_td2">'
      );
      $this->table->set_template($tmpl);

      $form .= $this->table->generate();
      $form .= form_close();


//erm send info to browser
//-----------------------------------------------------------------------------
      $subtitle = $this->_thissubmenu($this->lang->line('admin_users')).'<br />';
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$subtitle.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $this->db->trans_start();
      $this->db->delete('settings', array('cat'=>$cat));

      $cat = $this->db->escape($cat);
      $sql = "INSERT INTO " . $this->db->dbprefix . "settings (var, value, cat) VALUES "
      . " ('schedule_interval',".$this->db->escape($this->validation->schedule_interval*60).",$cat)";

      $this->db->query($sql);
      $this->db->trans_complete();

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/settings');
      return;
    }
  }
*/



}
?>
