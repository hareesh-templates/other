<?php

/**
 * @file admin/med_physician.php
 * @brief File to manage physicians. (list, add, edit and delete)
 * 
 * @class Med_Physician
 * @brief Class to manage physicians. (list, add, edit and delete)
 *
 * @details
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Med_Physician extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/med_physician";

  /**
   * the title for this controller
   */ 
  var $module_name = "med_physician";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();

  /**
   * the name of the DB table to store the physicians
   */ 
  var $dbtablename = "med_physician";


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Med_Physician() {
    parent::Controller();

    $this->access[2] = "show";
    $this->access[4] = "edit";
  }


  /**
   * return the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "show edit";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    //$items[] = '<b>'.$this->lang->line('admin_actions').'</b>';
    $items[] = anchor('admin/users/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    //$items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));

    return navbarsubmenu($title, $items, 'med_physician.png');
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";
    make_blocks(array(1));
    $leftmenu = $this->block_side1;
    return $leftmenu;
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('admin_physicians')).'<br />';
    $content .= $this->lang->line('admin_defactions');

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * creates and return a html form to add or edit the physician information (address, phones, job, etc)
   * also this method runs the validation process and store the result into $validate param
   *
   * @private
   *
   * @param action enum. The type of form to create. Valid options are "add" or "edit"
   * @param url_action string. The form's action URL.
   * @param vars array. An array with default values for the form or the values stored into DB for existing physicians.
   * @param validate boolean. It is set to TRUE by this method if validations was successful, else it is set to FALSE
   *
   * @return string
   */
  function _form ($action, $url_action, $vars, &$validate) {

    $this->validation->set_error_delimiters('','<br />');

    $rules = array();
    $rules['Code']  = "trim|required|alpha_dash";
    $rules['identifier']  = "trim|alpha_dash|max_length[50]";
    $rules['RegProf']  = "trim|alpha_dash|max_length[50]";

    $rules['Birth_y'] = "trim|numeric|exact_length[4]";
    $rules['Birth_m'] = "trim|numeric|exact_length[2]";
    $rules['Birth_d'] = "trim|numeric|exact_length[2]";
    $rules['Gender'] = "trim|numeric";
    $rules['Notes'] = "trim|xss_clean";

    $rules['Address1_street'] = "trim|strip_tags|max_length[50]";
    $rules['Address1_city'] = "trim|strip_tags|max_length[50]";
    $rules['Address1_state'] = "trim|strip_tags|max_length[50]";
    $rules['Address1_other'] = "trim|strip_tags|max_length[250]";
    $rules['Address1_zipcode'] = "trim|strip_tags|max_length[50]";
    $rules['Address1_country'] = "trim|strip_tags|max_length[50]";
    $rules['Address2_street'] = "trim|strip_tags|max_length[50]";
    $rules['Address2_city'] = "trim|strip_tags|max_length[50]";
    $rules['Address2_state'] = "trim|strip_tags|max_length[50]";
    $rules['Address2_other'] = "trim|strip_tags|max_length[250]";
    $rules['Address2_zipcode'] = "trim|strip_tags|max_length[50]";
    $rules['Address2_country'] = "trim|strip_tags|max_length[50]";

    $rules['Phone1_home'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone1_work'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone1_mobil'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone1_other'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone2_home'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone2_work'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone2_mobil'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone2_other'] = "trim|alpha_dash|max_length[50]";
    $rules['Phone_contact'] = "trim|strip_tags|max_length[250]";

    $this->validation->set_rules($rules);
    //------------------------------------------------------------------------------

    $fields['failbirth'] = '';

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['identifier'] = $this->lang->line('physician_id1');
    $fields['RegProf'] = $this->lang->line('physician_regprof');
    $fields['Birth_y'] = $this->lang->line('physician_birth_y');
    $fields['Birth_m'] = $this->lang->line('physician_birth_m');
    $fields['Birth_d'] = $this->lang->line('physician_birth_d');
    $fields['Gender'] = $this->lang->line('physician_gender');
    $fields['Notes'] = $this->lang->line('admin_notes');

    $fields['Address1_street'] = $this->lang->line('physician_street');
    $fields['Address1_city'] = $this->lang->line('physician_city');
    $fields['Address1_state'] = $this->lang->line('physician_state');
    $fields['Address1_other'] = $this->lang->line('physician_othersignals');
    $fields['Address1_zipcode'] = $this->lang->line('physician_zipcode');
    $fields['Address1_country'] = $this->lang->line('physician_country');
    $fields['Address2_street'] = $this->lang->line('physician_street');
    $fields['Address2_city'] = $this->lang->line('physician_city');
    $fields['Address2_state'] = $this->lang->line('physician_state');
    $fields['Address2_other'] = $this->lang->line('physician_othersignals');
    $fields['Address2_zipcode'] = $this->lang->line('physician_zipcode');
    $fields['Address2_country'] = $this->lang->line('physician_country');

    $fields['Phone1_home'] = $this->lang->line('physician_homephone');
    $fields['Phone1_work'] = $this->lang->line('physician_businessphone');
    $fields['Phone1_mobil'] = $this->lang->line('physician_mobilphone');
    $fields['Phone1_other'] = $this->lang->line('physician_otherphone');
    $fields['Phone2_home'] = $this->lang->line('physician_homephone');
    $fields['Phone2_work'] = $this->lang->line('physician_businessphone');
    $fields['Phone2_mobil'] = $this->lang->line('physician_mobilphone');
    $fields['Phone2_other'] = $this->lang->line('physician_otherphone');
    $fields['Phone_contact'] = $this->lang->line('physician_contactto');

    $this->validation->set_fields($fields);
    //------------------------------------------------------------------------------

    $form = '';

    if ( ! $validate = $this->validation->run()) {

      foreach ($fields as $key => $val) {
        if ( isset($vars[$key])) $this->validation->$key = $vars[$key];
      }

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";
      $form .= $err;

      $required = $this->lang->line('admin_required');

      //------------------------------------------------------------------------------

      $key   = 'formPhysician';
      $data  = array('id' => $key, 'name' => $key);
      $hidden = array ('Code'=>$this->validation->Code, 'failbirth'=>0);
      $form .= form_open($url_action, $data, $hidden);

      //------------------------------------------------------------------------------

      $key = 'Code';
      $fcode = sprintf(
        '<b>%s: %s</b> <br /> (%s)',
        $this->lang->line('admin_code'),
        $this->validation->$key,
        anchor('admin/users/edit/'.$this->validation->$key, $this->lang->line('admin_edit'))
      );

      $key = 'identifier';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fid = sprintf('%s <br /> %s', $this->lang->line('physician_id1'), form_input($data));

      $key = 'RegProf';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fregprof = sprintf('%s <br /> %s', $this->lang->line('physician_regprof'), form_input($data));

      $key = 'Birth_y';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '3');
      $fbirth_y = form_input($data);

      $key = 'Birth_m';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '2');
      $fbirth_m = form_input($data);

      $key = 'Birth_d';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '2');
      $fbirth_d = form_input($data);

      $fbirth = sprintf('%s (yyyy/mm/dd) <br /> %s %s %s', $this->lang->line('physician_birth'), $fbirth_y, $fbirth_m, $fbirth_d);

      $key  = 'Gender';
      $data = array(0=>$this->lang->line('main_pleaseselect'),1=>$this->lang->line('physician_gender_m'),2=>$this->lang->line('physician_gender_f'));
      $fgender = sprintf('%s <br /> %s', $this->lang->line('physician_gender'), form_dropdown($key, $data, $this->validation->$key));

      $key = 'Notes';
      $fnotes = sprintf('%s <br /> %s', $this->lang->line('admin_notes'), textArea($key, $this->validation->$key, 'mini', '100px', '100%'));

      //------------------------------------------------------------------------------

      $key = 'Address1_street';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa1street = sprintf('%s <br /> %s', $this->lang->line('physician_street'), form_input($data));

      $key = 'Address1_city';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa1city = sprintf('%s <br /> %s', $this->lang->line('physician_city'), form_input($data));

      $key = 'Address1_state';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa1state = sprintf('%s <br /> %s', $this->lang->line('physician_state'), form_input($data));

      $key = 'Address1_zipcode';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa1zipcode = sprintf('%s <br /> %s', $this->lang->line('physician_zipcode'), form_input($data));

      $key = 'Address1_country';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa1country = sprintf('%s <br /> %s', $this->lang->line('physician_country'), form_input($data));

      $key = 'Address1_other';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'style'=>'width: 99%;' );
      $fa1other = sprintf('%s <br /> %s', $this->lang->line('physician_othersignals'), form_input($data));

      $key = 'Address2_street';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa2street = sprintf('%s <br /> %s', $this->lang->line('physician_street'), form_input($data));

      $key = 'Address2_city';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa2city = sprintf('%s <br /> %s', $this->lang->line('physician_city'), form_input($data));

      $key = 'Address2_state';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa2state = sprintf('%s <br /> %s', $this->lang->line('physician_state'), form_input($data));

      $key = 'Address2_zipcode';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa2zipcode = sprintf('%s <br /> %s', $this->lang->line('physician_zipcode'), form_input($data));

      $key = 'Address2_country';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key , 'size' => '10');
      $fa2country = sprintf('%s <br /> %s', $this->lang->line('physician_country'), form_input($data));

      $key = 'Address2_other';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'style'=>'width: 99%;' );
      $fa2other = sprintf('%s <br /> %s', $this->lang->line('physician_othersignals'), form_input($data));

      //------------------------------------------------------------------------------

      $key = 'Phone1_home';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp1home = sprintf('%s 1<br /> %s', $this->lang->line('physician_homephone'), form_input($data));

      $key = 'Phone1_work';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp1work = sprintf('%s 1<br /> %s', $this->lang->line('physician_businessphone'), form_input($data));

      $key = 'Phone1_mobil';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp1mobil = sprintf('%s 1<br /> %s', $this->lang->line('physician_mobilphone'), form_input($data));

      $key = 'Phone1_other';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp1other = sprintf('%s 1<br /> %s', $this->lang->line('physician_otherphone'), form_input($data));

      $key = 'Phone2_home';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp2home = sprintf('%s 2<br /> %s', $this->lang->line('physician_homephone'), form_input($data));

      $key = 'Phone2_work';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp2work = sprintf('%s 2<br /> %s', $this->lang->line('physician_businessphone'), form_input($data));

      $key = 'Phone2_mobil';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp2mobil = sprintf('%s 2<br /> %s', $this->lang->line('physician_mobilphone'), form_input($data));

      $key = 'Phone2_other';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '10');
      $fp2other = sprintf('%s 2<br /> %s', $this->lang->line('physician_otherphone'), form_input($data));

      $key = 'Phone_contact';
      $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '40');
      $fpcontact = sprintf('%s <br /> %s', $this->lang->line('physician_contactto'), form_input($data));

      //------------------------------------------------------------------------------

      $key = 'Submit';
      if ($action == 'add') {
        $fsubmit = form_submit($key, $this->lang->line('physician_add'));
      }
      if ($action == 'edit') {
        $fsubmit = form_submit($key, $this->lang->line('admin_savechanges'));
      }

      //------------------------------------------------------------------------------

      $tmpl =
      '<table width="100%%" border=0>
          <tr>
            <td colspan="6"> <h4>%s</h4> </td>
          </tr>
          <tr>
            <td > %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
          </tr>
          <tr>
            <td colspan="6"> %s </td>
          </tr>
          <tr>
            <td colspan="6"> <h4>%s</h4> </td>
          </tr>
          <tr>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
          </tr>
          <tr>
            <td colspan="6"> %s </td>
          </tr>
          <tr>
            <td colspan="6"> <h4>%s</h4> </td>
          </tr>
          <tr>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
          </tr>
          <tr>
            <td colspan="6"> %s </td>
          </tr>
          <tr>
            <td colspan="6"> <h4>%s</h4> </td>
          </tr>
          <tr>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
          </tr>
          <tr>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
            <td align="center"> %s </td>
          </tr>
          <tr>
            <td colspan="6"> %s </td>
          </tr>
      </table>
      ';

      $form .= sprintf(
        $tmpl,
        $this->lang->line('physician_general'),
        $fcode,
        $fid,
        $fregprof,
        $fbirth,
        $fgender,
        $fnotes,
        $this->lang->line('physician_homeaddress'),
        $fa1street,
        $fa1city,
        $fa1state,
        $fa1zipcode,
        $fa1country,
        $fa1other,
        $this->lang->line('physician_bussinessaddress'),
        $fa2street,
        $fa2city,
        $fa2state,
        $fa2zipcode,
        $fa2country,
        $fa2other,
        $this->lang->line('physician_contact'),
        $fp1home,
        $fp1work,
        $fp1mobil,
        $fp1other,
        $fp2home,
        $fp2work,
        $fp2mobil,
        $fp2other,
        $fpcontact
      );

      $form .= '<br />'.$fsubmit;
      $form .= form_close();

    }

    return $form;

  }

  /**
   * always returns FALSE. This method is called when the birth date is invalid
   *
   * @private
   *
   * @param str string. dummy param. Enter a empty value
   *
   * @return boolean
   */
  function _failbirth($str) {
    $this->validation->set_message('_failbirth', $this->lang->line('physician_failbirth'));
    return FALSE;
  }


  /**
   * looks for the physician code into DB. If it exists, return TRUE, else return FALSE
   *
   * @private
   *
   * @param str string. The physician code
   *
   * @return boolean
   */
  function _code_exists($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("count(*)");
    $query = $this->db->get('users');
    if ($query->num_rows() == 0) {
      $this->validation->set_message('_code_exists', $this->lang->line('physician_codenofound'));
      return FALSE;
    } else {
      return TRUE;
    }
  }


  /**
   * sends to browser the list of physicians.
   *
   * @public
   *
   * @return nothing
   */
  function show() {

    if ($this->_accesgranted($this->access[2]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $itemxpage = 25;

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('url','form','text'));
    $this->load->library(array('pagination', 'table'));

    $this->db->where('is_physician', 1);
    $this->db->select('count(*) as count');
    $query = $this->db->get('users');
    $row = $query->row();
    $count = $row->count;

//erm creacion de los links
//------------------------------------------------------------------------------
    $config['base_url'] = $this->config->site_url().'/'.$this->module_url."/show";
    $config['total_rows'] = $count;
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = "4";
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    //$config['num_links'] = "2";
    $this->pagination->initialize($config);
    $links = $this->pagination->create_links();

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------
    $begin = intval($this->uri->segment(4, 0));
    if ($begin < 0) $begin = 0;
    $lista = "";

    $this->db->orderby('name');
    $this->db->join('med_physician', 'med_physician.physician_code=users.code', 'left');
    $this->db->where('is_physician', 1);
    $query = $this->db->get('users', $itemxpage, $begin);

    $this->table->set_heading(
      '#', $this->lang->line('admin_code'), $this->lang->line('admin_name'),
      $this->lang->line('users_status'),
      $this->lang->line('admin_lang'), $this->lang->line('users_groups'),
      $this->lang->line('main_functions')
    );

    $i = $begin+1;
    foreach ($query->result() as $row) {

      $details = anchor($this->module_url.'/edit/'.$row->code, $this->lang->line('physician_details'));
      $edit    = anchor('admin/users/edit/'.$row->code, $this->lang->line('admin_edit'));
      $del     = anchor('admin/users/del/'.$row->code, $this->lang->line('admin_del'));

      $groups = str_replace('[]','',$row->groups);
      $groups = str_replace('+',' ',$groups);
      if ($groups == '') $groups = '<b>'.$this->lang->line('usersgroups_none').'</b>';

      switch ($row->status) {
        case 0:
          $status =  $this->lang->line('main_disabled');
          break;
        case 1:
        default:
          $status =  $this->lang->line('main_enabled');
          break;
      }

      if ($row->lang == "") $row->lang = $this->lang->line('admin_all');

      $this->table->add_row(
        $i, $row->code, $row->name, $status, $row->lang, $groups,
        sprintf('%s - %s - %s', $details, $edit, $del)
      );

      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing=0 width="100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $lista = $this->table->generate();


//erm enviar los resultados a la salida
//------------------------------------------------------------------------------
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');

    $center = $this->_thissubmenu($this->lang->line('physician_listof')).'<br />';
    $center .= $lista ."<br />". $links;
    $data['content'] = theme($this->_leftmenu(), $center);
    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * creates and return a html form asking the physician code for edit or delete actions.
   *
   * @private
   *
   * @param action enum. The action URL of the form. Valid options are "edit" and "del"
   *
   * @return string
   */
  function _askcode_form ($action) {
    //action - allowed values: del / edit
    $form = "";

    $key = 'formPhysician';
    $attributes = array('id' => $key, 'name' => $key);

    if ($action == 'del') $form .= form_open($this->module_url.'/delask', $attributes);
    if ($action == 'edit') $form .= form_open($this->module_url.'/editask', $attributes);

    $key = 'Code';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_code'), form_input($data));

    if ($action == 'del') $this->table->add_row('', form_submit('submit', $this->lang->line('physician_del')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('physician_edit')));

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }

  /**
   * sends to browser a form asking the physician to be edited
   *
   * @public
   *
   * @return nothing
   */
  function editask () {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|alpha_dash|callback__code_exists";
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('physician_edit')).'<br />';
      $form .= $err . $this->_askcode_form ('edit');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/edit/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to update the physician's details, do the validation proccess
   * and if it is successfull, update the new physician's detail information
   *
   * @public
   *
   * @return nothing
   */
  function edit() {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

//erm buscar si el codigo existe en la tabla de usuarios
//------------------------------------------------------------------------------
    $this->db->where('code', $code);
    $this->db->where('is_physician', 1);
    $query = $this->db->get('users');
    if ($query->num_rows() == 0) {
      $msg = base64_encode(msgWarning('',$this->lang->line('physician_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

    $vars       = array();

//erm buscar si el codigo existe en la tabla physcians, sino agregarlo
//------------------------------------------------------------------------------
    $this->db->where('physician_code', $code);
    $query = $this->db->get($this->dbtablename);
    if ( ! $query->num_rows()) {

      $data = array('physician_code' => $code);
      $this->db->insert($this->dbtablename, $data);

    } else {

      if ($this->input->post('Code') === FALSE) {
        $row = $query->row();

        $vars['identifier'] = $row->identifier;
        $vars['RegProf'] = $row->regprof;

        $vars['Birth_y'] = $row->birthdate ? date('Y', $row->birthdate) : '';
        $vars['Birth_m'] = $row->birthdate ? date('m', $row->birthdate) : '';
        $vars['Birth_d'] = $row->birthdate ? date('d', $row->birthdate) : '';

        $vars['Gender'] = $row->gender;
        $vars['Notes'] = $row->notes;

        $vars['Address1_street'] = $row->address1_street;
        $vars['Address1_city'] = $row->address1_city;
        $vars['Address1_state'] = $row->address1_state;
        $vars['Address1_other'] = $row->address1_other;
        $vars['Address1_zipcode'] = $row->address1_zipcode;
        $vars['Address1_country'] = $row->address1_country;

        $vars['Address2_street'] = $row->address2_street;
        $vars['Address2_city'] = $row->address2_city;
        $vars['Address2_state'] = $row->address2_state;
        $vars['Address2_other'] = $row->address2_other;
        $vars['Address2_zipcode'] = $row->address2_zipcode;
        $vars['Address2_country'] = $row->address2_country;

        $vars['Phone1_home'] = $row->phone1_home;
        $vars['Phone1_work'] = $row->phone1_work;
        $vars['Phone1_mobil'] = $row->phone1_mobil;
        $vars['Phone1_other'] = $row->phone1_other;

        $vars['Phone2_home'] = $row->phone2_home;
        $vars['Phone2_work'] = $row->phone2_work;
        $vars['Phone2_mobil'] = $row->phone2_mobil;
        $vars['Phone2_other'] = $row->phone2_other;

        $vars['Phone_contact'] = $row->phone_contact;

      }
    }

    $vars['Code'] = $code;


    $validate   = false;
    $action     = 'edit';
    $url_action = $this->module_url . '/edit/' . $code;
    $form = $this->_form ($action, $url_action, $vars, $validate);

    if ( ! $validate) {

      $this->_showform ($form);

    } else {

      $datebirth = 0;
      $dd = intval($this->validation->Birth_d);
      $mm = intval($this->validation->Birth_m);
      $yy = intval($this->validation->Birth_y);
      if ($dd || $mm || $yy) {

        if ( ! checkdate  ($mm, $dd, $yy)) {

          $rules['failbirth']  = "callback__failbirth";
          $this->validation->set_rules($rules);
          $form = $this->_form ($action, $url_action, $vars, $validate);
          $this->_showform ($form);
          return;

        } else {
          $datebirth = mktime(0,0,0, $mm, $dd, $yy);
        }
      }

      $data = array(
        'identifier' =>  $this->validation->identifier,
        'regprof' =>  $this->validation->RegProf,
        'birthdate' =>  $datebirth,
        'gender' =>  $this->validation->Gender,
        'notes' =>  $this->validation->Notes,

        'address1_street' =>  $this->validation->Address1_street,
        'address1_city' =>  $this->validation->Address1_city,
        'address1_state' =>  $this->validation->Address1_state,
        'address1_other' =>  $this->validation->Address1_other,
        'address1_zipcode' =>  $this->validation->Address1_zipcode,
        'address1_country' =>  $this->validation->Address1_country,

        'address2_street' =>  $this->validation->Address2_street,
        'address2_city' =>  $this->validation->Address2_city,
        'address2_state' =>  $this->validation->Address2_state,
        'address2_other' =>  $this->validation->Address2_other,
        'address2_zipcode' =>  $this->validation->Address2_zipcode,
        'address2_country' =>  $this->validation->Address2_country,

        'phone1_home' =>  $this->validation->Phone1_home,
        'phone1_work' =>  $this->validation->Phone1_work,
        'phone1_mobil' =>  $this->validation->Phone1_mobil,
        'phone1_other' =>  $this->validation->Phone1_other,

        'phone2_home' =>  $this->validation->Phone2_home,
        'phone2_work' =>  $this->validation->Phone2_work,
        'phone2_mobil' =>  $this->validation->Phone2_mobil,
        'phone2_other' =>  $this->validation->Phone2_other,

        'phone_contact' =>  $this->validation->Phone_contact,
      );

      $this->db->where('physician_code', $code);
      $this->db->update($this->dbtablename, $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

  }


  /**
   * send to browser a html form to edit the physician's details (phone, address, job, etc)
   *
   * @private
   *
   * @param form string. The physician's detail html form
   *
   * @return nothing
   */
  function _showform ($form) {
    $content = '';
    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content .= $msg;
    $content .= $this->_thissubmenu($this->lang->line('admin_title'));
    $content .= $form;

    $data = default_Vars_Content();
    $data['title']  .= ' - ' . $this->lang->line('physician_title');
    $data['content'] = theme($this->_leftmenu(), $content);

    $this->load->view($this->config->item('theme'), $data);
  }

}
?>
