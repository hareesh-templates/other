<?php

/**
 * @file admin/settings.php
 * @brief File to setup system options: i.e. (globals, security, design, performance)
 * 
 * @class Settings
 * @brief Class to setup system options: i.e. (globals, security, design, performance)
 *
 * @details
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Settings extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/settings";

  /**
   * the title for this controller
   */ 
  var $module_name = "settings";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If admin has not permissions, redirect to access denied
   *
   * @public
   */
  function Settings() {
    parent::Controller();

    $this->access[1] = "settings";
  }


  /**
   * return the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "settings";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    /*
    $items[] = '<b>'.$this->lang->line('admin_actions').'</b>';
    $items[] = anchor($this->module_url.'/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    $items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));
    */

    return navbarsubmenu($title, '', 'settings.png');
    //return navbarsubmenu($title, $items, 'menu.png');
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";

    make_blocks(1);
    $leftmenu = $this->block_side1;

    return $leftmenu;
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {
    $this->setup();
  }


  /**
   * creates and return a html form to edit the website settings.
   *
   * @private
   *
   * @param action enum The type of form to create. Valid options are "add" or "edit"
   * @param directo string The form's action URL.
   *
   * @return string
   */
  function _make_form ($action, $directo) {

    $attributes = array('id' => 'formSettings', 'name' => 'formSettings');

    $form = form_open($directo, $attributes);

//erm global site settings
//--------------------------------------------------------------------
    $this->table->add_row('<b>'.$this->lang->line('settings_site').'</b>','');

    $key = "title";
    $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'30');
    $this->table->add_row($this->lang->line('settings_title'), form_input($data) . $this->lang->line('admin_required'));

    $key = "base_url";
    //$data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'30', 'readonly'=>'readonly');
    //$this->table->add_row($this->lang->line('settings_baseurl'), form_input($data));
    $this->table->add_row($this->lang->line('settings_baseurl'), $this->validation->$key);

    $key = "admin_email";
    $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'30');
    $this->table->add_row($this->lang->line('settings_adminemail'), form_input($data) . $this->lang->line('admin_required'));

    $key = "charset";
    $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'15');
    $this->table->add_row($this->lang->line('settings_charset'), form_input($data). $this->lang->line('admin_required'));

    $key = "timezone";
    $this->table->add_row($this->lang->line('settings_timezone'), timezone_menu($this->validation->$key, "", $key));

    $key = "keywords";
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'rows' => '3', 'style'=>'width:90%');
    $this->table->add_row($this->lang->line('settings_keywords'), form_textarea($data));

//erm security settings
//--------------------------------------------------------------------
    $this->table->add_row('<b>'.$this->lang->line('settings_security').'</b>','');

    $key = "cookie_prefix";
    $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'15');
    $this->table->add_row($this->lang->line('settings_cookiename'), form_input($data).$this->lang->line('admin_required'));

    $key = "sess_expiration";
    $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'5');
    $this->table->add_row($this->lang->line('settings_sessiontime'), form_input($data).$this->lang->line('admin_required'));

    $key = "encryption_key";
    $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'30');
    $this->table->add_row($this->lang->line('settings_sitekey'), form_input($data).$this->lang->line('admin_required'));


//erm site design
//--------------------------------------------------------------------
    $this->table->add_row('<b>'.$this->lang->line('settings_design').'</b>','');


    $key = "use_htmleditor";
    $array = array();
    $array['no'] = $this->lang->line('settings_noeditor');
    //$array['spaw2'] = $this->lang->line('settings_spaw2');
    $array['fckeditor'] = $this->lang->line('settings_fckeditor');
    $this->table->add_row($this->lang->line('settings_htmleditor'), form_dropdown($key, $array,  $this->validation->$key).'<br />'.$this->lang->line('settings_htmleditornote'));

    $key = "language";
    $this->table->add_row($this->lang->line('admin_lang'), form_dropdown($key, get_lang_list(), $this->validation->$key));

    $key = "theme";
    $this->table->add_row($this->lang->line('admin_theme'), form_dropdown($key, get_theme_list(),  $this->validation->$key));

    $this->table->add_row($this->lang->line('settings_footer1'), textArea('footer1', $this->validation->footer1, 'mini'));

    $this->table->add_row($this->lang->line('settings_footer2'), textArea('footer2', $this->validation->footer2, 'mini'));


//erm site performance
//--------------------------------------------------------------------
    $this->table->add_row('<b>'.$this->lang->line('settings_performance').'</b>','');

    $key = "cacheenabled";
    $radio = form_radio($key, '1', intval($this->validation->$key)) . $this->lang->line('main_yes')
    .form_radio($key, '0', !intval($this->validation->$key)) . $this->lang->line('main_no');
    $this->table->add_row($this->lang->line('settings_cachepages'), $radio.'<br />'.$this->lang->line('settings_cachepagesnote'));

    $key = "cachetime";
    $data = array('name'=>$key, 'id'=>$key, 'value'=>$this->validation->$key, 'size'=>'5');
    $this->table->add_row($this->lang->line('settings_cachetime'), form_input($data).$this->lang->line('admin_required'));


    $this->table->add_row('', '<br />'.form_submit('submit', $this->lang->line('admin_savechanges')));

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=0 style="width:100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">'
    );
    $this->table->set_template($tmpl);

    $form .= $this->table->generate();
    $form .= form_close();


    return $form;
  }


  /**
   * sends to browser a settings form, do the validation proccess and if it is successfull, then update the new website settings
   *
   * @public
   *
   * @return nothing
   */
  function setup () {

    if ($this->_accesgranted($this->access[1]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie','date'));

//erm buscar todas las variables de configuracion de categoria admin
//------------------------------------------------------------------------------
    $this->db->where('cat', 'admin');
    $query = $this->db->get('settings');

    $settings_var = array();
    foreach ($query->result() as $row) {
      $settings_var[$row->var] = $row->value;
    }

    if (!isset($settings_var['title'])) $settings_var['title'] = 'Clinic Manager';
    if (!isset($settings_var['base_url'])) $settings_var['base_url'] = $this->config->item('base_url');
    if (!isset($settings_var['admin_email'])) $settings_var['admin_email'] = 'admin@email.com';
    if (!isset($settings_var['language'])) $settings_var['language'] = 'english';
    if (!isset($settings_var['theme'])) $settings_var['theme'] = 'default';
    if (!isset($settings_var['charset'])) $settings_var['charset'] = 'UTF-8';
    if (!isset($settings_var['keywords'])) $settings_var['keywords'] = '';
    if (!isset($settings_var['cachetime'])) $settings_var['cachetime'] = '120'; //erm number of minutes
    if (!isset($settings_var['encryption_key'])) $settings_var['encryption_key'] = 'string_key_change_to_any_you_want';
    if (!isset($settings_var['cookie_prefix'])) $settings_var['cookie_prefix'] = 'cookie_prefix_';
    if (!isset($settings_var['sess_expiration'])) $settings_var['sess_expiration'] = '300';
    if (!isset($settings_var['footer1'])) $settings_var['footer1'] = '';
    if (!isset($settings_var['footer2'])) $settings_var['footer2'] = '';
    if (!isset($settings_var['use_htmleditor'])) $settings_var['use_htmleditor'] = 0;
    if (!isset($settings_var['timezone'])) $settings_var['timezone'] = 'UTC';
    if (!isset($settings_var['cacheenabled'])) $settings_var['cacheenabled'] = 0;

    $fields['title'] = $this->lang->line('settings_title');
    $fields['base_url'] = $this->lang->line('settings_baseurl');
    $fields['admin_email'] = $this->lang->line('settings_adminemail');
    $fields['language'] = $this->lang->line('admin_lang');
    $fields['theme'] = $this->lang->line('settings_theme');
    $fields['charset'] = $this->lang->line('settings_charset');
    $fields['keywords'] = $this->lang->line('settings_keywords');
    $fields['cachetime'] = $this->lang->line('settings_cachetime');
    $fields['encryption_key'] = $this->lang->line('settings_sitekey');
    $fields['cookie_prefix'] = $this->lang->line('settings_cookiename');
    $fields['sess_expiration'] = $this->lang->line('settings_sessiontime');
    $fields['footer1'] = $this->lang->line('settings_footer1');
    $fields['footer2'] = $this->lang->line('settings_footer2');
    $fields['use_htmleditor'] = $this->lang->line('settings_htmleditor');
    $fields['timezone'] = $this->lang->line('settings_timezone');
    $fields['cacheenabled'] = $this->lang->line('settings_cachepages');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    $this->validation->title = $settings_var['title'];
    //$this->validation->base_url = $settings_var['base_url'];
    $this->validation->base_url = $this->config->item('base_url');
    $this->validation->admin_email = $settings_var['admin_email'];
    $this->validation->language = $settings_var['language'];
    $this->validation->theme = $settings_var['theme'];
    $this->validation->charset = $settings_var['charset'];
    $this->validation->keywords = $settings_var['keywords'];
    $this->validation->cachetime = $settings_var['cachetime'];
    $this->validation->encryption_key = $settings_var['encryption_key'];
    $this->validation->cookie_prefix = $settings_var['cookie_prefix'];
    $this->validation->sess_expiration = intval($settings_var['sess_expiration']/60);
    $this->validation->footer1 = $settings_var['footer1'];
    $this->validation->footer2 = $settings_var['footer2'];
    $this->validation->use_htmleditor = $settings_var['use_htmleditor'];
    $this->validation->timezone = $settings_var['timezone'];
    $this->validation->cacheenabled = $settings_var['cacheenabled'];

    $this->validation->set_error_delimiters('','<br />');

    $rules['title']  = "trim|strip_tags|required|xss_clean";
    //$rules['base_url']  = "trim|required|htmlentities|xss_clean";
    $rules['admin_email']  = "trim|required|valid_email|xss_clean";
    $rules['language']  = "trim|required|xss_clean";
    $rules['theme']  = "trim|required|xss_clean";
    $rules['charset']  = "trim|strip_tags|required|xss_clean";
    $rules['keywords']  = "trim|strip_tags|xss_clean";
    $rules['cachetime']  = "trim|required|numeric|xss_clean";
    $rules['encryption_key']  = "trim|required|xss_clean";
    $rules['cookie_prefix']  = "trim|required|xss_clean";
    $rules['sess_expiration']  = "trim|required|numeric|xss_clean";
    $rules['footer1']  = "trim|xss_clean";
    $rules['footer2']  = "trim|xss_clean";
    $rules['use_htmleditor']  = "trim|required|xss_clean";
    $rules['timezone']  = "trim|required|xss_clean";
    $rules['cacheenabled']  = "trim|required|xss_clean";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $form = $this->_thissubmenu($this->lang->line('admin_settings'));
      $form .= $err . $this->_make_form('setup', $this->module_url.'/setup');

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $cat = $this->db->escape('admin');
      $sql = "INSERT INTO " . $this->db->dbprefix . "settings (var, value, cat) VALUES "
      . " ('title',".$this->db->escape($this->validation->title).",$cat), "
      //. " ('base_url',".$this->db->escape($this->validation->base_url).",$cat), "
      . " ('admin_email',".$this->db->escape($this->validation->admin_email).",$cat), "
      . " ('language',".$this->db->escape($this->validation->language).",$cat), "
      . " ('theme',".$this->db->escape($this->validation->theme).",$cat), "
      . " ('charset',".$this->db->escape($this->validation->charset).",$cat), "
      . " ('keywords',".$this->db->escape($this->validation->keywords).",$cat), "
      . " ('cachetime',".$this->db->escape($this->validation->cachetime).",$cat), "
      . " ('cacheenabled',".$this->db->escape($this->validation->cacheenabled).",$cat), "
      . " ('encryption_key',".$this->db->escape($this->validation->encryption_key).",$cat), "
      . " ('cookie_prefix',".$this->db->escape($this->validation->cookie_prefix).",$cat), "
      . " ('sess_expiration',".$this->db->escape(intval($this->validation->sess_expiration)*60).",$cat), "
      . " ('footer1',".$this->db->escape($this->validation->footer1).",$cat), "
      . " ('footer2',".$this->db->escape($this->validation->footer2).",$cat), "
      . " ('timezone',".$this->db->escape($this->validation->timezone).",$cat), "
      . " ('use_htmleditor',".$this->db->escape($this->validation->use_htmleditor).",$cat); ";

      $this->db->trans_start();
      $this->db->delete('settings', array('cat'=>'admin'));
      $this->db->query($sql);
      $this->db->trans_complete();

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;
    }

  }
}
?>
