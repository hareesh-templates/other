<?php

/**
 * @file admin/cron.php
 * @brief File to manage cron. (enable, disable task)
 * 
 * @class Cron
 * @brief Class to manage cron. (enable, disable task)
 *
 * @details cron is the S.O.'s process of load methods periodically and automated
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Cron extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url  = "admin/cron";

  /**
   * the title for this controller
   */ 
  var $module_name = "Cron Jobs";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();

  /**
   * contains all the functions of this class that begins with the prefix "run_"
   */ 
  var $run_functions = array();


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Cron () {
    parent::Controller();

    $this->access[0] = "config";

    $this->run_functions = get_class_methods($this);
    foreach ($this->run_functions as $key => $val) {
      if (strpos($val, 'run_') !== 0) unset($this->run_functions[$key]);
    }

    $this->settingsfromdb->loadconfig('cron');

  }


  /**
   * return the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "config";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {
    return navbarsubmenu($title, '', 'cron.png');
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";

    make_blocks(1);
    $leftmenu = $this->block_side1;

    return $leftmenu;
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @public
   * 
   * @return string
   */
  function index () {
    $this->setup();
  }


  /**
   * sends to browser a setup cron form, do the validation proccess
   * and if it is successfull, then update the new cron configuration
   *
   * @public
   *
   * @return nothing
   */
  function setup () {

    if ($this->_accesgranted($this->access[0]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('cron');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie','date'));

//erm buscar todas las variables de configuracion de categoria admin
//------------------------------------------------------------------------------
    $rules  = array();
    $fields = array();
    $vars   = array();

    $cat  = 'cron';
    $this->db->where('cat', $cat);
    $query = $this->db->get('settings');
    foreach ($query->result() as $row) {
      $vars[$row->var]   = $row->value;
    }

    foreach ($this->run_functions as $val) {
      $rules[$val]  = "numeric";
      $fields[$val]  = $val;
    }

    $this->validation->set_fields($fields);
    $this->validation->set_rules($rules);
    $this->validation->set_error_delimiters('','<br />');

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";


      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $content  = '';
      $content .= $msg;
      $content .= $this->_thissubmenu($this->lang->line('cron_tittle'));
      $content .= sprintf('<br /><div class="msg_1">%s</div><br />', $this->lang->line('cron_instructions'));
      $content .= $err;
      $content .= $this->_make_form('setup', $this->module_url.'/setup', $vars);

      $data = default_Vars_Content();
      $data['title']    .= ' - ' . $this->lang->line('admin_title');
      $data['content']   = theme($this->_leftmenu(), $content);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $this->db->trans_start();
      $this->db->delete('settings', array('cat'=>$cat));

      if (sizeof($this->run_functions)) {
        $sql = sprintf('INSERT INTO %ssettings (var, value, cat) VALUES ',$this->db->dbprefix);
        $values = '';
        foreach ($this->run_functions as $val) {
          $check = '0';
          if (isset($this->validation->$val)) $check = $this->validation->$val;
          if ($values != '') $values .= ', ';
          $values .= sprintf('("%s", "%s", "%s")', $val, $check, $cat);
        }
        $sql = $sql . $values . ';';
        $this->db->query($sql);
      }

      $this->db->trans_complete();

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }
  }


  /**
   * creates and return a html form to edit the cron configuration
   *
   * @private
   *
   * @param action enum. The type of form to create. Valid options are "add" or "edit"
   * @param directo string. The form's action URL.
   * @param vars array Contains if each $this->run_functions are checked to be executed or not.
   *
   * @return string
   */
  function _make_form ($action, $directo, $vars) {

    $attributes = array('id' => 'formSettings', 'name' => 'formSettings');
    $form = form_open($directo, $attributes);

    $this->table->add_row(sprintf('<b>%s</b>', $this->lang->line('cron_list')));

    foreach ($this->run_functions as $val) {
      if ( ! isset($vars[$val]) ) $vars[$val] = 0;

      $data = array(
        'name'        => $val,
        'id'          => $val,
        'value'       => '1',
        'checked'     => $vars[$val],
      );

      $this->table->add_row(
        sprintf(
          '%s %s <br /> %s <br /><br /> %s:<br /> %s',
          form_checkbox($data),
          sprintf('<label for="%s">%s</label>', $val, $val),
          $this->lang->line('run_notify_next_appointments'),
          $this->lang->line('cron_command'),
          'wget ' . site_url() .'/'. $this->module_url .'/run_notify_next_appointments'
        ),
        anchor($this->module_url.'/run/run_notify_next_appointments', $this->lang->line('cron_runmanually'))

      );

    }

    $this->table->add_row('<br />'.form_submit('submit', $this->lang->line('admin_savechanges')));

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=4 cellspacing=0 style="width:100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">'
    );
    $this->table->set_template($tmpl);

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }


  /**
   * run a valid cron method. Valid cron methods are those into $this->run_functions variable
   *
   * this method will look for the method to be executed into the URI segment 4
   *
   * @public
   *
   * @return nothing
   */
  function run () {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->lang->load('cron');
    $this->load->helper(array('url','cookie'));

    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ( ! $code) {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }


    if ( ! in_array ($code, $this->run_functions)) {
      $msg = base64_encode(msgErr('', $this->lang->line('cron_noexists')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }

    eval('$this->_'.$code.'();');
    $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
    set_cookie('msg', $msg, 0);
    redirect($this->module_url);
    return;

  }


  /**
   * if this method was checked into cron configuration, then run it, else does nothing
   *
   * @public
   *
   * @return nothing
   */
  function run_notify_next_appointments () {
    if ( ! $this->config->item('run_notify_next_appointments')) {
      return;
    }
    $this->_run_notify_next_appointments ();
  }


  /**
   * Send an email to all physicians who have next day appointments 
   *
   * @private
   *
   * @return nothing
   */
  function _run_notify_next_appointments () {

    $this->lang->load('admin');
    $this->lang->load('cron');
    $this->load->helper(array('url', 'date'));
    $this->load->library('email');

    $now = now();

//erm cargar la informacion desde la base de datos
//------------------------------------------------------------------------------
//erm. get all open appointments from now up two days.
    $where = array('a.status >' => 0, 'a.status <' => 4, 'a.time_from<=' => $now + intval(60*60*24*2));

    $prefix = $this->db->dbprefix;
    $this->db->select(sprintf(
      'a.*, b.name as physician, b.timezone, b.email, c.name as patient, d.name as speciality
      FROM %smed_appointment as a
      LEFT JOIN %susers as b ON a.physician_code=b.code && b.is_physician=1
      LEFT JOIN %smed_patient as c ON a.patient_code=c.code
      LEFT JOIN %smed_specialities as d ON a.speciality_code=d.code
      ',
      $prefix,
      $prefix,
      $prefix,
      $prefix
    ));
    $this->db->where($where);
    $this->db->orderby('physician, time_from');
    $query = $this->db->get();

    $physician      = array();
    $physician_info = array();
    if ($query->num_rows() > 0) {

      foreach ($query->result() as $row) {

        $nowtz = gmt_to_local($now, $row->timezone);
        $tomorrow = mktime(23,59,59,date('n',$nowtz),date('j',$nowtz)+1,date('Y',$nowtz));

        if ($row->time_from < $tomorrow) {

          $tmp =
          $this->_run_notify_next_appointments_format (
            $row->status, $row->id, $row->time_from,
            $row->time_to, $row->patient, $row->patient_code, $row->speciality, $row->notes,
            $row->physician
          );

          //-----------------------------------------------------------------------------------------------------
          $physician_info[$row->physician_code]['email'] = $row->email;
          $physician_info[$row->physician_code]['name'] = $row->physician;
          //erm. above lines code could run few times; but in this case better simplicity instead of beauty :)
          //-----------------------------------------------------------------------------------------------------

          if (isset($physician[$row->physician_code])) {
            $physician[$row->physician_code] .= $tmp;
          } else {
            $physician[$row->physician_code] = $tmp;
          }

        }
      }

    }

//erm recuperar cualquier cookie de mensaje
//------------------------------------------------------------------------------

    $content = '';
    //!!$content .= $physician['erick'];

    $cssscr = $this->config->item('theme_url') . 'style.css';
    $template =
    '
    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">
    <html>
      <head>
        <meta content="text/html; charset='.$this->config->item('charset').'" http-equiv="content-type" >
        <link rel="stylesheet" href="'.$cssscr.'" type="text/css">
      </head>
      <body>
        <table width="800px"><tr><td>
          <div id="main" class="main"  >
            <div class="ccontent">
              <br />
              %s
            </div>
          </div>
        </td></tr></table>
      </body>
    </html>
    '
    ;

    $config['priority'] = 1;
    $this->email->initialize($config);


    foreach ($physician as $key => $val) {

      $msg =
      sprintf(
        $template,
        sprintf(
          '<div >
            <b>%s: </b> %s
            <br />
            <b>%s: </b> %s
          </div>
          <hr />
          %s
          <br />
          %s
          ',
          $this->lang->line('cron_appointment_to'),
          $physician_info[$key]['name'],
          $this->lang->line('cron_appointment_subject'),
          $this->lang->line('cron_appointment_msg'),
          $val,
          $this->lang->line('cron_appointment_regards')

        )
      );

      $this->email->from($this->config->item('admin_email'));
      $this->email->to($physician_info[$key]['email']);
      $this->email->subject($this->lang->line('cron_appointment_msglittle'));
      $this->email->message($msg);
      $this->email->send();
      $this->email->clear();

    }

    log_message('info', "run_notify_next_appointments ran succesfully");

  }

  /**
   * Returns html with formated appointment
   *
   * @private
   *
   * @param status int. the appointment's status
   * @param id int. the appointment's ID
   * @param timefrom int. the begin time of this appointment
   * @param timeto int. the end time of this appointment
   * @param patient string. the patient's name
   * @param patient_code string. the patient's code
   * @param speciality string. the speciality
   * @param notes string. the appoitment's notes
   * @param physician string. the physician name
   *
   * @return string (html)
   */
  function _run_notify_next_appointments_format ($status, $id, $timefrom, $timeto, $patient, $patient_code, $speciality, $notes, $physician) {

    $this->load->helper(array('date','url'));

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('table'));

    $now = gmt_to_local(now(), $this->config->item('timezone'));
    $today = mktime(0,0,0,date('n',$now),date('j',$now),date('Y',$now));
    $tomorrow = mktime(0,0,0,date('n',$now),date('j',$now)+1,date('Y',$now));

    $action_url = site_url().'/'.$this->module_url;

    $class_css = 'schedule_patient_today';

    if ($timefrom < $today) {
      $class_css = 'schedule_busy';
    }

    if ($timefrom >= $tomorrow) {
      $class_css = 'schedule_empty';
    }

    if ( ! $status) {
      $class_css = 'schedule_appointment_canceled';
    }

    if ($status == 4) {
      $class_css = 'schedule_free';
    }

    $data = '';
    $info = '';

    $info = sprintf(
      '<b>%s - %s</b>
      <div>%s: %s</div>
      <div>%s: %s</div>
      <div>%s: %s</div>
      <i>%s</i>',
      date('h:i a', $timefrom),
      date('h:i a', $timeto),
      $this->lang->line('patient_patient'),
      anchor('history/patient/'.$patient_code, $patient),
      $this->lang->line('diagnostic_speciality'),
      $speciality,
      $this->lang->line('diagnostic_physician'),
      $physician,
      $notes
    );

    $data =
    sprintf(
      '<div id="schedule"><table border=0 class="'.$class_css.'" width="100%%" ><tr>
      <td width="75px"><h3>%s<br/>%s</h3></td>
      <td >%s</td>
      </tr></table></div>',
      date('D j', $timefrom),
      date('M Y', $timefrom),
      $info
    );

    return $data;
  }


}
?>
