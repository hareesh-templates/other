<?php

/**
 * @file admin/admins.php
 * @brief File to manage admins. (list, add, edit and delete)
 * 
 * @class Admins
 * @brief Class to manage admins. (list, add, edit and delete)
 *
 * @details One admin is a user that can configure settings
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Admins extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/admins";

  /**
   * the title for this controller
   */ 
  var $module_name = "admins";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If admin has not permissions, redirect to access denied
   *
   * @public
   */
  function Admins() {
    parent::Controller();

    $this->access[1] = "add";
    $this->access[2] = "show";
    $this->access[3] = "del";
    $this->access[4] = "edit";
  }

  /**
   * returns the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "show";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   * @param only_superuser boolean When only super_user can access that function
   *
   * @return boolean
   */
  function _accesgranted ($function, $only_superuser=TRUE) {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function,$only_superuser)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * returns a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    $items[] = anchor($this->module_url.'/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    $items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));

    return navbarsubmenu($title, $items, 'admins.png');
  }


  /**
   *
   * returns a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";

    /*
    $submenu =
    anchor($this->module_url.'/add', $this->lang->line('admin_add')).'<br />'
    .anchor($this->module_url.'/editask', $this->lang->line('admin_edit')).'<br />'
    .anchor($this->module_url.'/delask', $this->lang->line('admin_del')).'<br />'
    .anchor($this->module_url.'/show', $this->lang->line('admin_list')).'';
    $submenu = block ($this->lang->line('admin_admins'), $submenu);
    */

    make_blocks(1);
    $leftmenu = $this->block_side1;

    return $leftmenu;
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $content = $this->_thissubmenu($this->lang->line('admin_admins')).'<br />';
    $content .= $this->lang->line('admin_defactions');

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');
    $data['content'] = theme($this->_leftmenu(), $msg.$content);

    $this->load->view($this->config->item('theme'), $data);

  }

  /**
   * sends to browser an add admin form, do the validation proccess and if it is successfull, then add the new admin
   *
   * @public
   *
   * @return nothing
   */
  function add() {

    if ($this->_accesgranted($this->access[1]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie', 'date'));

    $modules = get_admin_list();

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|strip_tags|required|alpha_numeric|callback__unique_code_check";
    $rules['Name']  = "trim|strip_tags|required|htmlentities|xss_clean";
    $rules['Email']  = "trim|strip_tags|required|valid_email|xss_clean";
    $rules['Password']  = "trim|required|xss_clean";
    $rules['Language']  = "trim|xss_clean";
    $rules['Theme']  = "trim|xss_clean";
    $rules['Notes']  = "trim|xss_clean";
    $rules['Super_User']  = "trim|xss_clean";
    foreach ($modules as $item) {
      $rules['Module-'.$item] = "trim|xss_clean";
    }
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Email'] = $this->lang->line('admin_email');
    $fields['Password'] = $this->lang->line('admin_password');
    $fields['Language'] = $this->lang->line('admin_lang');
    $fields['Theme'] = $this->lang->line('admin_theme');
    $fields['Super_User'] = $this->lang->line('admins_superuser');
    $fields['Notes'] = $this->lang->line('admin_notes');
    foreach ($modules as $item) {
      $fields['Module-'.$item] = 'Module-'.$item;
    }

    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_admins')).'<br />';
      $form .= $err . $this->_make_form('add', $this->module_url.'/add');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $rights = '';
      foreach ($modules as $item) {
        $varname = 'Module-'.$item;
        if ($this->validation->$varname != '') {
          $rights .= '+'.$item.'['.$this->validation->$varname.']';
        }
      }
      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      'password' => md5($this->validation->Password),
      'email' => $this->validation->Email,
      'createddate' => now(),
      'accessgranted' => $rights,
      'lastlogdate' => 0,
      'superuser' => $this->validation->Super_User,
      'lang' => $this->validation->Language,
      'theme' => $this->validation->Theme,
      'notes' => $this->validation->Notes
      );
      $this->db->insert('admins', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url);
      return;
    }
  }

  /**
   * creates and return a html form to add or edit an admin.
   *
   * @private
   *
   * @param $action enum. The type of form to create. Valid options are "add" or "edit"
   * @param $directo string. The form's action URL.
   *
   * @return string
   */
  function _make_form ($action, $directo) {
    //@action - allowed values: add / edit
    $form = "";


//erm formularios para introducir los permisos
//------------------------------------------------------------------------------------------------------
    $data = get_admin_list();
    $rights  = $this->table->set_heading($this->lang->line('main_module'),$this->lang->line('admins_grantedaccess'));
    $rights .= $this->table->add_row('', '<div>'.$this->lang->line('admins_accessnote').'</div>');
    foreach ($data as $item) {
      $varname = 'Module-'.$item;
      $data = array('name' => $varname, 'id' => $varname, 'value' => $this->validation->$varname, 'style' => 'width:95%');

      include_once(APPPATH.'controllers/admin/'.$item.'.php');
      $options = '';
      eval('$options = '.$item.'::_accessoptions();');
      $rights .= $this->table->add_row('<b>'.$item.'</b>', form_input($data).'<br />'.$this->lang->line('main_functions').': ' . $options);
    }
    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing="0" width="95%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $rights .= $this->table->generate();
    $this->table->clear();
//erm FIN formularios para introducir los permisos
//------------------------------------------------------------------------------------------------------


    $attributes = array('id' => 'formAdmin', 'name' => 'formAdmin');
    $form = form_open($directo, $attributes);

    if ($action == 'add') {
      $data = array('name' => 'Code', 'id' => 'Code', 'value' => $this->validation->Code, 'size' => '16');
      $this->table->add_row($this->lang->line('admin_code'), form_input($data).$this->lang->line('admin_required'));
    }
    if ($action == 'edit') {
      $data = "<b>".$this->validation->Code."</b>";
      $this->table->add_row($this->lang->line('admin_code'), $data.form_hidden('Code', $this->validation->Code));
    }

    if ($action == 'add') $passnote = $this->lang->line('admin_required');
    if ($action == 'edit') $passnote = $this->lang->line('admin_enternewpasstochange');

    $data = array('name' => 'Password', 'id' => 'Password', 'value' => $this->validation->Password, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_password'), form_input($data).$passnote);

    $data = array('name' => 'Name', 'id' => 'Name', 'value' => $this->validation->Name, 'size' => '26');
    $this->table->add_row($this->lang->line('admin_name'), form_input($data).$this->lang->line('admin_required'));

    $data = array('name' => 'Email', 'id' => 'Email', 'value' => $this->validation->Email, 'size' => '26');
    $this->table->add_row($this->lang->line('admin_email'), form_input($data).$this->lang->line('admin_required'));

    $key = 'Notes';
    $this->table->add_row($this->lang->line('admin_notes'), textArea($key, $this->validation->$key, 'mini'));

    $this->table->add_row($this->lang->line('admin_lang'), form_dropdown('Language', get_lang_list(), $this->validation->Language));
    $this->table->add_row($this->lang->line('admin_theme'), form_dropdown('Theme', get_theme_list(), $this->validation->Theme));

    $this->table->add_row($this->lang->line('admins_access'), $rights);


    $key = "Super_User";
    $radio = form_radio($key, '1', intval($this->validation->$key)) . $this->lang->line('main_yes')
    .form_radio($key, '0', !intval($this->validation->$key)) . $this->lang->line('main_no');
    $this->table->add_row($this->lang->line('admins_superuser'), $radio);

    $this->table->add_row('', msgWarning('',$this->lang->line('admins_sugetfullaccess')));

    if ($action == 'add') $this->table->add_row('', form_submit('submit', $this->lang->line('admins_add')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('admin_savechanges')));

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=2 cellspacing=2 style="width:100%">');
    $this->table->set_template($tmpl);

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }


  /**
   * looks for the admin code into DB. If it exists, return FALSE, else return TRUE
   *
   * @private
   *
   * @param str string. The admin code
   *
   * @return boolean
   */
  function _unique_code_check($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('admins');
    if ($query->num_rows() > 0) {
      $this->validation->set_message('_unique_code_check', $this->lang->line('admins_codeduplicated'));
      return FALSE;
    } else {
      return TRUE;
    }
  }

  /**
   * looks for the admin code into DB. If it exists, return TRUE, else return FALSE
   *
   * @private
   *
   * @param $str string The admin code
   *
   * @return boolean
   */
  function _code_exits($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('admins');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_code_exits', $this->lang->line('admins_codenofound'));
      return FALSE;
    }
  }


  /**
   * looks into DB for super_user admins. If at least one super_user exists return TRUE, else return FALSE
   *
   * @private
   *
   * @param $str string The admin code
   *
   * @return boolean
   */
  function _at_least_one_su($str) {

    $this->db->where(array("superuser"=>1, "code != "=>$str));
    $this->db->select("code");
    $query = $this->db->get('admins');

    if ($query->num_rows() > 0) {

      return TRUE;

    } else {

      $this->validation->set_message('_at_least_one_su', $this->lang->line('admins_atleastonesu'));
      return FALSE;
    }

    return FALSE;
  }


  /**
   * creates and return a html form asking the admin code for edit or delete actions.
   *
   * @private
   *
   * @param action string The action URL of the form. Valid options are "edit" and "del"
   *
   * @return string
   */
  function _askcode_form ($action) {
    // action - allowed values: del / edit
    $form = "";

    $attributes = array('id' => 'formAdmins', 'name' => 'formAdmins');

    if ($action == 'del') $form .= form_open($this->module_url.'/delask', $attributes);
    if ($action == 'edit') $form .= form_open($this->module_url.'/editask', $attributes);

    $data = array('name' => 'Code', 'id' => 'Code', 'value' => $this->validation->Code, 'size' => '16');
    $this->table->add_row($this->lang->line('admin_code'), form_input($data));

    if ($action == 'del') $this->table->add_row('', form_submit('submit', $this->lang->line('admins_del')));
    if ($action == 'edit') $this->table->add_row('', form_submit('submit', $this->lang->line('admins_edit')));

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }


  /**
   * sends to browser the list of admins.
   *
   * @public
   *
   * @return nothing
   */
  function show() {

    if ($this->_accesgranted($this->access[2], FALSE) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $itemxpage = 25;

    $this->lang->load('admin');
    $this->load->helper(array('url','form', 'date'));
    $this->load->library(array('pagination','table'));

//erm creacion de los links
//------------------------------------------------------------------------------
    $config['base_url'] = $this->config->site_url().'/'.$this->module_url."/show";
    $config['total_rows'] = $this->db->count_all('admins');
    $config['per_page'] = $itemxpage;
    $config['uri_segment'] = "4";
    $config['full_tag_open'] = "<div class='pagination'>";
    $config['full_tag_close'] = "</div>";
    //$config['num_links'] = "2";
    $this->pagination->initialize($config);
    $links = $this->pagination->create_links();

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------
    $begin = intval($this->uri->segment(4, 0));
    if ($begin < 0) $begin = 0;
    $lista = "";

    $this->db->join('sessions', 'sessions.session_id = admins.session_id', 'left');
    $this->db->orderby("name", "asc");
    $query = $this->db->get('admins', $itemxpage, $begin);

    $this->table->set_heading(
    '', '#', $this->lang->line('admin_code'),$this->lang->line('admin_name'), $this->lang->line('admin_email'), $this->lang->line('main_functions')
    );
    $i = $begin+1;
    foreach ($query->result() as $row) {
      $del = anchor($this->module_url.'/del/'.$row->code, $this->lang->line('admin_del'));
      $edit = anchor($this->module_url.'/edit/'.$row->code, $this->lang->line('admin_edit'));
      $su = $row->superuser ? ' ['.$this->lang->line('admins_superuser').'] ' : '';

      $online = '';
      if ($row->session_id != '') {
        $onlinetitle = unix_to_human(gmt_to_local($row->last_activity, $this->config->item('timezone')))
        .' [' . $row->ip_address . ']';
        $online = theme_imgtag('online.png', $onlinetitle, "ONLINE");
      }

      $this->table->add_row($online, $i, $row->code, $row->name, safe_mailto($row->email, $row->email), $edit.'-'.$del.$su);
      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing=0 width="100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $lista = $this->table->generate();


//erm enviar los resultados a la salida
//------------------------------------------------------------------------------
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');

    $center = $this->_thissubmenu($this->lang->line('admins_listof')).'<br />';
    $center .= $lista ."<br />". $links;
    $data['content'] = theme($this->_leftmenu(), $center);
    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * sends to browser a form asking the admin to be deleted
   *
   * @public
   *
   * @return nothing
   */
  function delask() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|alpha_numeric";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admins_del')).'<br />';
      $form .= $err . $this->_askcode_form ('del');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/del/'.$this->validation->Code);
      return;
    }

  }

  /**
   * sends to browser a form to confirm the admin deletion, if admin click yes, the admin is deleted
   *
   * @public
   *
   * @return nothing
   */
  function del() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask/');
      return;
    }

    $this->validation->Code = $code;
    $this->validation->set_error_delimiters('','<br />');

    $rules['Code']  = "trim|required|alpha_numeric|callback__at_least_one_su";
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form_code = form_hidden('Code', $code);
      $form =  $this->_thissubmenu($this->lang->line('admins_del')).'<br />'
      . $err
      . Ask_yesno_form (sprintf($this->lang->line('admins_askdel'), $code), $this->module_url.'/del/'.$code, $this->module_url.'/delask', $form_code);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      $this->db->delete('admins', array('code' => $code));
      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask');
      return;
    }
  }

  /**
   * sends to browser a form asking the admin to be edited
   *
   * @public
   *
   * @return nothing
   */
  function editask () {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|required|alpha_numeric|callback__code_exits";
    $this->validation->set_rules($rules);
    $fields['Code'] = $this->lang->line('admin_code');
    $this->validation->set_fields($fields);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admins_edit')).'<br />';
      $form .= $err . $this->_askcode_form ('edit');

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      redirect($this->module_url.'/edit/'.$this->validation->Code);
      return;
    }
  }


  /**
   * sends to browser a form to update the admin, do the validation proccess
   * and if it is successfull, update the new admin information
   *
   * @public
   *
   * @return nothing
   */
  function edit() {

    if ($this->_accesgranted($this->access[4]) == 0) return;
    //$this->output->cache($this->config->item('cachetime'));


//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie', 'date'));

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

//erm buscar si el codigo existe en la base de datos
//------------------------------------------------------------------------------
    $this->db->where('code', $code);
    $query = $this->db->get('admins');

    if ($query->num_rows() == 0) {

      $msg = base64_encode(msgWarning('',$this->lang->line('admins_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

    $modules = get_admin_list();

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Email'] = $this->lang->line('admin_email');
    $fields['Password'] = $this->lang->line('admin_password');
    $fields['Language'] = $this->lang->line('admin_lang');
    $fields['Theme'] = $this->lang->line('admin_theme');
    $fields['Super_User'] = $this->lang->line('admins_superuser');
    $fields['Notes'] = $this->lang->line('admin_notes');
    foreach ($modules as $item) {
      $fields['Module-'.$item] = 'Module-'.$item;
    }
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {
      $row = $query->row();
      $this->validation->Code = $code;
      $this->validation->Name = $row->name;
      $this->validation->Email = $row->email;
      $this->validation->Password = '';
      $this->validation->Language = $row->lang;
      $this->validation->Theme = $row->theme;
      $this->validation->Super_User = $row->superuser;
      $this->validation->Notes = $row->notes;

      foreach ($modules as $item) {
        $itemval[0] = '';
        $itemval[1] = '';
        $itemval[2] = '';
        eregi ('(\+'.$item.'[^[]*)\[([^]]*)', $row->accessgranted, $itemval);
        $varname = 'Module-'.$item;
        $this->validation->$varname = trim($itemval[2]);
      }
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|strip_tags|required|alpha_numeric|callback__at_least_one_su";
    $rules['Name']  = "trim|strip_tags|required|htmlentities|xss_clean";
    $rules['Email']  = "trim|strip_tags|required|valid_email|xss_clean";
    $rules['Password']  = "trim|xss_clean";
    $rules['Language']  = "trim|xss_clean";
    $rules['Theme']  = "trim|xss_clean";
    $rules['Notes']  = "trim|xss_clean";
    $rules['Super_User']  = "trim|xss_clean|callback__at_least_one_su";
    foreach ($modules as $item) {
      $rules['Module-'.$item] = "trim|xss_clean";
    }
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_admins')).'<br />';
      $form .= $err . $this->_make_form('edit', $this->module_url.'/edit/'.$code);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $rights = '';
      foreach ($modules as $item) {
        $varname = 'Module-'.$item;
        if ($this->validation->$varname != '') {
          $rights .= '+'.$item.'['.$this->validation->$varname.']';
        }
      }

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      'email' => $this->validation->Email,
      //'createddate' => now(), //erm do not modify createddate when editing
      'accessgranted' => $rights,
      //'lastlogdate' => 0, //erm do not modify lastlogdate when editing
      'superuser' => $this->validation->Super_User,
      'lang' => $this->validation->Language,
      'theme' => $this->validation->Theme,
      'notes' => $this->validation->Notes
      );
      if ($this->validation->Password != "") $data['password'] = md5($this->validation->Password);

      $this->db->where('code', $code);
      $this->db->update('admins', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/editask');
      return;
    }

  }
}
?>
