<?php

/**
 * @file admin/modules.php
 * @brief File to manage modules (list, add, edit and delete)
 * 
 * @class Modules
 * @brief Class to manage modules (list, add, edit and delete)
 *
 * @details A module is a piece of software (controller) that does do something. i.e. users, private messages, diagnostic, etc.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED_ADMIN - Controller
 */

class Modules extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "admin/modules";

  /**
   * the title for this controller
   */ 
  var $module_name = "modules";

  /**
   * the admin access level for this controller
   */ 
  var $access = array();


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If admin has not permissions, redirect to access denied
   *
   * @public
   */
  function Modules() {
    parent::Controller();

    $this->access[1] = "install";
    $this->access[2] = "show";
    $this->access[3] = "del";
    $this->access[4] = "edit";
  }


  /**
   * return the valid permissions for this controller
   *
   * @private
   *
   * @return string
   */
  function _accessoptions() {
    return "install show del edit";
  }


  /**
   * returns TRUE if admin has valid access to this controller;
   * redirect to "access denied" page if admin has not valid access;
   * and redirect to "admin login" if it is not a logged admin
   *
   * @private
   *
   * @param function string The name of the function to look for rights
   *
   * @return boolean
   */
  function _accesgranted ($function) {
    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    if (!admin_accesgranted($this->module_name,$function)) {
      redirect('admin/principal/accessdenied');
      return 0;
    }

    return 1;
  }


  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string. the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    /*
    $items[] = '<b>'.$this->lang->line('admin_actions').'</b>';
    $items[] = anchor($this->module_url.'/add', $this->lang->line('admin_add'));
    $items[] = anchor($this->module_url.'/editask', $this->lang->line('admin_edit'));
    $items[] = anchor($this->module_url.'/delask', $this->lang->line('admin_del'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('admin_list'));
    */

    return navbarsubmenu($title, '', 'modules.png');
  }


  /**
   *
   * Return a html with the left side blocks (theme left side)
   *
   * @private
   * 
   * @return string
   */
  function _leftmenu () {
    $leftmenu = "";
    make_blocks(array(1));
    $leftmenu = $this->block_side1;
    return $leftmenu;
  }


  /**
   * controller default method
   *
   * default method to load when this class is invoqued with not controller in the URI
   *
   * @public
   *
   * @return nothing
   */
  function index() {

    $this->lang->load('admin');
    $this->load->helper(array('url','cookie'));

    if (!is_admin()) {
      redirect('admin');
      return 0;
    }

    $this->show();

  }


  /**
   * sends to browser the list of modules.
   *
   * @public
   *
   * @return nothing
   */
  function show() {

    if ($this->_accesgranted($this->access[2]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->helper(array('url','form'));
    $this->load->library(array('pagination', 'table'));

//erm obtener la pagina desde la base de datos y mostrar
//------------------------------------------------------------------------------
    $lista = "";
    $this->db->orderby('code');
    $query = $this->db->get('modules');

    $this->table->set_heading(
    '#', $this->lang->line('admin_code'), $this->lang->line('admin_name'), $this->lang->line('main_enabled'),
    $this->lang->line('main_visible'), $this->lang->line('admin_lang'), $this->lang->line('modules_groups'),
    $this->lang->line('main_status'), $this->lang->line('main_functions')
    );

    $this->table->add_row('', '<b>'.$this->lang->line('modules_installed').'</b>');

    $moduleslist = get_modules_list();

    $i = 1;
    foreach ($query->result() as $row) {
      $del = anchor($this->module_url.'/del/'.$row->code, $this->lang->line('modules_uninstall'));
      $edit = anchor($this->module_url.'/edit/'.$row->code, $this->lang->line('admin_edit'));

      $enabled = $row->enabled == 1 ? $this->lang->line('main_yes') : '<b>'.$this->lang->line('main_no').'</b>';
      $visible = $row->visible == 1 ? $this->lang->line('main_yes') : '<b>'.$this->lang->line('main_no').'</b>';
      if ($row->lang == "") $row->lang = $this->lang->line('admin_all');

      $groups = str_replace('[]','',$row->groupaccess);
      $groups = str_replace('+',' ',$groups);
      if ($groups == '') $groups = '<b>'.$this->lang->line('usersgroups_none').'</b>';

      $status = '';
      if (isset($moduleslist[$row->code])) {
        unset($moduleslist[$row->code]);
        $status = $this->lang->line('main_ok');
        $img = theme_imgtag ('module_ok.png');
      } else {
        $status = $this->lang->line('modules_filemissing');
        $img = theme_imgtag ('module_error.png');
      }

      $this->table->add_row($i, $img .' '. $row->code, $row->name, $enabled, $visible, $row->lang, $groups, $status, $edit.'-'.$del);
      $i++;
    }

    $this->table->add_row('', '<b>'.$this->lang->line('modules_uninstalled').'</b>');

    $img = theme_imgtag ('module_install.png');
    foreach ($moduleslist as $item) {
      $install = anchor($this->module_url.'/install/'.$item, $this->lang->line('modules_install'));
      $status = $this->lang->line('modules_noinstalled');
      $this->table->add_row($i, $img .' '. $item, '', '', '', '', '', $status, $install);
      $i++;
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing=0 width="100%">',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',

    );
    $this->table->set_template($tmpl);
    $lista = $this->table->generate();


//erm enviar los resultados a la salida
//------------------------------------------------------------------------------
    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('admin_title');

    $center = $this->_thissubmenu($this->lang->line('modules_listof'));
    $center .= $lista;
    $data['content'] = theme($this->_leftmenu(), $msg.$center);
    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * sends to browser an install module form, do the validation proccess and if it is successfull, then install the new module
   *
   * this method expects a valid module code into URI segment 4
   *
   * @public
   *
   * @return nothing
   */
  function install () {
    if ($this->_accesgranted($this->access[1]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form','cookie'));


//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;
    }

    $customgroups = get_usersgroups_list();


    $this->validation->set_error_delimiters('','<br />');
    $rules['Code']  = "trim|strip_tags|required|xss_clean|callback__unique_code_check";
    $rules['Name']  = "trim|strip_tags|xss_clean";
    $rules['Language']  = "trim|xss_clean";
    $rules['Enabled']  = "trim|required|xss_clean";
    $rules['Visible']  = "trim|required|xss_clean";

    $rules['Group-admin'] = "trim|alpha_dash|xss_clean";
    $rules['Group-user'] = "trim|alpha_dash|xss_clean";
    $rules['Group-guest'] = "trim|alpha_dash|xss_clean";
    $rules['Group-all'] = "trim|alpha_dash|xss_clean";
    foreach ($customgroups as $key => $value) {
      $rules['Group-'.$key] = "trim|alpha_dash|xss_clean";
    }
    $this->validation->set_rules($rules);

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Language'] = $this->lang->line('admin_lang');
    $fields['Enabled'] = $this->lang->line('main_enabled');
    $fields['Visible'] = $this->lang->line('main_visible');

    $this->validation->set_fields($fields);

    if ($this->input->post('Code') === FALSE) {
      $this->validation->Code = $code;
      $this->validation->Enabled = 1;
      $this->validation->Visible = 1;
      $varname = 'Group-all';
      $this->validation->$varname = 1;
    }

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_modules')).'<br />';
      $form .= $err . $this->_make_form('install', $this->module_url.'/install/'.$code, $customgroups);

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $msg.$form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $groups = '';
      $var = 'Group-admin';
      if (isset($this->validation->$var)) $groups .= '+admin[]';
      $var = 'Group-user';
      if (isset($this->validation->$var)) $groups .= '+user[]';
      $var = 'Group-guest';
      if (isset($this->validation->$var)) $groups .= '+guest[]';
      $var = 'Group-all';
      if (isset($this->validation->$var)) $groups .= '+all[]';
      foreach ($customgroups as $key => $value) {
        $varname = 'Group-'.$key;
        if (isset($this->validation->$varname)) $groups .= '+'.$key.'[]';
      }

      $data = array(
      'code' => $code,
      'name' => $this->validation->Name,
      'enabled' => $this->validation->Enabled,
      'visible' => $this->validation->Visible,
      'lang' => $this->validation->Language,
      'groupaccess' => $groups,
      );
      $this->db->insert('modules', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;
    }
  }


  /**
   * creates and return a html form to add or edit a module
   *
   * @private
   *
   * @param action enum. The type of form to create. Valid options are "add" or "edit"
   * @param directo string. The form's action URL.
   * @param customgroups array. Custom groups taken from "Groups" option into Administration Panel.  System groups are: Group-admin, Group-user, Group-guest, Group-guest, Group-all
   *
   * @return string
   */
  function _make_form ($action, $directo, $customgroups) {
    //@action - allowed values: add / edit

//erm formularios para introducir los permisos de los grupos
//------------------------------------------------------------------------------------------------------
    $groupsform = '';
    $groupsform = $this->table->set_heading($this->lang->line('modules_whocansee'),$this->lang->line('admin_notes'));

    $this->table->add_row('<b>'.$this->lang->line('usersgroups_system').'</b>','');
    $varname = 'Group-admin';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_admin'), $this->lang->line('usersgroups_adminnote'));

    $varname = 'Group-user';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_user'), $this->lang->line('usersgroups_usernote'));

    $varname = 'Group-guest';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_guest'), $this->lang->line('usersgroups_guestnote'));

    $varname = 'Group-all';
    $select = isset($this->validation->$varname) ? 1: 0;
    $this->table->add_row(form_checkbox($varname, '1', $select).$this->lang->line('usersgroups_all'), $this->lang->line('usersgroups_allnote'));

    $this->table->add_row('<b>'.$this->lang->line('usersgroups_custom').'</b>','');

    foreach ($customgroups as $key => $value) {
      $var = 'Group-'.$key;
      $this->table->add_row(form_checkbox($var, '1', (isset($this->validation->$var) ? 1: 0)).$key, $value);
    }

    $tmpl = array (
    'table_open'  => '<table class="table_1" cellspacing=0 width=95%>',
    'row_start'           => '<tr class="table_1_td1">',
    'row_alt_start'       => '<tr class="table_1_td2">',
    );
    $this->table->set_template($tmpl);
    $groupsform .= $this->table->generate();
    $this->table->clear();

//erm FIN formularios para introducir los permisos de los grupos
//------------------------------------------------------------------------------------------------------

    $form =  '';

    $key = 'formModule';
    $attributes = array('id' => $key, 'name' => $key);
    $form = form_open($directo, $attributes);

    $data = "<b>".$this->validation->Code."</b>";
    $this->table->add_row($this->lang->line('admin_code'), $data.form_hidden('Code', $this->validation->Code));

    $key = 'Name';
    $data = array('name' => $key, 'id' => $key, 'value' => $this->validation->$key, 'size' => '16');
    $this->table->add_row($this->lang->line('main_title'), form_input($data));

    $key = 'Enabled';
    $radio = form_radio($key, '1', intval($this->validation->$key)) . $this->lang->line('main_yes')
    .form_radio($key, '0', !intval($this->validation->$key)) . $this->lang->line('main_no');
    $this->table->add_row($this->lang->line('main_enabled'), $radio);

    $key = 'Visible';
    $radio = form_radio($key, '1', intval($this->validation->$key)) . $this->lang->line('main_yes')
    .form_radio($key, '0', !intval($this->validation->$key)) . $this->lang->line('main_no');
    $this->table->add_row($this->lang->line('main_visible'), $radio);

    $note = $this->lang->line('modules_langnote');
    $key = 'Language';
    $this->table->add_row($this->lang->line('admin_lang'), form_dropdown($key, get_lang_list(), $this->validation->Language).' '.$note);

    $this->table->add_row($this->lang->line('modules_groups'), $groupsform);

    if ($action == 'install') $this->table->add_row('', '<br />'.form_submit('submit', $this->lang->line('modules_install')));
    if ($action == 'edit') $this->table->add_row('', '<br />'.form_submit('submit', $this->lang->line('admin_savechanges')));

    $tmpl = array ('table_open'  => '<table border=0 cellpadding=2 cellspacing=2 style="width:100%">');
    $this->table->set_template($tmpl);

    $form .= $this->table->generate();
    $form .= form_close();

    return $form;
  }


  /**
   * looks for the module code into DB. If it exists, return FALSE, else return TRUE
   *
   * @private
   *
   * @param str string. The module code
   *
   * @return boolean
   */
  function _unique_code_check($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('modules');
    if ($query->num_rows() > 0) {
      $this->validation->set_message('_unique_code_check', $this->lang->line('modules_codeduplicated'));
      return FALSE;
    } else {
      return TRUE;
    }
  }


  /**
   * sends to browser a form to confirm the module uninstall, if admin click yes, the module is uninstalled
   *
   * this method expects a valid module code into URI segment 4
   *
   * @public
   *
   * @return nothing
   */
  function del() {

    if ($this->_accesgranted($this->access[3]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'/delask/');
      return;
    }

    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('modules_del')).'<br />'
      . $err
      . Ask_yesno_form (sprintf($this->lang->line('modules_askdel'), $code), $this->module_url.'/del/'.$code, $this->module_url.'');

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {
      $this->db->delete('modules', array('code' => $code));
      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;
    }
  }


  /**
   * sends to browser a form to update the module, do the validation proccess
   * and if it is successfull, update the new module information
   *
   * @public
   *
   * @return nothing
   */
  function edit() {

    if ($this->_accesgranted($this->access[4]) == 0) return;

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('admin');
    $this->load->library(array('validation','table'));
    $this->load->helper(array('url','form', 'cookie'));

//erm sino esta el parametro redirigir hacia editask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(4, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;
    }

//erm buscar si el codigo existe en la base de datos
//------------------------------------------------------------------------------
    $this->db->where('code', $code);
    $query = $this->db->get('modules');

    if ($query->num_rows() == 0) {

      $msg = base64_encode(msgWarning('',$this->lang->line('modules_codenofound')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;
    }

    $customgroups = get_usersgroups_list();

    $fields['Code'] = $this->lang->line('admin_code');
    $fields['Name'] = $this->lang->line('admin_name');
    $fields['Language'] = $this->lang->line('admin_lang');
    $fields['Enabled'] = $this->lang->line('main_enabled');
    $fields['Visible'] = $this->lang->line('main_visible');
    $this->validation->set_fields($fields);

//erm si es la primera vez que se muestra el form, tomar datos desde la DB
//------------------------------------------------------------------------------
    if ($this->input->post('Code') === FALSE) {
      $row = $query->row();
      $this->validation->Code = $code;
      $this->validation->Name = $row->name;
      $this->validation->Language = $row->lang;
      $this->validation->Enabled = $row->enabled;
      $this->validation->Visible = $row->visible;

      $tmparray = array('admin','user','guest','all');
      foreach ($tmparray as $key) {
        if (strpos($row->groupaccess, '+'.$key.'[]') !== FALSE) {
          $varname = 'Group-'.$key;
          $this->validation->$varname = 1;
        }
      }

      foreach ($customgroups as $key => $value) {
        if (strpos($row->groupaccess, '+'.$key.'[]') !== FALSE) {
          $varname = 'Group-'.$key;
          $this->validation->$varname = 1;
        }
      }

    }

    $this->validation->set_error_delimiters('','<br />');

    $rules['Code']  = "trim|strip_tags|required|xss_clean";
    $rules['Name']  = "trim|strip_tags|xss_clean";
    $rules['Language']  = "trim|xss_clean";
    $rules['Enabled']  = "trim|required|xss_clean";
    $rules['Visible']  = "trim|required|xss_clean";

    $rules['Group-admin'] = "trim|alpha_dash|xss_clean";
    $rules['Group-user'] = "trim|alpha_dash|xss_clean";
    $rules['Group-guest'] = "trim|alpha_dash|xss_clean";
    $rules['Group-all'] = "trim|alpha_dash|xss_clean";
    foreach ($customgroups as $key => $value) {
      $rules['Group-'.$key] = "trim|alpha_dash|xss_clean";
    }
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('admin_modules')).'<br />';
      $form .= $err . $this->_make_form('edit', $this->module_url.'/edit/'.$code, $customgroups);

      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('admin_title');
      $data['content'] = theme($this->_leftmenu(), $form);

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $groups = '';

      $var = 'Group-admin';
      if (isset($this->validation->$var)) $groups .= '+admin[]';
      $var = 'Group-user';
      if (isset($this->validation->$var)) $groups .= '+user[]';
      $var = 'Group-guest';
      if (isset($this->validation->$var)) $groups .= '+guest[]';
      $var = 'Group-all';
      if (isset($this->validation->$var)) $groups .= '+all[]';

      foreach ($customgroups as $key => $value) {
        $varname = 'Group-'.$key;
        if (isset($this->validation->$varname)) $groups .= '+'.$key.'[]';
      }

      $data = array(
      'code' => $this->validation->Code,
      'name' => $this->validation->Name,
      'lang' => $this->validation->Language,
      'enabled' => $this->validation->Enabled,
      'visible' => $this->validation->Visible,
      'groupaccess' => $groups,
      );
      $this->db->where('code', $code);
      $this->db->update('modules', $data);

      $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));
      set_cookie('msg', $msg, 0);
      redirect($this->module_url.'');
      return;
    }

  }
}

?>
