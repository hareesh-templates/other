<?php

/**
 * @file appointment.php
 * @brief File to manage appointments
 * 
 * @class Appointment
 * @brief Class to manage appointments
 *
 * @details appointments are requested by patients
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Controller
 */

class Appointment extends Controller {

  /**
   * the URI segment name to access this controller
   */ 
  var $module_url = "appointment";

  /**
   * the title for this controller
   */ 
  var $module_name = "Appointment";

  /**
   * the database table related to this controller
   */ 
  var $dbtablename = "med_appointment";


  /**
   * Constructor
   *
   * Load the libraries and helper required globally by this class
   * If user has not permissions, redirect to access denied
   *
   * @public
   */
  function Appointment () {
    parent::Controller();

    if (!is_module(str_replace('.php', '', pathinfo(__FILE__, PATHINFO_BASENAME)))) {
      $this->load->helper('url');
      redirect('principal/accessdenied');
      return;
    }
  }

  /**
   * Actions Submenu for this controller
   *
   * Return a html submenu navigation bar with options for this controller
   *
   * @private
   * 
   * @param title string the title to show in the submenu navbar
   *
   * @return string
   */
  function _thissubmenu($title) {

    $this->load->helper(array('url'));

    $items[] = anchor($this->module_url.'/add_bydoc', $this->lang->line('appointment_add_bymed'));
    $items[] = anchor($this->module_url.'/add_byspe', $this->lang->line('appointment_add_byspe'));
    $items[] = anchor($this->module_url.'/show', $this->lang->line('schedule_gotoday'));

    $this->db->where('status', -1);
    $query = $this->db->get('med_appointment');
    $rows = $query->num_rows();

    $items[] = anchor($this->module_url.'/online', sprintf('%d %s', $rows, $this->lang->line('appointment_online')));

    return navbarsubmenu($title, $items, 'appointment.png');
  }

  /**
   * controller default method
   *
   * this default method loads 'show' method
   *
   * @public
   *
   * @return nothing
   */
  function index() {
    $this->show();
  }


  /**
   * callback form validator
   *
   * returns TRUE if the patient code does NOT exists, otherwise FALSE
   * this method is loaded by the form validator proccess
   *
   * @private
   * 
   * @param str string the code to validate
   *
   * @return boolean
   */
  function _patient_unique_code_check($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select('code');
    $query = $this->db->get('med_patient');
    if ($query->num_rows() > 0) {
      $this->validation->set_message('_patient_unique_code_check', $this->lang->line('patient_codeduplicated'));
      return FALSE;
    } else {
      return TRUE;
    }
  }

  /**
   * add new patiends
   *
   * quick method to add a new patient asking the minimun information (code and name)
   * is patiend was sucessful added send to browser 'done', else show the form with
   * error validations.
   *
   * This method is intented to be used with ajax
   *
   * @public
   *
   * @return string
   */
  function add_patient() {

    $this->lang->load('admin');
    $this->lang->load('med_common');

    $this->load->helper(array('form', 'date'));
    $this->load->library(array('validation', 'table'));

    $this->validation->set_error_delimiters('','<br />');
    $rules['add_patient_code']  = "trim|strip_tags|required|xss_clean|callback__patient_unique_code_check";
    $rules['add_patient_name']  = "trim|strip_tags|required|xss_clean";
    $this->validation->set_rules($rules);

    $fields['add_patient_code'] = $this->lang->line('admin_code');
    $fields['add_patient_name'] = $this->lang->line('admin_name');
    $this->validation->set_fields($fields);

    $name = $this->input->xss_clean($this->uri->segment(3, ''));
    $code = $this->input->xss_clean($this->uri->segment(4, ''));

    if ($name != '')  $_POST['add_patient_name'] = $name;
    if ($code != '')  $_POST['add_patient_code'] = $code;

    if ($name != '' && $code == '') {
      $tmp = explode(' ', $name);
      $code = '';
      if (isset($tmp[0])) $code .= substr($tmp[0], 0, 3);
      if (isset($tmp[1])) $code .= substr($tmp[1], 0, 2);
      $this->db->select('MAX(id)+1 as code');
      $result = $this->db->get('med_patient');
      if ($result->num_rows() > 0) {
        $row = $result->row();
        $code .= $row->code;
      }
      $code = strtolower($code);
      $code = eregi_replace('[^a-z, 0-9]','', $code);
    }

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = "";

      $form .= $err;

      $key = 'add_patient_name';
      $data = array('name' => $key, 'id' => $key, 'value' => $name, 'size' => '26');
      $this->table->add_row($this->lang->line('admin_name'), form_input($data));

      $key = 'add_patient_code';
      $data = array('name' => $key, 'id' => $key, 'value' => $code, 'size' => '16');
      $this->table->add_row($this->lang->line('admin_code'), form_input($data));

      $form .= $this->table->generate();

      $form .=  '<br /><table id="add_patient_send" class="submit"><tr><td>'.$this->lang->line('patient_add').'</td></tr></table>';

      echo $form;

    } else {

      $data = array(
      'code' => $this->validation->add_patient_code,
      'name' => $this->validation->add_patient_name,
      'email' => '',
      'createddate' => now(),
      'status' => 1,
      'notes' => '',
      );
      $this->db->insert('med_patient', $data);

      echo "done";
    }
  }

  /**
   * load _add method with TRUE param
   *
   * @public
   *
   * @return nothing
   */
  function add_bydoc () {
    $this->_add(true);
  }

  /**
   * load _add method with FALSE param
   *
   * @public
   *
   * @return nothing
   */
  function add_byspe () {
    $this->_add(false);
  }

  /**
   * frontend themed view to include new appointments
   * 
   * send to browser a themed view with ajax capabilities and add appoinments into DB
   *
   * @private
   * 
   * @param bydoctor boolean Set to true to include appoin_bydoc.js file (ajax). Set to false to include appoin_byspe.js file (ajax)
   *
   * @return nothing
   */
  function _add($bydoctor = true) {

    $this->lang->load('admin');
    $this->lang->load('med_common');

    $this->load->helper(array('cookie', 'date'));

    //erm main vars to initialice make_form
    if ($bydoctor) {
      $vars = array('action'=>'add','directo'=>$this->module_url.'/add_bydoc');
    } else {
      $vars = array('action'=>'add','directo'=>$this->module_url.'/add_byspe');
    }

    $vars['physicians'] = array('-'=>'--- '.$this->lang->line('main_pleaseselect').' ---');
    $vars['specialities'] = array('-'=>'--- '.$this->lang->line('main_pleaseselect').' ---');

    $validation = FALSE;
    $form = $this->_form_main ($vars, $validation, $bydoctor);

    if ($validation == FALSE) {

      $content = $this->_thissubmenu($this->lang->line('appointment_add')).'<br />'.$form;

      $msg = base64_decode(get_cookie('msg', TRUE));
      set_cookie('msg', '', 0);

      make_blocks();
      $data = default_Vars_Content();
      $data['meta'] .= '
      <meta http-equiv="expires" content="-1" >
      <meta http-equiv="pragma" content="no-cache" >
      ';
      $data['title'] .= ' - ' . $this->lang->line('appointment_title');
      $data['content'] = theme($this->block_side1, $msg.$content);

      if ($bydoctor) {

        $data['java'] .= sprintf(
          '<script type="text/javascript" src="%sinclude/appoin_bydoc.js"></script>',
          base_url()
        );

      } else {

        $data['java'] .= sprintf(
          '<script type="text/javascript" src="%sinclude/appoin_byspe.js"></script>',
          base_url()
        );

      }

      $this->load->view($this->config->item('theme'), $data);

    } else {

      $tmp = split('-', $this->validation->Form_Hour);

      $tmp[0] = $this->validation->Form_Day . ' ' . trim($tmp[0]);
      $tmp[1] = $this->validation->Form_Day . ' ' . trim($tmp[1]);

      $date1 = strtotime($tmp[0]);
      $date2 = strtotime($tmp[1]);

      if ($this->_check_date_isfree ($date1, $date2, $this->validation->Physician)) {

        $data = array(
        'physician_code' => $this->validation->Physician,
        'speciality_code' => $this->validation->Speciality,
        'patient_code' => $this->validation->Patient,
        'time_from' => $date1,
        'time_to' => $date2,
        'datecreated' => now(),
        'notes' => $this->validation->Notes,
        );
        $this->db->insert($this->dbtablename, $data);

        $msg = base64_encode(msgSuccess('', $this->lang->line('admin_taskok')));

      } else {

        $msg = base64_encode(msgErr('', $this->lang->line('appointment_timenoavailable')));

      }
      set_cookie('msg', $msg, 0);
      $this->load->helper(array('url'));

      if ($bydoctor) {
        $redirect = $this->module_url.'/add_bydoc';
      } else {
        $redirect = $this->module_url.'/add_byspe';
      }

      redirect($redirect);
      return;

    }
  }

  /**
   * callback form validator
   *
   * returns TRUE if the physician exists and is enabled, otherwise FALSE
   * this method is loaded by the form validator proccess
   *
   * @private
   * 
   * @param str string the code to validate
   *
   * @return boolean
   */
  function _check_physician($str) {
    $this->db->where(array('code'=>$str));
    $this->db->where(array('status'=>1, 'is_physician'=>1));
    $this->db->select("code");
    $query = $this->db->get('users');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_physician', $this->lang->line('physician_codenofound'));
      return FALSE;
    }
  }

  /**
   * callback form validator
   *
   * returns TRUE if the patient exists and is enabled, otherwise FALSE
   * this method is loaded by the form validator proccess
   *
   * @private
   * 
   * @param str string the code to validate
   *
   * @return boolean
   */
  function _check_patient($str) {
    $this->db->where(array('code'=>$str));
    $this->db->where('status', 1);
    $this->db->select("code");
    $query = $this->db->get('med_patient');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_patient', $this->lang->line('patient_codenofound'));
      return FALSE;
    }
  }

  /**
   * callback form validator
   *
   * returns TRUE if physician is available on the timeframe choosen, otherwise FALSE
   * this method is loaded by the form validator proccess
   *
   * @private
   * 
   * @param date1 int unixtimestamp date/time from
   * @param date2 int unixtimestamp date/time to
   * @param physician string the code to validate
   *
   * @return boolean
   */
  function _check_date_isfree ($date1, $date2, $physician) {

    $where = sprintf(
    '((time_from>=%d && time_from<=%d) || (time_from>=%d && time_from<=%d))',
    $date1,
    $date2,
    $date1,
    $date2
    );

    $this->db->from(array('med_appointment'));
    $this->db->where('status != ', 0);
    $this->db->where('physician_code', $physician);
    $this->db->where($where);
    $this->db->limit(1);
    $query = $this->db->get();

    if ($query->num_rows() > 0) {
      return 0;
    }

    return 1;
  }

  /**
   * callback form validator
   *
   * returns TRUE if the spaciality exists, otherwise FALSE
   * this method is loaded by the form validator proccess
   *
   * @private
   * 
   * @param str string the code to validate
   *
   * @return boolean
   */
  function _check_speciality($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('med_specialities');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_speciality', $this->lang->line('specialities_codenofound'));
      return FALSE;
    }
  }

  /**
   * callback form validator
   *
   * returns TRUE if the date entered has valid format [yyyy/mm/dd], otherwise FALSE
   * this method is loaded by the form validator proccess
   *
   * @private
   * 
   * @param str string the date to validate
   *
   * @return boolean
   */
  function _check_valid_day($str) {
    $date = 1;
    $validdate = "[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}";
    if (eregi($validdate, $str) === FALSE) {
      $date = 0;
    }

    if ($date) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_valid_day', $this->lang->line('schedule_invalid_day'));
      return FALSE;
    }
  }

  /**
   * callback form validator
   *
   * returns TRUE if the time entered has valid format [hh:mm:ss(a|p)m] and is a valid time, otherwise FALSE
   * this method is loaded by the form validator proccess
   *
   * @private
   * 
   * @param str string the date to validate
   *
   * @return boolean
   */
  function _check_valid_time($str) {

    $date1 = true;
    $date2 = true;

    $tmp = split('-', $str);

    if (is_array($tmp)) {
      $validtime = "[0-9][0-9]:[0-9][0-9](a|p)m";

      if (eregi($validtime, $tmp[0]) === FALSE) {
        $date1 = 0;
      } else {
        $tmp[0] = "1926-04-06 " . trim($tmp[0]);
        if (strtotime($tmp[0]) === FALSE) $date1 = 0;
      }

      if (eregi($validtime, $tmp[1]) === FALSE) {
        $date2 = 0;
      } else {
        $tmp[1] = "1926-04-06 " . trim($tmp[1]);
        if (strtotime($tmp[1]) === FALSE) $date2 = 0;
      }
    } else {
      $date1 = false;
      $date2 = false;
    }

    if ($date1 && $date2) {
      return TRUE;
    } else {
      $this->validation->set_message('_check_valid_time', $this->lang->line('schedule_invalid_time'));
      return FALSE;
    }
  }

  /**
   * creates the main form to add appointments
   *
   * returns a html form
   *
   * @private
   * @param vars array array with values to populate de form. $vars must include the 'action' variable with 'add' either 'edit' values
   * @param validation boolean this variable will be set to true is form validation success, otherwise false
   * @param bydoctor boolean set to true to show physician control first, set to false to show specialities control first
   *
   * @return string
   */
  function _form_main ($vars, &$validation, $bydoctor) {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('form', 'url'));
    $this->load->library(array('validation', 'table'));

    $speciality_tag = 'Speciality';
    $physician_tag = 'Physician';
    $calendar_tag = 'Form_Day';
    $time_tag = 'Form_Hour';
    $patient_tag = 'Patient';


    $this->validation->set_error_delimiters('','<br />');
    $rules[$speciality_tag]  = "trim|required|xss_clean|callback__check_speciality";
    $rules[$physician_tag]  = "trim|required|xss_clean|callback__check_physician";
    $rules[$calendar_tag]  = "trim|required|xss_clean|callback__check_valid_day";
    $rules[$time_tag]  = "trim|required|xss_clean|callback__check_valid_time";
    $rules[$patient_tag]  = "trim|required|xss_clean|callback__check_patient";
    $rules['Notes']  = "trim|xss_clean";

    $this->validation->set_rules($rules);

    $fields[$speciality_tag] = $this->lang->line('specialities_name');
    $fields[$physician_tag] = $this->lang->line('physician_physician');
    $fields[$calendar_tag] = $this->lang->line('schedule_day');
    $fields[$time_tag] = $this->lang->line('schedule_time');
    $fields[$patient_tag] = $this->lang->line('patient_patient');
    $fields['Notes'] = $this->lang->line('admin_notes');
    $this->validation->set_fields($fields);

    $form = "";
    $validation = $this->validation->run();

    if ($validation == FALSE) {

      if ($vars['action'] == 'edit') {
        $this->validation->Code = $vars['Code'];
        $this->validation->Physician = $vars['Physician'];
        $this->validation->Speciality = $vars['Speciality'];
      }

      if ($this->validation->error_string != "") $form .= msgErr("",$this->validation->error_string);

      if ($vars['action'] == 'edit') {
        $data = "<b>".$this->validation->Code."</b>";
        $this->table->add_row($this->lang->line('admin_code'), $data.form_hidden('Code', $this->validation->Code));
      }

//erm crear el formulario
//------------------------------------------------------------------------------------------
      $form_tag = 'form_Appoinment';
      $attributes = array('id' => $form_tag, 'name' => $form_tag);

      $form .= form_open($vars['directo'], $attributes);

//erm si se esta creado, crear y cargar el formulario con javascript y ajax
//------------------------------------------------------------------------------------------

      if ($bydoctor) {
        $control1 = '
            <td>'.$this->lang->line('physician_physician').'</td>
            <td id="ajax_physician" width="30px">&nbsp;</td>
            <td>
              <select id="'.$physician_tag.'" name="'.$physician_tag.'" >
              <option value="">Enable Javascript</option>
              </select>
            </td>
        ';
        $control2 = '
            <td width="30px">'.$this->lang->line('specialities_name').'</td>
            <td id="ajax_speciality" width="30px">&nbsp;</td>
            <td>
              <select  id="'.$speciality_tag.'" name="'.$speciality_tag.'" >
              <option value="">-- '.$this->lang->line('main_none').' --</option>
              </select>
            </td>
        ';
      } else {

        $control1 = '
            <td width="30px">'.$this->lang->line('specialities_name').'</td>
            <td id="ajax_speciality" width="30px">&nbsp;</td>
            <td>
              <select  id="'.$speciality_tag.'" name="'.$speciality_tag.'" >
              <option value="">Enable Javascript</option>
              </select>
            </td>
        ';
        $control2 = '
            <td>'.$this->lang->line('physician_physician').'</td>
            <td id="ajax_physician" width="30px">&nbsp;</td>
            <td>
              <select id="'.$physician_tag.'" name="'.$physician_tag.'" >
              <option value="">-- '.$this->lang->line('main_none').' --</option>
              </select>
            </td>
        ';

      }

      $controls = '
      <table border="0" cellpadding="4" >
        <tr>

        '.$control1.'

          <td valign="top" rowspan="4">
            <div id="calendar"  style="padding: 10px 10px 10px 10px ;">
            </div>
          </td>

          <td valign="top" rowspan="4">
            <div id="time">
            </div>
          </td>

        </tr>
        <tr>

        '.$control2.'

        </tr>
        <tr>
          <td>'.$this->lang->line('schedule_day').'</td>
          <td id="ajax_calendar" width="30px">&nbsp;</td>
          <td>
            <input id="'.$calendar_tag.'" name="'.$calendar_tag.'" readonly value="--" />
          </td>
        </tr>
        <tr>
          <td >'.$this->lang->line('schedule_time').'</td>
          <td id="ajax_time" width="30px">&nbsp;</td>
          <td>
            <input id="'.$time_tag.'" name="'.$time_tag.'" readonly value="--" />
          </td>
        </tr>

        <tr>
          <td colspan="5" style="height: 100%;">
          <hr>
          </td>
        </tr>

        <tr>

          <td  width="30px">'.$this->lang->line('patient_patient').'</td>
          <td id="ajax_patient" width="30px">&nbsp;</td>
          <td colspan="3">
            <div>
            '.theme_imgtag ('refresh.png', $this->lang->line('admin_refresh'), $this->lang->line('admin_refresh'), 'id="patient_refresh" style="cursor: pointer; "' . " ").'
            '.theme_imgtag ('add.png', $this->lang->line('patient_add'), $this->lang->line('patient_add'), 'id="patient_add" style="cursor: pointer; "' ." ").'
            '.anchor_popup(base_url().'doc/search_tips.html', $this->lang->line('search_tips'), '').'
            </div>
            <input size="30" id="'.$patient_tag.'" value="" title="'.$this->lang->line('appointment_searchpatienttip').'" /> &raquo;&raquo;
            <input size="10" readonly type="text" id="patient_selected" name="'.$patient_tag.'" value="--"  />
            <div id="patient_results" class="msg_1" style="min-height: 50px;" >'.$this->lang->line('appointment_enter3chars').'</div>
          </td>
        </tr>

        <tr>
          <td colspan="5" style="height: 100%;">
          <hr>
          </td>
        </tr>

        <tr>
          <td  width="30px">'.$this->lang->line('admin_notes').'</td>
          <td id="ajax_patient" width="30px">&nbsp;</td>
          <td colspan="3">

        ';

        $key = 'Notes';
        $controls .= textArea($key, $this->validation->$key, 'mini', '75px', '100%');

        $controls .= '
        </tr>

        <tr>
          <td colspan="5">
          <div>
          <input id="sumbmit_appoinment" type="submit" value="'.$this->lang->line('appointment_add').'">
          </div>
          </td>
        </tr>

      </table>
      ';

      $form .= $controls;
      $form .= form_close();

    }

    return $form;
  }


  /**
   * callback form validator
   *
   * returns TRUE if the speciality does NOT exists, otherwise FALSE
   * this method is loaded by the form validator proccess
   *
   * @private
   * 
   * @param str string the code to validate
   *
   * @return boolean
   */
  function _unique_code_check($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('med_specialities');
    if ($query->num_rows() > 0) {
      $this->validation->set_message('_unique_code_check', $this->lang->line('specialities_codeduplicated'));
      return FALSE;
    } else {
      return TRUE;
    }
  }

  /**
   * callback form validator
   *
   * returns TRUE if the speciality exists, otherwise FALSE
   * this method is loaded by the form validator proccess
   *
   * @private
   * 
   * @param str string the code to validate
   *
   * @return boolean
   */
  function _code_exits($str) {
    $this->db->where(array('code'=>$str));
    $this->db->select("code");
    $query = $this->db->get('med_specialities');
    if ($query->num_rows() > 0) {
      return TRUE;
    } else {
      $this->validation->set_message('_code_exits', $this->lang->line('specialities_codenofound'));
      return FALSE;
    }
  }


  /**
   * return a html calendar
   *
   * creates a calendar for year and month with available schedule for consultations
   * if $physician is specified, calendar will show only that physician schedules
   *
   * @private
   * 
   * @param year int ther year of the calendar
   * @param month int ther month of the calendar
   * @param physician string the code of the physician or empty to show all
   *
   * @return string
   */
  function _schedule_calendar ($year=0, $month=0, $physician='') {

    $this->load->helper(array('date', 'url'));
    $time = gmt_to_local(now(), $this->config->item('timezone'));

    if (intval($year) == 0) $year = date('Y', $time);
    if (intval($month) == 0) $month = date('n', $time);

    $date1 = mktime  (0, 0, 0, $month, 1, $year);
    $date2 = mktime  (23, 59, 59, $month, date('t', $date1), $year);

    $prefs = array (
      'local_time' => $time,
      'show_next_prev' => TRUE,
      'next_prev_url' => site_url() . '/' . $this->module_url . '/show/'
    );


    $prefs['template'] = '
    {table_open}<table class="calendar" cellpadding="3" cellspacing="0">{/table_open}
    {table_close}</table>{/table_close}

    {cal_cell_content}<div class="calendar_content"><a href="{content}">{day}</a></div>{/cal_cell_content}
    {cal_cell_content_today}<div class="calendar_content"><a href="{content}"><span class="calendar_today">{day}</span></a></div>{/cal_cell_content_today}

    {cal_cell_no_content}<span class="calendar_no_content" >{day}</span>{/cal_cell_no_content}
    {cal_cell_no_content_today}<span class="calendar_no_content" ><span class="calendar_today">{day}</span></span>{/cal_cell_no_content_today}
    ';


    $this->load->library('calendar', $prefs);

    $data = array();
//erm load schedules days for physician selected
//------------------------------------------------------------------------------
    $this->db->select('time_from');
    $this->db->from(array('med_appointment'));
    $this->db->where('time_from>=', $date1);
    $this->db->where('time_to<=', $date2);

    if ($physician != '') $this->db->where('physician_code', $physician);

    $this->db->orderby('time_from');
    $query = $this->db->get();

    $days = array();
    foreach ($query->result() as $row) {
      $date_time_zone = $row->time_from;
      $day = intval(date('d', $date_time_zone));
      if (!isset($days[$day])) {
        $days[$day] = 1;
      }
    }

    for ($i=1;$i<=31;$i++) {
      if (isset($days[$i])) {
        $data[$i] =
        sprintf('%s/%s/show/%d/%d/%d/%s', site_url(), $this->module_url, $year, $month, $i, $physician);
      }
    }

    return
    sprintf(
      '%s %s',
      $this->calendar->generate($year, $month, $data),
      anchor($this->module_url.'/show', $this->lang->line('schedule_gotoday'))
    );

  }

  /**
   * return a html formatted appointment
   *
   * @private
   * 
   * @param status int the status of the appointment (-1:confirm, 0:cancel, 1:pending, 3:at_lobby, 4:in_consultation, 5:done)
   * @param id int unique identifier of the appointment
   * @param timefrom int unixtimestamp date from
   * @param timeto int unixtimestamp date to
   * @param patient string the name of the patient
   * @param doctor string the name of the physician
   * @param notes string the notes of the appointment
   *
   * @return string
   */
  function _format_appointment ($status, $id, $timefrom, $timeto, $patient, $doctor, $notes ) {

    $this->load->helper(array('date','url'));

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('table'));

    $items = array();

    $txts = array();
    $imgs = array();
    $urls = array();

    $txts[-1] = $this->lang->line('appointment_confirm');
    $txts[0] = $this->lang->line('appointment_cancel');
    $txts[1] = $this->lang->line('appointment_pending');
    $txts[3] = $this->lang->line('appointment_atlobby');
    $txts[4] = $this->lang->line('appointment_consultation');
    $txts[5] = $this->lang->line('appointment_done');

    $class_action = "schedule_action_img";
    $imgs[-1] = theme_imgtag ('confirmed.png', $txts[-1], $txts[-1], "class='$class_action'" );
    $imgs[0] = theme_imgtag ('cancel.png', $txts[0], $txts[0], "class='$class_action'" );
    $imgs[1] = theme_imgtag ('pending.png', $txts[1], $txts[1], "class='$class_action'" );
    $imgs[3] = theme_imgtag ('atlobby.png', $txts[3], $txts[3], "class='$class_action'" );
    $imgs[4] = theme_imgtag ('doctor.png', $txts[4], $txts[4], "class='$class_action'" );
    $imgs[5] = theme_imgtag ('doctor.png', $txts[4], $txts[4], "class='$class_action'" );

    $urls[-1] = $this->module_url.'/confirm/'.$id;
    $urls[0] = $this->module_url.'/cancel/'.$id;
    $urls[1] = $this->module_url.'/pending/'.$id;
    $urls[3] = $this->module_url.'/atlobby/'.$id;

    if ($status == -1) {
      $txts[-1]  = anchor($urls[-1], $txts[-1]);
      $imgs[-1]  = anchor($urls[-1], $imgs[-1]);
    } else {
      $txts[-1] = sprintf('<strong>%s</strong>', $txts[-1]);
    }

    if ( ! $status ) {
      $txts[0] = $this->lang->line('appointment_canceled');
      $txts[0] = sprintf('<strong>%s</strong>', $txts[0]);
      $imgs[0] = '';
    } else {
      $txts[0]  = anchor($urls[0], $txts[0]);
      $imgs[0]  = anchor($urls[0], $imgs[0]);
    }

    if ($status == 1) {
      $txts[1] = sprintf('<strong>%s</strong>', $txts[1]);
    } else {
      $txts[1]  = anchor($urls[1], $txts[1]);
      $imgs[1]  = anchor($urls[1], $imgs[1]);
    }

    if ($status == 3) {
      $txts[3] = sprintf('<strong>%s</strong>', $txts[3]);
    } else {
      $txts[3]  = anchor($urls[3], $txts[3]);
      $imgs[3]  = anchor($urls[3], $imgs[3]);
    }

    if ($status == 4) {
      $txts[4] = sprintf('<strong>%s</strong>', $txts[4]);
    }

    if ($status == 5) {
      $txts[5] = sprintf('<strong>%s</strong>', $txts[5]);
      $imgs[5] = '';
    }

    $j1 = 0;
    $j2 = 3;
    if ( ! $status ) {
      $j1 = 0;
      $j2 = 0;
    }
    if ($status == 4) {
      $j1 = 4;
      $j2 = 4;
    }
    if ($status == 5) {
      $j1 = 5;
      $j2 = 5;
    }

    if ($status == -1) {
      $j1 = -1;
      $j2 = 0;
    }

    for ($i = $j1 ; $i <= $j2 ; $i++) {

      if ( ! isset($txts[$i])) continue;

      $action = $imgs[$i];
      if ($action  != '') $action .= '<br />';
      $action .= $txts[$i];

      $items[] = $action;
    }

    $this->table->clear();
    $menu = $this->table->make_columns($items, sizeof($items));
    $tmpl = array (
    'cell_start'=>'<td align="center" >',
    'cell_alt_start'=>'<td align="center" >'
    );
    $this->table->set_template($tmpl);
    $menu = $this->table->generate($menu);

    $class_css = '';
    switch ($status) {
      case 0:
        $class_css = 'schedule_appointment_canceled';
        break;
      default:
        $class_css = 'schedule_appointment';
        break;
    }

    $data = '';
    $info = '';

    if ( $status == -1 ) {
      $info = sprintf(
        '%s <b>%s @ %s - %s</b><br />%s: %s<br />%s %s<br /><i>%s</i>',
        msgWarning('', $this->lang->line('consultation_title')),
        date('d M Y', $timefrom),
        date('h:i a', $timefrom),
        date('h:i a', $timeto),
        $this->lang->line('patient_patient'),
        $patient,
        $this->lang->line('appointment_dr'),
        $doctor,
        $notes
      );
    } elseif ( ! $status ) {
      $info = sprintf(
        '<b>%s - %s</b> - %s: %s - %s %s',
        date('h:i a', $timefrom),
        date('h:i a', $timeto),
        $this->lang->line('patient_patient'),
        $patient,
        $this->lang->line('appointment_dr'),
        $doctor
      );
    } elseif ($status == 5) {
      $info = sprintf(
        '<b>%s - %s</b> - %s: %s - %s %s',
        date('h:i a', $timefrom),
        date('h:i a', $timeto),
        $this->lang->line('patient_patient'),
        $patient,
        $this->lang->line('appointment_dr'),
        $doctor
      );
    } else {
      $info = sprintf(
        '<b>%s - %s</b><br />%s: %s<br />%s %s<br /><i>%s</i>',
        date('h:i a', $timefrom),
        date('h:i a', $timeto),
        $this->lang->line('patient_patient'),
        $patient,
        $this->lang->line('appointment_dr'),
        $doctor,
        $notes
      );
    }

    $data =
    sprintf(
      '<table class="'.$class_css.'" width="100%%" ><tr>
      <td >%s</td>
      <td align="right">%s</td>
      </tr></table>',
      $info,
      $menu
    );

    return $data;
  }


  /**
   * creates a list of appointments
   *
   * returns a formatted html list of appointments for date, speciality and physician selected
   *
   * @private
   * 
   * @param date1 int unixtimestamp date from
   * @param date2 int unixtimestamp date to
   * @param speciality string the speciality to show or empty to show all
   * @param physician string the physician to show or empty to show all
   *
   * @return string
   */
  function _schedule ($date1, $date2, $speciality='', $physician='') {

    $this->load->helper(array('date','url'));

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->library(array('table'));

    $schedule = array();

    $prefix = $this->db->dbprefix;
    $this->db->select(sprintf(
      'a.*, b.name as physician, c.name as patient
      FROM %smed_appointment as a
      LEFT JOIN %susers as b ON a.physician_code=b.code && b.is_physician=1
      LEFT JOIN %smed_patient as c ON a.patient_code=c.code
      ',
      $prefix,
      $prefix,
      $prefix
    ));

    if ($speciality != '') $this->db->where('speciality_code', $speciality);
    if ($physician != '') $this->db->where('physician_code', $physician);
    $this->db->where('time_from>=', $date1);
    $this->db->where('time_to<=', $date2);

    $this->db->orderby('time_from, physician, patient');
    $query = $this->db->get();

    $interval = $this->config->item('schedule_interval');
    //$interval = (60*60*3);
    //erm. this interval is to split the day schedule into 3 hours each block.

    foreach ($query->result() as $row) {

      for ($j=0; $j<(60*60*24); $j+=$interval) { //erm intervalos de xx minutos
        $i = $j + $date1;

        if (
          ($row->time_from >= $i && $row->time_from <= ($i+$interval-1)) ||
          ($row->time_to >= $i && $row->time_to <= ($i+$interval-1))
        ) {

          $date_time_zone1 = $row->time_from;
          $date_time_zone2 = $row->time_to;

          $data = $this->_format_appointment (
            $row->status, $row->id, $row->time_from,
            $row->time_to, $row->patient, $row->physician, $row->notes
          );

          if (!isset($schedule[$j])) {
            $schedule[$j] = $data;
          } else {
            $schedule[$j] .= $data;
          }

          break;
        }
      }
    }

    $options = '';
    $allday = '';
    for ($j=0; $j<(60*60*24); $j+=$interval) { //erm intervalos de xx minutos

      $i = $j + $date1;
      $date_time_zone = $i;

      if (isset($schedule[$j])) {
        $id='schedule_busy';
        $data = $schedule[$j];
        $title=$this->lang->line('schedule_busy');

      } else {
        $id='schedule_empty';
        $data = '';
        $title=$this->lang->line('schedule_empty');
      }

      $allday .= sprintf(
        '<div class="%s" title="%s">%s%s</div>',
        $id,
        $title,
        date('h:ia',$date_time_zone).' - '.date('h:ia',$date_time_zone+$interval-1),
        $data
      );

    }

    $options .= '<div id="schedule">'.$allday.'</div>';

    return $options;
  }


  /**
   * sends to browser a themed view with the result of _schedule method
   *
   * this method lookup for URI segments for next params:
   * year (segment 3), month (segment 4), day (segment 5) and physician (segment 6)
   *
   * @public
   * 
   * @return nothing
   */
  function show() {

  //erm objetos que necesito
  //------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->helper(array('form', 'date', 'cookie'));
    $this->load->library(array('table'));

  //erm estan definidos el año y el mes del calendario?
  //------------------------------------------------------------------------------
    $year = $this->uri->segment(3, 0);
    $month = $this->uri->segment(4, 0);
    $day = $this->uri->segment(5, 0);
    $physician = $this->uri->segment(6, '');

    //erm el dia de hoy segun
    $time = gmt_to_local(now(), $this->config->item('timezone'));
    if (intval($day) == 0) {
      $day = date('d', $time);
    }
    if (intval($month) == 0) {
      $month = date('n', $time);
      $day = date('d', $time);
    }
    if (intval($year) == 0) {
      $year = date('Y', $time);
      $month = date('n', $time);
      $day = date('d', $time);
    }

    $date1 = mktime  (0, 0, 0, $month, $day, $year);
    $date2 = mktime  (23, 59, 59, $month, $day, $year);

    $title = date('D d, M Y', $date1);

    $schedule = $this->_schedule ($date1, $date2, '', $physician);
    $calentar = block($title, $this->_schedule_calendar($year, $month, $physician));

  //erm physicians list
  //------------------------------------------------------------------------------
    $action = sprintf('/%s/show/%d/%d/%d/',$this->module_url, $year, $month, $day);
    $drs  = "";
    $attributes = array('id' => 'ff', 'method'=>'get');
    $drs .= form_open($action, $attributes);
    $drs .= form_dropdown('fp', $this->_get_physicians(), $physician, 'id="fp" ' );
    $drs .= ' ';
    $drs .= form_submit('fs', $this->lang->line('schedule_filter'));
    $drs .= form_close();

    $drs .= '
    <script type="text/javascript">
    <!--
    window.addEvent("domready", function() {
      $("fp").addEvent("change", function(){
        $("ff").setProperty("action", "'.site_url().$action.'" + $("fp").get("value"));
      });
    });
    -->
    </script>
    ';

  //erm enviar los resultados a la salida
  //------------------------------------------------------------------------------

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $center =
    $msg
    .$this->_thissubmenu('')
    .sprintf('<h3>%s</h3>', $title)
    .sprintf('<div style="text-align: center;">%s</div>', $drs)
    .$schedule;

    make_blocks();
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('appointment_title');
    $data['content'] = theme($this->block_side1, $center,  $calentar . $this->block_side2);
    $this->load->view($this->config->item('theme'), $data);

  }


  /**
   * returns a list of physicians to be included in a dropdown control
   *
   * @private
   * 
   * @return string
   */
  function _get_physicians () {

    $this->lang->load('admin');

    $physicians = array();

//erm load physicians list
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->distinct();
    $this->db->select('code, name');
    $this->db->from(array('users','med_schedule'));
    $this->db->where($prefix.'users.code=' . $prefix.'med_schedule.physician_code');
    $this->db->where('status', 1);
    $this->db->where('is_physician', 1);
    $this->db->orderby('name');
    $query = $this->db->get();

    $physicians['']= '--- '.$this->lang->line('main_all').' ---';

    foreach ($query->result() as $row) {
      $name = $row->name;
      if ($name == '') $name = sprintf('[%s]', $row->code);
      $physicians[$row->code] =
      sprintf(
        '%s %s',
        $this->lang->line('appointment_dr'),
        $name
      );
    }

    return $physicians;
  }


  /**
   * change appointment status
   *
   * change the status of an appointment to 'at_lobby' if allowed, then redirect to the referer URL  (loader)
   * this method will search the appointment id at URI segment 3
   *
   * @public
   * 
   * @return nothing
   */
  function atlobby() {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->load->helper(array('url'));

    $redirect = $this->module_url;
    if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] != '') {
      $tmp = $_SERVER['HTTP_REFERER'];
      $tmp = trim(substr($tmp, strlen($this->config->site_url()), strlen($tmp)));
      if ($redirect != '') $redirect = $tmp;
    }

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }

    $data = array(
      'status' => 3,
    );
    $this->db->where('id', $code);
    $this->db->where('status >', 0);
    $this->db->where('status <', 4);
    $this->db->update($this->dbtablename, $data);

    redirect($redirect);

    return;
  }

  /**
   * change appointment status
   *
   * change the status of an appointment to 'pending' if allowed, then redirect to the referer URL  (loader)
   * this method will search the appointment id at URI segment 3
   *
   * @public
   * 
   * @return nothing
   */
  function pending() {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->load->helper(array('url'));

    $redirect = $this->module_url;
    if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] != '') {
      $tmp = $_SERVER['HTTP_REFERER'];
      $tmp = trim(substr($tmp, strlen($this->config->site_url()), strlen($tmp)));
      if ($redirect != '') $redirect = $tmp;
    }

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }

    $data = array(
      'status' => 1,
    );
    $this->db->where('id', $code);
    $this->db->where('status >', 0);
    $this->db->where('status <', 4);
    $this->db->update($this->dbtablename, $data);

    redirect($redirect);

    return;
  }

  /**
   * change appointment status
   *
   * change the status of an appointment to 'confirm' if allowed, then redirect to the referer URL  (loader)
   * before to change the status, a confirm dialog will be shown
   * this method will search the appointment id at URI segment 3
   *
   * @public
   * 
   * @return nothing
   */
  function confirm() {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->load->helper(array('url'));

    $redirect = $this->module_url;
    if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] != '') {
      $tmp = $_SERVER['HTTP_REFERER'];
      $tmp = trim(substr($tmp, strlen($this->config->site_url()), strlen($tmp)));
      if ($redirect != '') $redirect = $tmp;
    }

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }


    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('appointment_del')).'<br />'
      . $err
      . Ask_yesno_form (
        sprintf($this->lang->line('appointment_askconfirm'), $code),
        $this->module_url.'/confirm/'.$code,
        $redirect,
        form_hidden('redirect', base64_encode($redirect))
      );

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('appointment_title');
      $data['content'] = theme($this->block_side1, $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
        'status' => 1,
      );
      $this->db->where('id', $code);
      $this->db->where('status', -1);
      $this->db->update($this->dbtablename, $data);

      if ($this->input->post('redirect') !== FALSE)
        $redirect = base64_decode($this->input->post('redirect'));

      redirect($redirect);

      return;
    }
  }

  /**
   * change appointment status
   *
   * change the status of an appointment to 'confirm' if allowed, then redirect to the referer URL  (loader)
   * before to change the status, a confirm dialog will be shown
   * this method will search the appointment id at URI segment 3
   *
   * @public
   * 
   * @return nothing
   */
  function cancel() {

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->library('validation');
    $this->load->helper(array('url','form', 'cookie'));

//erm objetos que necesito
//------------------------------------------------------------------------------
    $this->load->helper(array('url'));

    $redirect = $this->module_url;
    if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] != '') {
      $tmp = $_SERVER['HTTP_REFERER'];
      $tmp = trim(substr($tmp, strlen($this->config->site_url()), strlen($tmp)));
      if ($redirect != '') $redirect = $tmp;
    }

//erm sino esta el parametro redirigir hacia delask function
//------------------------------------------------------------------------------
    $code = $this->input->xss_clean($this->uri->segment(3, 0));
    if ($code === "0") {
      $msg = base64_encode(msgWarning('', $this->lang->line('admin_ignoringtask')));
      set_cookie('msg', $msg, 0);
      redirect($redirect);
      return;
    }


    $this->validation->set_error_delimiters('','<br />');
    $rules['Submit']  = "required";
    $this->validation->set_rules($rules);

    if ($this->validation->run() == FALSE) {

      if ($this->validation->error_string != "") $err = msgErr("",$this->validation->error_string);
      else $err = "";

      $form = $this->_thissubmenu($this->lang->line('appointment_del')).'<br />'
      . $err
      . Ask_yesno_form (
        sprintf($this->lang->line('appointment_askcancel'), $code),
        $this->module_url.'/cancel/'.$code,
        $redirect,
        form_hidden('redirect', base64_encode($redirect))
      );

      make_blocks();
      $data = default_Vars_Content();
      $data['title'] .= ' - ' . $this->lang->line('appointment_title');
      $data['content'] = theme($this->block_side1, $form);
      $this->load->view($this->config->item('theme'), $data);

    } else {

      $data = array(
        'status' => 0,
      );
      $where = " ((status > 0 && status < 4) || status = -1)";
      $this->db->where('id', $code);
      $this->db->where($where);
      $this->db->update($this->dbtablename, $data);

      if ($this->input->post('redirect') !== FALSE)
        $redirect = base64_decode($this->input->post('redirect'));

      redirect($redirect);

      return;
    }
  }

  /**
   * specialities form
   * 
   * sends to browser a list of specialities for physician
   *
   * this method is intented to be used with ajax.
   * javascript will include this result into a dropdown to select a speciality
   *
   * this method expects a valid physician code at URI segment 3
   *
   * @public
   * 
   * @return nothing
   */
  function form_speciality () {

    $physician_code = $this->input->xss_clean($this->uri->segment(3, ''));

    $this->lang->load('admin');

//erm load specialities list
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->distinct();
    $this->db->select('code, name');
    $this->db->from(array('med_specialities','med_schedule'));

    $this->db->where($prefix.'med_specialities.code=' . $prefix.'med_schedule.speciality_code');
    if ($physician_code != '') $this->db->where('physician_code', $physician_code);

    $this->db->orderby('name');
    $query = $this->db->get();

    $options = '';
    $options .= '||--- '.$this->lang->line('main_pleaseselect').' ---';

    foreach ($query->result() as $row) {
      $options .= '&&'.$row->code . '|';
      //if ($selected == $row->code) $options .=  'selected';
      $options .= '|'.htmlspecialchars($row->name);
    }

    echo $options;
  }


  /**
   * physician form
   * 
   * sends to browser a list of physicians for speciality
   *
   * this method is intented to be used with ajax.
   * javascript will include this result into a dropdown to select a physician
   *
   * this method expects a valid speciality code at URI segment 3
   * 
   * @public
   * 
   * @return nothing
   */
  function form_physician () {

    $speciality_code = $this->input->xss_clean($this->uri->segment(3, ''));

    $this->lang->load('admin');

//erm load physicians list
//------------------------------------------------------------------------------
    $prefix = $this->db->dbprefix;
    $this->db->distinct();
    $this->db->select('code, name');
    $this->db->from(array('users','med_schedule'));

    $this->db->where('status', 1);
    $this->db->where('is_physician', 1);
    $this->db->where($prefix.'users.code=' . $prefix.'med_schedule.physician_code');
    if ($speciality_code != '') $this->db->where($prefix.'med_schedule.speciality_code=' . $speciality_code);

    $this->db->orderby('name');
    $query = $this->db->get();

    $options = '';
    $options .= '||--- '.$this->lang->line('main_pleaseselect').' ---';

    foreach ($query->result() as $row) {
      $options .= '&&'.$row->code.'|';
      //if ($selected == $row->code) $options .=  'selected';
      $options .='|'.sprintf('%s [%s]', htmlspecialchars($row->name), $row->code);

    }

    echo $options;
  }


  /**
   * hours available form
   * 
   * sends to browser a schedule list for physician and speciality selected
   *
   * this method is intented to be used with ajax.
   * javascript will include this result into the form
   *
   * this method expects the next URI segments:
   * valid speciality code a segment 3
   * valid year at segment 4
   * valid month at segment 5
   * valid day at segment 6
   * valid physician code at segment 7
   *
   * @public
   * 
   * @return nothing
   */
  function form_hours () {

    $speciality = $this->input->xss_clean($this->uri->segment(3, ''));
    $year = $this->input->xss_clean($this->uri->segment(4, 0));
    $month = $this->input->xss_clean($this->uri->segment(5, 0));
    $day = $this->input->xss_clean($this->uri->segment(6, 0));
    $physician = $this->input->xss_clean($this->uri->segment(7, ''));

    $date = mktime  (0, 0, 0, $month, $day, $year);

    $doquery = 1;

    if ($speciality == '') $doquery = 0;
    if ($year == 0) $doquery = 0;
    if ($month == 0) $doquery = 0;
    if ($day == 0) $doquery = 0;
    if ($physician == '') $doquery = 0;
    if ($date === FALSE || $date == -1) $doquery = 0;

    $this->lang->load('admin');
    $this->lang->load('med_common');


    $schedule = array();
    $busy = array();

    if ($doquery == 1) {

      $this->db->from(array('med_schedule'));
      $this->db->where('speciality_code', $speciality);
      $this->db->where('physician_code', $physician);
      $this->db->where('day', date('w', $date));
      $this->db->orderby('time_from');
      $query = $this->db->get();

      $key = 0;
      foreach ($query->result() as $row) {

        if ( ! $row->intervallum) $row->intervallum = 3600;

        for ($i=$row->time_from; $i<$row->time_to; $i+=$row->intervallum) { //erm intervalos de xx minutos
          $ini = $i;
          $end = $i+$row->intervallum-1;
          if ($ini >= $row->time_from && $end <= $row->time_to) {
            $schedule[$key]['ini'] = $ini;
            $schedule[$key]['end'] = $end;
            $key++;
          }
        }
      }

      $date1 = mktime  (0, 0, 0, $month, $day, $year);
      $date2 = mktime  (23, 59, 59, $month, $day, $year);

      $this->db->from(array('med_appointment'));
      $this->db->where('status !=', 0);
      $this->db->where('physician_code', $physician);
      $this->db->where('time_from>=', $date1);
      $this->db->where('time_to<=', $date2);
      $this->db->orderby('time_from, patient_code');
      $query = $this->db->get();

      foreach ($query->result() as $row) {

        foreach ($schedule as $key => $val) {
          $ini = $date1 + $val['ini'];
          $end = $date1 + $val['end'];
          if (
            ($row->time_from >= $ini && $row->time_from <= $end) ||
            ($row->time_to >= $ini && $row->time_to <= $end)
          ) {
            $busy[$key] = 1;
          }
        }

      }
    }

    $allday = '';
    foreach ($schedule as $key => $val) {

      if (isset($busy[$key])) {
        $class = 'schedule_busy';
        $title = $this->lang->line('schedule_busy');
      } else {
        $class = 'schedule_free';
        $title = $this->lang->line('schedule_available');
      }

      $date_temp = mktime (0, 0, 0, 4, 26, 1926);
      $allday .= sprintf(
        '<div class="%s" title="%s">%s - %s</div>',
        $class,
        $title,
        date('h:ia',$date_temp+$val['ini']),
        date('h:ia',$date_temp+$val['end'])
      );
    }

    echo sprintf('<div id="schedule">%s</div>', $allday);
  }

  /**
   * physician calendar form
   * 
   * sends to browser a calendar by physicians availables
   *
   * this method is intented to be used with ajax.
   * javascript will include this result into the form
   *
   * this method expects the next URI segments:
   * valid physician code a segment 3
   * valid year at segment 4
   * valid month at segment 5
   * valid speciality code at segment 6
   *
   * @public
   * 
   * @return nothing
   */
  function form_calendar_doc () {

    $physician = $this->input->xss_clean($this->uri->segment(3, ''));
    $year = $this->input->xss_clean($this->uri->segment(4, 0));
    $month = $this->input->xss_clean($this->uri->segment(5, 0));
    $speciality = $this->input->xss_clean($this->uri->segment(6, ''));

    echo $this->_form_calendar ($speciality, $year, $month, $physician, 'speciality');
  }

  /**
   * speciality calendar form
   * 
   * sends to browser a calendar by specialities availables
   *
   * this method is intented to be used with ajax.
   * javascript will include this result into the form
   *
   * this method expects the next URI segments:
   * valid speciality code a segment 3
   * valid year at segment 4
   * valid month at segment 5
   * valid physician code at segment 6
   *
   * @public
   * 
   * @return nothing
   */
  function form_calendar_spe () {

    $speciality = $this->input->xss_clean($this->uri->segment(3, ''));
    $year = $this->input->xss_clean($this->uri->segment(4, 0));
    $month = $this->input->xss_clean($this->uri->segment(5, 0));
    $physician = $this->input->xss_clean($this->uri->segment(6, ''));

    //echo $this->_form_calendar ('speciality');
    echo $this->_form_calendar ($speciality, $year, $month, $physician, 'doctor');
  }

  /**
   * schedule calendar form
   * 
   * return a html calendar with days showing available schedule
   *
   * @private
   * 
   * @param speciality string the speciality to show
   * @param year int the year of the calendar
   * @param month int the month of the calendar
   * @param physician string the physician to show
   * @param tips enum [doctor/speciality] show a list of doctos or specialities to be shown as tooltops when mouse over a day with schedules
   * 
   * @return string
   */
  function _form_calendar ($speciality, $year, $month, $physician, $tips) {

    $this->lang->load('admin');
    $this->lang->load('med_common');

    $this->load->helper(array('date'));
    $time = gmt_to_local(now(), $this->config->item('timezone'));

    if (intval($year) == 0) $year = date('Y', $time);
    if (intval($month) == 0) $month = date('n', $time);

    $prefs = array (
      'local_time' => $time,
      'show_next_prev' => TRUE,
      'next_prev_url' => '#/'
    );

    $prefs['template'] = '
    {table_open}<table class="calendar" cellpadding="3" cellspacing="0">{/table_open}
    {table_close}</table>{/table_close}

    {heading_previous_cell}<th style="cursor: pointer;"><a id="cal_previous" title="{previous_url}">&lt;&lt;</a></th>{/heading_previous_cell}
    {heading_next_cell}<th style="cursor: pointer;"><a id="cal_next" title="{next_url}">&gt;&gt;</a></th>{/heading_next_cell}

    {cal_cell_content}<div class="calendar_content" {content}>{day}</div>{/cal_cell_content}
    {cal_cell_content_today}<div class="calendar_content" {content}><span class="calendar_today">{day}</span></div>{/cal_cell_content_today}

    {cal_cell_no_content}<span class="calendar_no_content" >{day}</span>{/cal_cell_no_content}
    {cal_cell_no_content_today}<span class="calendar_no_content" ><span class="calendar_today">{day}</span></span>{/cal_cell_no_content_today}

    ';

    $this->load->library('calendar', $prefs);

//erm load appointments to see if physicians are busy
//------------------------------------------------------------------------------
    $appointments = array();

    $date1 = mktime  (0, 0, 0, $month, 1, $year);
    $date2 = mktime  (0, 0, -1, $month+1, 1, $year);

    $this->db->from(array('med_appointment'));
    $this->db->where('status !=', 0);
    $this->db->where('time_from>=', $date1);
    $this->db->where('time_to<=', $date2);

    if ($speciality != '') $this->db->where('speciality_code', $speciality);
    if ($physician != '') $this->db->where('physician_code', $physician);

    $this->db->orderby('time_from, patient_code');
    $query = $this->db->get();

    foreach ($query->result() as $row) {
      $day = date('j', $row->time_from);
      $tmp = mktime  (0, 0, 0, $month, $day, $year);
      $ini = $row->time_from - $tmp;
      $end = $row->time_to - $tmp;
      $appointments [$day][$row->physician_code][] = sprintf('%d-%d', $ini, $end);
    }

//erm load schedule expected to physicians be available
//------------------------------------------------------------------------------
    $schedule = array();
    $doctors  = array();

    $prefix = $this->db->dbprefix;
    $this->db->select(sprintf(
      'a.day, a.intervallum, a.time_from, a.time_to, a.speciality_code, b.name, b.code, c.name as speciality
      FROM %smed_schedule as a
      JOIN %susers as b ON a.physician_code=b.code
      JOIN %smed_specialities as c ON a.speciality_code=c.code
      ',
      $prefix,
      $prefix,
      $prefix
    ));

    if ($speciality != '') $this->db->where('speciality_code', $speciality);
    if ($physician != '') $this->db->where('physician_code', $physician);
    $this->db->where('b.status', 1);
    $this->db->where('b.is_physician', 1);

    $query = $this->db->get();

    foreach ($query->result() as $row) {

      for ($j=1;$j<=31;$j++) {
        $temp_date = mktime(23, 59, 59, intval($month), $j, intval($year));
        $day_of_week = intval(date('w', $temp_date));

        if ($day_of_week == $row->day && $temp_date > $time) {

          $tooltip = '';
          if ($tips == 'doctor') {
            if ($row->name == '') $row->name = sprintf('[%s]', $row->code);
            $tooltip = sprintf('%s %s', $this->lang->line('appointment_dr'), $row->name);
            if (trim($tooltip) == '') $tooltip = sprintf('[%s]', $row->code);
          }
          if ($tips == 'speciality') {
            $tooltip = $row->speciality;
            if (trim($tooltip) == '') $tooltip = sprintf('[%s]', $row->speciality_code);
          }

          $tmp_dr = true;
          if ($tooltip == '' || (isset($doctors[$j]) && strpos($doctors[$j], $tooltip) !== false) ) $tmp_dr = false;
          if ( $tmp_dr == true) {

            $tmp_str = sprintf('<div>%s</div>', $tooltip);
            if (isset($doctors[$j])) $doctors[$j] .= $tmp_str;
            else $doctors[$j] = $tmp_str;

          }


          if ( ! $row->intervallum) $row->intervallum = 3600;
          for ($i=$row->time_from; $i<$row->time_to; $i+=$row->intervallum) { //erm intervalos de xx minutos
            $ini = $i;
            $end = $i+$row->intervallum-1;
            if ($ini >= $row->time_from && $end <= $row->time_to) {
              $schedule[$j][$row->code][] = sprintf('%d-%d', $ini, $end);
            }
          }

        }
      }
    }

    $schedule_keep = array();

//erm see beetween appointments and schedule to see free time
//------------------------------------------------------------------------------
    foreach ($appointments as $akey => $aval) {

      if (isset($schedule[$akey])) {

        foreach ($schedule[$akey] as $skey => $sval) {

          if (isset($appointments[$akey][$skey])) {

            $tmpsche = $sval;
            $tmpappo = $appointments[$akey][$skey];

            for ($a=0; $a<sizeof($tmpappo); $a++) {
              for ($b=0; $b<sizeof($tmpsche); $b++) {
              //for ($b=sizeof($tmpsche)-1; $b>=0; $b--) {

                $sp1 = explode('-', $tmpappo[$a]);
                $sp2 = explode('-', $tmpsche[$b]);

                if (
                  ($sp1[0] >= $sp2[0] && $sp1[0] <= $sp2[1]) ||
                  ($sp1[1] >= $sp2[0] && $sp1[1] <= $sp2[1])
                ) {
                  unset ($schedule[$akey][$skey][$b]);
                }

              }
            }

          }
        }
      }
    }

    foreach($schedule as $key => $val) {

      $count = 0;
      foreach($val as $meds) $count += count($meds);
      if ( ! $count) $schedule[$key] = '';

    }


//erm create calendar links with freetime days and busy days
//------------------------------------------------------------------------------

    $data = array();

    for ($i=1;$i<=31;$i++) {
      $doc = '';
      if (isset($doctors[$i])) $doc = $doctors[$i];
      if (isset($schedule[$i])) {
        if (is_array($schedule[$i])) $class = '';
        else $class = 'style="color: red;" ';
        $data[$i]= sprintf('id="%d/%d/%d" title="%s" %s ', $year, $month, $i, $doc, $class);
      }
    }

    return
    '<input id="cal_actual_month" type="hidden" value="/'.$year.'/'.$month.'/" />'
    .$this->calendar->generate($year, $month, $data)
    ;

  }

  /**
   * search patients
   * 
   * sends to browser the result of the patients to search
   *
   * this method is intented to be used with ajax
   * javascript will request this method to search a patient meanwhile 'user' is tipyng
   * 
   * this method expects the patient to search at URI segment 3
   *
   * @public
   * 
   * @return nothing
   */
  function form_search_patient () {

    $this->lang->load('admin');
    $this->lang->load('med_common');
    $this->load->helper(array('text', 'url'));
    $this->load->library(array('pagination'));

    $limit = 10;

    $code = $this->input->xss_clean($this->uri->segment(3, ''));

    if ($code == '' || strlen($code) < 1) {
      echo $this->lang->line('appointment_enter3chars');
      return;
    }

//erm search number of patients which match
//------------------------------------------------------------------------------
/*
    $search_select = ", MATCH (code,name,email,notes) AGAINST ('$code*' IN BOOLEAN MODE) as relev";
    $search_where  = " (MATCH (code,name,email,notes) AGAINST ('$code*' IN BOOLEAN MODE))";
*/

    $search_select = sprintf("concat('1') as relev" );
    $search_where  = sprintf("(code LIKE '%%%s%%' || name LIKE '%%%s%%' || email LIKE '%%%s%%' || notes LIKE '%%%s%%')", $code, $code, $code, $code );

    $this->db->where('status=1');
    $this->db->where($search_where);
    $this->db->select('count(*) as numrows');
    $query = $this->db->get('med_patient');

    $numitems = 0;
    if ($query->num_rows() > 0) {
      $row = $query->row();
      $numitems = $row->numrows;
    }

//erm load physicians list
//------------------------------------------------------------------------------
    $search_select = ', MATCH (code,name,email,notes) AGAINST (\''.$code.'*\' IN BOOLEAN MODE) as relev';
    $search_where  = ' && (MATCH (code,name,email,notes) AGAINST (\''.$code.'*\' IN BOOLEAN MODE))';

    $prefix = $this->db->dbprefix;
    $this->db->select('*, '.$search_select);
    $this->db->from(array('med_patient'));
    $this->db->where('status=1 ' . $search_where);
    $this->db->orderby('relev DESC');
    $this->db->limit($limit, 0);
    $query = $this->db->get();

    $options = '';

    $records = $query->num_rows();
    if ($records > 0) {

      foreach ($query->result() as $row) {
/*
        $title = sprintf(
        '[%s]<br />%s<br />%s<br />%s',
        $row->code,
        $row->name,
        $row->email,
        word_limiter(strip_tags($row->notes), 30)
        );
*/
        if (strlen($row->name) > 25) $row->name = substr($row->name, 0, 23) . '..';
        $options .= sprintf(
        //'<div id="%s" class="schedule_patient" title="%s" >%s</div>',
        '<div id="%s" class="schedule_patient" >%s</div>',
        $row->code,
        //$title,
        sprintf('%s &raquo; [%s] &raquo; %s ',  $row->name, $row->code, $row->email )
        );
      }
    }
    $options = sprintf(
    '%s: %s<hr />%s',
    $this->lang->line('patient_patientsshown'),
    $records.'/'.$numitems,
    $options
    );

    echo $options;
    //echo '<br>' . $this->db->last_query();
  }


  /**
   * list of appointments
   * 
   * sends to browser a themed view with the list of appointments requested online
   *
   * @public
   * 
   * @return nothing
   */
  function online () {

  //erm objetos que necesito
  //------------------------------------------------------------------------------
    $this->lang->load('med_common');
    $this->lang->load('admin');
    $this->load->helper(array('form', 'date', 'cookie'));

    $content = '';

    $prefix = $this->db->dbprefix;
    $this->db->select(sprintf(
      'a.*, b.name as physician, c.name as patient
      FROM %smed_appointment as a
      LEFT JOIN %susers as b ON a.physician_code=b.code && b.is_physician=1
      LEFT JOIN %smed_patient as c ON a.patient_code=c.code
      ',
      $prefix,
      $prefix,
      $prefix
    ));
    $this->db->where('a.status', -1);

    $this->db->orderby('time_from, physician, patient');
    $query = $this->db->get();

    if ( ! $query->num_rows() ) {

      $content = $this->lang->line('consultation_nopending');

    } else {

      foreach ($query->result() as $row) {
        $content .= $this->_format_appointment (
          $row->status, $row->id, $row->time_from,
          $row->time_to, $row->patient, $row->physician, $row->notes
        );

      }
    }

  //erm enviar los resultados a la salida
  //------------------------------------------------------------------------------

    $msg = base64_decode(get_cookie('msg', TRUE));
    set_cookie('msg', '', 0);

    $title = date('D d, M Y', now());
    $calentar = block($title, $this->_schedule_calendar());

    $center  = '';
    $center .= $msg;
    $center .= $this->_thissubmenu('');
    $center .= $content;

    make_blocks();
    $data = default_Vars_Content();
    $data['title'] .= ' - ' . $this->lang->line('appointment_online');
    $data['content'] = theme($this->block_side1, $center,  $calentar . $this->block_side2);
    $this->load->view($this->config->item('theme'), $data);


  }

}
?>
