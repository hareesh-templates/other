<?php

/**
 * @file /language/portuguese/content_lang.php
 * @brief File to store translation.
 * 
 * @details English - content module. Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */

$lang['content_relevancy'] = "Relevância";
$lang['content_noresults'] = "Sem resultados";
$lang['content_search'] = "Artigos de Busca";
$lang['content_title'] = "Artigos";
$lang['content_noavailable'] = "Artigo com código '%s' não está disponível";
$lang['content_title'] = "Artigos";
$lang['content_created'] = "Criado";
$lang['content_modified'] = "Modificado";

?>
