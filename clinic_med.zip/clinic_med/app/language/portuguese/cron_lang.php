<?php

/**
 * @file /language/portuguese/cron_lang.php
 * @brief File to store translation.
 * 
 * @details English - Cron. Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */
$lang['run_notify_next_appointments'] = "Enviar um e-mail para todos os médicos que tiverem consultas no dia seguinte";
$lang['cron_appointment_regards'] = "Saudações";
$lang['cron_appointment_subject'] = "Assunto";
$lang['cron_appointment_to'] = "Para o Dr.";
$lang['cron_appointment_msg'] = "Localize as suas próximas consuntas abaixo";
$lang['cron_appointment_msglittle'] = "Suas próximas consultas";

$lang['cron_noexists'] = "Não há Cron job";
$lang['cron_disabled'] = "Cron job está desabilitado";
$lang['cron_instructions'] = "Verifique os cron jobs que você deseja rodar. Observe que verificar apenas habilita/desabilita o cron job, mas NÃO cria o crontab (programação periódica). Vá para o seu painel de controle e adicione o crontab manualmente para cada cron job desejado.";
$lang['cron_function'] = "Função Cron";
$lang['cron_tittle'] = "Cron Jobs";
$lang['cron_list'] = "Lista de Jobs";
$lang['cron_command'] = "Configure a crontab, usando o próximo comando";
$lang['cron_runmanually'] = "Rode manualmente";

?>
