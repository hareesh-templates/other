<?php

/**
 * @file /language/portuguese/admin_lang.php
 * @brief File to store translation.
 * 
 * @details English - Administration Panel. Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */


$lang['install_importsqldberr'] = "Database error when trying to import the sql file '%s' into database.<br /><br />%s";
$lang['install_logs'] = "The logs directory '%s' is not writeable";
$lang['install_captcha'] = "The captcha directory '%s' is not writeable";
$lang['install_success'] = "Clinic MED was successfully installed.<br /><br />Now you would set permission to 'read only' for all files located at next directory (also that directory) <br/ > %s<br /><br />You might delete these files: <br />%s<br />%s";
$lang['install_config_err'] = "Error on installing Clinic_MED. Please verify and try again";
$lang['install_configloaderr'] = "Unable to create the autoload config file '%s'. Check that it has write permissions";
$lang['install_configdberr'] = "Unable to create the database config file '%s'. Check that it has write permissions";
$lang['install_sqlnotexist'] = "The SQL file '%s' to populate the database does not exists";
$lang['install_nowriteable'] = "The config directory '%s' is not writeable";
$lang['install_unabletousedb'] = "Error when trying to connect to the database with data provided";
$lang['install_err_tablesexists'] = "Some tables with that prefix already exists on DB. Select another code";
$lang['install_unableimportsql'] = "Error when trying to import the sql file '%s' into database. Check tha it has read permissions";
$lang['install_cfgdberror'] = "Error when trying to create the database config file %s";
$lang['install_database'] = "Database name";
$lang['install_host'] = "Host";
$lang['install_username'] = "Username";
$lang['install_password'] = "Password";
$lang['install_title'] = "Installation";
$lang['install_notes'] = "Welcome to Clinic MED, an open source application for Professional Clinic Management licensed under GPL

If all is ok, this procedure:

- Creates the config files
- Imports the SQL file to create the new tables; using the database access provided and the code as table prefix

&raquo; Code: enter a prefix without spaces for your database. i.e. my_clinic_
&raquo;  Database name: the name of the database to be used. Ask to your hosting provider for this information
&raquo;  Host: Tipically 'localhost' without quotes. Ask to your hosting provider for this information
&raquo;  Username: The user name to connect to database. Ask to your hosting provider for this information
&raquo;  Password: The password to connecto to database. Ask to your hosting provider for this information

- <b>The initial admin login is user='admin' password='123456' both without quotes</b>
";


$lang['day_name'] = "Dia";
$lang['day_sun'] = "Domingo";
$lang['day_mon'] = "Segunda-feira";
$lang['day_tue'] = "Terça-feira";
$lang['day_wed'] = "Quarta-feira";
$lang['day_thu'] = "Quinta-feira";
$lang['day_fri'] = "Sexta-feira";
$lang['day_sat'] = "Sábado";

$lang['search_tips'] = "Dicas de pesquisa";
$lang['search_created'] = "Criado";
$lang['search_noresults'] = "Sua pesquisa não gerou resultados";
$lang['search_results'] = "Resultados da pesquisa";
$lang['search_relevance'] = "Relevância";
$lang['search_keywords'] = "Pesquisar por";
$lang['search_submit'] = "Pesquisar";
$lang['search_reset'] = "Resetar";
$lang['search_title'] = "Pesquisar";

$lang['modules_groups'] = "Grupos";
$lang['modules_codenofound'] = "O código de módulo não foi encontrado na base de dados";
$lang['modules_askdel'] = "Deseja realmente desinstalar o módulo com o código '%s'?";
$lang['modules_uninstall'] = "desinstalar";
$lang['modules_del'] = "Desinstalar Módulo";
$lang['modules_langnote'] = "Modulo estará disponível apenas para o idioma selecionado";
$lang['modules_whocansee'] = "Quem pode acessar o módulo";
$lang['modules_codeduplicated'] = "O código de módulo já foi instalado na base de dados.";
$lang['modules_install'] = "Instalar o módulo";
$lang['modules_noinstalled'] = "Não instalado";
$lang['modules_filemissing'] = "Arquivo faltando";
$lang['modules_listof'] = "Lista de Módulos";
$lang['modules_uninstalled'] = "Novos Módulos";
$lang['modules_installed'] = "Módulos instalados";
$lang['modules_groups'] = "Grupos";

$lang['usersgroups_none'] = "nenhum";
$lang['usersgroups_group'] = "grupo";
$lang['usersgroups_nocharplus'] = "Caractere '+' não é permitido no código";
$lang['usersgroups_nospaces'] = "Espaços não são permitidos no código";
$lang['usersgroups_codereserved'] = "Codigo Grupo Usuário está reservado. Selecione outro código";
$lang['usersgroups_allnote'] = "Administrador, Usuário, Convidado e Outros";
$lang['usersgroups_adminnote'] = "Aqueles visitantes cadastrados como administradores";
$lang['usersgroups_guestnote'] = "Aqueles visitantes não cadastrados (anônimos)";
$lang['usersgroups_usernote'] = "Aqueles visitantes cadastrados com sua conta";
$lang['usersgroups_custom'] = "Grupos personalizados";
$lang['usersgroups_system'] = "Grupos do sistema";
$lang['usersgroups_guest'] = "Convidado";
$lang['usersgroups_user'] = "Usuário";
$lang['usersgroups_admin'] = "Administrador";
$lang['usersgroups_all'] = "Todos";
$lang['usersgroups_askdel'] = "Você realmente quer excluir o usuário com o grupo de usuários '%s'?";
$lang['usersgroups_codeduplicated'] = "O código do Grupo de Usuários já existe na base de dados. Selecione outro código";
$lang['usersgroups_codenofound'] = "O código de Grupo de Usuários não foi encontrado na base de dados";
$lang['usersgroups_add'] = "Adicionar novo grupo de usuários";
$lang['usersgroups_edit'] = "Editar grupo de usuários";
$lang['usersgroups_del'] = "Apagar grupo de usuários";
$lang['usersgroups_listof'] = "Listar grupo de usuários";

$lang['users_assigninstructions'] = "Esta é a lista de códigos de pacientes para os quais o usuário pode solicitar consultas on-line e ações similares.
Separe os vários códigos de pacientes com um travessão (-)
";
$lang['users_assign'] = "Designar";
$lang['users_assignpatients'] = "Designar Pacientes";
$lang['users_isphysician_note'] = "Caso esse usuário for médico, selecione seu nome no menu";
$lang['users_isphysician'] = "é médico";
$lang['users_groups4user'] = "Grupos para esse usuário";
$lang['users_listof'] = "Lista de Usuários";
$lang['users_smandatorysent'] = "A variável não foi encontrada na senha enviada pela mensagem";
$lang['users_smandatoryforgotten'] = "A variável não foi encontrada na mensagem de senha esquecida";
$lang['users_smandatorynew'] = "Variável não foi encontrada na mensagem de novas contas";
$lang['users_includevarmsg'] = "É obrigatório incluir %s no texto. O mesmo será substituído pela variável correta";
$lang['users_emailsubject'] = "Assunto";
$lang['users_emailmsg'] = "Mensagem";
$lang['users_fromemail'] = "de e-mail";
$lang['users_settingsnew'] = "E-mail de novas contas";
$lang['users_settingsforgotten'] = "E-mail de senha esquecida";
$lang['users_settingsnewpass'] = "E-mail de envio de senha";
$lang['users_settingsmain'] = "Principais configurações";
$lang['users_config'] = "Config";
$lang['users_allownewuser'] = "Permite o registro de novos usuários";
$lang['users_askdel'] = "Você realmente quer excluir o usuário com o nome de usuário '%s'?";
$lang['users_edit'] = "Editar Usuário";
$lang['users_del'] = "Apagar Usuário";
$lang['users_Enable'] = "Habilitar";
$lang['users_Disable'] = "Desabilitar";
$lang['users_activate'] = "Ativar";
$lang['users_groups'] = "Grupos";
$lang['users_statusdisabled'] = "Disabilitar";
$lang['users_statusactive'] = "Ativar";
$lang['users_statuspending'] = "Pendente";
$lang['users_status'] = "Status";
$lang['users_add'] = "Adicionar novo usuário";

$lang['menu_med_caas'] = "C-a-a-S";
$lang['menu_cron'] = "Cron";
$lang['menu_groups'] = "Grupos";
$lang['menu_del'] = "Apagar Menu";
$lang['menu_edit'] = "Editar Menu";
$lang['menu_codenofound'] = "O código de menu não foi encontrado na base de dados";
$lang['menu_id'] = "Código";
$lang['menu_askdel'] = "Você realmente deseja apagar o menu com o código '%s'?";
$lang['menu_weight'] = "Peso";
$lang['menu_options'] = "Selecion a Opção";
$lang['menu_controllers'] = "Selecione o Controle";
$lang['menu_url'] = "Link Url para";
$lang['menu_urlnote'] = "Só digite a url se forem escolhidas opções de link. Para links externos, acrescente 'http://'. Para links internos '%s' será adicionado automaticamente";
$lang['menu_title'] = "Título do menu";
$lang['menu_selcontroller'] = "Controle/opção";
$lang['menu_add'] = "Adicione um novo menu";

$lang['content_askdel'] = "Você realmente deseja apagar o conteúdo com o código '%s'?";
$lang['content_listof'] = "Lista de Conteúdo";
$lang['content_del'] = "Apagar Conteúdo";
$lang['content_edit'] = "Editar Conteúdo";
$lang['content_codenofound'] = "O código de Conteúdo não foi encontrado na base de dados";
$lang['content_codeduplicated'] = "O código de conteúdo já existe na base de dados. Selecione outro código";
$lang['content_content'] = "Digite o conteúdo";
$lang['content_homepage'] = "Coloque na Página Inicial";
$lang['content_add'] = "Adicione o novo conteúdo";
$lang['content_keywords'] = "Palavras-chave";

$lang['settings_noeditor'] = "Sem editor html";
$lang['settings_fckeditor'] = "FCKeditor";
$lang['settings_spaw2'] = "Spaw2";
$lang['settings_cachepages'] = "Páginas de Cachê";
$lang['settings_cachepagesnote'] = "As páginas de cachê permanecerão ativas até expirarem";
$lang['settings_timezone'] = "Fuso Horário";
$lang['settings_htmleditornote'] = "O Javascript deve ser habilitado";
$lang['settings_htmleditor'] = "Use o editor de html";
$lang['settings_footer2'] = "Legenda de pé de página dois";
$lang['settings_footer1'] = "Legenda de pé de página um";
$lang['settings_performance'] = "Desempenho";
$lang['settings_design'] = "Design";
$lang['settings_security'] = "Segurança";
$lang['settings_site'] = "Site Global";
$lang['settings_sessiontime'] = "Tempo da Sessão [minutos]";
$lang['settings_cookiename'] = "Prefixo do Cookie";
$lang['settings_sitekey'] = "Chave do Site";
$lang['settings_cachetime'] = "Tempo de cachê time [minutos]";
$lang['settings_keywords'] = "Palavras-chave";
$lang['settings_charset'] = "CharSet";
$lang['settings_baseurl'] = "Url da base";
$lang['settings_title'] = "Título";
$lang['settings_adminemail'] = "E-mail Admin";
$lang['settings_def'] = "Nessas seções, você pode estabelecer a configuração do seu website";

$lang['blocks_whocansee'] = "Quem pode acessar o bloco";
$lang['blocks_groups'] = "Grupos";
$lang['blocks_file'] = "Arquivo";
$lang['blocks_filenote'] = "Só selecione o bloco se o tipo de arquivo for selecionado";
$lang['blocks_type'] = "Tipo";
$lang['blocks_content'] = "Conteúdo";
$lang['blocks_contentnote'] = "Só digite alguma coisa se o tipo de conteúdo for selecionado";
$lang['blocks_askdel'] = "Você realmente deseja apagar o bloco com o código '%s'?";
$lang['blocks_listof'] = "Lista dos Blocos";
$lang['blocks_codeduplicated'] = "O código do bloco já existe na base de dados. Selecione outro código";
$lang['blocks_codenofound'] = "O código do bloco não foi encontrado na base de dados";
$lang['blocks_add'] = "Adicione um novo bloco";
$lang['blocks_del'] = "Apagar o Bloco";
$lang['blocks_edit'] = "Editar o Bloco";
$lang['blocks_side1'] = "Esquerda";
$lang['blocks_side2'] = "Direita";
$lang['blocks_side3'] = "Centro-em cima";
$lang['blocks_side4'] = "Centro-em baixo";
$lang['blocks_side5'] = "Para cima";
$lang['blocks_side6'] = "Para baixo";
$lang['blocks_side'] = "Lado";


$lang['admins_atleastonesu'] = "Deve haver, pelo menos, um Super Usuário";
$lang['admins_askdel'] = "Você realmente deseja apagar o Administrador com o código '%s'?";
$lang['admins_listof'] = "Lista of Administradores";
$lang['admins_codeduplicated'] = "O código de Administrador já existe na base de dados. Selecione outro código";
$lang['admins_codenofound'] = "O código de Administrador não foi encontrado na base de dados";
$lang['admins_sugetfullaccess'] = "ATENÇÃO: Caso o Super Usuário for verificado, ele/ela obterá acesso total";
$lang['admins_add'] = "Adicionar novo Administrador";
$lang['admins_del'] = "Apagar Administrador";
$lang['admins_edit'] = "Editar Administrador";
$lang['admins_superuser'] = "Super Usuário";
$lang['admins_access'] = "Acesso";
$lang['admins_grantedaccess'] = "Conceder acesso para";
$lang['admins_accessnote'] = "Para definir o acesso pleno para um módulo, digite **<br />Para negar acesso, deixe vazio<br />Para especificar o acesso, digite os nomes das funções separadas por um espaço em branco";

$lang['menu_med_schedule'] = "Programação";
$lang['menu_med_patient'] = "Pacientes";
$lang['menu_med_physician'] = "Médicos";
$lang['menu_med_specialities'] = "Especialidades";
$lang['menu_modules'] = "Módulos";
$lang['menu_usersgroups'] = "Grupos";
$lang['menu_users'] = "Usuários";
$lang['menu_menu'] = "Menu";
$lang['menu_content'] = "Conteúdo";
$lang['menu_admin'] = "Administração";
$lang['menu_admins'] = "Admins";
$lang['menu_cards'] = "Cartões";
$lang['menu_blocks'] = "Blocos";
$lang['menu_settings'] = "Configurações";

$lang['login_title'] = "Log In";
$lang['login_captchanote'] = "Para ajudar a se proteger contra software automático, digite os caracteres que aparecem na caixa abaixo";
$lang['login_alreadylog'] = "Você já está conectado";
$lang['login_logoutsuccess'] = "Você se desconectou com sucesso";
$lang['login_failed'] = "O seu nome de usuário ou senha estão incorretos. Tente novamente";
$lang['login_user'] = "Usuário";
$lang['login_pass'] = "Senha";
$lang['login_captcha'] = "Captcha";
$lang['login_entercaptcha'] = "Digite Captcha";
$lang['login_login'] = "Login";
$lang['login_logout'] = "Logout";
$lang['login_profile'] = "Perfil";

$lang['main_none'] = "Nenhum";
$lang['main_nodata'] = "Sem dados";
$lang['main_waitingdata'] = "Aguardando dados";
$lang['main_lastloginfo'] = "Últimas conexões";
$lang['main_lastip'] = "Do IP";
$lang['main_yourip'] = "Seu IP";
$lang['main_lastlogdate'] = "Data";
$lang['main_ok'] = "ok";
$lang['main_bad'] = "ok";
$lang['main_status'] = "Status";
$lang['main_visible'] = "Visível";
$lang['main_disabled'] = "Disabilitado";
$lang['main_enabled'] = "Habilitado";
$lang['main_pleaseselect'] = "Selecione";
$lang['main_title'] = "Título";
$lang['main_Annonymous'] = "Anônimo";
$lang['main_hello'] = "Oi";
$lang['main_all'] = "Todos";
$lang['main_others'] = "Outros";
$lang['main_module'] = "Módulo";
$lang['main_moduleaccessdenied'] = "Acesso negado. Você não pode acessar essa seção, porque você não está conectado, você não possui os direitos apropriados ou the módulo não está ativo.";
$lang['main_accessdenied'] = "Acesso negado. Você não pode acessar esta seção";

$lang['main_goback'] = "<a href=\"javascript:history.go(-1)\" título='Go Back'>Go Back</a>";

$lang['main_yes'] = "Sim";
$lang['main_no'] = "Não";
$lang['main_functions'] = "Função";
$lang['main_help'] = "Ajuda";
$lang['main_store'] = "Armazenar";
$lang['main_youraccount'] = "Sua Conta";
$lang['main_home'] = "Home";

$lang['admin_ref'] = "Ref";
$lang['admin_defactions'] = "Acima se encontra um sub-menu com todas as ações disponíveis para essa opção. É claro que você só poderá continuar se a sua conta possuir o direito de acesso ou se você for um Super Usuário";
$lang['admin_actions'] = "Ações::";
$lang['admin_settings'] = "Configurações";
$lang['admin_norecords'] = "Não foi encontrado nenhum registro";
$lang['admin_order'] = "Ordem";
$lang['admin_menu'] = "Menu";
$lang['admin_schedule'] = "Programação";
$lang['admin_patients'] = "Pacientes";
$lang['admin_history'] = "Histórico";
$lang['admin_physicians'] = "Médicos";
$lang['admin_usersgroups'] = "Grupos de Usuários";
$lang['admin_users'] = "Usuários";
$lang['admin_content'] = "Conteúdo";
$lang['admin_all'] = "Todos";
$lang['admin_modules'] = "Módulos";
$lang['admin_blocks'] = "Blocos";
$lang['admin_lang'] = "idioma";
$lang['admin_theme'] = "Tema";
$lang['admin_required'] = " <cor da fonte=vermelho>[Requerida]</fonte>";
$lang['admin_allfieldsrequired'] = "Todos os campos são obrigatórios";
$lang['admin_admins'] = "Administradores";
$lang['admin_add'] = "Adicionar";
$lang['admin_edit'] = "Edita";
$lang['admin_del'] = "apagar";
$lang['admin_refresh'] = "Atualizar";
$lang['admin_list'] = "Listar";
$lang['admin_taskok'] = "A tarefa foi realizada com sucesso";
$lang['admin_ignoringtask'] = "Não foi fornecido nenhum parâmetro. Ignorar a tarefa";
$lang['admin_mainmenu'] = "Menu Principal";
$lang['admin_title'] = "Administração";
$lang['admin_login'] = "Login";
$lang['admin_logout'] = "Logout";
$lang['admin_loggedas'] = "Você está conectado como";
$lang['admin_memoryusage'] = "Uso da Memória";
$lang['admin_pagerendering'] = "Reprodução da página";
$lang['admin_seconds'] = "segundos";
$lang['admin_code'] = "Código";
$lang['admin_name'] = "Nome";
$lang['admin_desc'] = "Descrição";
$lang['admin_notes'] = "Notas";
$lang['admin_email'] = "E-mail";
$lang['admin_password'] = "Senha";
$lang['admin_passwordagain'] = "Senha (novamente)";
$lang['admin_enternewpasstochange'] = "Somente se você desejar alterá-la";
$lang['admin_savechanges'] = "Salvar as mudanças";
$lang['admin_cards'] = "Cartões";
$lang['admin_tournaments'] = "Torneios";
$lang['admin_users'] = "Usuários";
$lang['admin_Keywords'] = "Palavras-chave";

?>
