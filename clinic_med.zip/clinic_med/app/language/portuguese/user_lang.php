<?php

/**
 * @file /language/portuguese/user_lang.php
 * @brief File to store translation.
 * 
 * @details English - Users. Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */

$lang['users_modulesgranted'] = "Módulos Concedidos";
$lang['users_nologinallowed'] = "você não pode se conectar porque a sua conta não está ativa.";
$lang['users_cachenote'] = "Quando o nosso site tiver um tráfego intenso; algumas configurações globais de sites irão substituir as suas configurações pessoais para melhorar a velocidade da página.";
$lang['users_nologged'] = "Você não está conectado. Conecte-se";
$lang['users_websettings'] = "configurações do site";
$lang['users_contactinfo'] = "Informações de Contato";
$lang['users_logininfo'] = "Informações de Login";
$lang['users_profile'] = "Perfil";
$lang['users_youraccount'] = "Minha Conta";
$lang['users_newpassmsg'] = "A sua senha foi restaurada e enviada para o seu endereço de e-mail.";
$lang['users_newpass'] = "Nova senha";
$lang['users_resetexpiredthanks'] = "A URL que você forneceu expirou. Solicite a sua senha esquecida novamente para obter outras instruções de e-mail";
$lang['users_resetexpired'] = "A senha de inicialização expirou";
$lang['users_emailforgotstep2'] = "Para iniciar o processo de substituição de senha, siga as instruções enviadas para o seu endereço de e-mail.";
$lang['users_emailsendpass'] = "Enviar Senha";
$lang['users_usernoexist'] = "O nome de usuário informado não existe nos nossos registros";
$lang['users_alreadyknowpass'] = "Já sabe a sua senha?";
$lang['users_emailsendpass'] = "Enviar Senha";
$lang['users_emailforgotmsg'] = "Digite o seu nome de usuário e as instruções para substituir a sua senha serão enviadas para o seu endereço de e-mail, associado à sua conta, em poucos segundos:";
$lang['users_emailreset'] = "Substitua a sua senha";
$lang['users_emailforgot'] = "Esqueceu a sua senha";
$lang['users_emailexpiredthanks'] = "A URL que você forneceu expirou. Entretanto, agradecemos por ter tentado ativar a sua nova conta. Crie uma conta novamente para obter um outro e-mail de verificação";
$lang['users_emailexpired'] = "A ativação de conta expirou";
$lang['users_emailverifiedthanks'] = "Agradecemos você por ter verificado o seu e-mail. A sua conta já foi ativada.";
$lang['users_emailverified'] = "Endereço de e-mail verificado";
$lang['users_alreadyverified'] = "Já verificou?";
$lang['users_nonewaccounts'] = "Desculpe-nos, mas, neste momento, não estamos aceitando novas contas. Caso você já tenha uma conta, você pode se conectar abaixo";
$lang['users_emailverifynote'] = "Para verificar se o seu endereço de e-mail associado com a sua conta está correto, nós enviamos uma mensagem de e-mail para o endereço que você informou. Para ativa a sua nova conta, acesse o seu e-mail e clique no link fornecido.";
$lang['users_emailverify'] = "Verificação de E-mail";
$lang['users_iacceptnote'] = "Ao clicar em  'Eu aceito' abaixo, você concorda com os nossos Termos de Serviço com a Política de Privacidade";
$lang['users_usernametaken'] = "O nome de usuário fornecido já está em uso. Escolha um outro diferente";
$lang['users_createaccount'] = "Eu aceito, Criar Conta";
$lang['users_captchanote'] = "Para ajudar a proteger contra software automatizado, digite os caracteres que aparecem na caixa abaixo";
$lang['users_username'] = "Nome de usuário";
$lang['users_youcansignhere'] = "Log In";
$lang['users_logout'] = "Logout";
$lang['users_ifyouhaveaccount'] = "Já possui uma conta?";
$lang['users_forgot'] = "Esqueceu a Senha";
$lang['users_register'] = "Criar uma conta";//Registro de Membro
$lang['users_cookienote'] = "Para se conectar você precisa habilitar os cookies!";
$lang['users_title'] = "Usuários";

?>
