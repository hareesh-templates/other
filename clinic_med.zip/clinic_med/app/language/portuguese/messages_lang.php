<?php

/**
 * @file /language/portuguese/messages_lang.php
 * @brief File to store translation.
 * 
 * @details English - Private Messages. Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */

$lang['messages_askdel'] = "Você realmente deseja apagar a messagem seguinte?";
$lang['messages_del'] = "Apagar Mensagem";
$lang['messages_delthismsg'] = "Apagar essa mensagem";
$lang['messages_reply'] = "Responder";
$lang['messages_newmsg'] = "nova";
$lang['messages_sent'] = "Enviada";
$lang['messages_msgnotfound'] = "A mensagem não foi encontrada";
$lang['messages_send'] = "Enviar Mensagem";
$lang['messages_message'] = "Mensagem";
$lang['messages_write'] = "Escrever a mensagem";
$lang['messages_date'] = "Data";
$lang['messages_priority'] = "Prioridade";
$lang['messages_subject'] = "Assunto";
$lang['messages_from'] = "De";
$lang['messages_to'] = "Para";
$lang['messages_writeto'] = "Escrever para o usuário";
$lang['messages_inbox'] = "Caixa de Entrada";
$lang['messages_title'] = "Mensagens Privadas";

?>
