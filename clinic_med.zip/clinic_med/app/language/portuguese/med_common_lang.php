<?php

/**
 * @file /language/portuguese/med_common_lang.php
 * @brief File to store translation.
 * 
 * @details English - Med Modules (appointment, consultation, diagnostic, etc). Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */

$lang['consultation_nopending'] = "Não há consultas pendentes";
$lang['consultation_patients'] = "Meus pacientes";
$lang['consultation_patientnofound'] = "O código do paciente não foi encontrado na base de dados ou não está mais atribuído a você";
$lang['consultation_add'] = "Adicionar Consulta";
$lang['consultation_myconsultations'] = "Minhas consultas";
$lang['consultation_add_bymed'] = "Solicite por Médico";
$lang['consultation_add_byspe'] = "Solicite por Especialidade";
$lang['consultation_title'] = "Consultas On-line";
$lang['consultation_instructions'] = "Com este módulo, você pode solicitar consultas on-line, as quais a nossa equipe irá marcar, o mais rápido possível
";
$lang['consultation_patients_noassigned'] = "Para solicitar consultas on-line, você deve ter os seus pacientes vinculados à sua conta.
No momento, você não possui nenhum; assim, entre em contato com administrador do site, que irá configurar a sua conta da maneira adequada.

Enquanto isso, você pode entrar em contato conosco por telefone ou por e-mail";


$lang['medcaas_uninstallnotes'] = "Esta opção desinstala o Clinic as a Service (CAAS).

<b>Este procedimento NÃO é reversível. Faça um back-up da sua base de dados, antes de continuar!!</b>

Se tudo estiver ok, este procedimento:

- Removerá todos os dados e tabelas, onde o prefixo for igual ao código CAAS.
- Apagará o diretório, onde o CAAS estiver instalado

<b>Este procedimento NÃO é reversível. Faça um back-up da sua base de dados, antes de continuar!!</b>
";

$lang['medcaas_installnotes'] = "Esta opção instala um novo Clinic as a Service (CAAS).

Se tudo estiver ok, este procedimento:

- Cria um novo diretório, o qual poderá ser acessado por intermédio de http://yourclinicdomain.com/code_new_clinic
- Descompactar o arquivo CAAS compactado naquele diretório
- Cria os arquivos config para o novo CAAS
- Importa o arquivo SQL CAAS para criar as novas tabelas; usando o acesso de base de dados fornecidos e o código CAAS como prefixo de tabelas

- <b>O login admin inicial é usuário='admin' senha='123456', ambos sem as aspas</b>
";

$lang['medcaas_err_tablesexists'] = "Algumas tabelas, nas quais já exista o prefixo CAAS na base de dados. Selecione outro código";
$lang['medcaas_err_deldb'] = "Erro ao tentar apagar os dados e as tabelas";
$lang['medcaas_err_deldir'] = "Erro ao tentar apagar o diretório '%s'";
$lang['medcaas_codenofound'] = "O código do Clinic as a Service não foi encontrado na base de dados";
$lang['medcaas_link'] = "Link";
$lang['medcaas_created'] = "Criado";
$lang['medcaas_sqlnotread'] = "O arquivo sql '%s' para ocupar a base de dados não pode ser lido";
$lang['medcaas_zipnotread'] = "O arquivo compactado '%s' não pode ser lido";
$lang['medcaas_unableimportsql'] = "Erro ao tentar importar o arquivo sql '%s' para a base de dados";
$lang['medcaas_indexerror'] = "Erro ao tentar criar o arquivo index.php";
$lang['medcaas_cfgerror'] = "Erro ao tentar criar o arquivo config principal";
$lang['medcaas_cfgdberror'] = "Erro ao tentar criar o arquivo config da base de dados";
$lang['medcaas_unabletousedb'] = "Erro ao tentar se conectar com a base de dados com os dados fornecidos";
$lang['medcaas_unablecreatedir'] = "Erro ao tentar criar o diretório '%s'";
$lang['medcaas_unabletounzip'] = "Erro ao tentar descompactar '%s' em '%s'";
$lang['medcaas_sqlnotexist'] = "O arquivo SQL '%s' para preencher a base de dados não existe";
$lang['medcaas_zipnotexist'] = "O arquivo compactado '%s' não existe";
$lang['medcaas_zipnoloaded'] = "A extensão PHP Zip não foi carregada";
$lang['medcaas_php5required'] = "PHP 5 ou maior é necessário para manipular o arquivo compactado";
$lang['medcaas_nowriteable'] = "o diretório alvo '%s' não é gravável";
$lang['medcaas_codeindirectory'] = "O código Clinic Service já existe no diretório alvo. Selecione outro código";
$lang['medcaas_database'] = "Nome da base de dados";
$lang['medcaas_host'] = "Anfitrião";
$lang['medcaas_username'] = "Nome de usuário";
$lang['medcaas_password'] = "Senha";
$lang['medcaas_codeduplicated'] = "O código Clinic Service já existe no diretório alvo. Selecione outro código";
$lang['medcaas_status'] = "Status de Instalação";
$lang['medcaas_title'] = "Clinic as a Service";

$lang['patientsearch_noresults'] = "Sem resultados";
$lang['patientsearch_new'] = "Nova pesquisa";
$lang['patientsearch_patient'] = "Pesquisar paciente";
$lang['patientsearch_physician'] = "Médico";
$lang['patientsearch_speciality'] = "Especialidade";
$lang['patientsearch_title'] = "Pesquisa de Paciente";

$lang['medhistory_print_friendly'] = "Adaptado para imprimir";
$lang['medhistory_summary'] = "Resumo";
$lang['medhistory_history'] = "Histórico";
$lang['medhistory_empty'] = "Histórico médico vazio";
$lang['medhistory_empty'] = "Histórico médico vazio";
$lang['medhistory_title'] = "Histórico do Paciente";

$lang['diagnostic_askremove'] = "Você realmente deseja remover o diagnóstico 'Ref-%s'?";
$lang['diagnostic_askdel'] = "Você realmente deseja apagar o diagnóstico 'Ref-%s'?";
$lang['diagnostic_delete'] = "Apagar";
$lang['diagnostic_remove'] = "Remover";
$lang['diagnostic_cancel'] = "Cancelar";
$lang['diagnostic_actions'] = "Ações";
$lang['diagnostic_physician'] = "Médico";
$lang['diagnostic_patient'] = "Paciente";
$lang['diagnostic_speciality'] = "Especialidade";
$lang['diagnostic_ins_cid'] = "Adicionar ICD";
$lang['diagnostic_ins_file'] = "Anexar Arquivo";
$lang['diagnostic_ins_diagnostic'] = "Diagnóstico";
$lang['diagnostic_appoinmnets'] = "Consultas";
$lang['diagnostic_appoinmnet']  = "Consulta";
$lang['diagnostic_appoinmnetnofound'] = "Não foi encontrada nenhuma consulta aberta";
$lang['diagnostic_notapppoinments'] = "Você não possui consultas pendentes";
$lang['diagnostic_diagnostic'] = "Diagnóstico";
$lang['diagnostic_attach'] = "Anexar arquivo";
$lang['diagnostic_attach_desc'] = "Anexar Descrição";
$lang['diagnostic_download'] = "Download";
$lang['diagnostic_attachnotfound'] = "Anexo não encontrado";
$lang['diagnostic_cid'] = "ICD";
$lang['diagnostic_cidtype'] = "Digita algumas tarefas ou código ICD para obter uma lista de classificação internacional de Doenças. ex.: A00, coração, cérebro, etc.";
$lang['diagnostic_handle'] = "Manipular";
$lang['diagnostic_no_appointment'] = "Diagnóstico sem consulta";
$lang['diagnostic_today'] = "Hoje";
$lang['diagnostic_nopatients'] = "Nenhum paciente para hoje";
$lang['diagnostic_title'] = "Diagnóstico do Paciente";

$lang['appointment_online'] = "Solicitações On-line";
$lang['appointment_add_bymed'] = "Adicionar por Médico";
$lang['appointment_add_byspe'] = "Adicionar por Especialidade";
$lang['appointment_done'] = "Feito";
$lang['appointment_end'] = "Fim";
$lang['appointment_begin'] = "Começar";
$lang['appointment_consultation'] = "Em Consulta";
$lang['appointment_dr'] = "Dr.";
$lang['appointment_atlobby'] = "Na recepção";
$lang['appointment_cancel'] = "Cancelar";
$lang['appointment_canceled'] = "Cancelada";
$lang['appointment_pending'] = "Pendente";
$lang['appointment_confirmed'] = "Confirmada";
$lang['appointment_confirm'] = "Confirmar";
$lang['appointment_askend'] = "Você realmente deseja finalizar a consulta 'Ref-%s'?";
$lang['appointment_timenoavailable'] = "A data e a hora selecionados não estão mais disponíveis";
$lang['appointment_searchpatienttip'] = "Digite alguns caracteres para pesquisar por código, nome, e-mail ou notas";
$lang['appointment_enter3chars'] = "Digite alguns caracteres";
$lang['appointment_del'] = "Apagar Consulta";
$lang['appointment_askdel'] = "Você realmente deseja apagar a consulta 'Ref-%s'?";
$lang['appointment_askcancel'] = "Você realmente deseja cancelar a consulta 'Ref-%s'?";
$lang['appointment_askconfirm'] = "Você realmente deseja confirmar a solicitação on-ine 'Ref-%s'?";
$lang['appointment_add'] = "Adicionar Consulta";
$lang['appointment_title'] = "Consultas";

$lang['schedule_filter'] = "Filtro";
$lang['schedule_interval'] = "Intervalo [minutos]";
$lang['schedule_invalid_day'] = "O dia não é uma variação de tempo válida";
$lang['schedule_invalid_time'] = "A hora não uma varia de tempo válida";
$lang['schedule_addschedule'] = "Adicionar Programação";
$lang['schedule_empty'] = "Vazio";
$lang['schedule_busy'] = "Ocupado";
$lang['schedule_available'] = "Disponível";
$lang['schedule_noneforday'] = "Nenhuma programação encontrada para este dia";
$lang['schedule_gotoday'] = "Vá para hoje";
$lang['schedule_name'] = "Programação";
$lang['schedule_askdel'] = "Você realmente deseja apagar a programação com o código '%s'?";
$lang['schedule_edit'] = "Editar Programação";
$lang['schedule_del'] = "Apagara Programação";
$lang['schedule_listof'] = "Lista de Programações";
$lang['schedule_codenofound'] = "A programação não pode ser encontradas na base de dados";
$lang['schedule_codeduplicated'] = "O ´código da programação já existe na base de dados. Selecione outro código";
$lang['schedule_add'] = "Adicionar uma nova programação";
$lang['schedule_to'] = "Para";
$lang['schedule_from'] = "De";
$lang['schedule_time'] = "Hora";
$lang['schedule_date'] = "Data";
$lang['schedule_day'] = "Dia";
$lang['schedule_hour'] = "Hora";
$lang['schedule_hours'] = "Houras";
$lang['schedule_minute'] = "Minuto";
$lang['schedule_minutes'] = "Minutos";
$lang['schedule_howlong'] = "Quanto tempo";
$lang['schedule_interval'] = "Intervalo";


$lang['patient_responsable'] = "Responsável";
$lang['patient_spouse'] = "Cônjuge";
$lang['patient_mother'] = "Mãe";
$lang['patient_father'] = "Pai";
$lang['patient_mobirth_d'] = "Dia de nascimento da mãe";
$lang['patient_mobirth_m'] = "Mês de nascimento da mãe";
$lang['patient_mobirth_y'] = "Ano de nascimento da mãe";
$lang['patient_fabirth_d'] = "Dia de nascimento do pai";
$lang['patient_fabirth_m'] = "Mês de nascimento do pai";
$lang['patient_fabirth_y'] = "Ano de nascimento do pai";
$lang['patient_mobirth'] = "Data de Nascimento da Mãe";
$lang['patient_fabirth'] = "Data de Nascimento do Pai";

$lang['patient_family'] = "Família";
$lang['patient_profession'] = "Profissão";
$lang['patient_bloob_group'] = "Grupo sanguíneo";
$lang['patient_insurance_number'] = "Número do seguro";
$lang['patient_insurance_type'] = "Tipo de seguro";
$lang['patient_failbirth'] = "Data de nascimento inválida";
$lang['patient_failmotherbirth'] = "A data de nascimento da mãe é inválida";
$lang['patient_failfatherbirth'] = "A data de nascimento do pai é inválida";
$lang['patient_contactto'] = "Contatar";
$lang['patient_otherphone'] = "Outro telefone";
$lang['patient_mobilphone'] = "Telefone celular";
$lang['patient_businessphone'] = "Telefone comercial";
$lang['patient_homephone'] = "Telefone residencial";
$lang['patient_contact'] = "Contato";
$lang['patient_bussinessaddress'] = "Endereço Comercial";
$lang['patient_general'] = "Geral";
$lang['patient_homeaddress'] = "Endereço Residencial";
$lang['patient_othersignals'] = "Outras informações";
$lang['patient_country'] = "País";
$lang['patient_zipcode'] = "Código Postal";
$lang['patient_state'] = "Estado";
$lang['patient_city'] = "Cidade";
$lang['patient_street'] = "Rua";
$lang['patient_gender_m'] = "Masculino";
$lang['patient_gender_f'] = "Feminino";
$lang['patient_gender'] = "Gênero";
$lang['patient_birth_d'] = "Dia do Nascimento";
$lang['patient_birth_m'] = "Mês do Nascimento";
$lang['patient_birth_y'] = "Ano do Nascimento";
$lang['patient_birth'] = "Data de Nascimento";
$lang['patient_reghosp'] = "Registro do Hospital";
$lang['patient_id1'] = "Identidade Pessoal";

$lang['patient_detail'] = "Detalhes";
$lang['patient_details'] = "Detalhes do paciente";
$lang['patient_datecreated'] = "Data da criação";
$lang['patient_patientsshown'] = "Pacientes Mostrados";
$lang['patient_patient'] = "Paciente";
$lang['patient_code'] = "Código";
$lang['patient_askdel'] = "Você realmente quer apagar o paciente com o código '%s'?";
$lang['patient_edit'] = "Editar Paciente";
$lang['patient_del'] = "Apagar Paciente";
$lang['patient_listof'] = "Lista de Pacientes";
$lang['patient_codenofound'] = "O código do paciente não foi encontrado na base de dados";
$lang['patient_codeduplicated'] = "O código do paciente já existe na base de dados. Selecione outro código";
$lang['patient_add'] = "Adicionar um novo paciente";

$lang['physician_failbirth'] = "A data de nascimento é inválida";
$lang['physician_contactto'] = "Contate";
$lang['physician_otherphone'] = "Outro telefone";
$lang['physician_mobilphone'] = "Telefone celular";
$lang['physician_businessphone'] = "Telefone comercial";
$lang['physician_homephone'] = "Telefone residencial";
$lang['physician_contact'] = "Contato";
$lang['physician_bussinessaddress'] = "Endereço Comercial";
$lang['physician_general'] = "Geral";
$lang['physician_homeaddress'] = "Endereço Residencial";
$lang['physician_othersignals'] = "Outras informações";
$lang['physician_country'] = "País";
$lang['physician_zipcode'] = "Código Postal";
$lang['physician_state'] = "Estado";
$lang['physician_city'] = "Cidade";
$lang['physician_street'] = "Rua";
$lang['physician_gender_m'] = "Masculino";
$lang['physician_gender_f'] = "Feminino";
$lang['physician_gender'] = "Gênero";
$lang['physician_birth_d'] = "Dia do Nascimento";
$lang['physician_birth_m'] = "Mês do Nascimento";
$lang['physician_birth_y'] = "Ano do Nascimento";
$lang['physician_birth'] = "Data de Nascimento";
$lang['physician_regprof'] = "Registro Profissional";
$lang['physician_id1'] = "Identidade Pessoal";
$lang['physician_youarentdr'] = "Você não é médico";
$lang['physician_title'] = "Médicos";
$lang['physician_physician'] = "Médico";
$lang['physician_askdel'] = "Você realmente deseja apagar o médico com o código '%s'?";
$lang['physician_edit'] = "Editar Médico";
$lang['physician_del'] = "Apagar Médico";
$lang['physician_listof'] = "Lista de Médicos";
$lang['physician_codenofound'] = "O código do médico não foi encontrado na base de dados";
$lang['physician_codeduplicated'] = "O código do médico já existe na base de dados. Selecione outro código";
$lang['physician_add'] = "Adiconar um novo médico";
$lang['physician_details'] = "Detalhes";

$lang['specialities_askdel'] = "Você realmente deseja apagar a especialidade com o código '%s'?";
$lang['specialities_del'] = "Apagar a especialidade";
$lang['specialities_edit'] = "Edita a Especialidade";
$lang['specialities_codeduplicated'] = "O código da especialidade já existe na base de dados. Selecione outro código";
$lang['specialities_codenofound'] = "O código da especialidade não foi encontrado na base de dados";
$lang['specialities_add'] = "Adicionar especialidade";
$lang['specialities_listof'] = "Lista de especialidades";
$lang['specialities_please_select'] = "Selecione a especialidade";
$lang['specialities_code'] = "Código";
$lang['specialities_name'] = "Especialidade";
$lang['specialities_title'] = "Especialidades";

$lang['med_functions'] = "Funções";
$lang['med_actions'] = "Ações";
$lang['med_add'] = "Adicionar";
$lang['med_edit'] = "Editar";
$lang['med_delete'] = "Apagar";
$lang['med_list'] = "Listar";

?>
