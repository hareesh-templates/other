<?php

/**
 * @file /language/english/cron_lang.php
 * @brief File to store translation.
 * 
 * @details English - Cron. Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */

$lang['run_notify_next_appointments'] = "Send an email to all physicians who have next day appointments";
$lang['cron_appointment_regards'] = "Regards";
$lang['cron_appointment_subject'] = "Subject";
$lang['cron_appointment_to'] = "To Dr.";
$lang['cron_appointment_msg'] = "Please find your next appointments below";
$lang['cron_appointment_msglittle'] = "Your next appointments";

$lang['cron_noexists'] = "Cron job does not exists";
$lang['cron_disabled'] = "Cron job is disabled";
$lang['cron_instructions'] = "Check those cron jobs you want to run. Note that checking only enable/disable the cron job, but DO NOT create the crontab (periodical schedule). GOTO your control panel and add the crontab manually for each cron job desired.";
$lang['cron_function'] = "Cron function";
$lang['cron_tittle'] = "Cron Jobs";
$lang['cron_list'] = "List of Jobs";
$lang['cron_command'] = "Setup crontab using next command";
$lang['cron_runmanually'] = "Run manually";

?>
