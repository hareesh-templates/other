<?php

/**
 * @file /language/english/content_lang.php
 * @brief File to store translation.
 * 
 * @details English - content module. Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */

$lang['content_relevancy'] = "Relevancy";
$lang['content_noresults'] = "No results";
$lang['content_search'] = "Search Articles";
$lang['content_title'] = "Articles";
$lang['content_noavailable'] = "Article with code '%s' is no available";
$lang['content_title'] = "Articles";
$lang['content_created'] = "Created";
$lang['content_modified'] = "Modified";

?>
