<?php

/**
 * @file /language/english/med_common_lang.php
 * @brief File to store translation.
 * 
 * @details English - Med Modules (appointment, consultation, diagnostic, etc). Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */

$lang['consultation_nopending'] = "There is not pending consultations";
$lang['consultation_patients'] = "My patients";
$lang['consultation_patientnofound'] = "Patient code not found in database or is not longer assigned to you";
$lang['consultation_add'] = "Add Consultation";
$lang['consultation_myconsultations'] = "My consultations";
$lang['consultation_add_bymed'] = "Ask by Physician";
$lang['consultation_add_byspe'] = "Ask by Speciality";
$lang['consultation_title'] = "Online consultations";
$lang['consultation_instructions'] = "With this module you can ask for online consultations, which our staff will handle as soon as possible
";
$lang['consultation_patients_noassigned'] = "In order to ask for online consultations you must have your patients assigned with your account.
At this moment you don't have any; so please contact the site manager who will setup properly your account.

Meanwhile you can contact us by phone or email
";


$lang['medcaas_uninstallnotes'] = "This option uninstalls a Clinic MED as a Service (CAAS).

<b>This procedure is NOT reversible. Backup your database before continue!!</b>

If all is ok, this procedure:

- Drop all data and tables where the prefix is equal to the CAAS code.
- Delete the directory where the CAAS is installed

<b>This procedure is NOT reversible. Backup your database before continue!!</b>
";

$lang['medcaas_installnotes'] = "This option installs a new Clinic MED as a Service (CAAS).

If all is ok, this procedure:

- Create de new directory, which will be accessible through http://yourdomain.com/code_new_clinic
- Unzip de zipped CAAS file into that directory
- Create the config files for the new CAAS
- Import the SQL CAAS file to create the new tables; using the database access provided and the CAAS code as tables prefix

- <b>The initial admin login is user='admin' password='123456' both without quotes</b>
";

$lang['medcaas_err_tablesexists'] = "Some tables with that CAAS prefix already exists on DB. Select another code";
$lang['medcaas_err_deldb'] = "Error when trying to delete data and tables";
$lang['medcaas_err_deldir'] = "Error when trying to delete the directory '%s'";
$lang['medcaas_codenofound'] = "Clinic MED as a Service code not found in database";
$lang['medcaas_link'] = "Link";
$lang['medcaas_created'] = "Created";
$lang['medcaas_sqlnotread'] = "The sql file '%s' to populate the database is not readable";
$lang['medcaas_zipnotread'] = "The zipped file '%s' is not readable";
$lang['medcaas_unableimportsql'] = "Error when trying to import the sql file '%s' into database";
$lang['medcaas_indexerror'] = "Error when trying to create the index.php file";
$lang['medcaas_cfgerror'] = "Error when trying to create the main config file";
$lang['medcaas_cfgdberror'] = "Error when trying to create the database config file %s";
$lang['medcaas_unabletousedb'] = "Error when trying to connect to the database with data provided";
$lang['medcaas_unablecreatedir'] = "Error when trying to create '%s' directory";
$lang['medcaas_unabletounzip'] = "Error when trying to unzip '%s' into '%s'";
$lang['medcaas_sqlnotexist'] = "The SQL file '%s' to populate the database does not exists";
$lang['medcaas_zipnotexist'] = "The zipped file '%s' does not exists";
$lang['medcaas_zipnoloaded'] = "PHP Zip extension was not loaded";
$lang['medcaas_php5required'] = "PHP 5 or greater is required to handle the zipped file";
$lang['medcaas_nowriteable'] = "The target directory '%s' is not writeable";
$lang['medcaas_codeindirectory'] = "Clinic MED Service code already exist on target directory. Select another code";
$lang['medcaas_database'] = "Database name";
$lang['medcaas_host'] = "Host";
$lang['medcaas_username'] = "Username";
$lang['medcaas_password'] = "Password";
$lang['medcaas_codeduplicated'] = "Clinic MED Service code already exist on database. Select another code";
$lang['medcaas_status'] = "Install status";
$lang['medcaas_title'] = "Clinic MED as a Service";

$lang['patientsearch_noresults'] = "No results";
$lang['patientsearch_new'] = "New Search";
$lang['patientsearch_patient'] = "Search for patient";
$lang['patientsearch_physician'] = "Physician";
$lang['patientsearch_speciality'] = "Speciality";
$lang['patientsearch_title'] = "Patient Search";

$lang['medhistory_print_friendly'] = "Printer Friendly";
$lang['medhistory_summary'] = "Summary";
$lang['medhistory_history'] = "History";
$lang['medhistory_empty'] = "Medical history empty";
$lang['medhistory_empty'] = "Medical history empty";
$lang['medhistory_title'] = "Patient History";

$lang['diagnostic_askremove'] = "Really do you want to remove diagnostic 'Ref-%s'?";
$lang['diagnostic_askdel'] = "Really do you want to delete diagnostic 'Ref-%s'?";
$lang['diagnostic_delete'] = "Delete";
$lang['diagnostic_remove'] = "Remove";
$lang['diagnostic_cancel'] = "Cancel";
$lang['diagnostic_actions'] = "actions";
$lang['diagnostic_physician'] = "Physician";
$lang['diagnostic_patient'] = "Patient";
$lang['diagnostic_speciality'] = "Speciality";
$lang['diagnostic_ins_cid'] = "Add ICD";
$lang['diagnostic_ins_file'] = "Attach File";
$lang['diagnostic_ins_diagnostic'] = "Diagnostic";
$lang['diagnostic_appoinmnets'] = "Appointments";
$lang['diagnostic_appoinmnet']  = "Appointment";
$lang['diagnostic_appoinmnetnofound'] = "No open appoinment found";
$lang['diagnostic_notapppoinments'] = "You don't have pending appointments";
$lang['diagnostic_diagnostic'] = "Diagnostic";
$lang['diagnostic_attach'] = "Attach File";
$lang['diagnostic_attach_desc'] = "Attach Description";
$lang['diagnostic_download'] = "Download";
$lang['diagnostic_attachnotfound'] = "Attach not found";
$lang['diagnostic_cid'] = "ICD";
$lang['diagnostic_cidtype'] = "Type some chars or ICD code to get a list of International Classification of Diseases. ie: A00, heart, brain, etc";
$lang['diagnostic_handle'] = "Handle";
$lang['diagnostic_no_appointment'] = "Diagnostic without appointment";
$lang['diagnostic_today'] = "Today";
$lang['diagnostic_nopatients'] = "No patients for today";
$lang['diagnostic_title'] = "Patient Diagnostic";

$lang['appointment_online'] = "Online Requests";
$lang['appointment_add_bymed'] = "Add by Physician";
$lang['appointment_add_byspe'] = "Add by Speciality";
$lang['appointment_done'] = "Done";
$lang['appointment_end'] = "End";
$lang['appointment_begin'] = "Begin";
$lang['appointment_consultation'] = "In Consultation";
$lang['appointment_dr'] = "Dr.";
$lang['appointment_atlobby'] = "At lobby";
$lang['appointment_cancel'] = "Cancel";
$lang['appointment_canceled'] = "Canceled";
$lang['appointment_pending'] = "Pending";
$lang['appointment_confirmed'] = "Confirmed";
$lang['appointment_confirm'] = "Confirm";
$lang['appointment_askend'] = "Really do you want to end apppointment 'Ref-%s'?";
$lang['appointment_timenoavailable'] = "Date and time selected is not longer available";
$lang['appointment_searchpatienttip'] = "Enter some chars to search by code, name, email or notes";
$lang['appointment_enter3chars'] = "Enter some chars";
$lang['appointment_del'] = "Delete Appointment";
$lang['appointment_askdel'] = "Really do you want to delete apppointment 'Ref-%s'?";
$lang['appointment_askcancel'] = "Really do you want to cancel apppointment 'Ref-%s'?";
$lang['appointment_askconfirm'] = "Really do you want to confirm the online request 'Ref-%s'?";
$lang['appointment_add'] = "Add Appointment";
$lang['appointment_title'] = "Appointments";

$lang['schedule_filter'] = "Filter";
$lang['schedule_interval'] = "Interval [minutes]";
$lang['schedule_invalid_day'] = "Day is not a valid time range";
$lang['schedule_invalid_time'] = "Time is not a valid time range";
$lang['schedule_addschedule'] = "Add Schedule";
$lang['schedule_empty'] = "Empty";
$lang['schedule_busy'] = "Busy";
$lang['schedule_available'] = "Available";
$lang['schedule_noneforday'] = "No schedules found for this day";
$lang['schedule_gotoday'] = "Go today";
$lang['schedule_name'] = "Schedule";
$lang['schedule_askdel'] = "Really do you want to delete schedule with code '%s'?";
$lang['schedule_edit'] = "Edit Schedule";
$lang['schedule_del'] = "Delete Schedule";
$lang['schedule_listof'] = "List of Schedules";
$lang['schedule_codenofound'] = "Schedule code not found in database";
$lang['schedule_codeduplicated'] = "Schedule code already exist on database. Select another code";
$lang['schedule_add'] = "Add new Schedule";
$lang['schedule_to'] = "To";
$lang['schedule_from'] = "From";
$lang['schedule_time'] = "Time";
$lang['schedule_date'] = "Date";
$lang['schedule_day'] = "Day";
$lang['schedule_hour'] = "Hour";
$lang['schedule_hours'] = "Hours";
$lang['schedule_minute'] = "Minute";
$lang['schedule_minutes'] = "Minutes";
$lang['schedule_howlong'] = "How long";
$lang['schedule_interval'] = "Interval";


$lang['patient_responsable'] = "Responsable";
$lang['patient_spouse'] = "Spouse";
$lang['patient_mother'] = "Mother";
$lang['patient_father'] = "Father";
$lang['patient_mobirth_d'] = "Mother birth Day";
$lang['patient_mobirth_m'] = "Mother birth Month";
$lang['patient_mobirth_y'] = "Mother birth Year";
$lang['patient_fabirth_d'] = "Father birth Day";
$lang['patient_fabirth_m'] = "Father birth Month";
$lang['patient_fabirth_y'] = "Father birth Year";
$lang['patient_mobirth'] = "Mother Birth";
$lang['patient_fabirth'] = "Father Birth";

$lang['patient_family'] = "Family";
$lang['patient_profession'] = "Profession";
$lang['patient_bloob_group'] = "Blood group";
$lang['patient_insurance_number'] = "Insurance number";
$lang['patient_insurance_type'] = "Insurance type";
$lang['patient_failbirth'] = "The birth date is invalid";
$lang['patient_failmotherbirth'] = "The mother birth date is invalid";
$lang['patient_failfatherbirth'] = "The father birth date is invalid";
$lang['patient_contactto'] = "Contact to";
$lang['patient_otherphone'] = "Other phone";
$lang['patient_mobilphone'] = "Mobil phone";
$lang['patient_businessphone'] = "Business phone";
$lang['patient_homephone'] = "Home phone";
$lang['patient_contact'] = "Contact";
$lang['patient_bussinessaddress'] = "Bussiness Address";
$lang['patient_general'] = "General";
$lang['patient_homeaddress'] = "Home Address";
$lang['patient_othersignals'] = "Other signals";
$lang['patient_country'] = "Country";
$lang['patient_zipcode'] = "Zip Code";
$lang['patient_state'] = "State";
$lang['patient_city'] = "City";
$lang['patient_street'] = "Street";
$lang['patient_gender_m'] = "Male";
$lang['patient_gender_f'] = "Female";
$lang['patient_gender'] = "Gender";
$lang['patient_birth_d'] = "Birth Day";
$lang['patient_birth_m'] = "Birth Month";
$lang['patient_birth_y'] = "Birth Year";
$lang['patient_birth'] = "Birth";
$lang['patient_reghosp'] = "Hospital's register";
$lang['patient_id1'] = "Personal ID";

$lang['patient_detail'] = "Details";
$lang['patient_details'] = "Patient details";
$lang['patient_datecreated'] = "Date created";
$lang['patient_patientsshown'] = "Patients Shown";
$lang['patient_patient'] = "Patient";
$lang['patient_code'] = "Code";
$lang['patient_askdel'] = "Really do you want to delete patient with code '%s'?";
$lang['patient_edit'] = "Edit Patient";
$lang['patient_del'] = "Delete Patient";
$lang['patient_listof'] = "List of Patients";
$lang['patient_codenofound'] = "Patient code not found in database";
$lang['patient_codeduplicated'] = "Patient code already exist on database. Select another code";
$lang['patient_add'] = "Add new Patient";

$lang['physician_failbirth'] = "The birth date is invalid";
$lang['physician_contactto'] = "Contact to";
$lang['physician_otherphone'] = "Other phone";
$lang['physician_mobilphone'] = "Mobil phone";
$lang['physician_businessphone'] = "Business phone";
$lang['physician_homephone'] = "Home phone";
$lang['physician_contact'] = "Contact";
$lang['physician_bussinessaddress'] = "Bussiness Address";
$lang['physician_general'] = "General";
$lang['physician_homeaddress'] = "Home Address";
$lang['physician_othersignals'] = "Other signals";
$lang['physician_country'] = "Country";
$lang['physician_zipcode'] = "Zip Code";
$lang['physician_state'] = "State";
$lang['physician_city'] = "City";
$lang['physician_street'] = "Street";
$lang['physician_gender_m'] = "Male";
$lang['physician_gender_f'] = "Female";
$lang['physician_gender'] = "Gender";
$lang['physician_birth_d'] = "Birth Day";
$lang['physician_birth_m'] = "Birth Month";
$lang['physician_birth_y'] = "Birth Year";
$lang['physician_birth'] = "Birth";
$lang['physician_regprof'] = "Register Professional";
$lang['physician_id1'] = "Personal ID";
$lang['physician_youarentdr'] = "You are no physician";
$lang['physician_title'] = "Physicians";
$lang['physician_physician'] = "Physician";
$lang['physician_askdel'] = "Really do you want to delete physician with code '%s'?";
$lang['physician_edit'] = "Edit Physician";
$lang['physician_del'] = "Delete Physician";
$lang['physician_listof'] = "List of Physicians";
$lang['physician_codenofound'] = "Physician code not found in database";
$lang['physician_codeduplicated'] = "Physician code already exist on database. Select another code";
$lang['physician_add'] = "Add new Physician";
$lang['physician_details'] = "Details";

$lang['specialities_askdel'] = "Really do you want to delete speciality with code '%s'?";
$lang['specialities_del'] = "Delete Speciality";
$lang['specialities_edit'] = "Edit Speciality";
$lang['specialities_codeduplicated'] = "Speciality code already exists on database. Select another code";
$lang['specialities_codenofound'] = "Speciality code not found in database";
$lang['specialities_add'] = "Add Speciality";
$lang['specialities_listof'] = "List of specialities";
$lang['specialities_please_select'] = "Please select speciality";
$lang['specialities_code'] = "Code";
$lang['specialities_name'] = "Speciality";
$lang['specialities_title'] = "Specialities";

$lang['med_functions'] = "Functions";
$lang['med_actions'] = "Actions";
$lang['med_add'] = "Add";
$lang['med_edit'] = "Edit";
$lang['med_delete'] = "Delete";
$lang['med_list'] = "List";

?>
