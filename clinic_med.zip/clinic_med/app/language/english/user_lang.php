<?php

/**
 * @file /language/english/user_lang.php
 * @brief File to store translation.
 * 
 * @details English - Users. Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */

$lang['users_modulesgranted'] = "Granted Modules";
$lang['users_nologinallowed'] = "You cannot log in because your account is not active.";
$lang['users_cachenote'] = "When our site have big traffic; some global website settings would overwrite your personal website settings to improve pages speed.";
$lang['users_nologged'] = "You are not logged. Please Log In";
$lang['users_websettings'] = "Website Settings";
$lang['users_contactinfo'] = "Contact Information";
$lang['users_logininfo'] = "Login Information";
$lang['users_profile'] = "Profile";
$lang['users_youraccount'] = "My Account";
$lang['users_newpassmsg'] = "Your password have been reset and it was sent to your email address.";
$lang['users_newpass'] = "New password";
$lang['users_resetexpiredthanks'] = "The URL you provided has expired. Please ask your forgotten password again to get another instructions email";
$lang['users_resetexpired'] = "Reset password expired";
$lang['users_emailforgotstep2'] = "To initiate the password reset process, please follow the instructions sent to your email address.";
$lang['users_emailsendpass'] = "Send Password";
$lang['users_usernoexist'] = "Username entered does not exists in our records";
$lang['users_alreadyknowpass'] = "Already know your password?";
$lang['users_emailsendpass'] = "Send Password";
$lang['users_emailforgotmsg'] = "Please enter your user name and instructions to reset your password will be sent to the email address associated with your account in a matter of seconds:";
$lang['users_emailreset'] = "Reset your password";
$lang['users_emailforgot'] = "Forgotten password";
$lang['users_emailexpiredthanks'] = "The URL you provided has expired. However, thank you for trying to activate your new account. Please create an account again to get another verification email";
$lang['users_emailexpired'] = "Account activation expired";
$lang['users_emailverifiedthanks'] = "Thank you for verifying your email. Your account is now activated.";
$lang['users_emailverified'] = "Email Address Verified";
$lang['users_alreadyverified'] = "Already have verified?";
$lang['users_nonewaccounts'] = "We apologize but at this moment we are not accepting new accounts. If you already have an account, you can log in below";
$lang['users_emailverifynote'] = "In order to verify that the email address associated with your account is correct, we have sent an email message to the address you entered. To activate your new account, please access your email and click on the link provided.";
$lang['users_emailverify'] = "Email Verification";
$lang['users_iacceptnote'] = "By clicking on 'I accept' below you are agreeing to our Terms of Service and Privacy Policy";
$lang['users_usernametaken'] = "Username entered already in use. Please choose a different one";
$lang['users_createaccount'] = "I accept, Create Account";
$lang['users_captchanote'] = "To help protect against automated software, please enter the characters that appear below in the box";
$lang['users_username'] = "Username";
$lang['users_youcansignhere'] = "Log In";
$lang['users_logout'] = "Logout";
$lang['users_ifyouhaveaccount'] = "Already have an account?";
$lang['users_forgot'] = "Forgotten Password";
$lang['users_register'] = "Create an account";//Member Registration
$lang['users_cookienote'] = "To login you need to enable cookies!";
$lang['users_title'] = "Users";

?>
