<?php

/**
 * @file /language/english/admin_lang.php
 * @brief File to store translation.
 * 
 * @details English - Administration Panel. Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */

$lang['install_importsqldberr'] = "Database error when trying to import the sql file '%s' into database.<br /><br />%s";
$lang['install_logs'] = "The logs directory '%s' is not writeable";
$lang['install_captcha'] = "The captcha directory '%s' is not writeable";
$lang['install_success'] = "Clinic MED was successfully installed.<br /><br />Now you would set permission to 'read only' for all files located at next directory (also that directory) <br/ > %s<br /><br />You might delete these files: <br />%s<br />%s";
$lang['install_config_err'] = "Error on installing Clinic_MED. Please verify and try again";
$lang['install_configloaderr'] = "Unable to create the autoload config file '%s'. Check that it has write permissions";
$lang['install_configdberr'] = "Unable to create the database config file '%s'. Check that it has write permissions";
$lang['install_sqlnotexist'] = "The SQL file '%s' to populate the database does not exists";
$lang['install_nowriteable'] = "The config directory '%s' is not writeable";
$lang['install_unabletousedb'] = "Error when trying to connect to the database with data provided";
$lang['install_err_tablesexists'] = "Some tables with that prefix already exists on DB. Select another code";
$lang['install_unableimportsql'] = "Error when trying to import the sql file '%s' into database. Check tha it has read permissions";
$lang['install_cfgdberror'] = "Error when trying to create the database config file %s";
$lang['install_database'] = "Database name";
$lang['install_host'] = "Host";
$lang['install_username'] = "Username";
$lang['install_password'] = "Password";
$lang['install_title'] = "Installation";
$lang['install_notes'] = "Welcome to Clinic MED, an open source application for Professional Clinic Management licensed under GPL

If all is ok, this procedure:

- Creates the config files
- Imports the SQL file to create the new tables; using the database access provided and the code as table prefix

&raquo; Code: enter a prefix without spaces for your database. i.e. my_clinic_
&raquo;  Database name: the name of the database to be used. Ask to your hosting provider for this information
&raquo;  Host: Tipically 'localhost' without quotes. Ask to your hosting provider for this information
&raquo;  Username: The user name to connect to database. Ask to your hosting provider for this information
&raquo;  Password: The password to connecto to database. Ask to your hosting provider for this information

- <b>The initial admin login is user='admin' password='123456' both without quotes</b>
";

$lang['day_name'] = "Day";
$lang['day_sun'] = "Sunday";
$lang['day_mon'] = "Monday";
$lang['day_tue'] = "Tuesday";
$lang['day_wed'] = "Wednesday";
$lang['day_thu'] = "Thursday";
$lang['day_fri'] = "Friday";
$lang['day_sat'] = "Saturday";

$lang['search_tips'] = "Search Tips";
$lang['search_created'] = "Created";
$lang['search_noresults'] = "Your search did not match any result";
$lang['search_results'] = "Search Results";
$lang['search_relevance'] = "Relevancy";
$lang['search_keywords'] = "Search for";
$lang['search_submit'] = "Search";
$lang['search_reset'] = "Reset";
$lang['search_title'] = "Search";

$lang['modules_groups'] = "Groups";
$lang['modules_codenofound'] = "Module code not found in database";
$lang['modules_askdel'] = "Really do you want to uninstall module with code '%s'?";
$lang['modules_uninstall'] = "Uninstall";
$lang['modules_del'] = "Uninstall Module";
$lang['modules_langnote'] = "Module only will be available for language selected";
$lang['modules_whocansee'] = "Who can access the module";
$lang['modules_codeduplicated'] = "Module code already installed on database.";
$lang['modules_install'] = "Install the Module";
$lang['modules_noinstalled'] = "Not installed";
$lang['modules_filemissing'] = "File is missing";
$lang['modules_listof'] = "List of Modules";
$lang['modules_uninstalled'] = "New Modules";
$lang['modules_installed'] = "Installed Modules";
$lang['modules_groups'] = "Groups";

$lang['usersgroups_none'] = "none";
$lang['usersgroups_group'] = "group";
$lang['usersgroups_nocharplus'] = "Char '+' is not allowed into code";
$lang['usersgroups_nospaces'] = "Spaces are not allowed into code";
$lang['usersgroups_codereserved'] = "User Group code is reserved. Select another code";
$lang['usersgroups_allnote'] = "Administrator, User, Guest and Custom";
$lang['usersgroups_adminnote'] = "Those visitors logged as administrators";
$lang['usersgroups_guestnote'] = "Those visitors not logged (anonymous)";
$lang['usersgroups_usernote'] = "Those visitors logged with their account";
$lang['usersgroups_custom'] = "Custom Groups";
$lang['usersgroups_system'] = "System Groups";
$lang['usersgroups_guest'] = "Guest";
$lang['usersgroups_user'] = "User";
$lang['usersgroups_admin'] = "Administrator";
$lang['usersgroups_all'] = "All";
$lang['usersgroups_askdel'] = "Really do you want to delete user with user group '%s'?";
$lang['usersgroups_codeduplicated'] = "User Group code already exist on database. Select another code";
$lang['usersgroups_codenofound'] = "User Group code not found in database";
$lang['usersgroups_add'] = "Add new User Group";
$lang['usersgroups_edit'] = "Edit User Group";
$lang['usersgroups_del'] = "Delete User Group";
$lang['usersgroups_listof'] = "List of Users Groups";

$lang['users_assigninstructions'] = "This is the list of patients codes for whom the user can to ask online appointments and similar actions.
Separe several patients codes with a dash (-)
";
$lang['users_assign'] = "Assign";
$lang['users_assignpatients'] = "Assign Patients";
$lang['users_isphysician_note'] = "If this user is a physician, then select his/her name from the dropdown";
$lang['users_isphysician'] = "Is physician";
$lang['users_groups4user'] = "Groups for this user ";
$lang['users_listof'] = "List of Users";
$lang['users_smandatorysent'] = "Variable was no found into password sent message";
$lang['users_smandatoryforgotten'] = "Variable was no found into forgotten password message";
$lang['users_smandatorynew'] = "Variable was no found into new accounts message";
$lang['users_includevarmsg'] = "It is mandatory to include %s in the text. It will be replaced with the proper variable";
$lang['users_emailsubject'] = "Subject";
$lang['users_emailmsg'] = "Message";
$lang['users_fromemail'] = "From email";
$lang['users_settingsnew'] = "New accounts email";
$lang['users_settingsforgotten'] = "Forgotten password email";
$lang['users_settingsnewpass'] = "Password sent email";
$lang['users_settingsmain'] = "Main Settings";
$lang['users_config'] = "Config";
$lang['users_allownewuser'] = "Allow new users registration";
$lang['users_askdel'] = "Really do you want to delete user with username '%s'?";
$lang['users_edit'] = "Edit User";
$lang['users_del'] = "Delete User";
$lang['users_Enable'] = "Enable";
$lang['users_Disable'] = "Disable";
$lang['users_activate'] = "Activate";
$lang['users_groups'] = "Groups";
$lang['users_statusdisabled'] = "Disabled";
$lang['users_statusactive'] = "Active";
$lang['users_statuspending'] = "Pending";
$lang['users_status'] = "Status";
$lang['users_add'] = "Add new User";

$lang['menu_med_caas'] = "C-a-a-S";
$lang['menu_cron'] = "Cron";
$lang['menu_groups'] = "Groups";
$lang['menu_del'] = "Delete Menu";
$lang['menu_edit'] = "Edit Menu";
$lang['menu_codenofound'] = "Menu code not found in database";
$lang['menu_id'] = "Code";
$lang['menu_askdel'] = "Really do you want to delete menu with code '%s'?";
$lang['menu_weight'] = "Weight";
$lang['menu_options'] = "Select Option";
$lang['menu_controllers'] = "Select Controller";
$lang['menu_url'] = "Url link to";
$lang['menu_urlnote'] = "Enter the url only if link options were chosen. For outside links, add 'http://'. For inside links '%s' will be added automatic";
$lang['menu_title'] = "Menu title";
$lang['menu_selcontroller'] = "Controller/option";
$lang['menu_add'] = "Add new menu";

$lang['content_askdel'] = "Really do you want to delete content with code '%s'?";
$lang['content_listof'] = "List of Content";
$lang['content_del'] = "Delete Content";
$lang['content_edit'] = "Edit Content";
$lang['content_codenofound'] = "Content code not found in database";
$lang['content_codeduplicated'] = "Content code already exist on database. Select another code";
$lang['content_content'] = "Enter the content";
$lang['content_homepage'] = "Put in Home Page";
$lang['content_add'] = "Add new content";
$lang['content_keywords'] = "Keywords";

$lang['settings_noeditor'] = "No html Editor";
$lang['settings_fckeditor'] = "FCKeditor";
$lang['settings_spaw2'] = "Spaw2";
$lang['settings_cachepages'] = "Cache Pages";
$lang['settings_cachepagesnote'] = "Cached pages will remain alive until they expires";
$lang['settings_timezone'] = "Time Zone";
$lang['settings_htmleditornote'] = "Javascript must be enabled";
$lang['settings_htmleditor'] = "Use html Editor";
$lang['settings_footer2'] = "Footer two";
$lang['settings_footer1'] = "Footer one";
$lang['settings_performance'] = "Performance";
$lang['settings_design'] = "Design";
$lang['settings_security'] = "Security";
$lang['settings_site'] = "Global Site";
$lang['settings_sessiontime'] = "Session Time [minutes]";
$lang['settings_cookiename'] = "Cookie Prefix";
$lang['settings_sitekey'] = "Site Key";
$lang['settings_cachetime'] = "Cache time [minutes]";
$lang['settings_keywords'] = "Keywords";
$lang['settings_charset'] = "CharSet";
$lang['settings_baseurl'] = "Base Url";
$lang['settings_title'] = "Title";
$lang['settings_adminemail'] = "Admin email";
$lang['settings_def'] = "In this sections you can setup the configuration of your website";

$lang['blocks_whocansee'] = "Who can access the block";
$lang['blocks_groups'] = "Groups";
$lang['blocks_file'] = "File";
$lang['blocks_filenote'] = "Select a block only if file type was selected";
$lang['blocks_type'] = "Type";
$lang['blocks_content'] = "Content";
$lang['blocks_contentnote'] = "Enter something only if content type was selected";
$lang['blocks_askdel'] = "Really do you want to delete block with code '%s'?";
$lang['blocks_listof'] = "List of Blocks";
$lang['blocks_codeduplicated'] = "Block code already exist on database. Select another code";
$lang['blocks_codenofound'] = "Block code not found in database";
$lang['blocks_add'] = "Add new Block";
$lang['blocks_del'] = "Delete Block";
$lang['blocks_edit'] = "Edit Block";
$lang['blocks_side1'] = "Left";
$lang['blocks_side2'] = "Right";
$lang['blocks_side3'] = "Center-Up";
$lang['blocks_side4'] = "Center-Down";
$lang['blocks_side5'] = "Up";
$lang['blocks_side6'] = "Down";
$lang['blocks_side'] = "Side";


$lang['admins_atleastonesu'] = "Must be at least one Super User";
$lang['admins_askdel'] = "Really do you want to delete Administrator with code '%s'?";
$lang['admins_listof'] = "List of Administrators";
$lang['admins_codeduplicated'] = "Administrator code already exist on database. Select another code";
$lang['admins_codenofound'] = "Administrator code not found in database";
$lang['admins_sugetfullaccess'] = "WARNING: If Super User is checked, he/she will get full access";
$lang['admins_add'] = "Add new Administrator";
$lang['admins_del'] = "Delete Administrator";
$lang['admins_edit'] = "Edit Administrator";
$lang['admins_superuser'] = "Super User";
$lang['admins_access'] = "Access";
$lang['admins_grantedaccess'] = "Granted access to";
$lang['admins_accessnote'] = "To set full access for a module enter **<br />To deny access let empty<br />To set specific access enter function names separated by blank space";

$lang['menu_med_schedule'] = "Schedule";
$lang['menu_med_patient'] = "Patients";
$lang['menu_med_physician'] = "Physicians";
$lang['menu_med_specialities'] = "Specialities";
$lang['menu_modules'] = "Modules";
$lang['menu_usersgroups'] = "Groups";
$lang['menu_users'] = "Users";
$lang['menu_menu'] = "Menu";
$lang['menu_content'] = "Content";
$lang['menu_admin'] = "Administration";
$lang['menu_admins'] = "Admins";
$lang['menu_cards'] = "Cards";
$lang['menu_blocks'] = "Blocks";
$lang['menu_settings'] = "Settings";

$lang['login_title'] = "Log In";
$lang['login_captchanote'] = "To help protect against automated software, please enter the characters that appear below in the box";
$lang['login_alreadylog'] = "You already are logged";
$lang['login_logoutsuccess'] = "You have logout successfully";
$lang['login_failed'] = "Your User Name or Password are incorrect. Please try again";
$lang['login_user'] = "User";
$lang['login_pass'] = "Password";
$lang['login_captcha'] = "Captcha";
$lang['login_entercaptcha'] = "Enter Captcha";
$lang['login_login'] = "Login";
$lang['login_logout'] = "Logout";
$lang['login_profile'] = "Profile";

$lang['main_none'] = "None";
$lang['main_nodata'] = "No data";
$lang['main_waitingdata'] = "Waiting data";
$lang['main_lastloginfo'] = "Last connections";
$lang['main_lastip'] = "From IP";
$lang['main_yourip'] = "Your IP";
$lang['main_lastlogdate'] = "Date";
$lang['main_ok'] = "ok";
$lang['main_bad'] = "ok";
$lang['main_status'] = "Status";
$lang['main_visible'] = "Visible";
$lang['main_disabled'] = "Disabled";
$lang['main_enabled'] = "Enabled";
$lang['main_pleaseselect'] = "Please Select";
$lang['main_title'] = "Title";
$lang['main_Annonymous'] = "Anonymous";
$lang['main_hello'] = "Hello";
$lang['main_all'] = "All";
$lang['main_others'] = "Others";
$lang['main_module'] = "Module";
$lang['main_moduleaccessdenied'] = "Access denied. You cannot enter at this section because you are not logged, you don't have the proper rights or the module is not active.";
$lang['main_accessdenied'] = "Access denied. You cannot enter at this section";
$lang['main_goback'] = "<a href=\"javascript:history.go(-1)\" title='Go Back'>Go Back</a>";
$lang['main_yes'] = "Yes";
$lang['main_no'] = "No";
$lang['main_functions'] = "Functions";
$lang['main_help'] = "Help";
$lang['main_store'] = "Store";
$lang['main_youraccount'] = "Your Account";
$lang['main_home'] = "Home";

$lang['admin_ref'] = "Ref";
$lang['admin_defactions'] = "Above is a sub menu with all actions available for this option. Of course you only can continue if your account have rights to get access granted or if you are the Super User";
$lang['admin_actions'] = "Actions ::";
$lang['admin_settings'] = "Settings";
$lang['admin_norecords'] = "No records Found";
$lang['admin_order'] = "Order";
$lang['admin_menu'] = "Menu";
$lang['admin_schedule'] = "Schedule";
$lang['admin_patients'] = "Patients";
$lang['admin_history'] = "History";
$lang['admin_physicians'] = "Physicians";
$lang['admin_usersgroups'] = "Users Groups";
$lang['admin_users'] = "Users";
$lang['admin_content'] = "Content";
$lang['admin_all'] = "All";
$lang['admin_modules'] = "Modules";
$lang['admin_blocks'] = "Blocks";
$lang['admin_lang'] = "Language";
$lang['admin_theme'] = "Theme";
$lang['admin_required'] = " <font color=red>[Required]</font>";
$lang['admin_allfieldsrequired'] = "All fields are required";
$lang['admin_admins'] = "Administrators";
$lang['admin_install'] = "Install";
$lang['admin_add'] = "Add";
$lang['admin_edit'] = "Edit";
$lang['admin_del'] = "Delete";
$lang['admin_refresh'] = "Refresh";
$lang['admin_list'] = "List";
$lang['admin_taskok'] = "Task was done successfully";
$lang['admin_ignoringtask'] = "No param provided. Ignoring task";
$lang['admin_mainmenu'] = "Main Menu";
$lang['admin_title'] = "Administration";
$lang['admin_login'] = "Login";
$lang['admin_logout'] = "Logout";
$lang['admin_loggedas'] = "You are logged as";
$lang['admin_memoryusage'] = "Memory Usage";
$lang['admin_pagerendering'] = "Page rendering";
$lang['admin_seconds'] = "seconds";
$lang['admin_code'] = "Code";
$lang['admin_name'] = "Name";
$lang['admin_desc'] = "Description";
$lang['admin_notes'] = "Notes";
$lang['admin_email'] = "Email";
$lang['admin_password'] = "Password";
$lang['admin_passwordagain'] = "Password (again)";
$lang['admin_enternewpasstochange'] = "Only if you want to change it";
$lang['admin_savechanges'] = "Save changes";
$lang['admin_users'] = "Users";
$lang['admin_Keywords'] = "Keywords";

?>
