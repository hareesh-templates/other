<?php

/**
 * @file /language/english/messages_lang.php
 * @brief File to store translation.
 * 
 * @details English - Private Messages. Enter the translation text between the quotes.
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Language
 */

$lang['messages_askdel'] = "Really do you want to delete the following message?";
$lang['messages_del'] = "Delete Message";
$lang['messages_delthismsg'] = "Delete this message";
$lang['messages_reply'] = "Reply";
$lang['messages_newmsg'] = "new";
$lang['messages_sent'] = "Sent";
$lang['messages_msgnotfound'] = "Message was no found";
$lang['messages_send'] = "Send Message";
$lang['messages_message'] = "Message";
$lang['messages_write'] = "Write Message";
$lang['messages_date'] = "Date";
$lang['messages_priority'] = "Priority";
$lang['messages_subject'] = "Subject";
$lang['messages_from'] = "From";
$lang['messages_to'] = "To";
$lang['messages_writeto'] = "Write to user";
$lang['messages_inbox'] = "Inbox";
$lang['messages_title'] = "Private Messages";

?>
