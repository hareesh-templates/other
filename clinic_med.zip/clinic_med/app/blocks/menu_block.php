<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file menu_block.php
 * @brief File to create the menu
 * 
 * @class Menu_block
 * @brief Class to create the menu
 *
 * @details The menu can be configured into the Administration Panel (Menu Option)
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Block
 */

class Menu_block {


  /**
   * Returns a string (html) with the menu
   *
   * @private
   * 
   * @return string
   */
  function _get_content () {

    $CI =& get_instance();
    $CI->load->helper(array('url'));

    $menus = '';

    $wheregroups = get_sql_wheregroups_granted();
    if ($wheregroups != '')  $CI->db->where($wheregroups);

    $CI->db->orderby("weight, type, name");
    $query = $CI->db->get('menu');

    foreach ($query->result() as $row) {

      $menu = '';

      switch ($row->type) {
        case '-title-':
          $menu .= '<div class="title">'.$row->name.'</div>';
          break;
        case '-line-':
          $menu .= '<div class="line"></div>';
          break;
        case '-oulink-':
          $menu .= sprintf('<div class="oulink">%s</div>', anchor($row->link, $row->name, array('target'=>'_blank')));
          break;
        case '-inlink-':
        default:
          $menu .= sprintf('<div class="inlink">%s</div>', anchor($row->link, $row->name));
          break;
      }

      $menus .= $menu;
    }

    return sprintf('<div class="menu">%s</div>', $menus);
  }

}

?>
