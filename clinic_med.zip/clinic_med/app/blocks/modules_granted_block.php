<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file modules_granted_block.php
 * @brief File to create a menu with enabled / allowed modules
 * 
 * @class Modules_granted_block
 * @brief Class to create a menu with enabled / allowed modules
 *
 * @details Modules can be enabled / disabled in the Administration Panel (Module option). Allowed modules are those where the user has access granted
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Block
 */

class Modules_granted_block {


  /**
   * Returns a string (html) with the enabled / allowed modules
   *
   * @private
   * 
   * @return string
   */
  function _get_content () {

    $CI =& get_instance();
    $CI->load->helper(array('url'));

    $modules_granted = get_granted_modules();

    $menus = '';

    if (is_array($modules_granted)) {
      foreach ($modules_granted as $code => $name) {
        if (strpos($name, '.:hidden:.') === false) {
          $menu = '';
          if ($name != "") {
            $menu .= sprintf('<div class="inlink">%s</div>', anchor($code, $name));
          } else {
            $menu .= sprintf('<div class="inlink">%s</div>', anchor($code, $code));
          }
          $menus .= $menu;
        }
      }
    }
    return sprintf('<div class="menu">%s</div>', $menus);
  }
}

?>
