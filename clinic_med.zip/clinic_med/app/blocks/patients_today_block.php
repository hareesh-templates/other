<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file patients_today_block.php
 * @brief File to show the patients for today
 * 
 * @class Patients_Today_block
 * @brief Class to show the patients for today
 *
 * @details This block shows the patients that the logged physician must handle today
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Block
 */


class Patients_Today_block {


  /**
   * Returns a string (html) with the list of patients for today
   *
   * @private
   * 
   * @return string
   */
  function _get_content () {

    if (!is_user()) {
      return "";
    }

    $CI =& get_instance();

    if ( ! $CI->userinfo['is_physician']) {
      $CI->lang->load('med_common');
      return $CI->lang->line('physician_youarentdr');
    }

    $restul = '';

    $CI->lang->load('med_common');
    $CI->load->helper('date');

    $time   = gmt_to_local(now(), $CI->config->item('timezone'));

    //$restul = unix_to_human($time);

    $day    = date('j', $time);
    $month  = date('n', $time);
    $year   = date('Y', $time);

    $date1 = mktime (0, 0, 0, $month, $day, $year);
    $date2 = mktime (23, 59, 59, $month, $day, $year);

    $prefix = $CI->db->dbprefix;
    $tb1 = $prefix . 'med_appointment';
    $tb2 = $prefix . 'med_patient';
    $CI->db->select($tb1.'.status, '.$tb1.'.time_from, '.$tb2.'.name, '.$tb1.'.speciality_code, '.$tb1.'.patient_code');
    $CI->db->from('med_appointment');
    $CI->db->join('med_patient', 'med_patient.code = med_appointment.patient_code', 'left');
    $CI->db->where('time_from >=', $date1);
    $CI->db->where('time_from <=', $date2);
    $CI->db->where('physician_code', $CI->userinfo['code']);
    $CI->db->where($tb1.'.status >', 0);
    $CI->db->where($tb1.'.status <', 5);
    $CI->db->orderby('time_from');
    $query = $CI->db->get();

    $txts = array();
    $imgs = array();

    $txts[0] = $CI->lang->line('appointment_cancel');
    $txts[1] = $CI->lang->line('appointment_pending');
    //$txts[2] = $CI->lang->line('appointment_confirmed');
    $txts[3] = $CI->lang->line('appointment_atlobby');
    $txts[4] = $CI->lang->line('appointment_consultation');

    $style = 'style="float: right;"';
    $imgs[0] = theme_imgtag ('cancel.png', $txts[0], $txts[0], $style);
    $imgs[1] = theme_imgtag ('pending.png', $txts[1], $txts[1], $style );
    //$imgs[2] = theme_imgtag ('confirmed.png', $txts[2], $txts[2], $style );
    $imgs[3] = theme_imgtag ('atlobby.png', $txts[3], $txts[3], $style );
    $imgs[4] = theme_imgtag ('doctor.png', $txts[4], $txts[4], $style );

    if ($query->num_rows() > 0) {

      foreach ($query->result() as $row) {

        $img = '';
        if (isset($imgs[$row->status])) $img = $imgs[$row->status];

        $restul .= sprintf(
        '<div class="schedule_patient_today">%s%s<br />%s</div>',
        $img,
        anchor('diagnostic', date('h:i:a', $row->time_from)),
        anchor('history/patient/'.$row->patient_code.'/'.$row->speciality_code, $row->name)
        );
      }

    } else {

      $restul = $CI->lang->line('diagnostic_nopatients');

    }
    return sprintf('<div>%s</div>', $restul);
  }

}

?>
