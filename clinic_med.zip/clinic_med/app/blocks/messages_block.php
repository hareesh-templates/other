<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file messages_block.php
 * @brief File to show unread private messages
 * 
 * @class Messages_block
 * @brief Class to show unread private messages
 *
 * @details
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Block
 */

class Messages_block {


  /**
   * Returns a string (html) with unread private messages. Also it includes a link to create new messages
   *
   * @private
   * 
   * @return string
   */
  function _get_content () {

    if (!is_user()) {
      return "";
    }

    $CI =& get_instance();
    $CI->load->helper('url');

/*
    <script type="text/javascript" src="'.$CI->config->item('base_url').'include/mtc-1.2.js">
    </script>
*/

    $restul = '';
    $restul .=
    '
    <script type="text/javascript">
      window.addEvent("domready", function(){

        var url = "'.site_url("messages/seeinbox").'";

        // refresh every xx seconds
        var timer = 60*3;

        var log = $("search4pm");

        /* our ajax istance */
        var ajax = new Request.HTML({
          url: url,
          update: log,
          method: "get",
          onComplete: function() {
            // when complete, we remove the spinner
            //log.removeClass("ajax-loading");
          }
        });

        /* our refresh function: add the loader class */
        var refresh = (function() {
          //log.empty().addClass("ajax-loading");
          ajax.send();
        });

        // the periodical starts here, the * 1000 is because milliseconds required
        //log.empty().addClass("ajax-loading");
        var periodical = refresh.periodical(timer * 1000, this);
        ajax.send();

      });
    </script>

    <div id="search4pm" class="messages_sumary_inbox">
    Enable Javascript
    </div>
    ';

    return $restul;
  }

}

?>
