<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file SettingsfromCookie.php
 * @brief File to handle settings from browser cookies 
 * 
 * @class SettingsfromCookie
 * @brief Class to handle settings from browser cookies 
 *
 * @details
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Library
 */

class SettingsfromCookie {

  /**
   * Constructor
   * 
   * Retrieve settings stored into browser cookies (session, language, theme, etc)
   */
  function SettingsfromCookie() {

    log_message('debug', "SettingsfromCookie Class Initialized");

    $CI =& get_instance();

//erm si el usuario ha conectado, establecer sus preferencias desde la session
//-------------------------------------------------------------------------------------
    if ($CI->session->userdata('usertheme'))  $CI->config->set_item('theme', $CI->session->userdata('usertheme'));
    if ($CI->session->userdata('userlang'))  $CI->config->set_item('language', $CI->session->userdata('userlang'));
    if ($CI->session->userdata('usertimezone'))  $CI->config->set_item('timezone', $CI->session->userdata('usertimezone'));

    $theme = substr($CI->config->item('theme'), 0, strpos($CI->config->item('theme'), '.'));
    $theme_url = $CI->config->item('base_url').'img/theme_'.$theme.'/';
    $CI->config->set_item('theme_url', $theme_url);

  }

}

?>
