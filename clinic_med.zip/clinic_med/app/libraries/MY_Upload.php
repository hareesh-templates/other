<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file MY_Upload.php
 * @brief File to extends the CI_Upload class
 * 
 * @class MY_Upload
 * @brief Class to extends the CI_Upload class
 *
 * @details this class changes the upload behaviour from disk file to database
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Library
 */


class MY_Upload extends CI_Upload {

  /**
   * Performs the file upload, and if it is successful, store the content of that file into the binary_file param.
   * Return TRUE if the process was successful, otherwise FALSE
   *
   * @public
   *
   * @param field string the $_FILES array item with the name of the file uploaded
   * @param binary_file binary this param will be set by this method with the content of the file
   * 
   * @return  bool
   */
  function do_upload($field, &$binary_file) {

    // Is $_FILES[$field] set? If not, no reason to continue.
    if ( ! isset($_FILES[$field]))
    {
      $this->set_error('upload_userfile_not_set');
      return FALSE;
    }

    // Was the file able to be uploaded? If not, determine the reason why.
    if ( ! is_uploaded_file($_FILES[$field]['tmp_name']))
    {
      $error = ( ! isset($_FILES[$field]['error'])) ? 4 : $_FILES[$field]['error'];

      switch($error)
      {
        case 1  :   $this->set_error('upload_file_exceeds_limit');
          break;
        case 3  :   $this->set_error('upload_file_partial');
          break;
        case 4  :   $this->set_error('upload_no_file_selected');
          break;
        default :   $this->set_error('upload_no_file_selected');
          break;
      }

      return FALSE;
    }

    // Set the uploaded data as class variables
    $this->file_temp = $_FILES[$field]['tmp_name'];
    $this->file_name = $_FILES[$field]['name'];
    $this->file_size = $_FILES[$field]['size'];
    $this->file_type = preg_replace("/^(.+?);.*$/", "\\1", $_FILES[$field]['type']);
    $this->file_type = strtolower($this->file_type);
    $this->file_ext  = $this->get_extension($_FILES[$field]['name']);

    // Convert the file size to kilobytes
    if ($this->file_size > 0)
    {
      $this->file_size = round($this->file_size/1024, 2);
    }

    // Is the file type allowed to be uploaded?
    if ( ! $this->is_allowed_filetype())
    {
      $this->set_error('upload_invalid_filetype');
      return FALSE;
    }

    // Is the file size within the allowed maximum?
    if ( ! $this->is_allowed_filesize())
    {
      $this->set_error('upload_invalid_filesize');
      return FALSE;
    }

    // Are the image dimensions within the allowed size?
    // Note: This can fail if the server has an open_basdir restriction.
    if ( ! $this->is_allowed_dimensions())
    {
      $this->set_error('upload_invalid_dimensions');
      return FALSE;
    }

    // Sanitize the file name for security
    $this->file_name = $this->clean_file_name($this->file_name);

    // Remove white spaces in the name
    if ($this->remove_spaces == TRUE)
    {
      $this->file_name = preg_replace("/\s+/", "_", $this->file_name);
    }


    /*
     * Read the content and return it into binary_file variable
     */
    if (($binary_file = @file_get_contents($this->file_temp)) === FALSE) {
      $this->set_error('upload_destination_error');
      return FALSE;
    }

    return TRUE;
  }

}

// END MY_Upload Class
?>
