<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file SettingsfromDB.php
 * @brief File to handle settings from database
 * 
 * @class SettingsfromDB
 * @brief Class to handle settings from database
 *
 * @details
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Library
 */

class SettingsfromDB {

  /**
   * Constructor
   * 
   * loads the loadconfig method
   *
   * @param cat string the category of settings to retrieve
   *
   * @public
   */
  function SettingsfromDB($cat="admin") {
    $this->loadconfig();
  }


  /**
   * Retrieve settings stored into database (session expiration, performance, etc)
   *
   * @public
   *
   * @param cat string the category of settings to retrieve
   *
   * @return nothing
   */
  function loadconfig($cat="admin") {
    $CI =& get_instance();
    $CI->db->where('cat', $cat);
    $query = $CI->db->get('settings');

    log_message('debug', "SettingsfromDB Class Initialized");

    $settings_var = array();
    $base_url = $CI->config->item('base_url');
    foreach ($query->result() as $row) {
      $CI->config->set_item($row->var, $row->value);
    }
    $CI->config->set_item('base_url', $base_url);
    //erm esto es por si a alguien se le ocurre agregar a la DB la variable base_url

    $theme = substr($CI->config->item('theme'), 0, strpos($CI->config->item('theme'), '.'));
    $theme_url = $CI->config->item('base_url').'img/theme_'.$theme.'/';
    $CI->config->set_item('theme_url', $theme_url);
  }
}

?>
