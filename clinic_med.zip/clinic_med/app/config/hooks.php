<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file hooks.php
 * @brief File to store settings.
 * 
 * @details This file lets you define "hooks" to extend CI without hacking the core files. http://www.codeigniter.com/user_guide/general/hooks.html
 *
 * @author CodeIgniter [http://codeigniter.com/] / Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 * 
 * @sa Clinic_MED - Settings
 */


/*
| -------------------------------------------------------------------------
| Hooks
| -------------------------------------------------------------------------
| This file lets you define "hooks" to extend CI without hacking the core
| files.  Please see the user guide for info:
|
|  http://www.codeigniter.com/user_guide/general/hooks.html
|
*/

?>
