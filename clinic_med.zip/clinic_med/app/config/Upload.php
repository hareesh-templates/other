<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file Upload.php
 * @brief File to store settings.
 * 
 * @details This file lets you define upload settings
 *
 * @author CodeIgniter [http://codeigniter.com/] / Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 * 
 * @sa Clinic_MED - Settings
 */

/*
| -------------------------------------------------------------------------
| Upload configuration file
| -------------------------------------------------------------------------
| This file lets you define upload settings
|
*/

/*
* upload_path
* Do not apply because files will be in database. Set to '-'
*
*
* allowed_types
* The mime types corresponding to the types of files you allow to be uploaded.
* Usually the file extension can be used as the mime type.
* Separate multiple types with a pipe '|'.
*
*
* overwrite
* FALSE   TRUE/FALSE (boolean)
* Do not apply because files will be in database. Set to FALSE
*
*
* max_size
* 0   None
* The maximum size (in kilobytes) that the file can be. Set to zero for no limit.
* Note: Most PHP installations have their own limit, as specified in the php.ini file.
* Usually 2 MB (or 2048 KB) by default.
*
*
* max_width
* 0   None
* The maximum width (in pixels) that the file can be. Set to zero for no limit.
*
*
* max_height
* 0   None
* The maximum height (in pixels) that the file can be. Set to zero for no limit.
*
*
* encrypt_name
* FALSE   TRUE/FALSE (boolean)
* If set to TRUE the file name will be converted to a random encrypted string.
* This can be useful if you would like the file saved with a name that can not be
* discerned by the person uploading it.
*
*
* remove_spaces
* TRUE  TRUE/FALSE (boolean)
* If set to TRUE, any spaces in the file name will be converted to underscores.
* This is recommended.
*
*/

$config['upload_path'] = '-';
$config['allowed_types'] = 'mp3|ogg|wav|avi|mpeg|jpg|jpeg|gif|png|zip|rar|doc|txt|rtf|xls|pdf';
$config['overwrite'] = FALSE;
$config['max_size'] = '0';
$config['max_width'] = '0';
$config['max_height'] = '0';
$config['encrypt_name'] = TRUE;
$config['remove_spaces'] = TRUE;

?>
