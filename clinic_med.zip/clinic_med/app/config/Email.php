<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file Email.php
 * @brief File to store settings.
 * 
 * @details Default settings to use when sending email
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 * 
 * @sa Clinic_MED - Settings
 */

$config['mailtype'] = 'html';
$config['useragent'] = 'Adalid-Soft';
$config['protocol'] = 'sendmail';
$config['mailpath'] = '/usr/sbin/sendmail';
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;

?>
