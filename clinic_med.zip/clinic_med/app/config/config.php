<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file config.php
 * @brief File to store settings.
 * 
 * @details This file specifies the main settings to use
 *
 * @author CodeIgniter [http://codeigniter.com/] / Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 * 
 * @sa Clinic_MED - Settings
 */


//--------------------------------------------------------------------------------
//ERM Clinic as a Service (caas)
//--------------------------------------------------------------------------------

/*
|--------------------------------------------------------------------------
| caas_zippath
|--------------------------------------------------------------------------
|
| This determines the path where the zipped and SQL file are located
| Can be a private directory
| Include trailing slash at end
|
*/
//$config['caas_zippath']  = '/home/cireh/media_files/';
$config['caas_zippath']  = '/home/web/';

/*
|--------------------------------------------------------------------------
| caas_zipname
|--------------------------------------------------------------------------
|
| This determines the name of the file to unzip.
| This must be a valid zip file zipped
| It include a copy of Clinic source code.
| Keep it at save place so it cannot be downloaded.
|
*/
$config['caas_zipname']  = 'clinic.1.0.zip'; //

/*
|--------------------------------------------------------------------------
| caas_sqlname
|--------------------------------------------------------------------------
|
| This determines the name of the SQL file to import for a new CAAS
|
*/
$config['caas_sqlname']  = 'clinic.1.0.sql';

//--------------------------------------------------------------------------------
//ERM users module settings
//--------------------------------------------------------------------------------

$config['schedule_interval']  = (60*60*3); // default 3 hours
//number of seconds to split each schedule day.
//(if you want to explit each 2 hours set it to 7200 (60*60*2))

$config['users_accept']  = 1;
// 1 = Allow users create their own accounts
// 0 = Does not allow users create their own accounts

$config['users_fromemail']  = 'accounts-noreply@yoursite.com';
// The from from email address when sending emails to the user

$config['users_verifysubject']  = 'New account Verification';
// The subject email on verification

$config['users_verifymessage']  = 'To activate your new account click %s';
// The message email on verification

$config['users_resetsubject']  = 'Reset password instructions';
// The subject email on forgotten password

$config['users_resetinstructions']  = 'To reset your password click %s';
// The message email on forgotten password

$config['users_newpass']  = 'New Password';
// The subject email on new password sent

$config['users_newpassmsg']  = 'Your new password is %s';
// The message email on new password sent


//--------------------------------------------------------------------------------
//ERM main site options
//--------------------------------------------------------------------------------

$config['title']  = "Clinic MED";
// Title of the website

$config['cacheenabled']  = 0;
// 1 = Enable cache pages usage
// 0 = Disable cache pages usage

$config['cachetime']  = 10;
// If cacheenabled is true, the number of minutes to refresh cache pages

$config['theme']  = "default.html";
// The theme or skin to be used with the app.
// This file must be located at app_path/views directory

$config['use_htmleditor']  = 0;
// 1 = Enable usage of html_editor in some places where exits forms's textarea controls
// 0 = Disable usage of html_editor

$config['timezone']  = 'UM6';
// Time zone of the web.


/*
|--------------------------------------------------------------------------
| Default Character Set
|--------------------------------------------------------------------------
|
| This determines which character set is used by default in various methods
| that require a character set to be provided.
|
*/
$config['charset'] = "UTF-8";


/*
|--------------------------------------------------------------------------
| Default Language
|--------------------------------------------------------------------------
|
| This determines which set of language files should be used. Make sure
| there is an available translation if you intend to use something other
| than english.
|
*/
$config['language']  = "english";

/*
|--------------------------------------------------------------------------
| Index File
|--------------------------------------------------------------------------
|
| Typically this will be your index.php file, unless you've renamed it to
| something else. If you are using mod_rewrite to remove the page set this
| variable so that it is blank.
|
*/
$config['index_page'] = "index.php";

/*
|--------------------------------------------------------------------------
| Base Site URL
|--------------------------------------------------------------------------
|
| URL to your CodeIgniter root. Typically this will be your base URL,
| WITH a trailing slash:
|
|  http://www.your-site.com/
|
*/

//$config['base_url']  = "http://10.0.0.5/clinic/";
$tempo = explode($config['index_page'], $_SERVER['SCRIPT_NAME']);
$config['base_url']  = 'http://'.$_SERVER['SERVER_NAME'] . $tempo[0];


/*
|--------------------------------------------------------------------------
| URI PROTOCOL
|--------------------------------------------------------------------------
|
| This item determines which server global should be used to retrieve the
| URI string.  The default setting of "AUTO" works for most servers.
| If your links do not seem to work, try one of the other delicious flavors:
|
| 'AUTO'      Default - auto detects
| 'PATH_INFO'    Uses the PATH_INFO
| 'QUERY_STRING'  Uses the QUERY_STRING
| 'REQUEST_URI'    Uses the REQUEST_URI
| 'ORIG_PATH_INFO'  Uses the ORIG_PATH_INFO
|
*/
$config['uri_protocol']  = "AUTO";

/*
|--------------------------------------------------------------------------
| URL suffix
|--------------------------------------------------------------------------
|
| This option allows you to add a suffix to all URLs generated by CodeIgniter.
| For more information please see the user guide:
|
| http://www.codeigniter.com/user_guide/general/urls.html
*/

$config['url_suffix'] = "";


/*
|--------------------------------------------------------------------------
| Enable/Disable System Hooks
|--------------------------------------------------------------------------
|
| If you would like to use the "hooks" feature you must enable it by
| setting this variable to TRUE (boolean).  See the user guide for details.
|
*/
$config['enable_hooks'] = FALSE;


/*
|--------------------------------------------------------------------------
| Class Extension Prefix
|--------------------------------------------------------------------------
|
| This item allows you to set the filename/classname prefix when extending
| native libraries.  For more information please see the user guide:
|
| http://www.codeigniter.com/user_guide/general/core_classes.html
| http://www.codeigniter.com/user_guide/general/creating_libraries.html
|
*/
$config['subclass_prefix'] = 'MY_';


/*
|--------------------------------------------------------------------------
| Allowed URL Characters
|--------------------------------------------------------------------------
|
| This lets you specify which characters are permitted within your URLs.
| When someone tries to submit a URL with disallowed characters they will
| get a warning message.
|
| As a security measure you are STRONGLY encouraged to restrict URLs to
| as few characters as possible.  By default only these are allowed: a-z 0-9~%.:_-
|
| Leave blank to allow all characters -- but only if you are insane.
|
| DO NOT CHANGE THIS UNLESS YOU FULLY UNDERSTAND THE REPERCUSSIONS!!
|
*/
$config['permitted_uri_chars'] = '=@#*+a-z 0-9~%.:_\-|ÀÁÂÃÉÊÍÓÔÕÚÜàáâãéêíóôõúüÇç';


/*
|--------------------------------------------------------------------------
| Enable Query Strings
|--------------------------------------------------------------------------
|
| By default CodeIgniter uses search-engine friendly segment based URLs:
| www.your-site.com/who/what/where/
|
| You can optionally enable standard query string based URLs:
| www.your-site.com?who=me&what=something&where=here
|
| Options are: TRUE or FALSE (boolean)
|
| The two other items let you set the query string "words" that will
| invoke your controllers and its functions:
| www.your-site.com/index.php?c=controller&m=function
|
| Please note that some of the helpers won't work as expected when
| this feature is enabled, since CodeIgniter is designed primarily to
| use segment based URLs.
|
*/
$config['enable_query_strings'] = FALSE;
$config['controller_trigger'] = 'c';
$config['function_trigger'] = 'm';

/*
|--------------------------------------------------------------------------
| Error Logging Threshold
|--------------------------------------------------------------------------
|
| If you have enabled error logging, you can set an error threshold to
| determine what gets logged. Threshold options are:
| You can enable error logging by setting a threshold over zero. The
| threshold determines what gets logged. Threshold options are:
|
|  0 = Disables logging
|   0 = Error logging TURNED OFF
|  1 = Error Messages (including PHP errors)
|  2 = Debug Messages
|  3 = Informational Messages
|  4 = All Messages
|
| For a live site you'll usually only enable Errors (1) to be logged otherwise
| your log files will fill up very fast.
|
*/
$config['log_threshold'] = 1;

/*
|--------------------------------------------------------------------------
| Error Logging Directory Path
|--------------------------------------------------------------------------
|
| Leave this BLANK unless you would like to set something other than the default
| system/logs/ folder.  Use a full server path with trailing slash.
|
*/
$config['log_path'] = '';

/*
|--------------------------------------------------------------------------
| Date Format for Logs
|--------------------------------------------------------------------------
|
| Each item that is logged has an associated date. You can use PHP date
| codes to set your own date formatting
|
*/
$config['log_date_format'] = 'Y-m-d H:i:s';

/*
|--------------------------------------------------------------------------
| Cache Directory Path
|--------------------------------------------------------------------------
|
| Leave this BLANK unless you would like to set something other than the default
| system/cache/ folder.  Use a full server path with trailing slash.
|
*/
$config['cache_path'] = '';

/*
|--------------------------------------------------------------------------
| Encryption Key
|--------------------------------------------------------------------------
|
| If you use the Encryption class or the Sessions class with encryption
| enabled you MUST set an encryption key.  See the user guide for info.
|
*/
$config['encryption_key'] = "string_key_change_to_any_you_want";

/*
|--------------------------------------------------------------------------
| Session Variables
|--------------------------------------------------------------------------
|
| 'session_cookie_name' = the name you want for the cookie
| 'encrypt_sess_cookie' = TRUE/FALSE (boolean).  Whether to encrypt the cookie
| 'session_expiration'  = the number of SECONDS you want the session to last.
|  by default sessions last 7200 seconds (two hours).  Set to zero for no expiration.
|
*/
$config['sess_cookie_name']    = 'session';
$config['sess_expiration']    = 3600; //erm 600=10 min. numero de segundos para expirar la sesion
$config['sess_encrypt_cookie']  = TRUE;
$config['sess_use_database']  = TRUE;
$config['sess_table_name']    = 'sessions';
$config['sess_match_ip']    = FALSE;
$config['sess_match_useragent']  = FALSE;

/*
|--------------------------------------------------------------------------
| Cookie Related Variables
|--------------------------------------------------------------------------
|
| 'cookie_prefix' = Set a prefix if you need to avoid collisions
| 'cookie_domain' = Set to .your-domain.com for site-wide cookies
| 'cookie_path'   =  Typically will be a forward slash
|
*/
$config['cookie_prefix']  = "clinic_";
$config['cookie_domain']  = "";
$config['cookie_path']    = "/";

/*
|--------------------------------------------------------------------------
| Global XSS Filtering
|--------------------------------------------------------------------------
|
| Determines whether the XSS filter is always active when GET, POST or
| COOKIE data is encountered
|
*/
$config['global_xss_filtering'] = FALSE;

/*
|--------------------------------------------------------------------------
| Output Compression
|--------------------------------------------------------------------------
|
| Enables Gzip output compression for faster page loads.  When enabled,
| the output class will test whether your server supports Gzip.
| Even if it does, however, not all browsers support compression
| so enable only if you are reasonably sure your visitors can handle it.
|
| VERY IMPORTANT:  If you are getting a blank page when compression is enabled it
| means you are prematurely outputting something to your browser. It could
| even be a line of whitespace at the end of one of your scripts.  For
| compression to work, nothing can be sent before the output buffer is called
| by the output class.  Do not "echo" any values with compression enabled.
|
*/
$config['compress_output'] = FALSE;

/*
|--------------------------------------------------------------------------
| Master Time Reference
|--------------------------------------------------------------------------
|
| Options are "local" or "gmt".  This pref tells the system whether to use
| your server's local time as the master "now" reference, or convert it to
| GMT.  See the "date helper" page of the user guide for information
| regarding date handling.
|
*/
$config['time_reference'] = 'gmt';


/*
|--------------------------------------------------------------------------
| Rewrite PHP Short Tags
|--------------------------------------------------------------------------
|
| If your PHP installation does not have short tag support enabled CI
| can rewrite the tags on-the-fly, enabling you to utilize that syntax
| in your view files.  Options are TRUE or FALSE (boolean)
|
*/
$config['rewrite_short_tags'] = FALSE;




?>
