<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


/**
 * @file theme_helper.php
 * @brief File to handle theme (views) related issues
 * 
 * @details
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Helper
 */

// ---------------------------------------------------------------------------------------------------------


  /**
   * Return html with a submenu navigation bar
   *
   * @public
   * 
   * @param title (string) The title to include into the navigation bar
   * @param items (array) Array with items to include into the navigation bar
   * @param img (string) Path to the image to include as part of the navigation bar
   * 
   * @return string
   */
  function navbarsubmenu ($title, $items, $img='') {

    $menu = '<div class="navbarsubmenu">';
    if ($img != '') $menu .= theme_imgtag($img, $title, $title, " class='navbarsubmenu-img'");
    if ($title != '') $menu .= '<div class="navbarsubmenu-title">'.$title.'</div>';
    if ($items != '') {
      if (is_array($items)) {
        foreach ($items as $value) {
          $menu .= '<div class="navbarsubmenu-item">'.$value.'</div>';
        }
      } else {
        $menu .= '<div class="navbarsubmenu-item">'.$items.'</div>';
      }
    }
    $menu .= '</div>';

    return $menu;
  }

  /**
   * Return the code (html tags) of the textarea html element, either a simple one or using WYSIWYG editor (what you see is what you get html editor)
   *
   * WYSIWYG editor only will be include if it is enable into Administration Panel (settings option)
   *
   * @public
   * 
   * @param name (string) the textarea input name
   * @param content (string) the value of the textarea
   * @param toolbar (string) the type of toolbar to use. Allowed values are: all, standard, little, mini
   * @param height (string) to be inserted into style attribute
   * @param width (string) to be inserted into style attribute
   * @param resizing (enum) to allow resize on the fly the WYSIWYG editor. Allowed values are: none, horizontal, vertical, both
   * 
   * @return string
   */
  function textArea ($name, $content, $toolbar='standard', $height='75px', $width='95%', $resizing='none') {

    if (!function_exists("htmlspecialchars_decode")) {
      function htmlspecialchars_decode($string, $quote_style = ENT_COMPAT) {
        return strtr($string, array_flip(get_html_translation_table(HTML_SPECIALCHARS, $quote_style)));
      }
    }
    $content = htmlspecialchars_decode($content);

    $CI =& get_instance();
    if ($CI->config->item('use_htmleditor') == 'fckeditor') {

      switch ($toolbar) {
        case 'mini':
          $toolbar = 'Basic';
          break;
        case 'little':
          $toolbar = 'Litle';
          break;
        case 'all':
          $toolbar = 'All';
          break;
        case 'standard':
        default:
          $toolbar = 'Standard';
          break;
      }

      $CI->load->file(BASEPATH.'../include/FCKeditor/fckeditor.php');

      $oFCKeditor = new FCKeditor($name);
      $oFCKeditor->BasePath = base_url().'include/FCKeditor/';
      $oFCKeditor->Value = $content;
      $oFCKeditor->Width  = $width;
      $oFCKeditor->Height = $height;
      $oFCKeditor->ToolbarSet = $toolbar;
      return $oFCKeditor->CreateHtml();

    } else {

      $key = $name;
      $data = array('name'=>$key,'id'=>$key,'value'=>$content,'style'=>'width: '.$width.'; height: '.$height.';');
      return form_textarea($data);

    }
  }



  /**
   * Return a html form asking for some question, expecting yes or no reply
   *
   * @public
   * 
   * @param question (string) Question to ask for
   * @param yes_action (string) The form's action (URL) when yes is clicked
   * @param no_action (string) The URL to request when NO is clicked
   * @param form_items (string) Something to include between the question and the yes/no options
   * 
   * @return string
   */
  function Ask_yesno_form ($question, $yes_action, $no_action, $form_items='') {
    $CI =& get_instance();
    $form = "";

    $attributes = array('id' => 'formYesNo', 'name' => 'formYesNo');
    $form .= form_open($yes_action, $attributes)
    ."<div class='msg_2'>"
    .$question."<br /><br />"
    .$form_items
    .form_submit('Submit', $CI->lang->line('main_yes'))
    ." | ".anchor($no_action, $CI->lang->line('main_no'))
    ." | ".$CI->lang->line('main_goback')
    ."</div>"
    .form_close();

    return $form;
  }


  /**
   * Return the full URL path for the image.  This URL is intented to be used as 'src' property into any image tag
   *
   * The path returned will make reference to the selected theme directory (i.e. http://clinic/img/theme_selected/image.gif)
   *
   * @public
   * 
   * @param img (string) The name of the image including its extension
   * 
   * @return string
   */
  function theme_imgpath ($img) {
    $CI =& get_instance();

    $theme = substr($CI->config->item('theme'), 0, strpos($CI->config->item('theme'), '.'));
    $imgscr = $CI->config->item('base_url').'img/theme_'.$theme.'/'.$img;

    return $imgscr;
  }


  /**
   * Return an html image tag for an image located into the selected theme directory
   *
   * Example: &lt;img src='http://clinic/img/theme_selected/img_path' border='0' title='Some title' alt='this is the image' /&gt;
   *
   * @public
   * 
   * @param img (string) The name of the image including its extension
   * @param title (string) The title property for the image tag
   * @param alt (string) The alt property for the image tag
   * @param options (string) Any other valid property for the image tag
   * 
   * @return string
   */
  function theme_imgtag ($img, $title="", $alt="", $options="") {
    $CI =& get_instance();

    $theme = substr($CI->config->item('theme'), 0, strpos($CI->config->item('theme'), '.'));
    $imgscr = $CI->config->item('base_url').'img/theme_'.$theme.'/'.$img;

    $tmp = "<img src='".$imgscr."' border='0' title='$title' alt='$alt' ". $options . "/>";
    return $tmp;
  }


  /**
   * Return an html image tag for an image located into the ..clinic/app/img/ directory
   *
   * Example: &lt;img src='http://clinic/img/img_path' border='0' title='Some title' alt='this is the image' /&gt;
   *
   * @public
   * 
   * @param img (string) The name of the image including its extension
   * @param title (string) The title property for the image tag
   * @param alt (string) The alt property for the image tag
   * @param options (string) Any other valid property for the image tag
   * 
   * @return string
   */
  function imgtag ($img, $title="", $alt="", $options="") {
    $CI =& get_instance();

    $imgscr = $CI->config->item('base_url').'img/'.$img;

    $tmp = "<img src='".$imgscr."'  title='$title' alt='$alt' " . $options . "/>";
    return $tmp;
  }


  /**
   * Return an array with default values to be included into the html page to be send to browser
   *
   * @li $vars['title'] The title for the html page. Taken from Administration Panel (settings option)
   * @li $vars['meta'] The meta for the html page (charset, author, robots, keywords, description, theme stylesheet). Taken from Administration Panel (settings option)
   * @li $vars['java'] the javascript for the html page. Default are include/mtc-1.2.js and include/mtm-1.2.js files.
   * @li $vars['navbar'] A menu bar. Default 'Home' link
   * @li $vars['banner'] Any banner. Default none
   * @li $vars['content'] Any content. Default none
   * @li $vars['base_url'] The URL of the portal
   * @li $vars['footer1'] A footer to be included at bottom. Taken from Administration Panel (settings option)
   * @li $vars['footer2'] A footer to be included at bottom. Taken from Administration Panel (settings option)
   * @li $vars['header1'] A header to be included at top. Default login/logout links
   *
   * @public
   * 
   * @return array
   */
  function default_Vars_Content () {

    $CI =& get_instance();

    $vars['title'] = $CI->config->item('title');

    $cssscr = $CI->config->item('theme_url') . 'style.css';

    $vars['meta'] = '
    <meta content="text/html; charset='.$CI->config->item('charset').'" http-equiv="content-type" >

    <meta content="Adalid-Soft" name="author" >
    <link rel="shortcut icon" href="'.$CI->config->item('base_url').'img/favicon.ico" type="image/x-icon" >
    <meta name="robots" content="all" >
    <meta name="keywords" content="'.$CI->config->item('keywords').'" >
    <meta name="description" content="Description here" >
    <link rel="stylesheet" href="'.$cssscr.'" type="text/css">
    ';


    $vars['java'] = '
    <script type="text/javascript" src="'.$CI->config->item('base_url').'include/mtc-1.2.js"></script>
    <script type="text/javascript" src="'.$CI->config->item('base_url').'include/mtm-1.2.js"></script>
    <script type="text/javascript">
    <!--
    -->
    </script>
    ';

    $vars['navbar'] = anchor($CI->config->site_url(), $CI->lang->line('main_home')) ;
    $vars['banner'] = '';
    $vars['content'] = '';

    $vars['base_url'] = $CI->config->item('base_url');

    $vars['footer1'] = $CI->config->item('footer1');
    if ($vars['footer1'] != '') $vars['footer1'] .= '<br />';
    $vars['footer1'] .= ''
    .$CI->lang->line('admin_pagerendering').' '. $CI->benchmark->elapsed_time().' '.$CI->lang->line('admin_seconds').' | '
    .$CI->lang->line('admin_memoryusage') .' '. $CI->benchmark->memory_usage();

    $vars['footer2'] = $CI->config->item('footer2');
    if ($vars['footer2'] != '') $vars['footer2'] .= '<br />';
    $vars['footer2'] .= 'Licensed by <a href="http://www.checkup.med.br">checkup.med.br</a> | Coded by <a href="http://adalid-soft.com">adalid-soft.com</a>';


    $vars['header1'] = $CI->lang->line('main_hello') . ' ';
    if ($CI->session->userdata('admin') != '') {
      $vars['header1'] .= $CI->session->userdata('admin');
      $vars['header1'] .= sprintf(' | %s ', anchor('admin/principal/logout', $CI->lang->line('login_logout')));

    } else {
      if ($CI->session->userdata('user') != '') {
        $vars['header1'] .= $CI->session->userdata('user');
        $vars['header1'] .= sprintf(' | %s ', anchor('user/profile', $CI->lang->line('login_profile')));
        $vars['header1'] .= sprintf(' | %s ', anchor('user/logout', $CI->lang->line('login_logout')));
      } else {
        $vars['header1'] .= $CI->lang->line('main_Annonymous');
        $vars['header1'] .= sprintf(' | %s ', anchor('user/login', $CI->lang->line('login_login')));
      }
    }

    return $vars;
  }

  /**
   * Return a html div with title and content inside
   *
   * Add a proper style sheet for 'msg_3' that represents a Success message
   *
   * @public
   * 
   * @param title (string) The title of the message
   * @param content (string) The content of the message
   * 
   * @return string
   */
  function msgSuccess ($title, $content) {
    return msg ($title, $content, 3);
  }


  /**
   * Return a html div with title and content inside
   *
   * Add a proper style sheet for 'msg_4' that represents a Error message
   *
   * @public
   * 
   * @param title (string) The title of the message
   * @param content (string) The content of the message
   * 
   * @return string
   */
  function msgErr ($title, $content) {
    return msg ($title, $content, 4);
  }


  /**
   * Return a html div with title and content inside
   *
   * Add a proper style sheet for 'msg_2' that represents a Warning message
   *
   * @public
   * 
   * @param title (string) The title of the message
   * @param content (string) The content of the message
   * 
   * @return string
   */
  function msgWarning ($title, $content) {
    return msg ($title, $content, 2);
  }


  /**
   * Return a html div with title and content inside
   *
   * Add a proper style sheet for 'msg_1' that represents a Normal message
   *
   * @public
   * 
   * @param title (string) The title of the message
   * @param content (string) The content of the message
   * 
   * @return string
   */
  function msgNormal ($title, $content) {
    return msg ($title, $content, 1);
  }


  /**
   * Return a html div with title and content inside
   *
   * @public
   * 
   * @param title (string) The title of the message
   * @param content (string) The content of the message
   * @param type (enum: 1, 2, 3, 4) The type of message, which will include a specific CSS. CSS are: msg_1, msg_2, msg_3 and msg_4 for 1,2,3 and 4 respectively
   * 
   * @return string
   */
  function msg ($title, $content, $type) {
    switch ($type) {
      case 2:
        $class = 'msg_2';
        break;
      case 3:
        $class = 'msg_3';
        break;
      case 4:
        $class = 'msg_4';
        break;
      case 1:
      default:
        $class = 'msg_1';
        break;
    }

    $tmp = "<div class='".$class."'>";
    if ($title != "") $tmp .= "<h4>$title</h4>";
    $tmp .=  "$content</div><br />";
    return $tmp;
  }


  /**
   * Creates the valid html blocks of the portal.
   *
   * Valid blocks are those enabled, matching the language selected and with access granted for logged user/admin
   *
   * Blocks side are represented with a number:
   *
   * @li -1 for all blocks
   * @li 1 blocks at left
   * @li 2 blocks at right
   * @li 3 blocks at center-up (inside content)
   * @li 4 blocks at center-down (inside content)
   * @li 5 blocks at up (before content)
   * @li 6 blocks at down (after content)
   *
   * @public
   * 
   * @param side (enum: -1, 1, 2, 3, 4, 5, 6) Blocks to create. Also this variable can be an array with a combination of that numbers
   * 
   * @return nothing
   */
  function make_blocks ($side=-1) {

    /*
    "1" Left
    "2" Right
    "3" Center-Up
    "4" Center-Down
    "5" Up
    "6" Down
    */

    $blocks = array('1'=>'','2'=>'','3'=>'','4'=>'','5'=>'','6'=>'','7'=>'');

    $numsides = sizeof($blocks)-1;

    $CI =& get_instance();

    $where = '';
    if (is_array($side)) {// && sizeof($side) > 0
      foreach ($side as $value) {
        if ($where != '') $where .= ' || ';
        $where .= 'side='.$value;
      }
      $where = '('. $where .')';
    } else {
      if ($side != -1) $where = 'side='.$side;
    }
    if ($where != '') $where .= ' && ';
    $where .= 'enabled=1 && (lang="'.$CI->config->item('language').'" || lang="") ';


//erm FIN buscar si el visitante actual tiene todos los permisos disponibles para entrar
//-------------------------------------------------------------------------------------------
    $wheregroups = get_sql_wheregroups_granted();

    if ($wheregroups != '') $where .= ' && ('.$wheregroups.')';

    $CI->db->where($where);
    $CI->db->orderby("side, sort, name");
    $query = $CI->db->get('blocks');

    if ($query->num_rows() > 0) {
      foreach ($query->result() as $row) {
        if ($row->side > $numsides || $row->side < 0) $actualside = $numsides + 1;
        else $actualside = $row->side;

        if ($row->type == 1) {
          //erm the block is content type
          $row->content = str_replace('{base_url}', $CI->config->item('base_url'), $row->content);
          $row->content = str_replace('{site_url}', $CI->config->site_url(), $row->content);
          $blocks[$actualside] .= block($row->name, $row->content);
        }

        if ($row->type == 2) {
          //erm the block is file type
          $file = APPPATH.'blocks/'.$row->file.'_block.php';
          if (is_readable($file)) {
            include_once($file);
            $filecontent = '';
            eval('$filecontent = '.$row->file.'_block::_get_content();');
            $blocks[$actualside] .= block($row->name, $filecontent);
          } else {
            $blocks[$actualside] .= block('Missing '.$row->file.' file', ' ');
          }
        }
      }
    }

    foreach ($blocks as $key => $value) {
      $name_var = 'block_side'.$key;
      $CI->$name_var = $value;
    }
  }



  /**
   * Return a html div representing a block with title and content
   *
   * @public
   * 
   * @param title (string) The title of the block
   * @param content (string) The content of the block
   * 
   * @return string
   */
  function block ($title, $content) {

    if ($title == "" && $content == "") return "";

    $tmp = "<div>";
    if ($title != "") $tmp .= "<div class='blocktitle'>$title</div>";
    if ($content != "") $tmp .= "<div class='block'>$content</div>";
    $tmp .= "</div>";

    return $tmp;
  }


  /**
   * Return a html div representing a banner with title and content
   *
   * @public
   * 
   * @param title (string) The title of the block
   * @param content (string) The content of the block
   * 
   * @return string
   */
  function Banner ($title, $content) {
    $tmp = "<div id='banner' class='banner'>";
    if ($title != "") $tmp .= "<h5>$title</h5>";
    $tmp .=  "$content</div>";
    return $tmp;
  }


  /**
   * Return a html page split into left, center and right sides.
   *
   * Each side will have the Blocks created with make_blocks function. Center side generally will have the Modules result.
   *
   * @public
   * 
   * @param left (string) The content to include at left side
   * @param center (string) The content to include at center side
   * @param right (string) The content to include at right side
   * 
   * @return string
   */
  function theme($left, $center="", $right="") {

    $CI =& get_instance();

    if ($CI->session->userdata('ip_address') == '10.0.0.5') {
      $CI->output->enable_profiler();
    }

    $tmp = '';

    if (isset($CI->block_side5) && $CI->block_side5 != "") {
      $tmp .= $CI->block_side5;
    }

    $tmp .= '
    <table id="content" style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
    <tr>
    ';

    if (isset($left) && $left != "") {
      $tmp .= '<td  id="lcontent" class="lcontent" style="vertical-align: top; ">';
      $tmp .= $left;
      $tmp .= '</td>';
    }

    if (isset($center) && $center != "") {
      $tmp .= '<td id="ccontent" class="ccontent" style="vertical-align: top; ">';
      if (isset($CI->block_side3) && $CI->block_side3 != "") {
        $tmp .= $CI->block_side3;
      }
      $tmp .= $center;
      if (isset($CI->block_side4) && $CI->block_side4 != "") {
        $tmp .= $CI->block_side4;
      }
      $tmp .= '</td>';
    }

    if (isset($right) && $right != "") {
      $tmp .= '<td id="rcontent" class="rcontent" style="vertical-align: top; width: ">';
      $tmp .= $right;
      $tmp .= '</td>';
    }

    $tmp .= '
    </tr>
    </table>
    ';

    if (isset($CI->block_side6) && $CI->block_side6 != "") {
      $tmp .= $CI->block_side6;
    }

    return $tmp;
  }


  /**
   * Return an array with the list of portal languages
   *
   * These languages files are located into .../clinic/app/languages directory
   *
   * @public
   * 
   * @return array
   */
  function get_lang_list() {
    $CI =& get_instance();
    $CI->load->helper('directory');

    $data = directory_map(APPPATH.'/language');
    $langs = array();
    $langs[''] = $CI->lang->line('admin_all');
    foreach ($data as $item) {
      if (is_dir(APPPATH.'/language/'.$item)) {
        $tmp = str_replace('_',' ',$item);
        $langs[$item] = strtoupper(substr($tmp, 0, 1)) . substr($tmp, 1, strlen($tmp));
      }
    }
    return $langs;
  }



  /**
   * Return an array with the list installed themes
   *
   * Each theme is a file located into .../clinic/app/views directory.
   *
   * Each theme would have its own directory located into .../clinic/img with the same name and the prefix 'theme_'.
   * 
   * Into that directory you will store theme images, theme CSS, etc.
   *
   * @public
   * 
   * @return array
   */
  function get_theme_list() {
    $CI =& get_instance();
    $CI->load->helper('directory');

    $data = directory_map(APPPATH.'/views');
    $themes = array();
    foreach ($data as $item) {
      $tmp = str_replace('_',' ',$item);
      $themes[$item] = strtoupper(substr($tmp, 0, 1)) . substr($tmp, 1, strpos($tmp, '.')-1);
    }

    return $themes;
  }

?>
