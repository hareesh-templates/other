<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @file login_helper.php
 * @brief File to handle granted access related issues
 * 
 * @details
 *
 * @author Erick Romero [http://www.adalid-soft.com] / Alexander Amato [http://www.checkup.med.br/clinicmed/license.html]
 * @version 1.0
 *
 * @sa Clinic_MED - Helper
 */

// ---------------------------------------------------------------------------------------------------------

  /**
   * Return TRUE when the module is installed, enabled and the user has access granted to it, otherwise FALSE
   *
   * @public
   * 
   * @param modulecode string the module code to search
   * 
   * @return boolean
   */
  function is_module ($modulecode='') {

    $CI =& get_instance();

    static $moduleinfo = array();
    static $ismodule = -1;
    if ($ismodule != -1) {
      $CI->moduleinfo = $moduleinfo;
      return $ismodule;
    }

    $modules_granted = get_granted_modules();
    if (isset($modules_granted[$modulecode])) {
      $moduleinfo['code'] =  $modulecode;
      $moduleinfo['name'] =  $modules_granted[$modulecode];
      $ismodule = 1;
    } else {
      $ismodule = 0;
    }

    return $ismodule;

  }


  /**
   * Return a valid SQL query with the groups which the user belongs to.
   * 
   * Intented to be used into WHERE clause for SQL queries
   *
   * @public
   * 
   * @return string
   */
  function get_sql_wheregroups_granted () {

    static $wheregroups = "-1";
    if ($wheregroups != "-1") {
      return $wheregroups;
    }

    $CI =& get_instance();

//erm buscar si el visitante actual tiene todos los permisos disponibles para entrar
//-------------------------------------------------------------------------------------------

    $wheregroups = " groupaccess like '%+all[]%' ";
    if (is_admin()) {
      if ($wheregroups != '') $wheregroups .= ' || ';
      $wheregroups .= " groupaccess like '%+admin[]%' ";
    }

    if (is_user()) {

//erm buscar por los customgroups que esten activados
//-------------------------------------------------------------------------------------------

      $groups = array();
      $CI->db->where('status=1');
      $CI->db->orderby('code');
      $query = $CI->db->get('usersgroups');
      foreach ($query->result() as $row) {
        $groups[$row->code.'[]'] = 1;
      }


      if ($wheregroups != '') $wheregroups .= ' || ';
      $wheregroups .= " groupaccess like '%+user[]%' ";

      $customgroups = explode('+', $CI->userinfo['groups']);
      foreach ($customgroups as $key) {
        if ($key != '' && isset($groups[$key])) {
          if ($wheregroups != '') $wheregroups .= ' || ';
          $wheregroups .= " groupaccess like '%+".$key."%' ";
        }
      }
    }

    if (!is_user() && !is_admin()) {
      if ($wheregroups != '') $wheregroups .= ' || ';
      $wheregroups .= " groupaccess like '%+guest[]%' ";
    }

    return $wheregroups;

  }


  /**
   * Return an array with the user granted modules
   * 
   * The array returned is in the way array[module_code] = 'module_name'
   *
   * @public
   * 
   * @return array
   */
 function get_granted_modules () {

    static $granted_modules_links = "-1";
    if ($granted_modules_links != "-1") {
      return $granted_modules_links;
    }

    $CI =& get_instance();

    $text = '';

    $where = ' enabled=1 ';
    if ($where != '') $where .= ' && ';
    //$where .= ' (lang="'.$CI->config->item('language').'" || lang="") ';
    $where .= sprintf(' (lang="%s" || lang="") ', $CI->config->item('language'));

//erm FIN buscar si el visitante actual tiene todos los permisos disponibles para entrar
//-------------------------------------------------------------------------------------------
    $wheregroups = get_sql_wheregroups_granted();

    if ($wheregroups != '') $where .= ' && ('.$wheregroups.')';

    $CI->db->where($where);
    $CI->db->orderby('name');
    $query = $CI->db->get('modules');

    $granted_modules_links = array();

    //erm probar si el modulo esta activo en la base de datos
    if ($query->num_rows() > 0) {

      //erm probar si el archivo existe fisicamente en el disco duro
      $moduleslist = get_modules_list();

      foreach ($query->result() as $row) {
        if (isset($moduleslist[$row->code])) {
          if ($row->visible == 0) $row->name = $row->name . ' .:hidden:.';
          $granted_modules_links[$row->code] = $row->name;
        }
      }
    }

    return $granted_modules_links;

  }


  /**
   * Return TRUE if the user is a valid logged user
   *
   * It is a valid user when: the user is logged, enabled (Administration Panel - Users Option) and session has not expired
   * 
   * @public
   * 
   * @return boolean
   */
  function is_user () {

    $CI =& get_instance();

    static $userinfo = array();
    static $isuser = -1;
    if ($isuser != -1) {
      $CI->userinfo = $userinfo;
      return $isuser;
    }

    if (!$CI->session->userdata('user') || !$CI->session->userdata('userpass')) {
      //erm sino estan definidas las cookies, no es admin
      $isuser = 0;
    } else {
      //erm si las cookies estan definidas, probar en la DB si es usuario
      $CI->db->where(array('status'=>1, 'code'=>$CI->session->userdata('user'), 'password'=>$CI->session->userdata('userpass'),'password<>'=>''));
      $query = $CI->db->get('users');
      if ($query->num_rows() > 0) {
        $userinfo = $query->row_array();
        $CI->userinfo = $userinfo;
        $isuser = 1;
      } else {
        $isuser = 0;
      }
    }
    return $isuser;
  }



  /**
   * Return TRUE if the admin is a valid logged admin
   *
   * It is a valid user when: the admin is logged, enabled (Administration Panel - Admin Option) and session has not expired
   * 
   * @public
   * 
   * @return boolean
   */
  function is_admin () {

    $CI =& get_instance();

    static $isadmin = -1;
    static $admininfo = array();
    if ($isadmin != -1) {
      $CI->admininfo = $admininfo;
      return $isadmin;
    }

    if (!$CI->session->userdata('admin') || !$CI->session->userdata('password')) {
      //erm sino estan definidas las cookies, no es admin
      $isadmin = 0;
    } else {
      //erm si las cookies estan definidas, probar en la DB si es admin
      $CI->db->where(array('code'=>$CI->session->userdata('admin'), 'password'=>$CI->session->userdata('password'),'password<>'=>''));
      $query = $CI->db->get('admins');
      if ($query->num_rows() > 0) {
        $admininfo = $query->row_array();
        $CI->admininfo = $admininfo;
        $isadmin = 1;
      } else {
        $isadmin = 0;
      }
    }

    return $isadmin;
  }


  /**
   * Return TRUE if the logged admin has access granted for the module/function, otherwise FALSE
   * 
   * @public
   *
   * @param module string The name's module
   * @param function string The name's funtion of the module
   * @param only_superuser boolean If set to TRUE then only a logged super_admin will have access granted
   * 
   * @return boolean
   */
  function admin_accesgranted ($module, $function, $only_superuser=FALSE) {

    $CI =& get_instance();

    $accesgrandted = 0;
    if (is_admin()) {

      if ($CI->admininfo['superuser'] == 1) {
        $accesgrandted = 1;
      } else {
        if ($only_superuser == TRUE) {
          $accesgrandted = 0;

        } else {
          $itemval[0] = '';
          $itemval[1] = '';
          $itemval[2] = '';
          eregi ('(\+'.$module.'[^[]*)\[([^]]*)', $CI->admininfo['accessgranted'], $itemval);
          $modules = explode(' ', $itemval[2]);
          foreach ($modules as $item) {
            if (strtoupper($item) == trim(strtoupper($function)) || $item == '**') {
              $accesgrandted = 1;
              break;
            }
          }
        }
      }
    }
    return $accesgrandted;
  }


  /**
   * Return a list of all Usergroups defined by admin
   *
   * Usergroups are managed into Administration Panel (Usersgroups option)
   * 
   * @public
   *
   * @return array
   */
  function get_usersgroups_list() {

    $CI =& get_instance();

    $dir = array();
    $CI->db->orderby('code');
    $query = $CI->db->get('usersgroups');
    foreach ($query->result() as $row) {
      $dir[$row->code] = $row->notes;
    }

    return $dir;
  }



  /**
   * Return an array with the PHP files located into controllers directory
   * 
   * @public
   *
   * @return array
   */
  function get_modules_list() {

    $CI =& get_instance();
    $dir = array();
    get_directory_list(&$dir, APPPATH.'/controllers','.php', 1);
    unset($dir['principal']);
    return $dir;

  }

  /**
   * Return an array with the PHP files located into blocks directory
   * 
   * @public
   *
   * @return array
   */
  function get_blocks_list() {

    $CI =& get_instance();
    $dir = array();
    get_directory_list(&$dir, APPPATH.'/blocks','_block.php', 1);
    return $dir;

  }


  /**
   * Return an array with the PHP files located into admin directory
   * 
   * @public
   *
   * @return array
   */
  function get_admin_list() {

    $CI =& get_instance();
    $dir = array();
    get_directory_list(&$dir, APPPATH.'/controllers/admin','.php', 1);
    unset($dir['principal']);

    return $dir;

  }


  /**
   * Return an array with the PHP files located into controllers directory recursively
   * 
   * @public
   *
   * @return array
   */
  function get_controllers_list() {

    $CI =& get_instance();
    $dir = array();
    $dir[' '] = '--- '.$CI->lang->line('menu_controllers').' ---';
    get_directory_list(&$dir, APPPATH.'/controllers/','.php', 0);
    return $dir;

  }

  /**
   * Creates an array with the list of files stored into the specified directory
   *
   * Each file will be added to the array with no extension
   * 
   * @public
   *
   * @param dir (array) this method will set this variable with the array created
   * @param path (string) the directory path to get
   * @param strip (string) the type of file to get. Include the dot (.) at beginning
   * @param onlyroot (boolean) Set to TRUE to include only files located inside.  Set to FALSE to include all files recursively (sub directories)
   * 
   * @return nothing
   */
  function get_directory_list(&$dir, $path, $strip='.php', $onlyroot=0) {
    $CI =& get_instance();
    $CI->load->helper('directory');

    $data = directory_map($path, $onlyroot);

    foreach ($data as $key => $value) {
      if (is_array($value)) {

        foreach ($value as $key2 => $value2) {
          if (strpos($value2, $strip) !== FALSE) {
            $value2 = str_replace($strip, '', $value2);
            $dir[$key.'/'.$value2] = str_replace('_',' ',$key.'/'.$value2);
          }
        }

      } else {
        if (strpos($value, $strip) !== FALSE) {
          $value = str_replace($strip, '', $value);
          //$dir[$value] = str_replace('_',' ',$value2);
          $dir[$value] = $value;
        }
      }
    }
    asort($dir);

  }


?>
