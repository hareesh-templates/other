window.addEvent('domready', function(){

  var speciality = $("Speciality");
  var calendar_control = $("Form_Day");
  var calendar = $("calendar");
  var physician = $("Physician");
  var time_control = $("Form_Hour");
  var time = $("time");

  var patient = $("Patient");
  var patient_control = $("patient_selected");

  var urlpath = location.href.split(".php")[0] +  ".php/appointment/";


//---------------------------------------------------------
//erm func to load physicians
//---------------------------------------------------------
  var ajax_physician = new Request.HTML({
    url: urlpath +  "form_physician",
    //update: physician,
    method: "get",
    autoCancel: true,
    onComplete: function() {

      physician.options.length = 0;
      var options = this.response.text.split('&&');
      for(i = 0; i < options.length; i++) {
        var option = options[i].split('|');
        physician.options[i] = new Option(option[2], option[0]);
        if (option[1] != "") physician.selectedIndex=i;
      }
      $("ajax_physician").removeClass("ajax-loading");

    }
  });

  $("ajax_physician").empty().addClass("ajax-loading");
  ajax_physician.send();

  physician.addEvent("change", function(){
    $("ajax_speciality").addClass("ajax-loading");
    calendar_control.set('value', "--");
    time_control.set('value', "--");

    var tmp_spec = "";
    if (physician != null) tmp_spec = physician.get('value');
    url =  urlpath + "form_speciality/" + tmp_spec;
    ajax_speciality.get(url);

  });

//---------------------------------------------------------
//erm func physician was selected, fill other controls
//---------------------------------------------------------
  var ajax_speciality = new Request.HTML({
    //update: speciality,
    method: "get",
    autoCancel: true,
    onComplete: function() {
      speciality.options.length = 0;

      if (physician.get('value') != "") {

        var options = this.response.text.split('&&');
        for(i = 0; i < options.length; i++) {
          var option = options[i].split('|');
          speciality.options[i] = new Option(option[2], option[0]);
          if (option[1] != "") speciality.selectedIndex=i;
        }
        $("ajax_physician").empty();
        speciality.fireEvent("change");

      } else {
        url = urlpath + "form_calendar_spe/";
        ajax_calendar.get(url);
        time.empty();
      }

      $("ajax_speciality").removeClass("ajax-loading");
    }
  });


  speciality.addEvent("change", function(){

    if (speciality.get('value') != "") {
      $("ajax_speciality").empty();
    }
    $("ajax_calendar").addClass("ajax-loading");

    var tmp_spec = "";
    if (physician != null) tmp_spec = physician.get('value');
    var tmp_month = "";
    if ($("cal_actual_month") != null) tmp_month = $("cal_actual_month").get('value');
    var tmp_phys = "";
    if (speciality.get('value') != null) tmp_phys = speciality.get('value');

    url = urlpath + "form_calendar_doc/" + tmp_spec + tmp_month + tmp_phys;
    ajax_calendar.get(url);

  });

//---------------------------------------------------------
//erm func physician selected, load calendar
//---------------------------------------------------------

  var ajax_calendar = new Request.HTML({
    update: calendar,
    method: "get",
    autoCancel: true,
    onComplete: function() {

      //erm agregar un evento para el mes anterior
      if ($("cal_previous") != null) {
        $("cal_previous").addEvent("click", function(e) {
          new Event(e).stop(); // prevent default
          if (physician.get('value') != '') {
            $("cal_actual_month").set('value', $("cal_previous").getProperty("title").replace("#","")+"/");
            speciality.fireEvent("change");
          } else {
            $("ajax_physician").set('html', "<span style='color: red;text-decoration: blink;font-weight: bold;font-size: medium;'>&raquo;&raquo;&raquo;</span>");
            $("ajax_time").removeClass("ajax-loading");
          }
        });
      }

      //erm agregar un evento para el mes siguiente
      if ($("cal_next") != null) {
        $("cal_next").addEvent("click", function(e) {
          new Event(e).stop(); // prevent default
          if (physician.get('value') != '') {
            $("cal_actual_month").set('value', $("cal_next").getProperty("title").replace("#","")+"/");
            speciality.fireEvent("change");
          } else {
            $("ajax_physician").set('html', "<span style='color: red;text-decoration: blink;font-weight: bold;font-size: medium;'>&raquo;&raquo;&raquo;</span>");
            $("ajax_time").removeClass("ajax-loading");
          }
        });
      }

      //erm agregar un evento para cuando se hace click en un dia
      var list = $$('#calendar div');
      list.each(function(element) {
        element.addEvent("click", function(e) {
          new Event(e).stop();

          if (physician.get('value') != "") {

            $("ajax_time").addClass("ajax-loading");

            if (speciality.get('value') != '') {

              $("ajax_calendar").empty();

              calendar_control.set('value', element.getProperty("id"));

              var spe = speciality.get("value");
              var phy = physician.get("value");
              var day = calendar_control.get("value");

              var url = urlpath  + 'form_hours' + '/' + spe + '/' + day + '/' + phy;
              ajax_physician_hours.get(url);

            } else {
              $("ajax_speciality").set('html', "<span style='color: red;text-decoration: blink;font-weight: bold;font-size: medium;'>&raquo;&raquo;&raquo;</span>");
              $("ajax_time").removeClass("ajax-loading");
            }
          } else {

            $("ajax_physician").set('html', "<span style='color: red;text-decoration: blink;font-weight: bold;font-size: medium;'>&raquo;&raquo;&raquo;</span>");
            $("ajax_time").removeClass("ajax-loading");

          }

        });
      });

      time.empty();
      calendar_control.set('value', "--");
      time_control.set('value', "--");
      var Tips1 = new Tips($$('.calendar_content'));

      $("ajax_calendar").removeClass("ajax-loading");

    }
  });

//---------------------------------------------------------
//erm calendar day selected, load the hours
//---------------------------------------------------------
  var ajax_physician_hours = new Request.HTML({
    update: time,
    method: "get",
    autoCancel: true,
    onComplete: function() {

      $("ajax_physician").empty();

      var list2 = $$('#schedule .schedule_free');
      list2.each(function(element2) {

        element2.addEvents({
            'mouseenter': function(){
              this.addClass('schedule_free_over');
            },
            'mouseleave': function(){
              this.removeClass('schedule_free_over');
            },
            'click': function(){
              time_control.set('value', this.get('text'));
              $("ajax_time").empty();
            }
        });

      });

      $("ajax_time").removeClass("ajax-loading");
      time_control.set('value',"--");
    }
  });


//---------------------------------------------------------
//erm something was typed into patient input, load list
//---------------------------------------------------------
  var ajax_patient = new Request.HTML({
    update: $("patient_results"),
    method: "get",
    onComplete: function() {

      //var Tips1 = new Tips($$('.schedule_patient'));

      var list = $$('.schedule_patient');
      list.each(function(element) {
        element.addEvent("click", function(e) {
          patient_control.set('value', element.getProperty("id"));
          $("ajax_patient").empty();
        });
      });
    }
  });

  patient.addEvent("keyup", function(e){

    patient_control.set('value', '--');

    var url = urlpath +  "form_search_patient/" + patient.get('value');
    ajax_patient.get(url);

  });

//---------------------------------------------------------
//erm search refresh button
//---------------------------------------------------------
  $("patient_refresh").addEvent("click", function(){
    patient.fireEvent('keyup');
  });

//---------------------------------------------------------
//erm new patient button
//---------------------------------------------------------
  var ajax_add_patient = new Request.HTML({
    url: urlpath +  "add_patient",
    //update: $("patient_results"),
    method: "get",
    onComplete: function() {

      $("ajax_patient").removeClass("ajax-loading");

      if (this.response.text == 'done') {

        var code = $('add_patient_code').get('value');
        patient.set('value', $('add_patient_name').get('value'));
        patient.fireEvent('keyup');
        patient_control.set('value', code);

      } else {

        $("patient_results").set('html', this.response.text);

        $('add_patient_send').addEvent('click', function() {

          var name = $('add_patient_name').get('value');
          var code = $('add_patient_code').get('value');

          if (name == '') name = ' ';
          if (code == '') code = ' ';

          var url = urlpath +  "add_patient/" + name + '/' + code;
          ajax_add_patient.get(url);

        });

      }
    }
  });

  $("patient_add").addEvent("click", function(){
    $("ajax_patient").addClass("ajax-loading");
    var url = urlpath +  "add_patient/" + patient.get('value');
    ajax_add_patient.get(url);
  });


//---------------------------------------------------------
//erm adding a new appoinment
//---------------------------------------------------------
  $("sumbmit_appoinment").addEvent("click", function(e) {

    var sendform = 1;

    if (speciality.get('value') == '') {
      $("ajax_speciality").set("html", "<span style='color: red;text-decoration: blink;font-weight: bold;font-size: medium;'>&raquo;&raquo;&raquo;</span>");
      sendform = 0;
    } else {
      $("ajax_speciality").empty();
    }

    if (physician.get('value') == '') {
      $("ajax_physician").set("html", "<span style='color: red;text-decoration: blink;font-weight: bold;font-size: medium;'>&raquo;&raquo;&raquo;</span>");
      sendform = 0;
    } else {
      $("ajax_physician").empty();
    }

    if (calendar_control.get('value') == '--') {
      $("ajax_calendar").set("html", "<span style='color: red;text-decoration: blink;font-weight: bold;font-size: medium;'>&raquo;&raquo;&raquo;</span>");
      sendform = 0;
    } else {
      $("ajax_calendar").empty();
    }

    if (time_control.get('value') == '--') {
      $("ajax_time").set("html", "<span style='color: red;text-decoration: blink;font-weight: bold;font-size: medium;'>&raquo;&raquo;&raquo;</span>");
      sendform = 0;
    } else {
      $("ajax_time").empty();
    }

    if (patient_control.get('value') == '--') {
      $("ajax_patient").set("html", "<span style='color: red;text-decoration: blink;font-weight: bold;font-size: medium;'>&raquo;&raquo;&raquo;</span>");
      sendform = 0;
    } else {
      $("ajax_patient").empty();
    }

    if (sendform == 0) {
      e.stop(); // prevent default
    }

  });

  url = urlpath + "form_calendar_spe/";
  ajax_calendar.get(url);

});
