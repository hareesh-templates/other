/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author DXM04
 */
public class detallesPaciente extends Activity {
    String procid;
    String telfamily="";
    String teldoc="";
    String telpac="";
    private AlertDialog alertDialog;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        String[] datos = new String[13];
        Bundle b = getIntent().getExtras();
        procid = (String)b.getCharSequence("PROCID");
        setContentView(R.layout.detallespac);
        
        datos = get_data(procid);
        if(datos!=null)
        {
            setdatos(datos);
        }
        else finish();
    }

    private String[] get_data(String procid) {
        
        String[] temp = new String[13];
        int temporal;
        String result = "";
        InputStream is=null;
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("idproc",procid));
        
        try{
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.1.100:2230/pacientdetail.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        }
        catch(Exception sex){
            Log.e("log_tag", "Error in http connection "+sex.toString());
        }
        //convert response to string
        try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
            }
            is.close();
            result=sb.toString();
            Log.e("log_tag", "Result:"+result);
        }
        catch(Exception sex){
            Log.e("log_tag", "Error converting result "+sex.toString());
        }
 
//parse json data
        try{
            JSONArray jArray = new JSONArray(result);
            JSONObject json_data = jArray.getJSONObject(0);
            
            temp[0] = json_data.getString("Nombres")+" "+json_data.getString("Apellidos");
            temp[1] = json_data.getString("tiposang");
            temp[2] = json_data.getString("factor");
            temp[3] = json_data.getString("sexo");
            temporal = json_data.getInt("edad");
            temp[4] = ""+temporal;
            temp[5] = json_data.getString("padecimientos");
            temp[6] = json_data.getString("alergias");
            temp[7] = json_data.getString("telcont");
            temp[8] = json_data.getString("familicont");
            temp[9] = json_data.getString("familitel");
            telfamily = temp[9];
            temp[10] = json_data.getString("medicpart");
            temp[11] = json_data.getString("medictel");
            teldoc = temp[11];
            temp[12] = json_data.getString("image"); 
                    
            return(temp);
        }
        catch(JSONException sex)
        {
            Log.e("log_tag", "Error parsing data "+sex.toString());
        }
        return null;
    }

    private void setdatos(String[] datos) {
        TextView Text;
        try
        {
            Text = (TextView)findViewById(R.id.headerdetalles);
            Text.setText(datos[0]);
            Text = (TextView)findViewById(R.id.fieldsangre);
            Text.setText(datos[1]);
            Text = (TextView)findViewById(R.id.fieldfactor);
            Text.setText(datos[2]);
            Text = (TextView)findViewById(R.id.fieldsexo);
            Text.setText(datos[3]);
            Text = (TextView)findViewById(R.id.fieldedad);
            Text.setText(datos[4]);
            Text = (TextView)findViewById(R.id.fieldproc);
            Text.setText(datos[5]);
            Text = (TextView)findViewById(R.id.fieldalerg);
            Text.setText(datos[6]);
            Text = (TextView)findViewById(R.id.fieldtel);
            Text.setText(datos[7]);
            Text = (TextView)findViewById(R.id.familycontfield);
            Text.setText(datos[8]);
            Text = (TextView)findViewById(R.id.familytelfield);
            Text.setText(datos[9]);
            Text = (TextView)findViewById(R.id.parmedicfield);
            Text.setText(datos[10]);
            Text = (TextView)findViewById(R.id.parmedictelfield);
            Text.setText(datos[11]);

            setimage(datos[12]);
        }
        catch (Exception er) {
            Log.e("data_error", "Error asignando datos: "+er.toString());
        }
    }

    private void setimage(String string) {
        ImageView v;
        String gurl;
        gurl = "http://192.168.1.100:2230/"+string;
        v = (ImageView)findViewById(R.id.test_image);
        try {
            Bitmap b = BitmapFactory.decodeStream((InputStream)new URL(gurl).getContent());
                v.setImageBitmap(b);
        } 
        catch (Exception er) {
            Log.e("image_error", "Imagen error: "+er.toString());
        }    
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Alternativa 1
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menudetail, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {       
        switch(item.getItemId())
        {
            case R.id.callfamily:
                if(telfamily.length()>0)
                    call("tel:"+telfamily);
                else showdialog("Llamar a Familiar","No hay número registrado");
            break;
            case R.id.callmedic:
                if(teldoc.length()>0)
                    call("tel:"+teldoc);
                else showdialog("Llamar a Médico","No hay número registrado");
            break;
            case R.id.callpacient:
                if(telpac.length()>0)
                    call("tel"+telpac);
                else showdialog("Llamar a Paciente","No hay número registrado");
            break;
            case R.id.retdetail:
                finish();
            break;
        }
        return true;
    }
    
    private void call(String teleph) 
    {
        try {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse(teleph));
            startActivity(callIntent);
        } 
        catch (ActivityNotFoundException activityException) 
        {
            Log.e("helloandroid dialing example", "Call failed");
        }
    }

    private void showdialog(String title, String message) {
        alertDialog = new AlertDialog.Builder(this).create();  
        alertDialog.setTitle(title);  
        alertDialog.setMessage(message);  
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {  
        public void onClick(DialogInterface dialog, int which) {  
            return;  
          } 
        });   
        alertDialog.show(); 
    }
}
