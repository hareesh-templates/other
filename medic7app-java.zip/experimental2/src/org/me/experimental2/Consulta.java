/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author DXM04
 */
public class Consulta extends Activity {
    private TextView ids;
    String ID;
    private AlertDialog alertDialog;
    boolean rec=false;
    String Name;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        Bundle b = getIntent().getExtras();
        ID = (String)b.getCharSequence("PROCID");
        Name = (String)b.getCharSequence("PATNA");
        setContentView(R.layout.consultaview);
        ids = (TextView)this.findViewById(R.id.reflabel2);
        if(ids!=null){
            ids.setText(" IDC: "+ID);
        }
        ids=(TextView)this.findViewById(R.id.paciname);
        if(ids!=null){
            ids.setText(Name);
        }
        llenadatos(ID);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Alternativa 1
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuconsulta, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        Intent menuactivity;
        
        switch(item.getItemId())
        {
            case R.id.labs:
                menuactivity = new Intent(Consulta.this,listalabs.class);
                menuactivity.putExtra("PROCID",ID);
                startActivity(menuactivity);
            break;
            case R.id.labsv:
                menuactivity = new Intent(Consulta.this, LabsRequest.class);
                menuactivity.putExtra("PROCID",ID);
                startActivity(menuactivity);
            break;
            case R.id.newStat:
                menuactivity = new Intent(Consulta.this, newEval.class);
                menuactivity.putExtra("PROCID",ID);
                menuactivity.putExtra("NAMEPAC",Name);
                startActivity(menuactivity);
                llenadatos(ID);
            break;
            case R.id.seguimiento:
                menuactivity = new Intent(Consulta.this, listaSeguimiento.class);
                menuactivity.putExtra("PROCID",ID);
                menuactivity.putExtra("NAMEPAC",Name);
                startActivity(menuactivity);
            break;
            case R.id.intercon:
                menuactivity = new Intent(Consulta.this, solicitConsult.class);
                menuactivity.putExtra("PROCID",ID);
                startActivity(menuactivity);
            break;
            case R.id.interconv:
                menuactivity = new Intent(Consulta.this, ICRequest.class);
                menuactivity.putExtra("PROCID",ID);
                startActivity(menuactivity);
            break;
            case R.id.detalles:
                menuactivity = new Intent(Consulta.this, detallesPaciente.class);
                menuactivity.putExtra("PROCID",ID);
                startActivity(menuactivity);
            break;
            case R.id.returnback:
                    this.finish();
            break;
            case R.id.cerrar:
                showsuredialog("Consulta","¿Deseas finalizar la consulta?");
                if(rec) this.finish();
                else return true;
            break;
        }
        
        return false;
    }
       
    private void llenadatos(String ID)
    {              
        String [] Cade;
        try
        {
            Cade = getpatientcadena(ID);
            if(Cade!=null)
            {
                ids=(TextView)this.findViewById(R.id.respres1);
                if(ids!=null){ ids.setText(" "+Cade[0]);}
                ids=(TextView)this.findViewById(R.id.pulse1data);
                if(ids!=null){ ids.setText(" "+Cade[1]);}
                ids=(TextView)this.findViewById(R.id.pulse2data);
                if(ids!=null){ ids.setText(" "+Cade[2]);}
                ids=(TextView)this.findViewById(R.id.pulse3data);
                if(ids!=null){ ids.setText(" "+Cade[3]);}
                ids=(TextView)this.findViewById(R.id.pressres);
                if(ids!=null){ ids.setText(Cade[4]);}
                ids=(TextView)this.findViewById(R.id.tempres);
                if(ids!=null){ ids.setText(" "+Cade[5]+"°C");}
                ids=(TextView)this.findViewById(R.id.medipada2);
                if(ids!=null){ ids.setText(Cade[6]);}
                ids=(TextView)this.findViewById(R.id.medipada3);
                if(ids!=null){ ids.setText(Cade[7]);}
                ids=(TextView)this.findViewById(R.id.header2);
                if(ids!=null){ ids.setText("Fecha: "+Cade[8]);}
            }
        }
        catch(Exception sex){
            Log.e("log_tag", "Error in inserting data "+sex.toString());
        }
    }
    
    private String[] getpatientcadena(String idc)
    {   
        String[] Datos = new String[9];
        
        String result = "";
        InputStream is=null;
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("idproc",idc));
        
        try{
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.1.100:2230/retrievepatientconsult.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        }
        catch(Exception sex){
            Log.e("log_tag", "Error in http connection "+sex.toString());
        }
        //convert response to string
        try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
            }
            is.close();
            result=sb.toString();
            Log.e("log_tag", "Result:"+result);
        }
        catch(Exception sex){
            Log.e("log_tag", "Error converting result "+sex.toString());
        }
 
//parse json data
        try{
            JSONArray jArray = new JSONArray(result);
            JSONObject json_data = jArray.getJSONObject(0);
            
            Datos[0] = json_data.getString("respiracion");
            Datos[1] = json_data.getString("pulso1");
            Datos[2] = json_data.getString("pulso2");
            Datos[3] = json_data.getString("pulso3");
            Datos[4] = json_data.getString("pression");
            Datos[5] = json_data.getString("temperatura");
            Datos[6] = json_data.getString("mediceva");
            Datos[7] = json_data.getString("consul_data");
            Datos[8] = json_data.getString("fecha");
            return(Datos);
        }
        catch(JSONException sex)
        {
            Log.e("log_tag", "Error parsing data "+sex.toString());
        }
        return null;
    }
    
    //Con 1 la salva a consulta, con 2 la salva a finalizar
    private boolean saveconsulta()
    {
        String result = null;
        
        InputStream is=null;
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();   
        nameValuePairs.add(new BasicNameValuePair("idproc",ID));
        
        try{
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.1.100:2230/finalizeconsult.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        }
        catch(Exception sexy){
            Log.e("log_tag", "Error in http connection "+sexy.toString());
        }
        
         try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
            }
            is.close();
            result=sb.toString();
            Log.e("log_tag", "Result:"+result);
        }
        catch(Exception sex){
            Log.e("log_tag", "Error converting result "+sex.toString());
        }
 
        //parse json data
        try{
            JSONObject json_data = new JSONObject(result);
            
            if(json_data.getInt("result") == 1)
                return true;
            else return false;
        }
        catch(JSONException sex)
        {
            Log.e("log_tag", "Error parsing data "+sex.toString());
        }
        return false;
    }

    private void showmyDialog(String titulo, String mensaje) {
        alertDialog = new AlertDialog.Builder(this).create();  
        alertDialog.setTitle(titulo);  
        alertDialog.setMessage(mensaje);  
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {  
        public void onClick(DialogInterface dialog, int which) {  
            return;  
          } 
        });   
        alertDialog.show(); 
    }
    
    private boolean finishconsulta()
    {
        if(saveconsulta()){
            return true;
        }
        else return false;
    }
    
    private void showsuredialog(String titulo, String mensaje)
    {
        final AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setIcon(android.R.drawable.ic_dialog_alert);
        b.setTitle(titulo);
        b.setMessage(mensaje);
        b.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface arg0, int arg1) {
                
                if(finishconsulta())
                {
                    showmyDialog("Consulta","Se ha finalizado correctamente.");
                    rec = true;
                }
                else{
                    showmyDialog("Consulta","No se ha podido finalizar.");
                    rec = false;
                } 
                return;
            }
        });
        b.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface arg0, int arg1) {
                return;
            }
        });
        b.show();
    }
}
