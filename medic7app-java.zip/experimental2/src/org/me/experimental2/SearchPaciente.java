/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.Editable;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 *
 * @author DXM04
 */
public class SearchPaciente extends Activity {
    public static final int ID_PAC = 35;
    private AlertDialog alertDialog;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.searchpat);
        
        Button cancel = (Button)findViewById(R.id.CancelaSearch);
        cancel.setOnClickListener(new OnClickListener() {

            public void onClick(View arg0) {
                return;
            }
        });
        
        Button accept = (Button)findViewById(R.id.AcceptSearch);
        accept.setOnClickListener(new OnClickListener() {

            public void onClick(View arg0) {
                Intent busqueda;
                String nombre = ((EditText)findViewById(R.id.editnombre)).getText().toString();
                String apellido = ((EditText)findViewById(R.id.editapelli)).getText().toString();
                
                if((nombre.length()>1) && (apellido.length()>1))
                {
                    busqueda = new Intent(SearchPaciente.this, listaResult.class);
                    busqueda.putExtra("nombres", nombre);
                    busqueda.putExtra("apellidos",apellido);
                    startActivityForResult(busqueda,ID_PAC);
                }
                else
                {
                    showalert("Búsqueda","Se requieren datos precisos.");
                }
            }

            private void showalert(String title, String mensaje) {
                
            }
        });
    }
    
    private void showalert(String title, String mensaje) {
        alertDialog = new AlertDialog.Builder(this).create();  
        alertDialog.setTitle(title);  
        alertDialog.setMessage(mensaje);  
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {  
        public void onClick(DialogInterface dialog, int which) {  
            return;  
          } 
        });   
        alertDialog.show(); 
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        switch(requestCode)
        {
            case ID_PAC:
                if(resultCode==RESULT_OK){
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("selectedid",data.getStringExtra("idfinal"));
                    returnIntent.putExtra("nombreB", data.getStringExtra("nombreC"));
                    setResult(RESULT_OK,returnIntent);
                    finish();
                }
            break;
        }
    }
}
