/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author DXM04
 */
public class newEval extends Activity {
    String ID;
    String nameP;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        Bundle b = getIntent().getExtras();
        ID = (String)b.getCharSequence("PROCID");
        nameP = (String)b.getCharSequence("NAMEPAC");
        
        setContentView(R.layout.hojaenferma);
        
        TextView T = (TextView)findViewById(R.id.headerenf);
        T.setText("IDC: "+ID+" -- "+nameP);
        
        Spinner respiracion =(Spinner)this.findViewById(R.id.respirationselectenf);
        ArrayAdapter<CharSequence> radapter = ArrayAdapter.createFromResource(this,R.array.respiration_array,android.R.layout.simple_spinner_item);
        respiracion.setAdapter(radapter);
        
        Spinner pulse1 = (Spinner)this.findViewById(R.id.pulselect1enf);
        ArrayAdapter<CharSequence> p1adapt = ArrayAdapter.createFromResource(this,R.array.pulse_array1,android.R.layout.simple_spinner_item);
        pulse1.setAdapter(p1adapt);
        
        Spinner pulse2 = (Spinner)this.findViewById(R.id.pulselect2enf);
        ArrayAdapter<CharSequence> p2adapt = ArrayAdapter.createFromResource(this,R.array.pulse_array2,android.R.layout.simple_spinner_item);
        pulse2.setAdapter(p2adapt);
        
       Button guardar = (Button)this.findViewById(R.id.Acceptenf);
        guardar.setOnClickListener(new OnClickListener() {

            public void onClick(View arg0) {
                if(saveentry())
                {
                    AlertDialog alertDialog = new AlertDialog.Builder(newEval.this).create();
                    alertDialog.setTitle("Ingreso");
                    alertDialog.setMessage("Hoja de evaluación creada.");
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                       public void onClick(DialogInterface dialog, int which) {
                          finish();
                       }
                    });
                    alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
                    alertDialog.show();
                }
                else
                {
                    AlertDialog alertDialog = new AlertDialog.Builder(newEval.this).create();
                    alertDialog.setTitle("Ingreso");
                    alertDialog.setMessage("No se ha podido guardar ¿Faltan datos?");
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                       public void onClick(DialogInterface dialog, int which) {
                          return;
                       }
                    });
                    alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
                    alertDialog.show();
                }
            }
        });
        
        Button cancela = (Button)this.findViewById(R.id.Cancelaenf);
        cancela.setOnClickListener(new OnClickListener() {

            public void onClick(View arg0) {
                finish();
            }
        }); 
    }
    
    
    private boolean saveentry() 
    {
        String[] Datos = new String[9];
        String result = "";
        InputStream is=null;
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        
        Datos[0] = ((Spinner)findViewById(R.id.respirationselectenf)).getSelectedItem().toString();
        Datos[1] = ((EditText)findViewById(R.id.pulseenf)).getText().toString();
        Datos[2] = ((Spinner)findViewById(R.id.pulselect1enf)).getSelectedItem().toString();
        Datos[3] = ((Spinner)findViewById(R.id.pulselect2enf)).getSelectedItem().toString();
        Datos[4] = ((EditText)findViewById(R.id.upperenf)).getText().toString();
        Datos[5] = ((EditText)findViewById(R.id.lowerenf)).getText().toString();
        Datos[6] = ((EditText)findViewById(R.id.tempeenf)).getText().toString();
        Datos[7] = ((EditText)findViewById(R.id.actualpadaenf)).getText().toString();
        Datos[8] = ((EditText)findViewById(R.id.medipadaenf)).getText().toString();
        for(int i=0;i<9;i++)
            if(Datos[i].length()<1)
                return false;
        
        nameValuePairs.add(new BasicNameValuePair("respira",Datos[0]));
        nameValuePairs.add(new BasicNameValuePair("pulso",Datos[1]));
        nameValuePairs.add(new BasicNameValuePair("pulso2",Datos[2]));
        nameValuePairs.add(new BasicNameValuePair("pulso3",Datos[3]));
        nameValuePairs.add(new BasicNameValuePair("upper",Datos[4]));
        nameValuePairs.add(new BasicNameValuePair("lower",Datos[5]));
        nameValuePairs.add(new BasicNameValuePair("tempera",Datos[6]));
        nameValuePairs.add(new BasicNameValuePair("medieva",Datos[7]));
        nameValuePairs.add(new BasicNameValuePair("medicine",Datos[8]));
        nameValuePairs.add(new BasicNameValuePair("idproc",ID));
        
        try{
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.1.100:2230/saveconsult.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        }
        catch(Exception sexy){
            Log.e("log_tag", "Error in http connection "+sexy.toString());
        }
        
         try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
            }
            is.close();
            result=sb.toString();
            Log.e("log_tag", "Result:"+result);
        }
        catch(Exception sex){
            Log.e("log_tag", "Error converting result "+sex.toString());
        }
 
        //parse json data
        try{
            JSONObject json_data = new JSONObject(result);
            
            if(json_data.getInt("result") == 1)
                return true;
            else return false;
        }
        catch(JSONException sex)
        {
            Log.e("log_tag", "Error parsing data "+sex.toString());
        }
        return false;
    }
}
