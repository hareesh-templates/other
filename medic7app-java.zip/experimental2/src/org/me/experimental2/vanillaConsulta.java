/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author DXM04
 */
public class vanillaConsulta extends Activity {
    private TextView ids;
    String ID;
    boolean rec=false;
    String Name;
    String IDC;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        super.onCreate(icicle);
        Bundle b = getIntent().getExtras();
        IDC = (String)b.getCharSequence("CONID");
        Name = (String)b.getCharSequence("PATNA");
        
        setContentView(R.layout.consultaview);
        ids = (TextView)this.findViewById(R.id.reflabel2);
        if(ids!=null){
            ids.setText("IDC: "+IDC);
        }
        ids=(TextView)this.findViewById(R.id.paciname);
        if(ids!=null){
            ids.setText(Name);
        }
        llenadatos(IDC);    
    }
    
    private void llenadatos(String IDX)
    {              
        String [] Cade;
        try
        {
            Cade = getpatientcadena(IDX);
            if(Cade!=null)
            {
                ids=(TextView)this.findViewById(R.id.respres1);
                if(ids!=null){ ids.setText(" "+Cade[0]);}
                ids=(TextView)this.findViewById(R.id.pulse1data);
                if(ids!=null){ ids.setText(" "+Cade[1]);}
                ids=(TextView)this.findViewById(R.id.pulse2data);
                if(ids!=null){ ids.setText(" "+Cade[2]);}
                ids=(TextView)this.findViewById(R.id.pulse3data);
                if(ids!=null){ ids.setText(" "+Cade[3]);}
                ids=(TextView)this.findViewById(R.id.pressres);
                if(ids!=null){ ids.setText(Cade[4]);}
                ids=(TextView)this.findViewById(R.id.tempres);
                if(ids!=null){ ids.setText(" "+Cade[5]+"°C");}
                ids=(TextView)this.findViewById(R.id.medipada2);
                if(ids!=null){ ids.setText(Cade[6]);}
                ids=(TextView)this.findViewById(R.id.medipada3);
                if(ids!=null){ ids.setText(Cade[7]);}
                ids=(TextView)this.findViewById(R.id.header2);
                if(ids!=null){ ids.setText("Fecha: "+Cade[8]);}
            }
        }
        catch(Exception sex){
            Log.e("log_tag", "Error in inserting data "+sex.toString());
        }
    }
    
    private String[] getpatientcadena(String idc)
    {   
        String[] Datos = new String[9];
        
        String result = "";
        InputStream is=null;
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("idcon",idc));
        
        try{
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.1.100:2230/retrieveconsultbefore.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        }
        catch(Exception sex){
            Log.e("log_tag", "Error in http connection "+sex.toString());
        }
        //convert response to string
        try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
            }
            is.close();
            result=sb.toString();
            Log.e("log_tag", "Result:"+result);
        }
        catch(Exception sex){
            Log.e("log_tag", "Error converting result "+sex.toString());
        }
 
//parse json data
        try{
            JSONArray jArray = new JSONArray(result);
            JSONObject json_data = jArray.getJSONObject(0);
            
            Datos[0] = json_data.getString("respiracion");
            Datos[1] = json_data.getString("pulso1");
            Datos[2] = json_data.getString("pulso2");
            Datos[3] = json_data.getString("pulso3");
            Datos[4] = json_data.getString("pression");
            Datos[5] = json_data.getString("temperatura");
            Datos[6] = json_data.getString("mediceva");
            Datos[7] = json_data.getString("consul_data");
            Datos[8] = json_data.getString("fecha");
            return(Datos);
        }
        catch(JSONException sex)
        {
            Log.e("log_tag", "Error parsing data "+sex.toString());
        }
        return null;
    }
}
