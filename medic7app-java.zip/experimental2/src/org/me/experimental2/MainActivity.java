/*
 * Medic7App : El 7 es porque es el séptimo intento.
 *
 * Esta aplicación es el producto de ideas, conocimiento, motivación y esfuerzo de varias personas.
 * Es por ello que es de todos y para todos, no de un sólo individuo.
 * 
 * Usar con fines educativos. Queda prohibido su uso con fines de distribución.
 * Y sí algún día llega a ser muy buena, será libre, sin insignias, sin créditos.
 * 
 * Dedicado a Lucy D. <--Esto se queda siempre.
 * 
 */
package org.me.experimental2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/**
 *
 * @author DXM04
 */
public class MainActivity extends Activity {

    Intent i;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.main);
        
        /*Button para la evaluación inicial*/
        final Button b = (Button)this.findViewById(R.id.triagebtn);
        b.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
             getdata(1);
            }
        });
        
        /*Button para consulta*/
        final Button v = (Button)this.findViewById(R.id.conslutbtn);
        v.setOnClickListener(new OnClickListener(){
            public void onClick(View arg0) {
                getdata(2);
            }
        });
        
        /*Button para cerrar*/
        final Button x = (Button)this.findViewById(R.id.Cerrarbtn);
        x.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                finish();
            }
        });
    }
    /*Invoca a las actividades*/
    public void getdata(int opt)
    {
        switch(opt)
        {
            case 1:
                    i = new Intent(MainActivity.this, takedata.class);
                    startActivity(i);
            break;
            case 2:
                    i = new Intent(MainActivity.this, listconsult.class);
                    startActivity(i);
            break;
            case 3:
            break;
            default:
            break;  
        }
    }
}
