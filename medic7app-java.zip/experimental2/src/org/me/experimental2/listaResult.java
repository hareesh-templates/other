/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author DXM04
 */
public class listaResult extends ListActivity{
    String name;
    String apell;
    String idp;
    
    private ProgressDialog m_ProgressDialog = null; 
    private ArrayList<Order> m_orders = null;
    private OrderAdapter m_adapter;
    private Runnable viewOrders;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        Bundle b = getIntent().getExtras();
        name = (String)b.getCharSequence("nombres");
        apell = (String)b.getCharSequence("apellidos");
        
        setContentView(R.layout.list_item);
        m_orders = new ArrayList<Order>();
        this.m_adapter = new OrderAdapter(this, R.layout.row, m_orders);
        setListAdapter(this.m_adapter);
        
        viewOrders = new Runnable(){
            @Override
            public void run() {
                getOrders();
            }
        };
        Thread thread =  new Thread(null, viewOrders, "MagentoBackground");
        thread.start();
        m_ProgressDialog = ProgressDialog.show(listaResult.this, "Please wait...", "Retrieving data ...", true);
    }
    
    private Runnable returnRes = new Runnable() {

        @Override
        public void run() {
            if(m_orders != null && m_orders.size() > 0){
                m_adapter.notifyDataSetChanged();
                for(int i=0;i<m_orders.size();i++)
                m_adapter.add(m_orders.get(i));
            }
            m_ProgressDialog.dismiss();
            m_adapter.notifyDataSetChanged();
        }
    };
    
    private void getOrders()
    {
        String result = "";
        InputStream is=null;
        int partial;
        String party;
        
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("pacname",name));
        nameValuePairs.add(new BasicNameValuePair("pacappe",apell));
        
        try{
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.1.100:2230/searchpacient.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        }
        catch(Exception sex){
            Log.e("log_tag", "Error in http connection "+sex.toString());
        }
        //convert response to string
        try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
            }
            is.close();
            result=sb.toString();
            Log.e("log_tag", "Result:"+result);
        }
        catch(Exception sex){
            Log.e("log_tag", "Error converting result "+sex.toString());
        }
 
//parse json data
        try{
            m_orders = new ArrayList<Order>();
            JSONArray jArray = new JSONArray(result);
            for(int i=0;i<jArray.length();i++)
            {
                JSONObject json_data = jArray.getJSONObject(i);
                Order o1 = new Order();
                o1.setOrderName(json_data.getString("Nombres")+" "+json_data.getString("Apellidos"));
                o1.setOrderStatus(json_data.getString("Direccion"));
                partial = json_data.getInt("id_paciente");
                party =partial+"";
                o1.setidpatient(party);
                m_orders.add(o1);
            }
            
        }
        catch(JSONException sex)
        {
            Log.e("log_tag", "Error parsing data "+sex.toString());
        }
        runOnUiThread(returnRes);
    }
    
    private class OrderAdapter extends ArrayAdapter<Order> {

        private ArrayList<Order> items;

        public OrderAdapter(Context context, int textViewResourceId, ArrayList<Order> items) {
                super(context, textViewResourceId, items);
                this.items = items;
        }
        
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
                View v = convertView;
                if (v == null) {
                    LayoutInflater vi = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    v = vi.inflate(R.layout.row, null);
                }
                Order o = items.get(position);
                if (o != null) {
                        TextView tt = (TextView) v.findViewById(R.id.toptext);
                        TextView bt = (TextView) v.findViewById(R.id.bottomtext);
                        TextView ip = (TextView) v.findViewById(R.id.patid);
                        if (tt != null) {
                              tt.setText("NOMBRE: "+o.getOrderName());                            
                        }
                        if(bt != null){
                              bt.setText("DIR: "+ o.getOrderStatus());
                        }
                        if(ip != null){
                              ip.setText("ID: "+ o.getidpatient());
                        }
                }
                return v;
        }
    }
    
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id)
    {
        try
        {
            super.onListItemClick(l, v, position, id);
            Order bkg = (Order)l.getItemAtPosition(position);
            
            Intent toconsulta = new Intent();
            toconsulta.putExtra("idfinal", bkg.getidpatient());
            toconsulta.putExtra("nombreC", bkg.getOrderName());
            setResult(RESULT_OK,toconsulta);
            finish();
        }
        catch(Exception ex)
        {

        }
    }
}
