/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;
/**
 *
 * @author DXM04
 */
public class takedata extends Activity {
    public static final int SELECT_PACIENT = 1;
    private String nombreA;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.takedataview);
       
        Spinner prioridad = (Spinner)this.findViewById(R.id.priorityselect);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.priority_array, android.R.layout.simple_spinner_item);
        prioridad.setAdapter(adapter);
        
        Spinner respiracion =(Spinner)this.findViewById(R.id.respirationselect);
        ArrayAdapter<CharSequence> radapter = ArrayAdapter.createFromResource(this,R.array.respiration_array,android.R.layout.simple_spinner_item);
        respiracion.setAdapter(radapter);
        
        Spinner pulse1 = (Spinner)this.findViewById(R.id.pulselect1);
        ArrayAdapter<CharSequence> p1adapt = ArrayAdapter.createFromResource(this,R.array.pulse_array1,android.R.layout.simple_spinner_item);
        pulse1.setAdapter(p1adapt);
        
        Spinner pulse2 = (Spinner)this.findViewById(R.id.pulselect2);
        ArrayAdapter<CharSequence> p2adapt = ArrayAdapter.createFromResource(this,R.array.pulse_array2,android.R.layout.simple_spinner_item);
        pulse2.setAdapter(p2adapt);
        
        Button guardar = (Button)this.findViewById(R.id.Accept);
        guardar.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                if(saveentry())
                {
                    AlertDialog alertDialog = new AlertDialog.Builder(takedata.this).create();
                    alertDialog.setTitle("Ingreso");
                    alertDialog.setMessage("Registro de paciente completo.");
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                       public void onClick(DialogInterface dialog, int which) {
                          finish();
                       }
                    });
                    alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
                    alertDialog.show();
                }
                else
                {
                    AlertDialog alertDialog = new AlertDialog.Builder(takedata.this).create();
                    alertDialog.setTitle("Ingreso");
                    alertDialog.setMessage("No se ha podido registrar ¿Faltan datos?");
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                       public void onClick(DialogInterface dialog, int which) {
                          return;
                       }
                    });
                    alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
                    alertDialog.show();
                }
            }

            
        });
        
        Button cancela = (Button)this.findViewById(R.id.Cancela);
        cancela.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                finish();
            }
        });
        
        Button busca = (Button)this.findViewById(R.id.SearchDat);
        busca.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
               Intent searchmuthafucka;
               searchmuthafucka = new Intent(takedata.this,SearchPaciente.class);
               startActivityForResult(searchmuthafucka,SELECT_PACIENT);
            }
        });
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        switch(requestCode)
        {
            case SELECT_PACIENT:
                if(resultCode==RESULT_OK){
                    EditText editText = (EditText)findViewById(R.id.PatientSerial);
                    editText.setText(data.getStringExtra("selectedid"));
                    nombreA = data.getStringExtra("nombreB");
                }
            break;
        }
    }
    
    private boolean saveentry() 
    {
        String[] Datos = new String[11];
        String result = "";
        InputStream is=null;
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        
        Datos[0] = ((EditText)findViewById(R.id.PatientSerial)).getText().toString();
        Datos[1] = ((Spinner)findViewById(R.id.priorityselect)).getSelectedItem().toString();
        Datos[2] = ((Spinner)findViewById(R.id.respirationselect)).getSelectedItem().toString();
        Datos[3] = ((EditText)findViewById(R.id.pulse)).getText().toString();
        Datos[4] = ((Spinner)findViewById(R.id.pulselect1)).getSelectedItem().toString();
        Datos[5] = ((Spinner)findViewById(R.id.pulselect2)).getSelectedItem().toString();
        Datos[6] = ((EditText)findViewById(R.id.upper)).getText().toString();
        Datos[7] = ((EditText)findViewById(R.id.lower)).getText().toString();
        Datos[8] = ((EditText)findViewById(R.id.tempe)).getText().toString();
        Datos[9] = ((EditText)findViewById(R.id.actualpada)).getText().toString();
        Datos[10] = ((EditText)findViewById(R.id.medipada)).getText().toString();
        for(int i=0;i<11;i++)
            if(Datos[i].length()<1)
                return false;
        
        nameValuePairs.add(new BasicNameValuePair("idpat",Datos[0]));
        nameValuePairs.add(new BasicNameValuePair("priority",Datos[1]));
        nameValuePairs.add(new BasicNameValuePair("respira",Datos[2]));
        nameValuePairs.add(new BasicNameValuePair("pulso",Datos[3]));
        nameValuePairs.add(new BasicNameValuePair("pulso2",Datos[4]));
        nameValuePairs.add(new BasicNameValuePair("pulso3",Datos[5]));
        nameValuePairs.add(new BasicNameValuePair("upper",Datos[6]));
        nameValuePairs.add(new BasicNameValuePair("lower",Datos[7]));
        nameValuePairs.add(new BasicNameValuePair("tempera",Datos[8]));
        nameValuePairs.add(new BasicNameValuePair("medieva",Datos[9]));
        nameValuePairs.add(new BasicNameValuePair("medicine",Datos[10]));
        nameValuePairs.add(new BasicNameValuePair("nombre",nombreA));
        
        try{
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.1.100:2230/startconsult.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        }
        catch(Exception sexy){
            Log.e("log_tag", "Error in http connection "+sexy.toString());
        }
        
         try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
            }
            is.close();
            result=sb.toString();
            Log.e("log_tag", "Result:"+result);
        }
        catch(Exception sex){
            Log.e("log_tag", "Error converting result "+sex.toString());
        }
 
        //parse json data
        try{
            JSONObject json_data = new JSONObject(result);
            
            if(json_data.getInt("result") == 1)
                return true;
            else return false;
        }
        catch(JSONException sex)
        {
            Log.e("log_tag", "Error parsing data "+sex.toString());
        }
        return false;
    }
}
