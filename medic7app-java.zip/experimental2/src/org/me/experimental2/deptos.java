/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

/**
 *
 * @author DXM04
 */
public class deptos {
    private int id_depto;
    private String nombre;
    private int position;
    
    public void setid(int id)
    {
        this.id_depto=id;
    }
    
    public void setposition(int pos)
    {
        this.position = pos;
    }
    
    public void setnombre(String nom)
    {
        this.nombre = nom;
    }
    
    public int getid()
    {
        return this.id_depto;
    }
    
    public int getposition()
    {
        return this.position;
    }
    
    public String getnombre()
    {
        return this.nombre;
    }
}
