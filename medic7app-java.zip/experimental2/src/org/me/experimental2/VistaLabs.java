/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author DXM04
 */
public class VistaLabs extends ListActivity {
    
    private ProgressDialog m_ProgressDialog = null; 
    private ArrayList<anylistitem> listitem;
    private ItemAdapter m_adapter;
    private Runnable Viewitems;
    private String ID_LAB;
    private String ID_PRO;
    private AlertDialog alertDialog;
    
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        Bundle b = getIntent().getExtras();
        ID_PRO = (String)b.getCharSequence("PROCID");
        ID_LAB = (String)b.getCharSequence("IDLAB");
        setContentView(R.layout.labview);
        listitem = new ArrayList<anylistitem>();
        this.m_adapter = new ItemAdapter(this,R.layout.anyrowitem,listitem);
        setListAdapter(this.m_adapter);
        
        Viewitems = new Runnable(){

            public void run() {
                getItems();
            }
        };
        Thread thread =  new Thread(null, Viewitems, "MagentoBackground");
        thread.start();
        m_ProgressDialog = ProgressDialog.show(VistaLabs.this,    
              "Please wait...", "Retrieving data ...", true);
    }
    
    private class ItemAdapter extends ArrayAdapter<anylistitem> {

        private ArrayList<anylistitem> items;

        public ItemAdapter(Context context, int textViewResourceId, ArrayList<anylistitem> items) {
                super(context, textViewResourceId, items);
                this.items = items;
        }
        
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
                View v = convertView;
                if (v == null) {
                    LayoutInflater vi = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    v = vi.inflate(R.layout.anyrowitem, null);
                }
                final anylistitem o = items.get(position);
                if (o != null) {
                        final CheckBox bx = (CheckBox)v.findViewById(R.id.checkitem);
                        TextView tx = (TextView)v.findViewById(R.id.rowid);
                        
                        if(bx!=null){
                            bx.setText(o.getname());
                            bx.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                        public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                            o.setcheck(bx.isChecked());
                        }
                    });
                        }
                        if(tx!=null){
                            tx.setText(o.getid());
                        }
                }
                return v;
        }
        
        @Override
        public int getCount() {
            return items.size();
        }
        
        public int ischeckedit(int pos)
        {
            anylistitem u = items.get(pos);
            if(u!=null){
                if(u.ischecked())
                    return Integer.parseInt(u.getid());
                else return -1;
            }
            else return -1;
        }
    }
    private Runnable returnRes = new Runnable() {

        @Override
        public void run() {
            if(listitem != null && listitem.size() > 0){
                m_adapter.notifyDataSetChanged();
                for(int i=0;i<listitem.size();i++)
                m_adapter.add(listitem.get(i));
            }
            m_ProgressDialog.dismiss();
            m_adapter.notifyDataSetChanged();
        }
    };
    
    private void getItems()
    {
        String result = "";
        InputStream is=null;
        int partial;
        String party;
        
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("id_parent",ID_LAB));
        
        try{
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.1.100:2230/retrievelabitems.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        }
        catch(Exception sex){
            Log.e("log_tag", "Error in http connection "+sex.toString());
        }
        //convert response to string
        try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
            }
            is.close();
            result=sb.toString();
            Log.e("log_tag", "Result:"+result);
        }
        catch(Exception sex){
            Log.e("log_tag", "Error converting result "+sex.toString());
        }
 
//parse json data
        try{
            listitem = new ArrayList<anylistitem>();
            JSONArray jArray = new JSONArray(result);
            for(int i=0;i<jArray.length();i++)
            {
                JSONObject json_data = jArray.getJSONObject(i);
                anylistitem item = new anylistitem();
                item.setname(json_data.getString("nombre_item"));
                partial = json_data.getInt("id_item");
                party =partial+"";
                item.setid(party);
                listitem.add(item);
            }
            
        }
        catch(JSONException sex)
        {
            Log.e("log_tag", "Error parsing data "+sex.toString());
        }
        runOnUiThread(returnRes);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Alternativa 1
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menusolicitud, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem menuitem)
    {         
        switch(menuitem.getItemId())
        {
            case R.id.solicit:
                requestlabs();
            return true;
            case R.id.cancelaop:
                this.finish();
            break;
        } 
        return false;
    }
    
    private void requestlabs() {
        int j = m_adapter.getCount();
        int k = 0;
        InputStream is=null;
        String result = null;
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        
        for(int i=0; i<j;i++)
        {
            if(m_adapter.ischeckedit(i)!=-1)
            {        
                nameValuePairs.add(new BasicNameValuePair("req"+k, String.valueOf(m_adapter.ischeckedit(i))));
                k++;
            }
            nameValuePairs.add(new BasicNameValuePair("total",String.valueOf(k)));
            nameValuePairs.add(new BasicNameValuePair("idpro",ID_PRO));
            nameValuePairs.add(new BasicNameValuePair("idlab",ID_LAB));
        }
        if(k>0)
        {
            try{
            
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://192.168.1.100:2230/savelabs.php");
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse response = httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();
            }
            catch(Exception sexy){
                Log.e("log_tag", "Error in http connection "+sexy.toString());
            }
        
            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                }
                is.close();
                result=sb.toString();
                Log.e("log_tag", "Result:"+result);
            }
            catch(Exception sex){
                Log.e("log_tag", "Error converting result "+sex.toString());
            }
            //parse json data
            try{
                JSONObject json_data = new JSONObject(result);

                if(json_data.getInt("result") == 1)
                {
                    choudialog("Laboratorios","Se han solicitado");
                        this.finish();
                }
                else choudialog("Laboratorios","No se han  podido solicitar. Reintenta");
                
            }
            catch(JSONException sex)
            {
                Log.e("log_tag", "Error parsing data "+sex.toString());
            }
            return;
        }
        else choudialog("Laboratorios","No hay laboratorios seleccionados");
        return;
    }
    
    private void choudialog(String title, String message)
    {
        alertDialog = new AlertDialog.Builder(this).create();  
        alertDialog.setTitle(title);  
        alertDialog.setMessage(message);  
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {  
        public void onClick(DialogInterface dialog, int which) {  
            return;  
          } 
        });  
        
        alertDialog.show(); 
    }
    
}
