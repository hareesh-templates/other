/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author DXM04
 */
public class solicitConsult extends Activity {
    private Spinner mySpin;
    String ID_PRO;
    String ID_DEP;
    ArrayList<deptos> Deptos;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        Bundle b = getIntent().getExtras();
        ID_PRO = (String)b.getCharSequence("PROCID");
        ArrayAdapter <CharSequence> adapter = new ArrayAdapter <CharSequence> (this, android.R.layout.simple_spinner_item );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Deptos = new ArrayList<deptos>();
        setContentView(R.layout.solicitconsulta);
        mySpin =(Spinner)findViewById(R.id.especialidadselect);
        
        getitems();
        if(Deptos.size()>0)
        {
            for(int i=0;i<Deptos.size();i++)
                adapter.add(Deptos.get(i).getnombre().toString());
        }
        else this.finish();
        mySpin.setPrompt("Especialidades");
        mySpin.setAdapter(adapter);
        mySpin.setOnItemSelectedListener(new OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                ID_DEP = String.valueOf(Deptos.get(arg2).getid());
                return;
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                ID_DEP="";
            }
        });
        
        Button acceptS = (Button)findViewById(R.id.Acceptsol);
        acceptS.setOnClickListener(new OnClickListener() {

            public void onClick(View arg0) {
                if(!"".equals(ID_DEP))
                    if(savesolicit())
                    {
                        AlertDialog alertDialog = new AlertDialog.Builder(solicitConsult.this).create();
                        alertDialog.setTitle("Interconsulta");
                        alertDialog.setMessage("Se ha solicitado la consulta.");
                        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                           public void onClick(DialogInterface dialog, int which) {
                              finish();
                           }
                        });
                        alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
                        alertDialog.show();
                    }
                    else
                    {
                        AlertDialog alertDialog = new AlertDialog.Builder(solicitConsult.this).create();
                        alertDialog.setTitle("Interconsulta");
                        alertDialog.setMessage("No se ha podido solicitar.");
                        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                           public void onClick(DialogInterface dialog, int which) {
                               return;
                           }
                        });
                        alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
                        alertDialog.show();
                    }
            }
        });
        
        Button cancelS = (Button)findViewById(R.id.Cancelasol);
        cancelS.setOnClickListener(new OnClickListener() {

            public void onClick(View arg0) {
                finish();
            }
        });
    }
    
    private boolean savesolicit() {
        boolean ret = false;
        String result = null;
        InputStream is=null;
        EditText mytext = (EditText)findViewById(R.id.solicittext);
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("idpro",ID_PRO));
        nameValuePairs.add(new BasicNameValuePair("iddepto",ID_DEP));
        nameValuePairs.add(new BasicNameValuePair("consulta",mytext.getText().toString()));
        
        try{

            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.1.100:2230/savesolicit.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        }
        catch(Exception sexy){
            Log.e("log_tag", "Error in http connection "+sexy.toString());
        }

        try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
            }
            is.close();
            result=sb.toString();
            Log.e("log_tag", "Result:"+result);
        }
        catch(Exception sex){
            Log.e("log_tag", "Error converting result "+sex.toString());
        }
        //parse json data
        try{
            JSONObject json_data = new JSONObject(result);

            if(json_data.getInt("result") == 1)
            {
                ret=true;
            }
            else ret=false;

        }
        catch(JSONException sex)
        {
            Log.e("log_tag", "Error parsing data "+sex.toString());
        }
        return ret;
    }
    
    private void getitems()
    {
        String result = "";
        InputStream is=null;
        
        try{
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.1.100:2230/retrievedeptos.php");
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        }
        catch(Exception sex){
            Log.e("log_tag", "Error in http connection "+sex.toString());
        }
        //convert response to string
        try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
            }
            is.close();
            result=sb.toString();
            Log.e("log_tag", "Result:"+result);
        }
        catch(Exception sex){
            Log.e("log_tag", "Error converting result "+sex.toString());
        }
 
//parse json data
        try{
            JSONArray jArray = new JSONArray(result);
            for(int i=0;i<jArray.length();i++)
            {
                JSONObject json_data = jArray.getJSONObject(i);
                deptos mydept = new deptos();
                mydept.setid(json_data.getInt("id_depto"));
                mydept.setnombre(json_data.getString("nombre_depto"));
                mydept.setposition(i);
                Deptos.add(mydept);
            }
        }
        catch(JSONException sex)
        {
            Log.e("log_tag", "Error parsing data "+sex.toString());
        }
    }
}
