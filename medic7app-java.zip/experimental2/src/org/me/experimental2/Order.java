/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

/**
 *
 * @author DXM04
 */
public class Order {
    private String orderName;
    private String orderStatus;
    private String patientid;
    
    public String getOrderName() {
        return orderName;
    }
    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }
    public String getOrderStatus() {
        return orderStatus;
    }
    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
    public void setidpatient(String dipat)
    {
        this.patientid=dipat;
    }
    public String getidpatient()
    {
        return patientid;
    }
}
