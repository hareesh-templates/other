/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.experimental2;

/**
 *
 * @author DXM04
 */
public class anylistitem {
    private String ID_item;
    private String nombre_item;
    private String extra_data_item;
    private boolean check;
    
    public void setcheck(boolean value)
    {
        this.check = value;
    }
    public boolean ischecked()
    {
        return this.check;
    }
    
    public void setid(String id)
    {
        this.ID_item = id;
    }
    
    public void setname(String name)
    {
        this.nombre_item = name;
    }
    
    public void set_extras(String extras)
    {
        this.extra_data_item = extras;
    }
    
    public String getid()
    {
        return this.ID_item;
    }
    
    public String getname()
    {
        return this.nombre_item;
    }
    
    public String getextradata()
    {
        return this.extra_data_item;
    }
}
