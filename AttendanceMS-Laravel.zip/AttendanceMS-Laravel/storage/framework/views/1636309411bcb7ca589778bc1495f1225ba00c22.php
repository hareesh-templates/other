<footer class="footer">
     ©  <?php echo e(date('Y')); ?> Simple Attendance Management System <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Ali Aqa Atayee</span>.
</footer><?php /**PATH D:\XAMPP\htdocs\AttendanceMS-Laravel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>