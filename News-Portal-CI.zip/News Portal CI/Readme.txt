How to run News Portal using CodeIgniter

Download the zip file
Extract the file and copy news folder
Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
Open PHPMyAdmin (http://localhost/phpmyadmin)
Create a database with name news
Import news.sql file(given inside the zip package in SQL file folder)
Run the script http://localhost/news (frontend)
Admin Credential
Username: admin@gmail.com
Password: Test@123